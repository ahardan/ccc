package gov.sec.cll.model.base;


import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.ADFContext;

import oracle.jbo.server.EntityImpl;
import oracle.jbo.server.TransactionEvent;

public class BaseEntityImpl  extends EntityImpl{
    
    private static ADFLogger logger = ADFLogger.createADFLogger(BaseEntityImpl.class);
    
    public BaseEntityImpl() {
        super();
    }

    @Override
    protected void doDML(int i, TransactionEvent transactionEvent) {
        
        //Get current Logged User 
        ADFContext adfc = ADFContext.getCurrent();
        String username = adfc.getSecurityContext().getUserName();
        logger.info("Current Logged User inside CLL application BaseEntityImpl  ******* " + username);
        
        if (i == DML_INSERT){
            setAttribute("CreatedBy", username);
        }
        if (i == DML_UPDATE){
            setAttribute("UpdatedBy", username);
        }
        logger.info("User name inside base entity class of CLL  is " + username);
        super.doDML(i, transactionEvent);
    }
}
