package gov.sec.cll.model.adfbc.services;

import gov.sec.cll.model.adfbc.services.common.CommentLogAppModule;
import gov.sec.cll.model.adfbc.views.AttachmentROViewImpl;
import gov.sec.cll.model.adfbc.views.CheckDupFileNumberROViewImpl;
import gov.sec.cll.model.adfbc.views.CheckDupFileNumberROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllApplicationPropertiesViewImpl;
import gov.sec.cll.model.adfbc.views.CllCommentDetailsDetagViewImpl;
import gov.sec.cll.model.adfbc.views.CllCommentDetailsViewImpl;
import gov.sec.cll.model.adfbc.views.CllCommentDetailsViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllCommentsListROViewImpl;
import gov.sec.cll.model.adfbc.views.CllCommentsListROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllDeletedCommentsListROViewImpl;
import gov.sec.cll.model.adfbc.views.CllDispositionTypeROViewImpl;
import gov.sec.cll.model.adfbc.views.CllDispositionTypeROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllDispositionTypeViewImpl;
import gov.sec.cll.model.adfbc.views.CllFileNumPubCommListROViewImpl;
import gov.sec.cll.model.adfbc.views.CllFileNumPubCommListROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFileNumberViewImpl;
import gov.sec.cll.model.adfbc.views.CllFileNumberViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumAttyViewImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumAttyViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumCommDetBulkActionViewImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumCommDetROViewImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumCommDetViewImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumProcessingViewImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumRelFrViewImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumRelFrViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumberCommDetailsViewImpl;
import gov.sec.cll.model.adfbc.views.CllFormLetterListPRViewImpl;
import gov.sec.cll.model.adfbc.views.CllFormLetterListPRViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFormLetterListROViewImpl;
import gov.sec.cll.model.adfbc.views.CllFormLetterSubTypeROViewImpl;
import gov.sec.cll.model.adfbc.views.CllFormLetterSubTypeROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFormLetterTextROViewImpl;
import gov.sec.cll.model.adfbc.views.CllFormLetterViewImpl;
import gov.sec.cll.model.adfbc.views.CllFormLetterViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllInternalToSecQueueCommentsListROViewImpl;
import gov.sec.cll.model.adfbc.views.CllMissingFileNumberCommentsListROViewImpl;
import gov.sec.cll.model.adfbc.views.CllOrigInCommentROViewImpl;
import gov.sec.cll.model.adfbc.views.CllParentCommDetailsROViewImpl;
import gov.sec.cll.model.adfbc.views.CllStatusPRViewImpl;
import gov.sec.cll.model.adfbc.views.CllStatusPRViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllStatusTypePRViewImpl;
import gov.sec.cll.model.adfbc.views.CllStatusTypeROViewImpl;
import gov.sec.cll.model.adfbc.views.CllStatusTypeROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllStatusTypeViewImpl;
import gov.sec.cll.model.adfbc.views.CllTypeROViewImpl;
import gov.sec.cll.model.adfbc.views.CllTypeViewImpl;
import gov.sec.cll.model.adfbc.views.CommentDetailsPublishingROViewImpl;
import gov.sec.cll.model.adfbc.views.CommentInboxQueuesROViewImpl;
import gov.sec.cll.model.adfbc.views.DocumentTypeViewImpl;
import gov.sec.cll.model.adfbc.views.FileNumCommDetSeqNumROViewImpl;
import gov.sec.cll.model.adfbc.views.FileNumberPubQueueROViewImpl;
import gov.sec.cll.model.adfbc.views.FileNumberQueueROViewImpl;
import gov.sec.cll.model.adfbc.views.FileNumberType1ViewImpl;
import gov.sec.cll.model.adfbc.views.FileNumberTypeROViewImpl;
import gov.sec.cll.model.adfbc.views.FileNumberTypeROViewRowImpl;
import gov.sec.cll.model.adfbc.views.FileNumberTypeViewImpl;
import gov.sec.cll.model.adfbc.views.FileNumbersForCommentDetROViewImpl;
import gov.sec.cll.model.adfbc.views.FormLetterCountROViewImpl;
import gov.sec.cll.model.adfbc.views.FormLetterTypesCountROViewImpl;
import gov.sec.cll.model.adfbc.views.FormLetterUnPubCountROViewImpl;
import gov.sec.cll.model.adfbc.views.SearchCommentsPRViewImpl;
import gov.sec.cll.model.adfbc.views.SearchCommentsPRViewRowImpl;
import gov.sec.cll.model.adfbc.views.SearchCommentsROViewImpl;
import gov.sec.cll.model.adfbc.views.SearchFileNumbersPRViewImpl;
import gov.sec.cll.model.adfbc.views.SearchFileNumbersPRViewRowImpl;
import gov.sec.cll.model.adfbc.views.SearchFileNumbersROViewImpl;
import gov.sec.cll.model.adfbc.views.StaffRolesROViewImpl;
import gov.sec.cll.model.adfbc.views.StaffViewImpl;
import gov.sec.cll.model.adfbc.views.StaffViewRowImpl;

import gov.sec.cll.model.adfbc.views.TemplateViewImpl;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowSet;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewObject;
import oracle.jbo.domain.Date;
import oracle.jbo.domain.Number;
import oracle.jbo.server.ApplicationModuleImpl;
import oracle.jbo.server.EntityImpl;
import oracle.jbo.server.ViewLinkImpl;
import oracle.jbo.server.ViewObjectImpl;

import org.apache.commons.lang.StringUtils;
// ---------------------------------------------------------------------
// ---    File generated by Oracle ADF Business Components Design Time.
// ---    Mon Nov 09 22:12:14 EST 2015
// ---    Custom code may be added to this class.
// ---    Warning: Do not modify method signatures of generated methods.
// ---------------------------------------------------------------------
public class CommentLogAppModuleImpl extends ApplicationModuleImpl implements CommentLogAppModule {
    /**
     * This is the default constructor (do not remove).
     */
    public CommentLogAppModuleImpl() {
    }

    private static ADFLogger logger = ADFLogger.createADFLogger(CommentLogAppModuleImpl.class);

    private static final QName CLL_FORM_SERVICE =
        new QName("/gov/sec/cll/cllservices/model/services/common/", "CllServices");

    /**
     * Container's getter for StaffView1.
     * @return StaffView1
     */
    public StaffViewImpl getStaffView1() {
        return (StaffViewImpl) findViewObject("StaffView1");
    }

    /**
     * Container's getter for StaffRolesROView1.
     * @return StaffRolesROView1
     */
    public ViewObjectImpl getStaffRolesROView1() {
        return (ViewObjectImpl) findViewObject("StaffRolesROView1");
    }

    /**
     * Retrieve a comment detail, and set the row as current
     *
     * @param commentDetId
     */
    public void retrieveCommentDetaisbyId(Number commentDetId) {
        logger.info("CommentLogAppModuelImpl.retrieveCommentDetailsById :: commentDetid : " + commentDetId);
        CllCommentDetailsViewImpl commentVO = getCllCommentDetailsView1();
        commentVO.setpCommentDetId(commentDetId);
        commentVO.setApplyViewCriteriaName("CllCommentDetailsByCommentDetId");
        commentVO.executeQuery();
        CllCommentDetailsViewRowImpl commentRow = (CllCommentDetailsViewRowImpl) commentVO.first();
        if (null != commentRow) {
            commentVO.setCurrentRow(commentRow);
        }
    }

    /**
     * Update Comment's forwarded info to a particular comment detail id
     *
     * @param commentDetId
     * @param fwdTo
     */
    public void updateCommentForwardInfo(Number commentDetId, String fwdTo) {
        CllCommentDetailsViewImpl commentVO = getCllCommentDetailsView1();
        retrieveCommentDetaisbyId(commentDetId);
        CllCommentDetailsViewRowImpl row = (CllCommentDetailsViewRowImpl) commentVO.getCurrentRow();
        if (null != row) {
            row.setForwardedTo(fwdTo);
            oracle.jbo.domain.Date jboCurrentDate =
                new oracle.jbo.domain.Date(new Timestamp(System.currentTimeMillis()));
            row.setForwardDate(jboCurrentDate);
            commitTransaction();
        }
    }

    /** Retrieves staff record for the given user name
     *
     * @param userName
     * @return  matching staff record
     */
    public Map getStaffDetailsByUserName(String userName) {
        logger.info("Starting getStaffDetailsByUserName  ***************");
        ViewObjectImpl staffVO = this.getStaffView1();
        ViewCriteria vc = staffVO.getViewCriteria("StaffViewByUserName");
        staffVO.setNamedWhereClauseParam("pUserName", userName);
        staffVO.applyViewCriteria(vc);
        staffVO.executeQuery();
        Map<String, Object> staffInfo = new HashMap<String, Object>();
        if (staffVO.getEstimatedRowCount() > 0) {
            logger.finest(" ************Nmber of rows  fetched for Staff." + staffVO.getEstimatedRowCount());
            StaffViewRowImpl staffRecord = (StaffViewRowImpl) staffVO.first();
            logger.info("User  First Name, Last Name  ***************" + staffRecord.getFirstName() + "   " +
                        staffRecord.getLastName());
            staffInfo.put("firstName", (String) staffRecord.getFirstName());
            staffInfo.put("lastName", (String) staffRecord.getLastName());
            staffInfo.put("middleName", (String) staffRecord.getMiddleName());
            staffInfo.put("staffId", staffRecord.getStaffId().getSequenceNumber());
            logger.info("Ending getStaffDetailsByUserName  ***************");
        }
        return staffInfo;
    }

    /**
     * Retrieves status id by status code
     *
     * @param code  Status code
     * @return  Status Id
     */
    public Number getStatus(String code) {
        Number statusId = null;
        CllStatusTypeROViewImpl statusView = this.getCllStatusTypeROView1();
        RowSetIterator statusViewIter = statusView.createRowSetIterator(null);
        statusViewIter.reset();
        while (statusViewIter.hasNext()) {
            CllStatusTypeROViewRowImpl statusViewRow = (CllStatusTypeROViewRowImpl) statusViewIter.next();
            if (statusViewRow.getCode().equals(code)) {
                statusId = statusViewRow.getCllStatusTypeId();
            }
        }
        statusViewIter.closeRowSetIterator();
        return statusId;
    }


    /**
     * Container's getter for FileNumberQueueROView1.
     * @return FileNumberQueueROView1
     */
    public ViewObjectImpl getFileNumberQueueROView1() {
        return (ViewObjectImpl) findViewObject("FileNumberQueueROView1");
    }

    /**
     * Container's getter for CllDispositionTypeROView1.
     * @return CllDispositionTypeROView1
     */
    public CllDispositionTypeROViewImpl getCllDispositionTypeROView1() {
        return (CllDispositionTypeROViewImpl) findViewObject("CllDispositionTypeROView1");
    }

    /**
     * Container's getter for CllCommentsListROView1.
     * @return CllCommentsListROView1
     */
    public CllCommentsListROViewImpl getCllCommentsListROView1() {
        return (CllCommentsListROViewImpl) findViewObject("CllCommentsListROView1");
    }

    /**
     * Container's getter for CllStatusPRView1.
     * @return CllStatusPRView1
     */
    public CllStatusPRViewImpl getCllStatusPRView1() {
        return (CllStatusPRViewImpl) findViewObject("CllStatusPRView1");
    }

    public boolean commitTransaction() {
        boolean rtn = false;
        try {
            this.getDBTransaction().commit();
            rtn = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rtn;
    }

    public void postTransaction() {
        this.getDBTransaction().postChanges();
    }

    public Row createRow(String paramVOName) {
        ViewObject paramVo = this.findViewObject(paramVOName);
        Row row = null;
        if (paramVo != null) {
            if (paramVo.first() != null) {
                row = paramVo.first();
            } else {
                Row r = paramVo.createRow();
                paramVo.insertRow(r);
                paramVo.setCurrentRow(r);
                row = r;
            }
        }
        return row;
    }

    public void initCommentsList(oracle.jbo.domain.Number filerNumId, String typeCode, String DispCode) {
        if (null == typeCode || "CL".equals(typeCode)) {
            Number typeId = null;
            CllStatusPRViewRowImpl statusRow = (CllStatusPRViewRowImpl) this.createRow("CllStatusPRView1");
            if (null == typeCode || "CL".equals(typeCode)) {
                typeCode = "FL";
            }
            RowSetIterator rSetIter =
                statusRow.getCommentLogCommonAppModule_CllTypeROView1_1().createRowSetIterator(null);
            rSetIter.reset();
            while (rSetIter.hasNext()) {
                Row r = rSetIter.next();
                if (r.getAttribute("Code").equals(typeCode)) {
                    typeId = (Number) r.getAttribute("CllTypeId");
                }
            }
            rSetIter.closeRowSetIterator();
            CllCommentsListROViewImpl cmntsList = this.getCllCommentsListROView1();
            if (null == DispCode || "".equals(DispCode)) {
                cmntsList.setApplyViewCriteriaName("findByCommentsCriteria", false);
            } else {
                cmntsList.setApplyViewCriteriaName("findByProcessedCommentsCriteria", false);
            }
            cmntsList.setNamedWhereClauseParam("bindFileNum", filerNumId);
            cmntsList.setNamedWhereClauseParam("bindType", typeId);
            cmntsList.setOrderByClause("SEC_RECEIVED_DATE desc");
            cmntsList.executeQuery();
            logger.finer("Comment List Query : " + cmntsList.getQuery());
        }
    }

    public String setActiontoComment(String action) {
        String rtn = null;
        Map staffInfo = this.getStaffDetailsByUserName(ADFContext.getCurrent()
                                                                 .getSecurityContext()
                                                                 .getUserName());
        oracle.jbo.domain.Number staffId = (Number) staffInfo.get("staffId"); //new oracle.jbo.domain.Number(1);
        CllCommentsListROViewImpl cmntsList = this.getCllCommentsListROView1();
        if (null == staffId) {
            rtn = "User Not Found";
        } else {
            rtn = "User Found";
            RowSetIterator cmntsListIter = cmntsList.createRowSetIterator(null);
            cmntsListIter.reset();
            while (cmntsListIter.hasNext()) {
                CllCommentsListROViewRowImpl cmntsListRow = (CllCommentsListROViewRowImpl) cmntsListIter.next();
                if (null != cmntsListRow.getSelectAttr() && cmntsListRow.getSelectAttr()) {
                    CllCommentDetailsViewImpl cmntDetailsView = this.getCllCommentDetailsView2();
                    Key commntIdKey = new Key(new Object[] { cmntsListRow.getCllCommDetId() });
                    Row[] commntrows = cmntDetailsView.findByKey(commntIdKey, 1);
                    if (commntrows.length > 0) {
                        CllCommentDetailsViewRowImpl commntRow = (CllCommentDetailsViewRowImpl) commntrows[0];
                        if ("ASSIGN".equals(action)) {
                            commntRow.setAssigned(staffId);
                            commntRow.setAssignedDate(new oracle.jbo.domain.Date(new Timestamp(System.currentTimeMillis())));
                        }
                    }
                }
            }
            cmntsListIter.closeRowSetIterator();
        }
        this.getDBTransaction().commit();
        return rtn;
    }

    public String setArchive() {
        logger.info("Running binding operation setArchive");
        String rtn = "";
        CllCommentsListROViewImpl cmntsList = this.getCllCommentsListROView1();
        if (cmntsList == null) {
            logger.info("CllCommentListRoVO is null");
        }
        RowSetIterator cmntsListIter = cmntsList.createRowSetIterator(null);
        cmntsListIter.reset();
        while (cmntsListIter.hasNext()) {
            CllCommentsListROViewRowImpl cmntsListRow = (CllCommentsListROViewRowImpl) cmntsListIter.next();

            if (null != cmntsListRow.getSelectAttr() && cmntsListRow.getSelectAttr()) {
                CllCommentDetailsViewImpl cmntDetailsView = this.getCllCommentDetailsView2();
                logger.info("Selected comment row with commId = " + cmntsListRow.getCllCommDetId());
                Key commntIdKey = new Key(new Object[] { cmntsListRow.getCllCommDetId() });
                Row[] commntrows = cmntDetailsView.findByKey(commntIdKey, 1);
                if (commntrows.length > 0) {
                    CllCommentDetailsViewRowImpl commntRow = (CllCommentDetailsViewRowImpl) commntrows[0];
                    commntRow.setArchived("Y");
                }
                this.getDBTransaction().commit();
                logger.info("Row archived = ");
            }
        }
        cmntsListIter.closeRowSetIterator();
        rtn = "Archived successfully";
        return rtn;
    }


    public String assignComment(String action) {
        String rtn = null;
        Map staffInfo = this.getStaffDetailsByUserName(ADFContext.getCurrent()
                                                                 .getSecurityContext()
                                                                 .getUserName());

        oracle.jbo.domain.Number staffId = (Number) staffInfo.get("staffId"); //new oracle.jbo.domain.Number(1);
        CllCommentsListROViewImpl cmntsList = this.getCllCommentsListROView1();
        if (null == staffId) {
            rtn = "User Not Found";
        } else {
            rtn = "User Found";
            RowSetIterator cmntsListIter = cmntsList.createRowSetIterator(null);
            cmntsListIter.reset();
            while (cmntsListIter.hasNext()) {
                CllCommentsListROViewRowImpl cmntsListRow = (CllCommentsListROViewRowImpl) cmntsListIter.next();
                if (null != cmntsListRow.getSelectAttr() && cmntsListRow.getSelectAttr()) {
                    CllCommentDetailsViewImpl cmntDetailsView = this.getCllCommentDetailsView2();
                    Key commntIdKey = new Key(new Object[] { cmntsListRow.getCllCommDetId() });
                    Row[] commntrows = cmntDetailsView.findByKey(commntIdKey, 1);
                    if (commntrows.length > 0) {
                        CllCommentDetailsViewRowImpl commntRow = (CllCommentDetailsViewRowImpl) commntrows[0];
                        if ("ASSIGN".equals(action)) {
                            commntRow.setAssigned(staffId);
                            commntRow.setAssignedDate(new oracle.jbo.domain.Date(new Timestamp(System.currentTimeMillis())));
                        }
                    }
                }
            }
            cmntsListIter.closeRowSetIterator();
            this.getDBTransaction().commit();
        }
        return rtn;
    }

    public void initFormLetterList(oracle.jbo.domain.Number filerNumId, String typeCode, String DispCode) {
        logger.info("CommentLogAppModuleImpl.initFormLetterList :: Param : filerNumId = " + filerNumId);
        logger.info("CommentLogAppModuleImpl.initFormLetterList :: Param : typeCode = " + typeCode);
        logger.info("CommentLogAppModuleImpl.initFormLetterList :: Param : DispCode = " + DispCode);
        if ("FL".equals(typeCode)) {
            Number typeId = null;
            Number FrmLtrId = null;
            String FormLtrSubType = null;
            typeCode = "FL";
            CllStatusPRViewRowImpl statusRow = (CllStatusPRViewRowImpl) this.createRow("CllStatusPRView1");
            CllFormLetterViewImpl formLetterSubTP = (CllFormLetterViewImpl) this.getCllFormLetterView1();
            formLetterSubTP.setApplyViewCriteriaName("findByFileNumber", false);
            formLetterSubTP.setNamedWhereClauseParam("bindFileNumId", filerNumId.bigDecimalValue());
            formLetterSubTP.executeQuery();
            CllFormLetterViewRowImpl formLetterSubTPRow = (CllFormLetterViewRowImpl) formLetterSubTP.first();
            if (null != formLetterSubTPRow) {
                FrmLtrId = formLetterSubTPRow.getCllFormLetterId().getSequenceNumber();
                FormLtrSubType = formLetterSubTPRow.getSubType();
            }
            RowSetIterator rSetIter =
                statusRow.getCommentLogCommonAppModule_CllTypeROView1_1().createRowSetIterator(null);
            rSetIter.reset();
            while (rSetIter.hasNext()) {
                Row r = rSetIter.next();
                if (r.getAttribute("Code").equals(typeCode)) {
                    typeId = (Number) r.getAttribute("CllTypeId");
                    break;
                }
            }
            rSetIter.closeRowSetIterator();
            CllCommentsListROViewImpl cmntsList = this.getCllCommentsListROView1();
            if (null == DispCode || "".equals(DispCode)) {
                cmntsList.setApplyViewCriteriaName("findByFormLetterCriteria", false);
            } else {
                cmntsList.setApplyViewCriteriaName("findByProcessedFormLetterCriteria", false);
            }
            cmntsList.setNamedWhereClauseParam("bindFileNum", filerNumId);
            cmntsList.setNamedWhereClauseParam("bindType", typeId);
            if (null != FrmLtrId) {
                cmntsList.setNamedWhereClauseParam("bindFormLtrId", FrmLtrId);
            }
            cmntsList.setOrderByClause("SEC_RECEIVED_DATE desc");
            cmntsList.executeQuery();

            CllFormLetterListROViewImpl formList = this.getCllFormLetterListROView1();
            formList.setbindFileNum(filerNumId);
            formList.setbindType(typeId);
            if (null != DispCode) {
                formList.setbindDispCode("APPR");
            } else {
                formList.setbindDispCode(null);
            }
            formList.executeQuery();
            CllFormLetterViewImpl formLetter = (CllFormLetterViewImpl) this.getCllFormLetterView1();
            formLetter.setApplyViewCriteriaName("findByFileNumber", false);
            formLetter.setNamedWhereClauseParam("bindFileNumId", filerNumId.bigDecimalValue());
            formLetter.executeQuery();
            this.fetchFormLtrText(filerNumId.intValue(), FormLtrSubType);
            // CASSECDEV-6118, CASSECDEV-6463, CASSECDEV-6475, CASSECDEV-6476 : Changes for File Number Publishing of Form Letter.
            FormLetterTypesCountROViewImpl typesCountView = this.getFormLetterTypesCountROView1();
            typesCountView.setApplyViewCriteriaName("findByFileNumberIdVC");
            typesCountView.setNamedWhereClauseParam("bindFileNumId", filerNumId);
            typesCountView.executeQuery();
        }
    }

    public void executeFormLetterListByType(oracle.jbo.domain.Number filerNumId, String DispCode, Number FrmLtrId) {
        Number typeId = null;
        CllStatusPRViewImpl statusView = this.getCllStatusPRView1();
        CllStatusPRViewRowImpl statusViewRow = (CllStatusPRViewRowImpl) statusView.getCurrentRow();
        if (null != statusViewRow) {
            RowSetIterator rSetIter =
                statusViewRow.getCommentLogCommonAppModule_CllTypeROView1_1().createRowSetIterator(null);
            rSetIter.reset();
            while (rSetIter.hasNext()) {
                Row r = rSetIter.next();
                if (r.getAttribute("Code").equals("FL")) {
                    typeId = (Number) r.getAttribute("CllTypeId");
                    break;
                }
            }
            rSetIter.closeRowSetIterator();
        }
        CllCommentsListROViewImpl cmntsList = this.getCllCommentsListROView1();
        if (null == DispCode || "".equals(DispCode)) {
            cmntsList.setApplyViewCriteriaName("findByFormLetterCriteria", false);
        } else {
            cmntsList.setApplyViewCriteriaName("findByProcessedFormLetterCriteria", false);
        }
        cmntsList.setNamedWhereClauseParam("bindFileNum", filerNumId);
        cmntsList.setNamedWhereClauseParam("bindType", typeId);
        if (null != FrmLtrId) {
            cmntsList.setNamedWhereClauseParam("bindFormLtrId", FrmLtrId);
        }
        cmntsList.setOrderByClause("SEC_RECEIVED_DATE desc");
        cmntsList.executeQuery();

        CllFormLetterListROViewImpl formList = this.getCllFormLetterListROView1();
        formList.setbindFileNum(filerNumId);
        formList.setbindType(typeId);
        if (null != DispCode) {
            formList.setbindDispCode("APPR");
        } else {
            formList.setbindDispCode(null);
        }
        formList.executeQuery();

        CllFormLetterViewImpl formLtr = (CllFormLetterViewImpl) this.getCllFormLetterView1();
        Key FrmLtrIdKey = new Key(new Object[] { FrmLtrId });
        Row[] frmLtrrows = formLtr.findByKey(FrmLtrIdKey, 1);
        if (frmLtrrows.length > 0) {
            CllFormLetterViewRowImpl frmLtrRow = (CllFormLetterViewRowImpl) frmLtrrows[0];
            formLtr.setCurrentRow(frmLtrRow);
        }
    }

    public void executeFormLetterListBySubType(oracle.jbo.domain.Number filerNumId, Integer index, String typeCode,
                                               String subType) {
        Number typeId = null;
        Number dispId = null;
        Row row = null;
        String Code = null;
        CllStatusPRViewImpl statusView = this.getCllStatusPRView1();
        CllStatusPRViewRowImpl statusViewRow = (CllStatusPRViewRowImpl) statusView.getCurrentRow();
        if (index != 0) {
            row = statusViewRow.getCllStatusSLView1().getRowAtRangeIndex(index - 1);
            Code = (String) row.getAttribute("Code");
        }
        RowSetIterator rSetIter =
            statusViewRow.getCommentLogCommonAppModule_CllTypeROView1_1().createRowSetIterator(null);
        rSetIter.reset();
        while (rSetIter.hasNext()) {
            Row r = rSetIter.next();
            if (r.getAttribute("Code").equals(typeCode)) {
                typeId = (Number) r.getAttribute("CllTypeId");
            }
        }
        rSetIter.closeRowSetIterator();
        CllFormLetterListROViewImpl formList = this.getCllFormLetterListROView1();
        formList.setbindFileNum(filerNumId);
        formList.setbindType(typeId);
        if (null == subType) {
            CllFormLetterSubTypeROViewImpl formLetterSubTP = this.getCllFormLetterSubTypeROView1();
            CllFormLetterSubTypeROViewRowImpl formLetterSubTPRow =
                (CllFormLetterSubTypeROViewRowImpl) formLetterSubTP.first();
            if (null != formLetterSubTPRow) {
                subType = formLetterSubTPRow.getSubType();
            }
        }
        formList.executeQuery();
    }

    public String setActiontoFormLetter(String action) {
        String rtn = null;
        Map staffInfo = this.getStaffDetailsByUserName(ADFContext.getCurrent()
                                                                 .getSecurityContext()
                                                                 .getUserName());
        oracle.jbo.domain.Number staffId = (Number) staffInfo.get("staffId"); //new oracle.jbo.domain.Number(1);
        CllCommentsListROViewImpl cmntsList = this.getCllCommentsListROView1();
        if (null == staffId) {
            rtn = "User Not Found";
        } else {
            rtn = "User Found";
            RowSetIterator cmntsListIter = cmntsList.createRowSetIterator(null);
            cmntsListIter.reset();
            while (cmntsListIter.hasNext()) {
                CllCommentsListROViewRowImpl cmntsListRow = (CllCommentsListROViewRowImpl) cmntsListIter.next();
                if (null != cmntsListRow.getSelectAttr() && cmntsListRow.getSelectAttr()) {
                    CllCommentDetailsViewImpl cmntDetailsView = this.getCllCommentDetailsView2();
                    Key commntIdKey = new Key(new Object[] { cmntsListRow.getCllCommDetId() });
                    Row[] commntrows = cmntDetailsView.findByKey(commntIdKey, 1);
                    if (commntrows.length > 0) {
                        CllCommentDetailsViewRowImpl commntRow = (CllCommentDetailsViewRowImpl) commntrows[0];
                        if ("ASSIGN".equals(action)) {
                            commntRow.setAssigned(staffId);
                            commntRow.setAssignedDate(new oracle.jbo.domain.Date(new Timestamp(System.currentTimeMillis())));
                        }
                    }
                }
            }
            cmntsListIter.closeRowSetIterator();
            this.getDBTransaction().commit();
        }

        return rtn;
    }

    public void approveFormLetterComments(Number fileNumId, Number formLetId, String fileNumTypeCode) {
        logger.info("CommentLogAppModImpl.approveFormLetterComments :: param :: fileNumId = " + fileNumId);
        logger.info("CommentLogAppModImpl.approveFormLetterComments :: param :: formLetId = " + formLetId);
        logger.info("CommentLogAppModImpl.approveFormLetterComments :: param :: fileNumTypeCode = " + fileNumTypeCode);
        Number statusTypeId = null;
        Number dispId = null;
        CllStatusTypeROViewImpl statusTypeView = this.getCllStatusTypeROView1();
        RowSetIterator statusTypeIter = statusTypeView.createRowSetIterator(null);
        statusTypeIter.reset();
        while (statusTypeIter.hasNext()) {
            CllStatusTypeROViewRowImpl statusTypeViewRow = (CllStatusTypeROViewRowImpl) statusTypeIter.next();
            if ("PRO".equals(statusTypeViewRow.getCode())) {
                statusTypeId = statusTypeViewRow.getCllStatusTypeId();
                break;
            }
        }
        logger.info("CommentLogAppModImpl.approveFormLetterComments :: Preparing statusTypeId = " + statusTypeId);
        statusTypeIter.closeRowSetIterator();
        CllDispositionTypeROViewImpl dispView = (CllDispositionTypeROViewImpl) this.getCllDispositionTypeROView1();
        RowSetIterator dispViewIter = dispView.createRowSetIterator(null);
        dispViewIter.reset();
        while (dispViewIter.hasNext()) {
            CllDispositionTypeROViewRowImpl dispViewRow = (CllDispositionTypeROViewRowImpl) dispViewIter.next();
            if ("APPR".equals(dispViewRow.getCode())) {
                dispId = dispViewRow.getCllDispositionTypeId();
                break;
            }
        }
        dispViewIter.closeRowSetIterator();
        logger.info("CommentLogAppModImpl.approveFormLetterComments :: Preparing dispId = " + dispId);

        CllCommentsListROViewImpl cmntsList = this.getCllCommentsListROView1();
        RowSetIterator cmntsListIter = cmntsList.createRowSetIterator(null);
        cmntsListIter.reset();

        boolean assignedSRSeqNumber = false;
        while (cmntsListIter.hasNext()) {
            CllCommentsListROViewRowImpl cmntsListRow = (CllCommentsListROViewRowImpl) cmntsListIter.next();
            logger.info("CommentLogAppModImpl.approveFormLetterComments :: cmntsListRow.getSelectAttr() = " +
                        cmntsListRow.getSelectAttr());
            if (null != cmntsListRow.getSelectAttr() && cmntsListRow.getSelectAttr()) {
                CllCommentDetailsViewImpl cmntDetailsView = this.getCllCommentDetailsView2();
                Key commntIdKey = new Key(new Object[] { cmntsListRow.getCllCommDetId() });
                Row[] commntrows = cmntDetailsView.findByKey(commntIdKey, 1);
                if (commntrows.length > 0) {
                    CllCommentDetailsViewRowImpl commntRow = (CllCommentDetailsViewRowImpl) commntrows[0];
                    if ("UPRO".equals(commntRow.getCommentStatusCode())) {
                        commntRow.setCllStatusTypeId(statusTypeId);
                        commntRow.setCllDispositionTypeId(dispId);
                        commntRow.setDispositionDate(new oracle.jbo.domain.Date(new Timestamp(System.currentTimeMillis())));
                    } else if ("PRO".equals(commntRow.getCommentStatusCode())) {
                        commntRow.setCllDispositionTypeId(dispId);
                        commntRow.setDispositionDate(new oracle.jbo.domain.Date(new Timestamp(System.currentTimeMillis())));
                    }
                    //If the file number type is SR and  if no seq number is already assigned to any other instance
                    //generate  SR sequence number for the first instance
                    /*if(fileNumTypeCode.equalsIgnoreCase("SR") && !assignedSRSeqNumber){
                            assignedSRSeqNumber=true;
                            FileNumCommDetSeqNumROViewImpl fileNumComDet= (FileNumCommDetSeqNumROViewImpl)this.getFileNumCommDetSeqNumROView1();
                            fileNumComDet.findRowWithSRSeqNumber(fileNumId, formLetId);
                            if(fileNumComDet.getEstimatedRowCount() <= 0){
                                Number nextSeqNumber= this.getCllFileNumberView1().getSetFileNumberSeqNumberNext(fileNumId);
                                CllFilenumberCommDetailsViewImpl cllFleNumComDetView=this.getCllFilenumberCommDetailsView2();
                                cllFleNumComDetView.assignSRSeqNumber(cmntsListRow.getCllCommDetId(), fileNumId,nextSeqNumber);
                            }
                    } */

                    //if the file# type is SR, generate  sequence number for every instance if it is not generated already
                    if (fileNumTypeCode.equalsIgnoreCase("SR")) {
                        CllFilenumberCommDetailsViewImpl cllFleNumComDetView = this.getCllFilenumberCommDetailsView2();
                        Number currSeqNumber =
                            cllFleNumComDetView.getSRSeqNumber(cmntsListRow.getCllCommDetId(), fileNumId);
                        if (null == currSeqNumber) {
                            Number nextSeqNumber =
                                this.getCllFileNumberView1().getSetFileNumberSeqNumberNext(fileNumId);
                            cllFleNumComDetView.assignSRSeqNumber(cmntsListRow.getCllCommDetId(), fileNumId,
                                                                  nextSeqNumber);
                        }
                    }

                }

            }
        }

        cmntsListIter.closeRowSetIterator();
        this.getDBTransaction().commit();
    }

    public void fetchFormLtrText(Integer fileNumId, String subType) {
        CllFormLetterTextROViewImpl formLtrText = this.getCllFormLetterTextROView1();
        formLtrText.setbindFileNum(fileNumId);
        formLtrText.setbindSubType(subType);
        formLtrText.executeQuery();
    }

    /**
     * Container's getter for CllFileNumAssignView1.
     * @return CllFileNumAssignView1
     */
    public ViewObjectImpl getCllFileNumAssignView1() {
        return (ViewObjectImpl) findViewObject("CllFileNumAssignView1");
    }

    /**
     * Container's getter for CllStatusTypeROView1.
     * @return CllStatusTypeROView1
     */
    public CllStatusTypeROViewImpl getCllStatusTypeROView1() {
        return (CllStatusTypeROViewImpl) findViewObject("CllStatusTypeROView1");
    }

    /**
     * Container's getter for CllDispositionTypeView1.
     * @return CllDispositionTypeView1
     */
    public CllDispositionTypeViewImpl getCllDispositionTypeView1() {
        return (CllDispositionTypeViewImpl) findViewObject("CllDispositionTypeView1");
    }

    /**
     * Container's getter for CllTypeView1.
     * @return CllTypeView1
     */
    public CllTypeViewImpl getCllTypeView1() {
        return (CllTypeViewImpl) findViewObject("CllTypeView1");
    }

    /**
     * Container's getter for CllStatusTypeView1.
     * @return CllStatusTypeView1
     */
    public CllStatusTypeViewImpl getCllStatusTypeView1() {
        return (CllStatusTypeViewImpl) findViewObject("CllStatusTypeView1");
    }

    /**
     * Container's getter for CllTypeROView1.
     * @return CllTypeROView1
     */
    public ViewObjectImpl getCllTypeROView1() {
        return (ViewObjectImpl) findViewObject("CllTypeROView1");
    }

    /**
     * Container's getter for CllCommentDetailsView1.
     * @return CllCommentDetailsView1
     */
    public CllCommentDetailsViewImpl getCllCommentDetailsView1() {
        return (CllCommentDetailsViewImpl) findViewObject("CllCommentDetailsView1");
    }

    /**
     * Container's getter for CllFilenumCommDetView1.
     * @return CllFilenumCommDetView1
     */
    public CllFilenumCommDetViewImpl getCllFilenumCommDetView1() {
        return (CllFilenumCommDetViewImpl) findViewObject("CllFilenumCommDetView1");
    }

    /**
     * Container's getter for CllFilenumCommDetCllCommentDetFKLink1.
     * @return CllFilenumCommDetCllCommentDetFKLink1
     */
    public ViewLinkImpl getCllFilenumCommDetCllCommentDetFKLink1() {
        return (ViewLinkImpl) findViewLink("CllFilenumCommDetCllCommentDetFKLink1");
    }

    /**
     * Container's getter for CllFileNumAssignROView1.
     * @return CllFileNumAssignROView1
     */
    public ViewObjectImpl getCllFileNumAssignROView1() {
        return (ViewObjectImpl) findViewObject("CllFileNumAssignROView1");
    }


    /**
     * Container's getter for CllFormLetterListROView1.
     * @return CllFormLetterListROView1
     */
    public CllFormLetterListROViewImpl getCllFormLetterListROView1() {
        return (CllFormLetterListROViewImpl) findViewObject("CllFormLetterListROView1");
    }

    /**
     * Container's getter for FileNumberType1View1.
     * @return FileNumberType1View1
     */
    public FileNumberType1ViewImpl getFileNumTypesFileNumbers() {
        return (FileNumberType1ViewImpl) findViewObject("FileNumTypesFileNumbers");
    }

    /**
     * Container's getter for CllFileNumber1View1.
     * @return CllFileNumber1View1
     */
    public ViewObjectImpl getCllFileNumber1View1() {
        return (ViewObjectImpl) findViewObject("CllFileNumber1View1");
    }

    /**
     * Container's getter for CllFileNumFileNumTypeFKLink1_1.
     * @return CllFileNumFileNumTypeFKLink1_1
     */
    public ViewLinkImpl getCllFileNumFileNumTypeFKLink1_1() {
        return (ViewLinkImpl) findViewLink("CllFileNumFileNumTypeFKLink1_1");
    }


    /**
     * Container's getter for CllFormLetterSubTypeROView1.
     * @return CllFormLetterSubTypeROView1
     */
    public CllFormLetterSubTypeROViewImpl getCllFormLetterSubTypeROView1() {
        return (CllFormLetterSubTypeROViewImpl) findViewObject("CllFormLetterSubTypeROView1");
    }

    /**
     * Container's getter for CllFilenumRelFr1View1.
     * @return CllFilenumRelFr1View1
     */
    public ViewObjectImpl getCllFilenumRelFr1View1() {
        return (ViewObjectImpl) findViewObject("CllFilenumRelFr1View1");
    }

    /**
     * Container's getter for CllFilenumRelFrCllFileNumberFKLink1_1.
     * @return CllFilenumRelFrCllFileNumberFKLink1_1
     */
    public ViewLinkImpl getCllFilenumRelFrCllFileNumberFKLink1_1() {
        return (ViewLinkImpl) findViewLink("CllFilenumRelFrCllFileNumberFKLink1_1");
    }

    /**
     * Container's getter for CllFormLetterTextROView1.
     * @return CllFormLetterTextROView1
     */
    public CllFormLetterTextROViewImpl getCllFormLetterTextROView1() {
        return (CllFormLetterTextROViewImpl) findViewObject("CllFormLetterTextROView1");
    }

    /**
     * Container's getter for CllSubmitterView1.
     * @return CllSubmitterView1
     */
    public ViewObjectImpl getCllSubmitterView1() {
        return (ViewObjectImpl) findViewObject("CllSubmitterView1");
    }

    /**
     * Container's getter for CllSubmittertCllCommentDetFKLink1.
     * @return CllSubmittertCllCommentDetFKLink1
     */
    public ViewLinkImpl getCllSubmittertCllCommentDetFKLink1() {
        return (ViewLinkImpl) findViewLink("CllSubmittertCllCommentDetFKLink1");
    }

    /**
     * Container's getter for CllFormLetterListPRView1.
     * @return CllFormLetterListPRView1
     */
    public CllFormLetterListPRViewImpl getCllFormLetterListPRView1() {
        return (CllFormLetterListPRViewImpl) findViewObject("CllFormLetterListPRView1");
    }

    /**
     * Container's getter for FileNumbersForCommentDetROView1.
     * @return FileNumbersForCommentDetROView1
     */
    public ViewObjectImpl getFileNumbersForCommentDetROView1() {
        return (ViewObjectImpl) findViewObject("FileNumbersForCommentDetROView1");
    }

    /**
     * Container's getter for CllMissingFileNumberCommentsListROView1.
     * @return CllMissingFileNumberCommentsListROView1
     */
    public ViewObjectImpl getCllMissingFileNumberCommentsListROView1() {
        return (ViewObjectImpl) findViewObject("CllMissingFileNumberCommentsListROView1");
    }

    /**
     * Container's getter for CllFormLetterView1.
     * @return CllFormLetterView1
     */
    public ViewObjectImpl getCllFormLetterView1() {
        return (ViewObjectImpl) findViewObject("CllFormLetterView1");
    }

    public void createFormLetter(Number fileNumId) {
        CllFormLetterListPRViewImpl formLtrPRView = this.getCllFormLetterListPRView1();
        CllFormLetterListPRViewRowImpl formLtrPRViewRow = new CllFormLetterListPRViewRowImpl();
        formLtrPRView.executeEmptyRowSet();
        if (formLtrPRView != null && null == formLtrPRView.first()) {
            formLtrPRViewRow = (CllFormLetterListPRViewRowImpl) formLtrPRView.createRow();
            formLtrPRView.insertRow(formLtrPRViewRow);
        } else {
            formLtrPRViewRow = (CllFormLetterListPRViewRowImpl) formLtrPRView.first();
        }
        formLtrPRViewRow.setKeyAttr(1);
        String subtype = this.getSubType(fileNumId);
        formLtrPRViewRow.setSubType(subtype);
        if (null == subtype) {
            this.fetchFormLetter(fileNumId, 0);
        } else {
            CllFormLetterViewImpl formLetter = (CllFormLetterViewImpl) this.getCllFormLetterView1();
            formLetter.setApplyViewCriteriaName("findByFileNumber", false);
            formLetter.setNamedWhereClauseParam("bindFileNumId", fileNumId.bigDecimalValue());
            formLetter.executeQuery();
        }
        formLtrPRView.setCurrentRow(formLtrPRViewRow);
        RowSet rSet = formLtrPRViewRow.getCllFormLetterSubTypeROView1();
        if (fileNumId != null)
            rSet.setNamedWhereClauseParam("bindFileNum", fileNumId);
        rSet.executeQuery();
    }

    /**
     *
     * @param fileNumId
     * @return
     */
    public String getSubType(Number fileNumId) {
        CllFormLetterSubTypeROViewImpl formLetter = this.getCllFormLetterSubTypeROView1();
        formLetter.setbindFileNum(fileNumId);
        formLetter.executeQuery();
        CllFormLetterSubTypeROViewRowImpl formLetterRow = (CllFormLetterSubTypeROViewRowImpl) formLetter.first();
        String subType = null;
        if (formLetterRow != null)
            subType = formLetterRow.getSubType();
        return subType;
    }

    /**
     *
     * @param fileNumId
     * @param index
     */
    public void fetchFormLetter(Number fileNumId, Integer index) {
        boolean exist = false;
        String lastCode = null;
        String selectedCode = null;
        oracle.jbo.domain.Number formLetterId = null;
        CllFormLetterListPRViewImpl formLtrPRView = this.getCllFormLetterListPRView1();
        CllFormLetterListPRViewRowImpl formLtrPRViewRow =
            (CllFormLetterListPRViewRowImpl) formLtrPRView.getCurrentRow();
        CllCommentDetailsViewImpl commentDet = this.getCllCommentDetailsView1();
        CllCommentDetailsViewRowImpl commentDetRow = (CllCommentDetailsViewRowImpl) commentDet.getCurrentRow();
        if (formLtrPRViewRow != null) {
            RowSet rSet = formLtrPRViewRow.getCllFormLetterSubTypeROView1();
            Row row = rSet.last();
            Row selectedRow = rSet.getRowAtRangeIndex(index - 1);
            if (null != row) {
                lastCode = (String) row.getAttribute("SubType");
            }
            if (null != selectedRow) {
                selectedCode = (String) selectedRow.getAttribute("SubType");
                formLetterId = (oracle.jbo.domain.Number) selectedRow.getAttribute("CllFormLetterId");
            }
            CllFormLetterViewImpl formLetter = (CllFormLetterViewImpl) this.getCllFormLetterView1();
            formLetter.setApplyViewCriteriaName("findByFileNumber", false);
            formLetter.setNamedWhereClauseParam("bindFileNumId", fileNumId);
            formLetter.executeQuery();
            CllFormLetterViewRowImpl formLetterRow = new CllFormLetterViewRowImpl();
            if (index != 0) {
                RowSetIterator rsetIter = formLetter.createRowSetIterator(null);
                rsetIter.reset();
                while (rsetIter.hasNext()) {
                    formLetterRow = (CllFormLetterViewRowImpl) rsetIter.next();
                    if (formLetterRow.getEntity(0).getEntityState() == EntityImpl.STATUS_NEW) {
                        formLetterRow.remove();
                    } else {
                        commentDetRow.setCllFormLetterId(formLetterId);
                    }
                }
                Key formIdKey = new Key(new Object[] { formLetterId });
                Row[] formrows = formLetter.findByKey(formIdKey, 1);
                formLetter.setCurrentRow(formrows[0]);
                rsetIter.closeRowSetIterator();
            } else {
                RowSetIterator rsetIter = formLetter.createRowSetIterator(null);
                rsetIter.reset();
                while (rsetIter.hasNext()) {
                    formLetterRow = (CllFormLetterViewRowImpl) rsetIter.next();
                    if (formLetterRow.getEntity(0).getEntityState() == EntityImpl.STATUS_NEW) {
                        exist = true;
                        formLetter.setCurrentRow(formLetterRow);
                        break;
                    }
                }
                if (!exist) {
                    formLetterRow = (CllFormLetterViewRowImpl) formLetter.createRow();
                    String newCode = generateSubTypeLetter(lastCode);
                    formLetterRow.setFilenumId(fileNumId.bigDecimalValue());
                    formLetterRow.setSubType(newCode);
                    formLetter.insertRow(formLetterRow);
                    formLetter.setCurrentRow(formLetterRow);
                }
                rsetIter.closeRowSetIterator();
            }
        }
    }

    public Number createNewFormLetter(Number fileNumId, oracle.jbo.domain.ClobDomain matchText) {
        logger.info("Creating New Form Letter :: fileNumId : " + fileNumId);
        Number newFormLetterId = new Number();
        //Refresh CllFormLetterView to have latest. This is to pick up the last
        CllFormLetterViewImpl formLetterVO = (CllFormLetterViewImpl) this.getCllFormLetterView1();
        formLetterVO.setApplyViewCriteriaName("findByFileNumber", false);
        formLetterVO.setNamedWhereClauseParam("bindFileNumId", fileNumId);
        formLetterVO.executeQuery();
        long count = formLetterVO.getEstimatedRowCount();
        logger.info("# of cuurent Form Letters = " + formLetterVO.getEstimatedRowCount());

        CllFormLetterViewRowImpl newFormLetterRow = (CllFormLetterViewRowImpl) formLetterVO.createRow();
        newFormLetterRow.setFilenumId(fileNumId.bigDecimalValue());
        newFormLetterRow.setFormLetterText(matchText);
        String newLetter = "";
        if (count > 0) {
            CllFormLetterViewRowImpl lastRow = (CllFormLetterViewRowImpl) formLetterVO.last();
            newLetter = generateSubTypeLetter(lastRow.getSubType());
        } else {
            newLetter = generateSubTypeLetter(null);
        }
        newFormLetterRow.setSubType(newLetter);
        formLetterVO.insertRow(newFormLetterRow);
        formLetterVO.setCurrentRow(newFormLetterRow);
        getDBTransaction().commit();
        newFormLetterId = newFormLetterRow.getCllFormLetterId().getSequenceNumber();
        logger.info("Returning newFormLetterId = " + newFormLetterId);
        return newFormLetterId;
    }

    /**
     * Generates a sequence alphabetic letter for the provided letter
     *
     * @param letter Alphabetic letter that will be previous for generated one
     * @return
     */
    private String generateSubTypeLetter(String letter) {
        logger.info(String.format("Generating New Letter for [%s]", letter));
        String newLetter;
        if (letter != null && !letter.trim().isEmpty()) {
            String substr = letter.substring(0, letter.length() - 1);
            String lastChar = letter.substring(letter.length() - 1);
            StringBuffer sb = new StringBuffer();
            if (!lastChar.equals("Z")) {
                logger.info("Getting next alphabet letter...");
                char c = lastChar.charAt(0);
                char newC = ++c;
                String newLastChar = String.valueOf(newC);
                sb.append(substr).append(newLastChar);
            } else {
                logger.info("Adding new letter A...");
                sb.append(substr)
                  .append("A")
                  .append("A");
            }
            newLetter = sb.toString();
        } else {
            newLetter = "A";
        }
        logger.info(String.format("Returning New Letter [%s]", newLetter));
        return newLetter;
    }

    /**
     * Container's getter for CllCommentDetailsView2.
     * @return CllCommentDetailsView2
     */
    public CllCommentDetailsViewImpl getCllCommentDetailsView2() {
        return (CllCommentDetailsViewImpl) findViewObject("CllCommentDetailsView2");
    }

    /**
     *
     * @return
     */
    //TODO: Is this really needed? Passing a hard code value?
    public boolean setMatchText() {
        CllCommentDetailsViewImpl comntLtr = this.getCllCommentDetailsView1();
        CllCommentDetailsViewRowImpl comntLtrRow = (CllCommentDetailsViewRowImpl) comntLtr.getCurrentRow();
        comntLtrRow.setCllTypeId(new Number(2));
        //        if(comntLtrRow.getCllStatusType() != null && comntLtrRow.getCllStatusType().equals(1))
        //        comntLtrRow.setCllStatusTypeId(new Number(2));
        boolean rtn = this.commitTransaction();
        return rtn;
    }

    /**
     *
     */
    public void setFormLetter() {
        this.postTransaction();
        CllFormLetterViewImpl formLetter = (CllFormLetterViewImpl) this.getCllFormLetterView1();
        CllFormLetterViewRowImpl formLetterRow = (CllFormLetterViewRowImpl) formLetter.getCurrentRow();
        CllCommentDetailsViewImpl commentDet = this.getCllCommentDetailsView1();
        CllCommentDetailsViewRowImpl commentDetRow = (CllCommentDetailsViewRowImpl) commentDet.getCurrentRow();
        if (formLetterRow != null && formLetterRow.getCllFormLetterId() != null)
            commentDetRow.setCllFormLetterId(formLetterRow.getCllFormLetterId().getSequenceNumber());
        //        this.commitTransaction();
    }

    /**
     *
     */
    public void createFileNumber() {
        oracle.jbo.domain.Number typeId = null;
        FileNumberTypeROViewImpl fileNumType = this.getFileNumberTypeROView1();
        RowSetIterator fileNumTypeIter = fileNumType.createRowSetIterator(null);
        fileNumTypeIter.reset();
        while (fileNumTypeIter.hasNext()) {
            FileNumberTypeROViewRowImpl fileNumTypeRow = (FileNumberTypeROViewRowImpl) fileNumTypeIter.next();
            if (null != fileNumTypeRow.getCode() && "CLL".equals(fileNumTypeRow.getCode()))
                typeId = fileNumTypeRow.getFilenumTypeId();
        }
        fileNumTypeIter.closeRowSetIterator();
        CllFileNumberViewImpl fileNum = (CllFileNumberViewImpl) this.getCllFileNumberView1();
        CllFileNumberViewRowImpl fileNumRow = (CllFileNumberViewRowImpl) fileNum.createRow();
        fileNumRow.setFilenumTypeId(typeId);
        fileNum.insertRow(fileNumRow);
        fileNum.setCurrentRow(fileNumRow);
        this.executeRelAttyQuery(fileNumRow.getFilenumId().getSequenceNumber());
    }

    public void insertFileNumber() {
        Number newSeQNum = null;
        Row row = null;
        CllFileNumberViewImpl fileNum = (CllFileNumberViewImpl) this.getCllFileNumberView1();
        CllFileNumberViewRowImpl fileNumRow = (CllFileNumberViewRowImpl) fileNum.getCurrentRow();
        Number fileTypeID = fileNumRow.getFilenumTypeId();
        if (fileNumRow.getEntity(0).getEntityState() == EntityImpl.STATUS_NEW) {
            FileNumberTypeViewImpl fileType = this.getFileNumberTypeView1();
            Key fileTypeKey = new Key(new Object[] { fileTypeID });
            Row[] fileTypeRows = fileType.findByKey(fileTypeKey, 1);
            if (null != fileTypeRows && fileTypeRows.length > 0) {
                row = fileTypeRows[0];
                String code = (String) row.getAttribute("Code");
                if ("CLL".equals(code)) {
                    Number seqNum = (Number) row.getAttribute("SeqNumber");
                    if (null != seqNum)
                        newSeQNum = new Number(seqNum.intValue() + 1);
                    else {
                        newSeQNum = new Number(1);
                    }
                    row.setAttribute("SeqNumber", newSeQNum);
                    String newFileNum = newSeQNum.toString();
                    fileNumRow.setFileNumber(newFileNum);
                }
            }
            this.postTransaction();
        }
        Number fileNumId = fileNumRow.getFilenumId().getSequenceNumber();
        CllFilenumRelFrViewImpl filenumRel = (CllFilenumRelFrViewImpl) this.getCllFilenumRelFrView1();
        RowSetIterator relRSetIter = filenumRel.createRowSetIterator(null);
        relRSetIter.reset();
        while (relRSetIter.hasNext()) {
            CllFilenumRelFrViewRowImpl filenumRelRow = (CllFilenumRelFrViewRowImpl) relRSetIter.next();
            filenumRelRow.setFilenumId(fileNumId);
        }
        relRSetIter.closeRowSetIterator();
        CllFilenumAttyViewImpl filenumAtty = this.getCllFilenumAttyView1();
        RowSetIterator attyRSetIter = filenumAtty.createRowSetIterator(null);
        attyRSetIter.reset();
        while (attyRSetIter.hasNext()) {
            CllFilenumAttyViewRowImpl filenumAttyRow = (CllFilenumAttyViewRowImpl) attyRSetIter.next();
            filenumAttyRow.setFilenumId(fileNumId);
        }
        attyRSetIter.closeRowSetIterator();
    }

    public void executeRelAttyQuery(Number fileNumId) {
        CllFilenumRelFrViewImpl filenumRel = (CllFilenumRelFrViewImpl) this.getCllFilenumRelFrView1();
        filenumRel.setApplyViewCriteriaName("findByFileNum", false);
        filenumRel.setNamedWhereClauseParam("bindFileNum", fileNumId);
        filenumRel.executeQuery();
        CllFilenumAttyViewImpl filenumAtty = this.getCllFilenumAttyView1();
        filenumAtty.setApplyViewCriteriaName("findByFileNum", false);
        filenumAtty.setNamedWhereClauseParam("bindFileNum", fileNumId);
        filenumAtty.executeQuery();
    }

    public boolean checkDuplicateFileNumber(Number fileTypeId, String fileNum) {
        boolean rtn = false;
        String fileNumber = null;
        CllFileNumberViewImpl fileNumId = (CllFileNumberViewImpl) this.getCllFileNumberView1();
        CllFileNumberViewRowImpl fileNumRow = (CllFileNumberViewRowImpl) fileNumId.getCurrentRow();
        int typeId = fileNumRow.getFilenumTypeId().intValue();
        Number newTypeID = new Number(typeId);
        if (fileNumRow.getFileNumber() != null)
            fileNumber = fileNumRow.getFileNumber()
                                   .toString()
                                   .trim();
        CheckDupFileNumberROViewImpl dupFileNum = this.getCheckDupFileNumberROView1();
        dupFileNum.setbindfileTypeId(newTypeID);
        dupFileNum.setbindfileNum(fileNumber);
        dupFileNum.executeQuery();
        CheckDupFileNumberROViewRowImpl dupFileNumRow = (CheckDupFileNumberROViewRowImpl) dupFileNum.first();
        if (dupFileNumRow != null)
            rtn = true;
        else
            rtn = false;
        return rtn;
    }

    public boolean checkDuplicateAttorney(Map paramsMap) {
        boolean rtn = false;
        String fName = (String) paramsMap.get("FIRST_NAME");
        String lName = (String) paramsMap.get("LAST_NAME");
        CllFilenumAttyViewImpl filenumAtty = this.getCllFilenumAttyView1();
        RowSetIterator attyRSetIter = filenumAtty.createRowSetIterator(null);
        attyRSetIter.reset();
        while (attyRSetIter.hasNext()) {
            CllFilenumAttyViewRowImpl filenumAttyRow = (CllFilenumAttyViewRowImpl) attyRSetIter.next();
            if (null != filenumAttyRow) {
                if (null != fName && fName.equals(filenumAttyRow.getFirstName()) && null != lName &&
                    lName.equals(filenumAttyRow.getLastName())) {
                    rtn = true;
                }
            }
        }
        attyRSetIter.closeRowSetIterator();
        return rtn;
    }

    public void addAttorneytoFile(Map paramsMap) {
        CllFilenumAttyViewImpl filenumAtty = this.getCllFilenumAttyView1();
        CllFilenumAttyViewRowImpl filenumAttyRow = (CllFilenumAttyViewRowImpl) filenumAtty.createRow();
        filenumAttyRow.setFirstName((String) paramsMap.get("FIRST_NAME"));
        filenumAttyRow.setLastName((String) paramsMap.get("LAST_NAME"));
        filenumAttyRow.setEmail((String) paramsMap.get("EMAIL"));
        filenumAttyRow.setPhoneNumber((String) paramsMap.get("PHONE_NUMBER"));
        filenumAttyRow.setSuffix((String) paramsMap.get("SUFFIX"));
        filenumAtty.insertRowAtRangeIndex(0, filenumAttyRow);
        filenumAtty.setCurrentRowAtRangeIndex(0);
    }


    /**
     * Container's getter for CheckDupFileNumberROView1.
     * @return CheckDupFileNumberROView1
     */
    public CheckDupFileNumberROViewImpl getCheckDupFileNumberROView1() {
        return (CheckDupFileNumberROViewImpl) findViewObject("CheckDupFileNumberROView1");
    }

    public void executeFileNUmberQueue() {
        FileNumberQueueROViewImpl fileNum = (FileNumberQueueROViewImpl) this.getFileNumberQueueROView1();
        fileNum.executeQuery();
    }

    /**
     * Container's getter for CllFilenumRelFrView1.
     * @return CllFilenumRelFrView1
     */
    public ViewObjectImpl getCllFilenumRelFrView1() {
        return (ViewObjectImpl) findViewObject("CllFilenumRelFrView1");
    }

    /**
     * Container's getter for CllFilenumAttyView1.
     * @return CllFilenumAttyView1
     */
    public CllFilenumAttyViewImpl getCllFilenumAttyView1() {
        return (CllFilenumAttyViewImpl) findViewObject("CllFilenumAttyView1");
    }

    /**
     * Container's getter for CllDeletedCommentsListROView1.
     * @return CllDeletedCommentsListROView1
     */
    public ViewObjectImpl getCllDeletedCommentsListROView1() {
        return (ViewObjectImpl) findViewObject("CllDeletedCommentsListROView1");
    }

    /**
     * Container's getter for FileNumberTypeView1.
     * @return FileNumberTypeView1
     */
    public FileNumberTypeViewImpl getFileNumberTypeView1() {
        return (FileNumberTypeViewImpl) findViewObject("FileNumberTypeView1");
    }

    public void createReleaseNumber() {
        CllFilenumRelFrViewImpl filenumRel = (CllFilenumRelFrViewImpl) this.getCllFilenumRelFrView1();
        CllFilenumRelFrViewRowImpl filenumRelRow = (CllFilenumRelFrViewRowImpl) filenumRel.createRow();
        filenumRel.insertRowAtRangeIndex(0, filenumRelRow);
        filenumRel.setCurrentRowAtRangeIndex(0);
    }

    public void deleteReleaseNumber() {
        CllFilenumRelFrViewImpl filenumRel = (CllFilenumRelFrViewImpl) this.getCllFilenumRelFrView1();
        CllFilenumRelFrViewRowImpl filenumRelRow = (CllFilenumRelFrViewRowImpl) filenumRel.getCurrentRow();
        if (filenumRelRow != null)
            filenumRelRow.remove();
    }

    public void deleteAttorneyDetails() {
        CllFilenumAttyViewImpl filenumAtty = this.getCllFilenumAttyView1();
        CllFilenumAttyViewRowImpl filenumAttyRow = (CllFilenumAttyViewRowImpl) filenumAtty.getCurrentRow();
        if (filenumAttyRow != null)
            filenumAttyRow.remove();
    }

    /**
     * Container's getter for CllApplicationPropertiesView1.
     * @return CllApplicationPropertiesView1
     */
    public CllApplicationPropertiesViewImpl getCllApplicationPropertiesView1() {
        return (CllApplicationPropertiesViewImpl) findViewObject("CllApplicationPropertiesView1");
    }

    /**
     * Container's getter for SearchCommentsROView1.
     * @return SearchCommentsROView1
     */
    public SearchCommentsROViewImpl getSearchCommentsROView1() {
        return (SearchCommentsROViewImpl) findViewObject("SearchCommentsROView1");
    }

    /**
     * Container's getter for SearchCommentsPRView1.
     * @return SearchCommentsPRView1
     */
    public SearchCommentsPRViewImpl getSearchCommentsPRView1() {
        return (SearchCommentsPRViewImpl) findViewObject("SearchCommentsPRView1");
    }

    public void initSearchComments() {
        SearchCommentsPRViewImpl searchCommPr = this.getSearchCommentsPRView1();
        if (null != searchCommPr) {
            searchCommPr.executeEmptyRowSet();
            SearchCommentsPRViewRowImpl searchCommPrRow = (SearchCommentsPRViewRowImpl) searchCommPr.first();
            if (null == searchCommPrRow) {
                searchCommPrRow = (SearchCommentsPRViewRowImpl) searchCommPr.createRow();
                searchCommPr.insertRow(searchCommPrRow);
                searchCommPr.setCurrentRow(searchCommPrRow);

                searchCommPrRow.getCllTypeROView1().executeQuery();
                searchCommPrRow.getCllTypeROView1().getEstimatedRowCount();

            }
        }
        SearchCommentsROViewImpl searchCommRO = this.getSearchCommentsROView1();
        if (null != searchCommRO) {
            searchCommRO.executeEmptyRowSet();
        }
    }

    public void initSearchFileNumbers() {
        SearchFileNumbersPRViewImpl searchFilesPrView = this.getSearchFileNumbersPRView1();
        if (null != searchFilesPrView) {
            searchFilesPrView.executeEmptyRowSet();
            SearchFileNumbersPRViewRowImpl searchFilesPrViewRow =
                (SearchFileNumbersPRViewRowImpl) searchFilesPrView.first();
            if (null == searchFilesPrViewRow) {
                searchFilesPrViewRow = (SearchFileNumbersPRViewRowImpl) searchFilesPrView.createRow();
                searchFilesPrView.insertRow(searchFilesPrViewRow);
                searchFilesPrView.setCurrentRow(searchFilesPrViewRow);
            }
        }
        SearchFileNumbersROViewImpl searchFileRO = this.getSearchFileNumbersROView1();
        searchFileRO.setbindFileNumber("XXYYZZ");
        searchFileRO.executeQuery();
    }

    public void searchComments(Integer index) {
        String type = null;
        String number = null;
        String releaseNumber = null;
        String subect = null;
        String fileNumber = null;
        String Affiliate = null;
        Date SecStDate = null;
        Date SecEndDate = null;
        Date stDtofLtr = null;
        Date endDtofLtr = null;
        String Submitter = null;
        String FromCommentId = null;
        String ToCommentId = null;
        String CommentTypeCode = null;
        SearchCommentsPRViewImpl searchCommPr = this.getSearchCommentsPRView1();
        if (null != searchCommPr) {
            SearchCommentsPRViewRowImpl searchCommPrRow = (SearchCommentsPRViewRowImpl) searchCommPr.getCurrentRow();
            if (null != searchCommPrRow) {
                releaseNumber = searchCommPrRow.getReleaseNumber();
                subect = searchCommPrRow.getSubject();
                Affiliate = searchCommPrRow.getAffiliate();
                stDtofLtr = searchCommPrRow.getDateofLetter();
                endDtofLtr = searchCommPrRow.getendDateofLetter();
                SecStDate = searchCommPrRow.getReceivedStDate();
                SecEndDate = searchCommPrRow.getReceivedEndDate();
                Submitter = searchCommPrRow.getSubmitterName();
                FromCommentId = searchCommPrRow.getFromCommentId();
                ToCommentId = searchCommPrRow.getToCommentId();


                CommentTypeCode = searchCommPrRow.getCommentType();
                if (null !=CommentTypeCode){
                RowSet rSetCommentType = searchCommPrRow.getCllTypeROView1();
                Row rowCommentType = rSetCommentType.getCurrentRow();
                if (null != rowCommentType) {
                    CommentTypeCode = (String) rowCommentType.getAttribute("Code");
                }
                }
                if (null != index) {

                    number = searchCommPrRow.getFileNumber();
                    RowSet rSet = searchCommPrRow.getFileNumberTypeROView1();
                    Row row = rSet.getRowAtRangeIndex(index - 1);

                    if (null != row) {
                        type = (String) row.getAttribute("Code");
                    }
                    if ("OTH".equals(type)) {
                        fileNumber = number;
                    } else if (null != type && !"OTH".equals(type)) {
                        fileNumber = type + "-" + number;
                    }
                }
            }
        }
        SearchCommentsROViewImpl searchCommRO = this.getSearchCommentsROView1();
        searchCommRO.setbindAffiliate(Affiliate);
        searchCommRO.setbindFileNumber(fileNumber);
        searchCommRO.setbindSubject(subect);
        searchCommRO.setbindReleaseNumber(releaseNumber);
        searchCommRO.setbindSubmitterName(Submitter);
        searchCommRO.setbindCommentTypeCode(CommentTypeCode);
        if (null != FromCommentId) {
            searchCommRO.setApplyViewCriteriaName("findByCommentId", true);
            if (null != FromCommentId && null == ToCommentId) {
                searchCommRO.setNamedWhereClauseParam("bindFromCommentId", FromCommentId);
                searchCommRO.setNamedWhereClauseParam("bindToCommentId", FromCommentId);

            } else if (null != FromCommentId && null != ToCommentId) {
                searchCommRO.setNamedWhereClauseParam("bindFromCommentId", FromCommentId);
                searchCommRO.setNamedWhereClauseParam("bindToCommentId", ToCommentId);

            } else {
                searchCommRO.removeApplyViewCriteriaName("findByCommentId");
            }
        } else {
            searchCommRO.removeApplyViewCriteriaName("findByCommentId");
        }
        if (null != stDtofLtr || null != endDtofLtr) {
            searchCommRO.setApplyViewCriteriaName("findByDateofLetter", true);
            if (null != stDtofLtr && null == endDtofLtr) {
                searchCommRO.setNamedWhereClauseParam("bindDateofLetter", stDtofLtr);
                searchCommRO.setNamedWhereClauseParam("bindEndDtofletter", stDtofLtr);
            } else if (null == stDtofLtr && null != endDtofLtr) {
                searchCommRO.setNamedWhereClauseParam("bindDateofLetter", endDtofLtr);
                searchCommRO.setNamedWhereClauseParam("bindEndDtofletter", endDtofLtr);
            } else {
                searchCommRO.setNamedWhereClauseParam("bindDateofLetter", stDtofLtr);
                searchCommRO.setNamedWhereClauseParam("bindEndDtofletter", endDtofLtr);
            }
        } else {
            searchCommRO.removeApplyViewCriteriaName("findByDateofLetter");
        }
        if (null != SecStDate || null != SecEndDate) {
            if (null != stDtofLtr || null != endDtofLtr) {
                searchCommRO.setApplyViewCriteriaName("findByDateReceived", true);
            } else {
                searchCommRO.setApplyViewCriteriaName("findByDateReceived", false);
            }
            if (null != SecStDate && null == SecEndDate) {
                searchCommRO.setNamedWhereClauseParam("bindStDateReceived", SecStDate);
                searchCommRO.setNamedWhereClauseParam("bindEndDateReceived", SecStDate);
            } else if (null == SecStDate && null != SecEndDate) {
                searchCommRO.setNamedWhereClauseParam("bindStDateReceived", SecEndDate);
                searchCommRO.setNamedWhereClauseParam("bindEndDateReceived", SecEndDate);
            } else {
                searchCommRO.setNamedWhereClauseParam("bindStDateReceived", SecStDate);
                searchCommRO.setNamedWhereClauseParam("bindEndDateReceived", SecEndDate);
            }
        } else {
            searchCommRO.removeApplyViewCriteriaName("findByDateReceived");
        }
        logger.finer("Search Query" + searchCommRO.getQuery());
        searchCommRO.executeQuery();
        ;
    }

    public void searchFileNumbers(Integer index) {
        String type = null;
        String number = null;
        String releaseNumber = null;
        String subect = null;
        String fileNumber = null;
        String lName = null;
        String fName = null;
        String aPhone = null;
        Number typeId = null;
        SearchFileNumbersPRViewImpl searchFilesPrView = this.getSearchFileNumbersPRView1();
        if (null != searchFilesPrView) {
            SearchFileNumbersPRViewRowImpl searchFilesPrViewRow =
                (SearchFileNumbersPRViewRowImpl) searchFilesPrView.getCurrentRow();
            releaseNumber = searchFilesPrViewRow.getReleaseNumber();
            subect = searchFilesPrViewRow.getSubject();
            lName = searchFilesPrViewRow.getLastName();
            fName = searchFilesPrViewRow.getFirstName();
            aPhone = searchFilesPrViewRow.getAttorneyPhone();
            if ((null != index) || (0 != index.intValue())) {
                number = searchFilesPrViewRow.getFileNumber();
                RowSet rSet = searchFilesPrViewRow.getFileNumberTypeROView1();
                Row row = rSet.getRowAtRangeIndex(index - 1);
                if (null != row) {
                    type = (String) row.getAttribute("Code");
                    typeId = (Number) row.getAttribute("FilenumTypeId");
                }
                if ("OTH".equals(type)) {
                    fileNumber = number;
                } else if (null != type && !"OTH".equals(type)) {
                    fileNumber = type + "-" + number;
                }
            }
        }
        SearchFileNumbersROViewImpl searchFileRO = this.getSearchFileNumbersROView1();
        searchFileRO.setbindFileTypeId(typeId);
        searchFileRO.setbindFileNumber(number);
        searchFileRO.setbindReleaseNumber(releaseNumber);
        searchFileRO.setbindSubject(subect);
        searchFileRO.setbindFirstName(fName);
        searchFileRO.setbindLastName(lName);
        searchFileRO.setbindAttorneyPhone(aPhone);
        searchFileRO.executeQuery();
    }

    public void findByFileNumberId(Number FileNumId) {
        CllFilenumRelFrViewImpl filenumRel = (CllFilenumRelFrViewImpl) this.getCllFilenumRelFrView1();
        filenumRel.setApplyViewCriteriaName("findByFileNum", false);
        filenumRel.setNamedWhereClauseParam("bindFileNum", FileNumId);
        filenumRel.executeQuery();
        CllFilenumAttyViewImpl fileAtty = this.getCllFilenumAttyView1();
        fileAtty.setApplyViewCriteriaName("findByFileNum", false);
        fileAtty.setNamedWhereClauseParam("bindFileNum", FileNumId);
        fileAtty.executeQuery();

    }

    public void resetCommentsSearch() {
        this.initSearchComments();
    }

    public void resetFileNumberSearch() {
        this.initSearchFileNumbers();
    }


    /**
     * Container's getter for CllFilenumProcessingView1.
     * @return CllFilenumProcessingView1
     */
    public CllFilenumProcessingViewImpl getCllFilenumProcessingView1() {
        return (CllFilenumProcessingViewImpl) findViewObject("CllFilenumProcessingView1");
    }

    /**
     * Container's getter for FormLetterCountROView1.
     * @return FormLetterCountROView1
     */
    public FormLetterCountROViewImpl getFormLetterCountROView1() {
        return (FormLetterCountROViewImpl) findViewObject("FormLetterCountROView1");
    }

    /**
     * Container's getter for CllParentCommDetailsROView1.
     * @return CllParentCommDetailsROView1
     */
    public CllParentCommDetailsROViewImpl getCllParentCommDetailsROView1() {
        return (CllParentCommDetailsROViewImpl) findViewObject("CllParentCommDetailsROView1");
    }

    /**
     * Container's getter for CommentDetailsPublishingROView1.
     * @return CommentDetailsPublishingROView1
     */
    public ViewObjectImpl getCommentDetailsPublishingROView1() {
        return (ViewObjectImpl) findViewObject("CommentDetailsPublishingROView1");
    }

    /**
     * Container's getter for CllFilenumRelFrView2.
     * @return CllFilenumRelFrView2
     */
    public CllFilenumRelFrViewImpl getCllFilenumRelFrView2() {
        return (CllFilenumRelFrViewImpl) findViewObject("CllFilenumRelFrView2");
    }

    /**
     * Container's getter for CllInternalToSecQueueCommentsListROView1.
     * @return CllInternalToSecQueueCommentsListROView1
     */
    public CllInternalToSecQueueCommentsListROViewImpl getCllInternalToSecQueueCommentsListROView1() {
        return (CllInternalToSecQueueCommentsListROViewImpl) findViewObject("CllInternalToSecQueueCommentsListROView1");
    }

    /**
     * Container's getter for CllSubmitterForPublishingCommentROView1.
     * @return CllSubmitterForPublishingCommentROView1
     */
    public ViewObjectImpl getCllSubmitterForPublishingCommentROView1() {
        return (ViewObjectImpl) findViewObject("CllSubmitterForPublishingCommentROView1");
    }

    /**
     * Container's getter for CllSubmitterForPublishingCommentROView2.
     * @return CllSubmitterForPublishingCommentROView2
     */
    public ViewObjectImpl getCllSubmitterForPublishingCommentROView2() {
        return (ViewObjectImpl) findViewObject("CllSubmitterForPublishingCommentROView2");
    }

    /**
     * Container's getter for CllSubmitterCllCommDetForPublishingViewLink1.
     * @return CllSubmitterCllCommDetForPublishingViewLink1
     */
    public ViewLinkImpl getCllSubmitterCllCommDetForPublishingViewLink1() {
        return (ViewLinkImpl) findViewLink("CllSubmitterCllCommDetForPublishingViewLink1");
    }

    public void initMissingFileQueue() {
        CllCommentsListROViewImpl cmntsList = this.getCllCommentsListROView1();
        cmntsList.setApplyViewCriteriaName("findByMissingFileNumberCriteria", false);
        cmntsList.setOrderByClause("SEC_RECEIVED_DATE ");
        cmntsList.executeQuery();

    }

    public void initInternalSecQueue() {
        CllCommentsListROViewImpl cmntsList = this.getCllCommentsListROView1();
        cmntsList.setApplyViewCriteriaName("findByInternalToSECCriteria", false);
        cmntsList.setOrderByClause("SEC_RECEIVED_DATE ");
        cmntsList.executeQuery();
    }

    public void initDeletedQueue() {
        CllCommentsListROViewImpl cmntsList = this.getCllCommentsListROView1();
        cmntsList.setApplyViewCriteriaName("findByDeletedQueue", false);
        cmntsList.setOrderByClause("SEC_RECEIVED_DATE desc");
        cmntsList.executeQuery();
    }

    /**
     * Container's getter for CllStatusTypePRView1.
     * @return CllStatusTypePRView1
     */
    public CllStatusTypePRViewImpl getCllStatusTypePRView1() {
        return (CllStatusTypePRViewImpl) findViewObject("CllStatusTypePRView1");
    }

    public String assignInternalSecQueueComment(String action) {
        String rtn = null;
        Map staffInfo = this.getStaffDetailsByUserName(ADFContext.getCurrent()
                                                                 .getSecurityContext()
                                                                 .getUserName());
        oracle.jbo.domain.Number staffId = (Number) staffInfo.get("staffId");
        CllCommentsListROViewImpl cmntsList = this.getCllCommentsListROView1();
        if (null == staffId) {
            rtn = "User Not Found";
        } else {
            rtn = "User Found";
            RowSetIterator cmntsListIter = cmntsList.createRowSetIterator(null);
            cmntsListIter.reset();
            while (cmntsListIter.hasNext()) {
                CllCommentsListROViewRowImpl cmntsListRow = (CllCommentsListROViewRowImpl) cmntsListIter.next();
                if (null != cmntsListRow.getSelectAttr() && cmntsListRow.getSelectAttr()) {
                    CllCommentDetailsViewImpl cmntDetailsView = this.getCllCommentDetailsView2();
                    Key commntIdKey = new Key(new Object[] { cmntsListRow.getCllCommDetId() });
                    Row[] commntrows = cmntDetailsView.findByKey(commntIdKey, 1);
                    if (commntrows.length > 0) {
                        CllCommentDetailsViewRowImpl commntRow = (CllCommentDetailsViewRowImpl) commntrows[0];
                        if ("ASSIGN".equals(action)) {
                            commntRow.setAssigned(staffId);
                            commntRow.setAssignedDate(new oracle.jbo.domain.Date(new Timestamp(System.currentTimeMillis())));
                        }
                    }
                }
            }
            cmntsListIter.closeRowSetIterator();
            this.getDBTransaction().commit();
        }
        return rtn;
    }

    /**
     * Container's getter for DocumentTypeView1.
     * @return DocumentTypeView1
     */
    public ViewObjectImpl getDocumentTypeView1() {
        return (ViewObjectImpl) findViewObject("DocumentTypeView1");
    }

    /**
     * Container's getter for TemplateView1.
     * @return TemplateView1
     */
    public ViewObjectImpl getTemplateView1() {
        return (ViewObjectImpl) findViewObject("TemplateView1");
    }

    /**
     * Container's getter for FormLetterUnPubCountROView1.
     * @return FormLetterUnPubCountROView1
     */
    public FormLetterUnPubCountROViewImpl getFormLetterUnPubCountROView1() {
        return (FormLetterUnPubCountROViewImpl) findViewObject("FormLetterUnPubCountROView1");
    }

    /**
     * Container's getter for SearchFileNumbersROView1.
     * @return SearchFileNumbersROView1
     */
    public SearchFileNumbersROViewImpl getSearchFileNumbersROView1() {
        return (SearchFileNumbersROViewImpl) findViewObject("SearchFileNumbersROView1");
    }

    /**
     * Container's getter for SearchFileNumbersPRView1.
     * @return SearchFileNumbersPRView1
     */
    public SearchFileNumbersPRViewImpl getSearchFileNumbersPRView1() {
        return (SearchFileNumbersPRViewImpl) findViewObject("SearchFileNumbersPRView1");
    }

    /**
     * Container's getter for AttachmentPublishingROView1.
     * @return AttachmentPublishingROView1
     */
    public ViewObjectImpl getAttachmentPublishingROView1() {
        return (ViewObjectImpl) findViewObject("AttachmentPublishingROView1");
    }

    /**
     * Container's getter for CllFilenumCommDetROView1.
     * @return CllFilenumCommDetROView1
     */
    public CllFilenumCommDetROViewImpl getCllFilenumCommDetROView1() {
        return (CllFilenumCommDetROViewImpl) findViewObject("CllFilenumCommDetROView1");
    }

    /**
     * Container's getter for FileNumberTypeROView1.
     * @return FileNumberTypeROView1
     */
    public FileNumberTypeROViewImpl getFileNumberTypeROView1() {
        return (FileNumberTypeROViewImpl) findViewObject("FileNumberTypeROView1");
    }

    /**
     * Container's getter for CllCommentDetailsDetagView1.
     * @return CllCommentDetailsDetagView1
     */
    public CllCommentDetailsDetagViewImpl getCllCommentDetailsDetagView1() {
        return (CllCommentDetailsDetagViewImpl) findViewObject("CllCommentDetailsDetagView1");
    }

    /**
     * Container's getter for AttachmentROView1.
     * @return AttachmentROView1
     */
    public AttachmentROViewImpl getAttachmentROView1() {
        return (AttachmentROViewImpl) findViewObject("AttachmentROView1");
    }

    public void initManageCommentLog(String TypeCode, String DispCode) {
        FileNumberQueueROViewImpl fileQue = (FileNumberQueueROViewImpl) this.getFileNumberQueueROView1();
        if (null == TypeCode) {
            fileQue.setbindCode("UPRO");
        } else {
            fileQue.setbindCode(TypeCode);
        }
        fileQue.setbindDispCode(DispCode);
        fileQue.executeQuery();

        CommentInboxQueuesROViewImpl comntInboxQ = (CommentInboxQueuesROViewImpl) this.getCommentInboxQueuesROView1();
        comntInboxQ.clearCache();
        comntInboxQ.executeQuery();
    }

    /**
     * Container's getter for CllFileNumberView1.
     * @return CllFileNumberView1
     */
    public CllFileNumberViewImpl getCllFileNumberView1() {
        return (CllFileNumberViewImpl) findViewObject("CllFileNumberView1");
    }


    /**
     * Container's getter for CllFilenumberCommDetailsView1.
     * @return CllFilenumberCommDetailsView1
     */
    public CllFilenumberCommDetailsViewImpl getCllFilenumberCommDetailsView1() {
        return (CllFilenumberCommDetailsViewImpl) findViewObject("CllFilenumberCommDetailsView1");
    }

    /**
     * Container's getter for CllFilenumberCommDetailsCllCommentDetFKLink1.
     * @return CllFilenumberCommDetailsCllCommentDetFKLink1
     */
    public ViewLinkImpl getCllFilenumberCommDetailsCllCommentDetFKLink1() {
        return (ViewLinkImpl) findViewLink("CllFilenumberCommDetailsCllCommentDetFKLink1");
    }

    /**
     * Container's getter for CllFilenumberCommDetailsView2.
     * @return CllFilenumberCommDetailsView2
     */
    public CllFilenumberCommDetailsViewImpl getCllFilenumberCommDetailsView2() {
        return (CllFilenumberCommDetailsViewImpl) findViewObject("CllFilenumberCommDetailsView2");
    }

    /**
     * Container's getter for FileNumCommDetSeqNumROView1.
     * @return FileNumCommDetSeqNumROView1
     */
    public ViewObjectImpl getFileNumCommDetSeqNumROView1() {
        return (ViewObjectImpl) findViewObject("FileNumCommDetSeqNumROView1");
    }

    public void updateSelectedActiontoComments(String action, Map inputMap) {
        CllCommentsListROViewImpl cmntsList = this.getCllCommentsListROView1();
        RowSetIterator cmntsListIter = cmntsList.createRowSetIterator(null);
        cmntsListIter.reset();
        while (cmntsListIter.hasNext()) {
            CllCommentsListROViewRowImpl cmntsListRow = (CllCommentsListROViewRowImpl) cmntsListIter.next();
            if (null != cmntsListRow.getSelectAttr() && cmntsListRow.getSelectAttr()) {
                CllCommentDetailsViewImpl cmntDetailsView = this.getCllCommentDetailsView2();
                Key commntIdKey = new Key(new Object[] { cmntsListRow.getCllCommDetId() });
                Row[] commntrows = cmntDetailsView.findByKey(commntIdKey, 1);
                if (commntrows.length > 0) {
                    logger.info(String.format("CommentLogAppModuleImpl.updateSelectedActiontoComments :: Updating %s to Comment Id %s",
                                              action, cmntsListRow.getCllCommDetId()));
                    CllCommentDetailsViewRowImpl commntRow = (CllCommentDetailsViewRowImpl) commntrows[0];
                    if ("ACTION".equals(action)) {
                        Number cllActionTypeId = (Number) inputMap.get("CllActionTypeId");
                        commntRow.setCllActionTypeId(cllActionTypeId);
                    } else if ("FINAL_ACTION".equals(action)) {
                        Number cllDispositionTypeId = (Number) inputMap.get("CllDispositionTypeId");
                        String dispTypeCode = (String) inputMap.get("DispTypeCode");
                        dispTypeCode = StringUtils.trimToEmpty(dispTypeCode);
                        String otherDisposition = (String) inputMap.get("OtherDisposition");
                        otherDisposition = StringUtils.trimToEmpty(otherDisposition);
                        Number cllStatusTypeId = getCllStatusTypeView1().getStatusTypeId("PRO");
                        if (!dispTypeCode.isEmpty()) {
                            if ("OTH".equals(dispTypeCode)) {
                                commntRow.setOtherDisposition(otherDisposition);
                            } else {
                                commntRow.setOtherDisposition(null);
                            }
                        }
                        commntRow.setCllDispositionTypeId(cllDispositionTypeId);
                        commntRow.setCllStatusTypeId(cllStatusTypeId);
                        commntRow.setDispositionDate(new oracle.jbo.domain.Date(new Timestamp(System.currentTimeMillis())));

                        //Update SR sequence if Final Action is Approve and SR File Number
                        String fileNumTypeCode = (String) inputMap.get("fileNumTypeCode");
                        Number fileNumId = (Number) inputMap.get("fileNumId");
                        logger.info("CommentLogAppModuleImpl.updateSelectedActiontoComments :: fileNumTypeCode : " +
                                    fileNumTypeCode);
                        logger.info("CommentLogAppModuleImpl.updateSelectedActiontoComments :: dispTypeCode : " +
                                    dispTypeCode);
                        if (dispTypeCode != null && fileNumTypeCode != null && dispTypeCode.equalsIgnoreCase("APPR") &&
                            fileNumTypeCode.equalsIgnoreCase("SR")) {
                            logger.info("CommentLogAppModuleImpl.updateSelectedActiontoComments :: fileNumId : " +
                                        fileNumId);
                            CllFilenumberCommDetailsViewImpl cllFleNumComDetView =
                                this.getCllFilenumberCommDetailsView2();
                            Number currSeqNumber =
                                cllFleNumComDetView.getSRSeqNumber(cmntsListRow.getCllCommDetId(), fileNumId);
                            if (null == currSeqNumber) {
                                Number nextSeqNumber =
                                    this.getCllFileNumberView1().getSetFileNumberSeqNumberNext(fileNumId);
                                logger.info("nextSeqNumber : " + nextSeqNumber);
                                cllFleNumComDetView.assignSRSeqNumber(cmntsListRow.getCllCommDetId(), fileNumId,
                                                                      nextSeqNumber);
                            }
                        }


                    } else if ("COMMENT".equals(action)) {
                        Number cllTypeId = (Number) inputMap.get("CllTypeId");
                        String cllTypeCode = (String) inputMap.get("CllTypeCode");
                        String cllTypeOtherCode = (String) inputMap.get("CllTypeOtherDesc");
                        String cllCurrTypeCode = cmntsListRow.getCllTypeCode();
                        commntRow.setCllTypeId(cllTypeId);
                        if (null != cllCurrTypeCode && "FL".equals(cllCurrTypeCode)) {
                            commntRow.setCllFormLetterId(null);
                        } else if (null != cllCurrTypeCode && "OTH".equals(cllCurrTypeCode)) {
                            commntRow.setCllTypeOtherDesc(null);
                        }
                        if (null != cllTypeCode && "OTH".equals(cllTypeCode) && null != cllTypeOtherCode) {
                            commntRow.setCllTypeOtherDesc(cllTypeOtherCode);
                        }
                    } else if ("SOURCE".equals(action)) {
                        Number sourceTypeId = (Number) inputMap.get("sourceTypeId");
                        commntRow.setCllSourceTypeId(sourceTypeId);
                    } else if ("DELETE".equals(action)) {
                        Number statusTypeId = (Number) inputMap.get("CllStatusTypeId");
                        commntRow.setCllStatusTypeId(statusTypeId);
                    }
                }
            }
        }
        cmntsListIter.closeRowSetIterator();
        this.commitTransaction();
    }

    /**Invokes  custom data control methods from CllFilenumCommDetBulkActionViewImpl to
     * delete a file nubmer or change existing file number for a comment
     *
     * @param commIds
     * @param fileNumIdOld
     * @param fileNumIdNew
     * @param fileNumTypeCode
     */
    public void changeFileNumber(List<Number> commIds, Number fileNumIdOld, Number fileNumIdNew,
                                 String fileNumTypeCode) {
        for (Number commDetId : commIds) {
            boolean fileNumExists = this.getCllFilenumCommDetROView1().commentHasFileNumId(commDetId, fileNumIdNew);
            if (fileNumExists) {
                //delete  old file number
                this.getCllFilenumCommDetBulkActionView1().deleteFileNumCommDet(commDetId, fileNumIdOld);
            } else {

                this.getCllFilenumCommDetBulkActionView1()
                    .changeFileNumCommDet(commDetId, fileNumIdOld, fileNumIdNew, fileNumTypeCode);
            }
        }

    }

    /**Removes the file number from each of the comment in the list
     *
     * @param commIds
     * @param fileNumid
     */
    public void removeFileNumFromComments(List<Number> commIds, Number fileNumid) {
        for (Number commDetId : commIds) {
            boolean fileNumExists = this.getCllFilenumCommDetROView1().commentHasFileNumId(commDetId, fileNumid);
            if (fileNumExists) {
                //delete  old file number
                this.getCllFilenumCommDetBulkActionView1().deleteFileNumCommDet(commDetId, fileNumid);
            }
        }
    }

    // CASSECDEV-6085 : CASSECDEV-6117 : Changes for File Number Publishing
    public void initFileNumPubCommentLog() {
        FileNumberPubQueueROViewImpl fileQue = (FileNumberPubQueueROViewImpl) this.getFileNumberPubQueueROView1();
        fileQue.executeQuery();
    }

    public List<Number> getFileNumPublishCommentIdList(oracle.jbo.domain.Number filerNumId, String typeCode) {
        logger.info("In getFileNumPublishCommentIdList... filerNumId:" + filerNumId + "   typeCode:" + typeCode);
        ArrayList<Number> commentIds = new ArrayList<Number>();
        try {
            if (typeCode == null) {
                typeCode = "CL";
            }
            Number typeId = null;
            CllStatusPRViewRowImpl statusRow = (CllStatusPRViewRowImpl) this.createRow("CllStatusPRView1");
            RowSetIterator rSetIter =
                statusRow.getCommentLogCommonAppModule_CllTypeROView1_1().createRowSetIterator(null);
            rSetIter.reset();
            while (rSetIter.hasNext()) {
                Row r = rSetIter.next();
                if (r.getAttribute("Code").equals(typeCode)) {
                    typeId = (Number) r.getAttribute("CllTypeId");
                }
            }
            rSetIter.closeRowSetIterator();
            CllFileNumPubCommListROViewImpl commentList = this.getCllFileNumPubCommListROView1();
            commentList.setApplyViewCriteriaName("findByCommentsCriteria", false);
            commentList.setNamedWhereClauseParam("bindFileNum", filerNumId);
            commentList.setNamedWhereClauseParam("bindType", typeId);
            commentList.setOrderByClause("LETTER_DATE desc");
            commentList.executeQuery();
            //logger.info("In getFileNumPublishCommentsList... Comment List Query : " + commentList.getQuery());
            logger.info("In getFileNumPublishCommentsList.... cmntsList RowCount:" + commentList.getRowCount());
            while (commentList.hasNext()) {
                CllFileNumPubCommListROViewRowImpl commentRow = (CllFileNumPubCommListROViewRowImpl) commentList.next();
                commentIds.add(commentRow.getCllCommDetId());
            }
        } catch (Exception e) {
            logger.warning("In getFileNumPublishCommentsList.... " + e, e);
        }
        logger.info("In getFileNumPublishCommentsList.... b4 return commentIds size:" + commentIds.size());
        return commentIds;
    }


    /**
     * Container's getter for CllFilenumCommDetBulkActionView1.
     * @return CllFilenumCommDetBulkActionView1
     */
    public CllFilenumCommDetBulkActionViewImpl getCllFilenumCommDetBulkActionView1() {
        return (CllFilenumCommDetBulkActionViewImpl) findViewObject("CllFilenumCommDetBulkActionView1");
    }


    /**
     * Container's getter for CllSubmitterRepView1.
     * @return CllSubmitterRepView1
     */
    public ViewObjectImpl getCllSubmitterRepView1() {
        return (ViewObjectImpl) findViewObject("CllSubmitterRepView1");
    }

    /**
     * Container's getter for CllSubmitterRepCllCommentFKLink1.
     * @return CllSubmitterRepCllCommentFKLink1
     */
    public ViewLinkImpl getCllSubmitterRepCllCommentFKLink1() {
        return (ViewLinkImpl) findViewLink("CllSubmitterRepCllCommentFKLink1");
    }

    /**
     * Container's getter for CllOrigInCommentROView1.
     * @return CllOrigInCommentROView1
     */
    public CllOrigInCommentROViewImpl getCllOrigInCommentROView1() {
        return (CllOrigInCommentROViewImpl) findViewObject("CllOrigInCommentROView1");
    }

    /**
     * Container's getter for FileNumberPubQueueROView1.
     * @return FileNumberPubQueueROView1
     */
    public FileNumberPubQueueROViewImpl getFileNumberPubQueueROView1() {
        return (FileNumberPubQueueROViewImpl) findViewObject("FileNumberPubQueueROView1");
    }

    /**
     * Container's getter for CllFileNumPubCommListROView1.
     * @return CllFileNumPubCommListROView1
     */
    public CllFileNumPubCommListROViewImpl getCllFileNumPubCommListROView1() {
        return (CllFileNumPubCommListROViewImpl) findViewObject("CllFileNumPubCommListROView1");
    }

    /**
     * Container's getter for FormLetterTypesCountROView1.
     * @return FormLetterTypesCountROView1
     */
    public FormLetterTypesCountROViewImpl getFormLetterTypesCountROView1() {
        return (FormLetterTypesCountROViewImpl) findViewObject("FormLetterTypesCountROView1");
    }

    /**
     * Container's getter for CommentInboxQueuesROView1.
     * @return CommentInboxQueuesROView1
     */
    public CommentInboxQueuesROViewImpl getCommentInboxQueuesROView1() {
        return (CommentInboxQueuesROViewImpl) findViewObject("CommentInboxQueuesROView1");
    }
}
