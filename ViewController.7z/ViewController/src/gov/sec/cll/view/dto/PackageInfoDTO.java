package gov.sec.cll.view.dto;

import java.util.Map;

public class PackageInfoDTO {
    
    private String targetDirectory;
    private String fileNumber;
    private String formLetterSubType;
    private Map<String,String> indexPageInfo;
    private Map<String, String> formLetterCommntInfo; 
    private Map<String,String> commentLetHtmlPageInfo; 
    
    
    public PackageInfoDTO() {
        super();
    }
    
    public void setTargetDirectory(String targetDirectory) {
        this.targetDirectory = targetDirectory;
    }

    public String getTargetDirectory() {
        return targetDirectory;
    }

    public void setIndexPageInfo(Map<String, String> indexPageInfo) {
        this.indexPageInfo = indexPageInfo;
    }

    public Map<String, String> getIndexPageInfo() {
        return indexPageInfo;
    }

    public void setFormLetterCommntInfo(Map<String, String> formLetterCommntInfo) {
        this.formLetterCommntInfo = formLetterCommntInfo;
    }

    public Map<String, String> getFormLetterCommntInfo() {
        return formLetterCommntInfo;
    }
 

   
    public void setFileNumber(String fileNumber) {
        this.fileNumber = fileNumber;
    }

    public String getFileNumber() {
        return fileNumber;
    }

    public void setCommentLetHtmlPageInfo(Map<String, String> commentLetHtmlPageInfo) {
        this.commentLetHtmlPageInfo = commentLetHtmlPageInfo;
    }

    public Map<String, String> getCommentLetHtmlPageInfo() {
        return commentLetHtmlPageInfo;
    }

    public void setFormLetterSubType(String formLetterSubType) {
        this.formLetterSubType = formLetterSubType;
    }

    public String getFormLetterSubType() {
        return formLetterSubType;
    }
}
