package gov.sec.cll.view.dto;

import java.io.Serializable;

public class ForwardCommentDTO implements Serializable{
    
    private String subject;
    private String comment;
    
    public ForwardCommentDTO() {
        super();
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSubject() {
        return subject;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getComment() {
        return comment;
    }
}
