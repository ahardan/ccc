package gov.sec.cll.view.utils;

import java.util.Collection;
import java.util.Collections;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import oracle.adf.share.logging.ADFLogger;

import org.apache.myfaces.trinidad.convert.ClientConverter;

public class BooleanConverter implements Converter, ClientConverter {

    public BooleanConverter() {
        super();
    }

    public Object getAsObject(FacesContext facesContext,
                              UIComponent uiComponent, String value) {
        return "true".equals(value) ? "Y" : "N";
    }

    public String getAsString(FacesContext facesContext,
                              UIComponent uiComponent, Object value) {
        return "Y".equals(value) ? "true" : "false";
    }

    public String getClientLibrarySource(FacesContext facesContext) {
        return null;
    }

    public Collection<String> getClientImportNames() {
        return Collections.emptySet();
    }

    public String getClientScript(FacesContext facesContext,
                                  UIComponent uiComponent) {
        return null;
    }

    public String getClientConversion(FacesContext facesContext,
                                      UIComponent uiComponent) {
        return null;
    }
}
