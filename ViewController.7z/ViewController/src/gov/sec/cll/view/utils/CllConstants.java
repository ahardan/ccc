package gov.sec.cll.view.utils;

public class CllConstants {

    //Comment status type codes
    public static final String CLL_STATUS_TYPE_CODE_UPRO = "UPRO";
    public static final String CLL_STATUS_TYPE_CODE_PRO = "PRO";
    public static final String CLL_STATUS_TYPE_CODE_PUB = "PUB";
    public static final String CLL_STATUS_TYPE_CODE_HLD = "HLD";
    public static final String CLL_STATUS_TYPE_CODE_FWD = "FWD";
    public static final String CLL_STATUS_TYPE_CODE_DEL = "DEL";

    //Comment Type codes
    public static final String CLL_TYPE_CODE_COMMENT_LETTER = "CL";
    public static final String CLL_TYPE_CODE_FORM_LETTER = "FL";
    public static final String CLL_TYPE_CODE_MEMO = "ME";
    public static final String CLL_TYPE_CODE_STAFF = "SS";
    public static final String CLL_TYPE_CODE_OTHER = "OTH";

    //Comment Type Descritions
    public static final String CLL_TYPE_DESC_COMMENT_LETTER = "Comment Letter";
    public static final String CLL_TYPE_DESC_CODE_FORM_LETTER = "Form Letter";
    public static final String CLL_TYPE_DESC_CODE_MEMO = "Memos";
    public static final String CLL_TYPE_DESC_CODE_STAFF = "Staff Study";
    public static final String CLL_TYPE_DESC_CODE_OTHER = "Other";

    //Comment Source Types
    public static final String CLL_SOURCE_TYPE_SG = "SG";
    public static final String CLL_SOURCE_TYPE_EM = "EM";
    public static final String CLL_SOURCE_TYPE_RM = "RM";
    public static final String CLL_SOURCE_TYPE_FX = "FX";
    public static final String CLL_SOURCE_TYPE_OTH = "OTH";

    // Disposition types
    public static final String CLL_DISPOSITION_TYPE_APPR = "APPR";
    public static final String CLL_DISPOSITION_TYPE_REJ = "REJ";
    public static final String CLL_DISPOSITION_TYPE_TCR = "TCR";
    public static final String CLL_DISPOSITION_TYPE_FISA = "FISA";
    public static final String CLL_DISPOSITION_TYPE_FTHLP = "FTHLP";
    public static final String CLL_DISPOSITION_TYPE_RCER = "RCER";
    public static final String CLL_DISPOSITION_TYPE_NWEB = "NWEB";
    public static final String CLL_DISPOSITION_TYPE_NPOS = "NPOS";
    public static final String CLL_DISPOSITION_TYPE_PFOS = "PFOS";
    public static final String CLL_DISPOSITION_TYPE_OTH = "OTH";
    public static final String RESOURCE_BUNDLE_LOCATION = "gov/sec/cll/view/ViewControllerBundle";

    // origination to comment details task flow
    public static final String ORIGINATION_COMMENTS_INBOX_Q = "COMMENTS_INBOX_Q";
    public static final String ORIGINATION_COMMENTS_Q = "COMMENTS_Q";
    public static final String ORIGINATION_FORMS_Q = "FORMS_Q";
    public static final String ORIGINATION_MEMOS_Q = "MEMOS_Q";
    public static final String ORIGINATION_STAFF_STUDY_Q = "STAFF_STUDY_Q";
    public static final String ORIGINATION_OTHER_Q = "OTHER_Q";
    public static final String ORIGINATION_MISSING_FILENUM_Q = "MISSING_FILENUM_Q";
    public static final String ORIGINATION_DELETED_Q = "DELETED_Q";
    public static final String CLL_MODULE = "CLL";
    public static final String ORIGINATION_COMMENT_LIST_TAB="COMMENT_LIST_TAB";
    public static final String ORIGINATION_FORMLETTER_LIST_TAB="FORMLETTER_LIST_TAB";   
    public static final String ORIGINATION_INTERNAL_TOSEC_Q = "INTERNAL_TO_SEC_Q";
    
    public static final String PROXY_STATUS_SUCCESS = "Success";

    // Template Code
    public static final String FORMLETTER_INDEXPAGE_TEMPLATE_CODE = "FLIP";
    public static final String FORMLETTER_COMMENTPAGE_TEMPLATE_CODE = "FLCP";
    public static final String COMMENTlETTER_INDEXPAGE_TEMPLATE_CODE = "CLIP";
    public static final String COMMENTlETTER_HTMLPAGE_TEMPLATE_CODE = "CLHP";
    public static final String COMMENTlETTER_EMPTY_SUBMTTER_NAME= "NA,NA";
    public static final String COMMENTlETTER_EMPTY_STAFF_NOTES= "NA";
    public static final String FILENUMPUB_FORMLETTER_INDEXPAGE_TEMPLATE_CODE = "FNPFLIP";
    public static final String FILENUMPUB_FORMLETTER_COMMENTPAGE_TEMPLATE_CODE = "FNPFLCP";
    
    //Comment Inbox Title
    public static final String COMMENT_INBOX_TITLE = "Comment Inbox";
    public static final String PUBLISHING_QUEUE_TITLE = "Publishing Queue";
    
    //Net button click or Prev Button click
    public static final String NEXT_COMMENT = "NEXT";
    public static final String PREVIOUS_COMMENT = "PREV";
    
    //File Number Type codes
    public static final String FILE_NUMBER_TYPE_SR_CODE = "SR";
    public static final String FILE_NUMBER_TYPE_CLL_CODE = "CLL";
    
    //File extension types.
    public static final String FILE_TYPE_EXTENSION_DOCX = ".docx";
    public static final String FILE_TYPE_EXTENSION_DOC = ".doc";
    public static final String FILE_TYPE_EXTENSION_PDF = ".pdf";
    public static final String FILE_TYPE_EXTENSION_HTML = ".htm";
    
    // Regular Expression for case-sensitive String replaceAll.
    public static final String CASE_SENSITIVE_REGEX = "(?i)";
    
    // delimiter
    public static final String INDEXPAGE_SUBMITTER_DELIMITER = "; ";
    
    // origination to comment list and Form List task flow
    public static final String ORIGINATION_FROM_FILE_NUMBER_PUB = "FILE_NUMBER_PUBLISHING";
    
}
