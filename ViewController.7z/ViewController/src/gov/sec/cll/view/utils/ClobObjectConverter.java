package gov.sec.cll.view.utils;


import gov.sec.cll.view.beans.ViewCommentDetails;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;

import oracle.adf.share.logging.ADFLogger;

import oracle.jbo.domain.ClobDomain;

public class ClobObjectConverter implements Converter {
    
    private static ADFLogger logger = ADFLogger.createADFLogger(ClobObjectConverter.class); 
    
    public ClobObjectConverter() {
    }
   
    /** Custom converter to handle  Clob object assigned to UI component
     *
     * @param context
     * @param component
     * @param value
     * @return
     */
    public Object getAsObject(FacesContext context, UIComponent component,
                              String value) {
        logger.info("Inside  getAsObject()   of  CLOB converter  ********************************");
        if (context == null || component == null) {
            throw new NullPointerException("FacesContext and UIComponent turned out to be null ******************* ");
        }
        if (value == null) {
            return null;
        }
        try {
            //logger.info("Before conversion  the   string is  : " +value );
            //logger.info("**********************************************************************************");  
            return new ClobDomain(value);  
            
        } catch (Exception ex) {
            final String message =" error";
            
            throw new ConverterException(message, ex);
        }
    }

   /**Converts  CLOB object to String for display purpose
     *
     * @param context
     * @param component
     * @param value
     * @return
     */
    public String getAsString(FacesContext context,
        UIComponent component,
        Object value) {
       
       logger.info("Inside  getAsString()   of  CLOB converter  ********************************");
        if (context == null || component == null) {
            throw new NullPointerException("FacesContext and UIComponent turned out to be null *******************");
        }
        return value.toString();
    }
   
   /**Converts spcial character to normal UTF-8 character in text
     *
     * @param s
     * @return
     */
    public static StringBuilder convertSpecialChars(StringBuilder s){  
           replaceChar(s,'\uFFFD', '\u0020');  
          return s; 
    }
    
   
    
    public static void replaceChar(StringBuilder sb, char from, char to)
    {
        for (int index = 0; index < sb.length(); index++) {
            if (sb.charAt(index) == from) {
                logger.info("Came across conversion of unitcodes *************************************");
                sb.setCharAt(index, to);
            }
        }
    }


}



