package gov.sec.cll.view.utils;

import gov.sec.cll.model.adfbc.views.CllCommentDetailsViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllCommentsListROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumCommDetViewRowImpl;
import gov.sec.cll.sharedcomponents.view.bundles.DatabaseResourceBundle;
import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;
import gov.sec.cll.sharedcomponents.view.utils.JSFUtils;
import gov.sec.cll.sharedcomponents.view.wrapper.RellogServicesWrapper;
import gov.sec.cll.view.beans.CommentList;
import gov.sec.cll.view.beans.InternalToSecQueue;
import gov.sec.cll.view.beans.MissingFileNumberQList;
import gov.sec.rellog.filenumber.view.dto.ReturnMasterFileNumberDTO;

import java.sql.Date;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.context.FacesContext;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.binding.OperationBinding;

import oracle.jbo.JboException;
import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.domain.Number;
import oracle.jbo.server.EntityImpl;
import oracle.jbo.server.ViewRowImpl;

import org.apache.myfaces.trinidad.model.RowKeySet;

public class CllUtils {
    
    public CllUtils() {
        super();
    }
    
    private static ADFLogger logger = ADFLogger.createADFLogger(CllUtils.class);
    private static final ResourceBundle rb =
                ResourceBundle.getBundle(CllConstants.RESOURCE_BUNDLE_LOCATION);
    
    /** Returns  user name of current logged in user
     *
     * @return user name
     */
    public static String getCurrentUserName(){
        ADFContext adfc = ADFContext.getCurrent();
        return   adfc.getSecurityContext().getUserName(); 
    }
    
    public static Number getStaffId(){ 
      logger.info("Starting getStaffId in CllUtils ********************** ");  
        Number staffId=null;
        try {
               String userName=CllUtils.getCurrentUserName(); 
               logger.info("User name currently logged in is ******************** "+userName);
               logger.info("User name currently logged in is ******************** "+userName);
             // String userName="clluser_ops2";
              OperationBinding operation = ADFUtils.findOperation("getStaffDetailsByUserName");
              operation.getParamsMap().put("userName",userName );
              operation.execute();
              Map<String,Object> staffDetails=(Map<String,Object>)operation.getResult();
              logger.info("Staff id retrieved  inside getStaffId   is "+ staffId);
              staffId= (Number)staffDetails.get("staffId"); 
          }catch (JboException e){
               String msg=rb.getString("VIEWCOMMENTINBOX_UNABLETOGET_STAFFDETAILS");  //token exists already and using the same
               JSFUtils.addFacesErrorMessage(msg);  
           } catch (Exception e){ 
                e.printStackTrace();
                String msg=rb.getString("VIEWCOMMENTINBOX_UNABLETOGET_STAFFDETAILS");  //token exists already and using the same
                JSFUtils.addFacesErrorMessage(msg);   
           }  
        logger.info("Ending getStaffId in CllUtils ********************** ") ;
        return staffId;
    }
    
    
    /**
      * This method returns the  bean instance using expression evaluation 
      * @param expr  -- expression language expression containing bean name along with scope of the bean
      * @return Object --  bean object 
      */    
     public static Object getBeanInstance(String expr){      
       FacesContext ctx = FacesContext.getCurrentInstance();
       return ctx.getApplication().evaluateExpressionGet(ctx, expr,Object.class);         
     }
    
    
    /**
      *Verifies  any pending change exist in the iterator CllCommentDetailsView1Iterator
      * @param iteratorName
      * @return
      */
     public static  boolean existIteratorPendingChangesCommDet(final String iteratorName) {
         logger.info("Starting  existIteratorPendingChangesCommDet() .... ");
         logger.info("Verifying changes in " + iteratorName);
         boolean changesExist = false;
         DCIteratorBinding iterator = ADFUtils.findIterator(iteratorName); 
         CllCommentDetailsViewRowImpl currentRow = (CllCommentDetailsViewRowImpl)iterator.getCurrentRow();  
         if (currentRow != null) {
             logger.info("Current comment ID  "  +currentRow.getCllCommDetId().toString());  
             EntityImpl entityImpl = currentRow.getEntity(0);
             byte entityState = entityImpl.getEntityState();
             logger.info("Entity State = " + entityState);
             if (EntityImpl.STATUS_NEW == entityState || EntityImpl.STATUS_MODIFIED == entityState) { 
                   //TODO  below code is kept because many a times, we had to revert to below snippet to check what exactly is modified
                     /*  if(existIteratorPendingChanges("CllFilenumCommDetView1Iterator")){ 
                            logger.info("CHANGED CHANGED   CllFilenumCommDetView1Iterator ************************************ ");
                            return true;  
                        }
                        if(existIteratorPendingChanges("CllSubmitterView1Iterator")){ 
                            logger.info("CHANGED CHANGED   CllSubmitterView1Iterator ************************************ "); 
                            return true;
                        } 
                      
                        if( currentRow.isAttributeChanged("CllTypeId")){  
                            logger.info("CHANGED CHANGED   CllTypeId ************************************ "); 
                            return true;  
                        }
                         if( currentRow.isAttributeChanged("CllSourceTypeId")){  
                             logger.info("CHANGED CHANGED   CllSourceTypeId ************************************ "); 
                             return true;  
                         }
                        if( currentRow.isAttributeChanged("CllDispositionTypeId")){  
                            logger.info("CHANGED CHANGED   CllDispositionTypeId ************************************ "); 
                            return true;  
                        }
                        
                        if( currentRow.isAttributeChanged("DispositionDate")){  
                            logger.info("CHANGED CHANGED   DispositionDate ************************************ "); 
                            return true;  
                        }
                        if( currentRow.isAttributeChanged("StaffNotes")){  
                            logger.info("CHANGED CHANGED   StaffNotes ************************************ "); 
                            return true;  
                        }
                        if( currentRow.isAttributeChanged("OtherDisposition")){  
                            logger.info("CHANGED CHANGED   OtherDisposition ************************************ "); 
                            return true;  
                        }
                        if( currentRow.isAttributeChanged("SecReceivedDate")){  
                            logger.info("CHANGED CHANGED   SecReceivedDate ************************************ "); 
                            return true;  
                        }
                        if( currentRow.isAttributeChanged("LetterDate")){  
                            logger.info("CHANGED CHANGED   LetterDate ************************************ "); 
                            return true;  
                        }
                       
                        if( currentRow.isAttributeChanged("Subject")){  
                             logger.info("CHANGED CHANGED   Subject ************************************ "); 
                             return true;  
                        }  
                        
                        if( currentRow.isAttributeChanged("CllFormLetterId")){  
                            logger.info("CHANGED CHANGED   CllFormLetterId ************************************ "); 
                            return true;  
                        }
                         if( currentRow.isAttributeChanged("Count1")){ 
                             logger.info("CHANGED CHANGED   Count1 ************************************ ");  
                             return true;
                         } 
                         if( currentRow.isAttributeChanged("Comments")){  
                             logger.info("CHANGED CHANGED   Comments ************************************ ");  
                             return true;  
                         }   */
                 logger.info("Comment Letter Log  is modified     ************************************ ");
                 changesExist = true;
             } else {
                 logger.info("Changes do not exist in the iterator .."+iteratorName);
                 changesExist = false;
             }
         }
         logger.info(String.format("Pending changes [%s] :: %b", iteratorName, changesExist));
         logger.info("Ending  existIteratorPendingChangesCommDet() .... ");
         return changesExist;
     }
    
    
    
    /**
      *Verifies  any pending change exist in the iterator other than CllCommentDetailsView1Iterator
      * @param iteratorName
      * @return
      */
     public static  boolean existIteratorPendingChanges(final String iteratorName) {
        logger.info("Starting  existIteratorPendingChanges() .... ");
                 logger.info("Verifying changes in " + iteratorName);
                 boolean changesExist = false;
                 DCIteratorBinding iterator = ADFUtils.findIterator(iteratorName);
                 ViewRowImpl currentRow = (ViewRowImpl)iterator.getCurrentRow(); 
                 if (currentRow != null) {
                     if(iteratorName.equals("CllFilenumCommDetView1Iterator")){
                         CllFilenumCommDetViewRowImpl currentFileNumberRow = (CllFilenumCommDetViewRowImpl)currentRow;  
                         logger.info("Current file number ID  "  +currentFileNumberRow.getFilenumId());
                         logger.info("Current comment ID  "  +currentFileNumberRow.getCllCommDetId());
                     }
                     EntityImpl entityImpl = currentRow.getEntity(0);
                     byte entityState = entityImpl.getEntityState();
                     logger.info("Entity State = " + entityState);
                     if (EntityImpl.STATUS_NEW == entityState || EntityImpl.STATUS_MODIFIED == entityState) {
                        // JSFUtils.addFacesErrorMessage("Pending changes exist. Save or cancel changes.");
                         changesExist = true;
                     } else {
                         logger.info("Changes do not exist in the iterator .."+iteratorName);
                         changesExist = false;
                     }
                 }
                 logger.info(String.format("Pending changes [%s] :: %b", iteratorName, changesExist));
                 logger.info("Ending  existIteratorPendingChanges() .... ");
                 return changesExist;
     }
     
    public static String removeSpecialCharsFromFileFolderName(String fileFolderName) {
        
        DatabaseResourceBundle dsbundle = new DatabaseResourceBundle();
        Map props = dsbundle.getResourceBundle();  
        if(null == props){
            logger.severe("Error   ....application  properties are empty returned by getResourceBundle() !!!**************************");
            JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_CHARS_NOT_ALLOWED_IN_FILENAME_FOLDERNAME_MSG"));    //this mesg already exists in resource bundle
            return null;
        } 
        if(null == props.get("CHARS_NOT_ALLOWED_IN_FILENAME_FOLDERNAME") ){ 
            logger.severe("Error   ... property is empty  !!!**************************");
            JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_CHARS_NOT_ALLOWED_IN_FILENAME_FOLDERNAME_MSG"));    //this mesg already exists in resource bundle
            return null;
        }
        String removeChars=(String)props.get("CHARS_NOT_ALLOWED_IN_FILENAME_FOLDERNAME");
        fileFolderName=fileFolderName.replaceAll(removeChars, ""); 
        return fileFolderName;
    }
     
    
   /** Sets the transient attribute SelectAttr  to true for  all the rows in bulk selection 
     *
     * @param rksSelectedRows
     * @param iteratorName
     * @return selected comment Ids
     */
    
    public static ArrayList<Number> getSelectedCommentsFromBulkProcess( RowKeySet rksSelectedRows, String iteratorName){
        ArrayList<Number>  commIds = new ArrayList<Number> ();
        if(null != rksSelectedRows && !rksSelectedRows.isEmpty() ){
            logger.info(" Number rows selected is  :  "+ rksSelectedRows.size());
            if(rksSelectedRows.size() <=0 ){
                //bulk selection is not done
                return commIds;
            }
            DCIteratorBinding commListIterator = ADFUtils.findIterator(iteratorName); 
            if (null == commListIterator) {
                return commIds;
            }
            RowSetIterator rsiSelectedRows = commListIterator.getRowSetIterator();
            Iterator rksSelectedRowsIter= rksSelectedRows.iterator();
            // Changes for CASSECDEV-6076: Added TreeMap to sort the comment Ids by received date.
            Map<Number, Date> unSortedCommentIdMap = new HashMap<Number, Date>();
            while(rksSelectedRowsIter.hasNext()){
                Key key = (Key)((List)rksSelectedRowsIter.next()).get(0);
                CllCommentsListROViewRowImpl  row=(CllCommentsListROViewRowImpl )rsiSelectedRows.getRow(key);
                //logger.info(" Comment id in the bulk selection  :  "+ row.getAttribute("CllCommDetId")); 
               
                unSortedCommentIdMap.put((Number)row.getAttribute("CllCommDetId"), (Date)row.getAttribute("LetterDate"));
                row.setAttribute("SelectAttr",true); 
            }            
            // Changes for CASSECDEV-6076: sortMapByValue() will sort the map by values in descending order.
            Map<Number, Date> sortedCommentIdMap = sortMapByValue(unSortedCommentIdMap);
            logger.info(" Sorted by Descending order Comment Ids " +sortedCommentIdMap);
            for(Map.Entry<Number, Date> entryCommId : sortedCommentIdMap.entrySet()){
                commIds.add(entryCommId.getKey());
            }
        } 
        logger.info(" Selected comments  " +commIds);
        return commIds;
        
    }
     
   
   
    
    /** Clears the SelectAttr  attribute for the iterator which typically we need to do in the bulk selection since
     * check box checks are not visible for the rows that are selected in the bulk selection
     *
     * @param iteratorName
     * @return boolean    
     */
    public static boolean clearBulkSelection(String iteratorName) {
        DCIteratorBinding commListIterator =
            ADFUtils.findIterator(iteratorName);
        if (null == commListIterator) {
            return false;
        }
        RowSetIterator rsi =
            commListIterator.getViewObject().createRowSetIterator(null);
        while (rsi.hasNext()) {
            CllCommentsListROViewRowImpl row =
                (CllCommentsListROViewRowImpl)rsi.next();
            row.setAttribute("SelectAttr", false);
        }
        rsi.closeRowSetIterator();
        return true;
    }
    
    /**
     * Finds the file number id by   type id and file number 
     * 
     * @param fileNumTypeId  
     * @param fileNumber
     * @return  File Number Id
     */
    public static  Number findFileNumberIdByTypeIdFileNumber(Number fileNumTypeId, String fileNumber,Number masterFileNumId){
        logger.info("Starting findFileNumberIdByTypeIdFileNumber *************");
        OperationBinding operation = ADFUtils.findOperation("getFileNumId");
        operation.getParamsMap().put("fileNumTypeId", fileNumTypeId);
        operation.getParamsMap().put("fileNumber", fileNumber);
        operation.getParamsMap().put("masterFileNumId", masterFileNumId);
        operation.execute();
        if (operation.getErrors().isEmpty()){
            if(null  != operation.getResult()){ 
                     Number fileNumId = (Number)operation.getResult();
                    logger.info("Found File Number   : " + fileNumId);
                    logger.info("Ending findFileNumberIdByTypeIdFileNumber  in ViewCommentDetails.java *************");
                    return fileNumId;
            }else {
                   logger.info("File number is not found in CLL  **********************");
                   logger.info("Ending findFileNumberIdByTypeIdFileNumber  in ViewCommentDetails.java *************");
                   return  new Number(0);  // to indicate  no error while searching but file number does not exist
            }
        } else {
            logger.severe("Error on finding File Number Id for file number type id  and file number : " + fileNumTypeId +  " "+ fileNumber+ "  " + operation.getErrors());
            logger.info("Ending findFileNumberIdByTypeIdFileNumber  i*************");
            return null;
        }
    }
    
    
   /**Adds  a file number to the list of comments
     *
     * @param commIds
     * @param fileNumId
     * @param fileNumtypeCode
     * @param availableAttr
     * @param masterFileNumId
     * @param origination
     */
    public static void  addFileNumToComments(ArrayList<Number> commIds, Number fileNumId, String fileNumtypeCode, String availableAttr, Number masterFileNumId, String origination){
        if(commIds.size() <=0) {
            return ;  //  just to indicate  no error...there is nothing to process because no comments selected
        } 
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope(); 
        //CommentList  commList = (CommentList )pageFlowScope.get("commentList"); 
        // ReturnMasterFileNumberDTO masterFileNumDTO= commList.getReturnMasterFileNumDTO();
        DCIteratorBinding dcIterBind = ADFUtils.findIterator("CllFilenumCommDetBulkActionView1Iterator"); 
        RowSetIterator rsi = dcIterBind.getRowSetIterator(); 
        for(Number commDetId:commIds){ 
            if(origination.equals(CllConstants.ORIGINATION_COMMENT_LIST_TAB)) {
                   OperationBinding opb = ADFUtils.findOperation("commentHasFileNumId"); 
                   opb.getParamsMap().put("commDetId",commDetId );   
                   opb.getParamsMap().put("fileNumId",fileNumId );  
                   opb.execute(); 
                   if(opb.getErrors().isEmpty()){
                            boolean  fileNumExists= (Boolean)opb.getResult();
                            if(fileNumExists){
                                continue; 
                            }
                    }else { 
                            JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_UNABLE_TO_ADD_FILE_NUMBER_MSG"));
                            logger.info(" ERROR ****** while executing data control method commentHasFileNumId() ****************** for the comment id : " + commDetId );
                            logger.info("" +opb.getErrors());
                            Boolean b = ADFUtils.doRollback();
                            return ;
                        } 
            }  
            //add the file number to the comment. 
            Row newRow = rsi.createRow();
            newRow.setAttribute("FilenumId", fileNumId); 
            newRow.setAttribute("CllCommDetId",commDetId );   
            if( fileNumtypeCode.equalsIgnoreCase(CllConstants.FILE_NUMBER_TYPE_SR_CODE)) { 
                    Number seqNumber=generateSeqNumber(commDetId,fileNumId) ;
                    if(null == seqNumber) {
                        Boolean b = ADFUtils.doRollback();
                        return;  //method generateSeqNumber() returns null in case of  errors
                        
                    }else{
                        if(seqNumber.intValue() != 0){
                           newRow.setAttribute("CommentSeqNumber", seqNumber); 
                        }
                    }
            }
            rsi.insertRow(newRow);
            
        }
        rsi.closeRowSetIterator();
        if(ADFUtils.doCommit()) {  
            logger.info("File number ID has been successfully  added to the comments  ***********"); 
            JSFUtils.addFacesInformationMessage("File# has been added to  " + commIds.size()  +  " comments successfully" );
            //String availableAttr =masterFileNumDTO.getAvailable();
            if( null != availableAttr  ){
                   // Number masterFileNumId= masterFileNumDTO.getMasterFileNumberId();  
                    ArrayList<Number> list= new ArrayList<Number>();
                    list.add(masterFileNumId);
                    updateAvailableMasterFileNumbers(list);   
            } 
        } else { 
            JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_UNABLE_TO_ADD_FILE_NUMBER_MSG"));
            Boolean b = ADFUtils.doRollback();
            return  ;
        } 
        
    }
   
   
   
    /**Changes  a file number in list of comments with new file number
     *
     * @param commIds
     * @param fileNumIdOld
     * @param fileNumIdNew
     */
     public static void  changeFileNumInComments(List<Number> commIds, Number fileNumIdOld, Number fileNumIdNew){ 
         if(commIds.size() <=0) {
             return ;  //  just to indicate  no error...there is nothing to process because no comments selected
         } 
         Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope(); 
         CommentList  commList = (CommentList )pageFlowScope.get("commentList"); 
         ReturnMasterFileNumberDTO masterFileNumDTO= commList.getReturnMasterFileNumDTO();
         OperationBinding opb = ADFUtils.findOperation("changeFileNumber"); 
         opb.getParamsMap().put("commIds",commIds );   
         opb.getParamsMap().put("fileNumIdOld",fileNumIdOld );  
         opb.getParamsMap().put("fileNumIdNew",fileNumIdNew );  
         opb.getParamsMap().put("fileNumTypeCode",masterFileNumDTO.getFileNumberTypeCode() );  
         opb.execute();  
         if(opb.getErrors().isEmpty()){
                 if(ADFUtils.doCommit()) {  
                     logger.info("File number ID has been successfully  changed in the comments  ***********"); 
                     if(commIds.size() ==1) {
                         JSFUtils.addFacesInformationMessage("File# has been changed in " + commIds.size()  +  " comment successfully" );
                     }else{
                         JSFUtils.addFacesInformationMessage("File# has been changed in " + commIds.size()  +  " comments successfully" );
                     }
                     String availableAttr =masterFileNumDTO.getAvailable();
                     if( null != availableAttr  ){//for available file number  this attribute is "Y".
                             Number masterFileNumId= masterFileNumDTO.getMasterFileNumberId();  
                             ArrayList<Number> list= new ArrayList<Number>();
                             list.add(masterFileNumId);
                             updateAvailableMasterFileNumbers(list);   
                     }
                     
                 } else { 
                     JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_UNABLE_TO_ADD_FILE_NUMBER_MSG"));
                     Boolean b = ADFUtils.doRollback();
                     return  ;
                 }
         }else{
             JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_UNABLE_TO_ADD_FILE_NUMBER_MSG"));
             logger.info(" ERROR ****** while changing file number  in bulk selection  ****************** " );
             logger.info("" +opb.getErrors());
             Boolean b = ADFUtils.doRollback();
              
         }
          
         
    }
    
    /**Invokes  web service to update  available field as not available for the Master file numbers added to the  
     *  @return boolean
     */
    public static boolean  updateAvailableMasterFileNumbers(ArrayList<Number> masterFileNumIds){ 
         boolean  flag=true;  
         RellogServicesWrapper wrapper=null; 
         try{  
                DatabaseResourceBundle dsbundle = new DatabaseResourceBundle();
                Map<String,String> bundle = dsbundle.getResourceBundle();  
//                String wsdlURL = (String)bundle.get("RELLOGSERVICES_WSDL_URL");
//                String nsURI = (String)bundle.get("RELLOGSERVICES_QNAME_NAMESPACE_URI");
//                String localPart = (String)bundle.get("RELLOGSERVICES_QNAME_LOCALPART");
//                logger.info("    RELLOGSERVICES_WSDL_URL = " + wsdlURL);
//                logger.info("    RELLOGSERVICES_QNAME_NAMESPACE_URI : " + nsURI);
//                logger.info("    RELLOGSERVICES_QNAME_LOCALPART : " + localPart); 
//                wrapper = new RellogServicesWrapper(wsdlURL, nsURI, localPart);
                wrapper = new RellogServicesWrapper(bundle);
                logger.info("  Created RellogServicesWrapper instance in  ViewCommentDetails  ***************** "); 
                if(null == wrapper){
                        JSFUtils.addFacesErrorMessage("File number available status might not been updated properly.");
                        return false;
                } 
                flag=wrapper.updateAvailableFlag(masterFileNumIds, false); 
        } catch (Exception e) { 
                 logger.info("ERROR  .....Exception occurred  in ViewCommentDetails while invoking !!");
                 e.printStackTrace();
                 JSFUtils.addFacesErrorMessage("File number available status might not been updated properly.");
                 return false;
        }
         return flag; 
    }
    
  /**  Generates Sequence number if required for the comment
     *
     * @param commDetId
     * @param fileNumId
     */
   private static Number generateSeqNumber(Number commDetId, Number fileNumId){
               Number seqNumberForFile = new Number(0); 
               OperationBinding opb = ADFUtils.findOperation("commentIsApproved"); 
               opb.getParamsMap().put("commentId",commDetId );    
               opb.execute(); 
               if(opb.getErrors().isEmpty()) { 
                       boolean  commApproved= (Boolean)opb.getResult();
                       if(commApproved){
                                   OperationBinding operation =ADFUtils.findOperation("getSetFileNumberSeqNumberNext");
                                   operation.getParamsMap().put("fileNumId",fileNumId ); 
                                   operation.execute();
                                   if (operation.getErrors().isEmpty()){
                                       seqNumberForFile= (Number) operation.getResult(); 
                                       logger.info("Next  Seq  nubmer for file number "+  fileNumId + " inside  CllUtils.generateSeqNumber() is :"  +seqNumberForFile); 
                                       return seqNumberForFile;
                                   } else {
                                       JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_ERR_GENERATING_SR_SEQ_NUMBER"));  
                                       logger.severe("Error while retrieving SR sequence number inside  CllUtils.generateSeqNumber()  " + operation.getErrors());
                                       return null;
                                   }  
                       }else{
                           return seqNumberForFile;
                       }
                }else {
                       JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_ERR_GENERATING_SEQ_NUMBER_MSG"));
                       logger.info(" ERROR ****** while executing data control method commentIsApproved() ****************** for the comment id : " + commDetId );
                       logger.info("" +opb.getErrors());
                       return null;
                }
          
             // return seqNumberForFile;
       
   }
    
    /** Inserts new master file number into CLL repository and returns  fileNumId
     *
     * @param fileNumTypeId
     * @param fileNumber
     * @return
     */
     public static Number addNewMasterFileNumberToCLLFileNumber( Number fileNumTypeId, String fileNumber, Number masterFileNumId){ 
        logger.info("Starting  addNewMasterFileNumberToCLLFileNumber  in CllUtils.java ******************");
        OperationBinding operation = ADFUtils.findOperation("addNewMasterFileNumberToCLLFileNumber"); 
        operation.getParamsMap().put("fileNumTypeId",fileNumTypeId );
        operation.getParamsMap().put("fileNumber",fileNumber );
        operation.getParamsMap().put("masterFileNumId",masterFileNumId );
        operation.execute(); 
        if (operation.getErrors().isEmpty()){
            if(null  != operation.getResult()){ 
                     Number fileNumId = (Number)operation.getResult();
                    logger.info("  File Number Id is  : " + fileNumId);
                    logger.info("Ending  addNewMasterFileNumberToCLLFileNumber  in CllUtils.java ******************");
                    return fileNumId;
            }else {
                
                 logger.severe("Error on saving master file number into CLL repository  " + fileNumTypeId +  "  "+ fileNumber+ "  " + operation.getErrors());
                 logger.info("Ending  addNewMasterFileNumberToCLLFileNumber  in CllUtils.java ******************");
                 return null;//  can  not proceed if file num id is null
            }
        } else {
            logger.severe("Error on saving master file number into CLL repository  " + fileNumTypeId +  "  "+ fileNumber+ "  " + operation.getErrors());
            logger.info("Ending  addNewMasterFileNumberToCLLFileNumber  in CllUtils.java ******************");
            return null;
        } 
        
    }
    

    /**Retrieves the master file number id from  the DTO returned by  Fie# search page  task flow
     *
     * @return fileNumbId
     */

    public static  Number getMasterFileNumberIdFromDTO(String origin){ 
        Number fileNumId=null;   
        ReturnMasterFileNumberDTO masterFileNumDTO=null;
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope(); 
        if(origin.equals(CllConstants.ORIGINATION_COMMENT_LIST_TAB)){
            CommentList  commList = (CommentList )pageFlowScope.get("commentList"); 
            masterFileNumDTO= commList.getReturnMasterFileNumDTO();
        }else if(origin.equals(CllConstants.ORIGINATION_MISSING_FILENUM_Q)){
            MissingFileNumberQList  missingFileNumberQList = (MissingFileNumberQList )pageFlowScope.get("missingFileNumberQList"); 
            masterFileNumDTO= missingFileNumberQList.getReturnMasterFileNumDTO();
        }else if(origin.equals(CllConstants.ORIGINATION_INTERNAL_TOSEC_Q)){
            InternalToSecQueue  internalToSecQueue = (InternalToSecQueue )pageFlowScope.get("internalToSecQueue"); 
            masterFileNumDTO= internalToSecQueue.getReturnMasterFileNumDTO();
        }  
        if(null == masterFileNumDTO  ) {
            JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_NO_FILENUMBER_SELECTED_IN_SEARCH_PAGE"));
            logger.info("The  MasterFileNumber DTO  returned by  file number container is null *****************"); 
            return fileNumId;
        }
        if(  null ==masterFileNumDTO.getMasterFileNumberId()) {
            JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_NO_FILENUMBER_SELECTED_IN_SEARCH_PAGE"));
            logger.info("The  MasterFileNumber ID  returned by  file number container is null  ****************"); 
            return fileNumId;
        }
        logger.info("MasterFileNumber Id returned from search page  is  :"+masterFileNumDTO.getMasterFileNumberId()); 
        String fileNumTypeCode=masterFileNumDTO.getFileNumberTypeCode();
        if(null == fileNumTypeCode){
            logger.info("ERROR  *************Master File Number  DTO  does not have  file number type Code !!  **********************");
            JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_FILENUM_TYPE_ID_NOT_FOUND")); 
            return fileNumId;
        } 
        Number fileNumTypeId =findFileNumberTypeId( masterFileNumDTO.getFileNumberTypeCode());
        if(null == fileNumTypeId){
            JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_FILENUM_TYPE_ID_NOT_FOUND")); 
            return  fileNumId;
        }
        //get the fileNumId from Cll file Number table  if it exists
        fileNumId=CllUtils.findFileNumberIdByTypeIdFileNumber(fileNumTypeId,masterFileNumDTO.getFileNumber(),masterFileNumDTO.getMasterFileNumberId());
        if(null == fileNumId){
             JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_FILENUM_ID_ERR_MSG"));
             logger.info("Error while searchig for master file number  in CLL  file number"); 
             return fileNumId ;
        }
        if( fileNumId.intValue()==0 ){
           //insert the master file number  in  CLL  file number  and commit the record and get the file num id
           fileNumId=addNewMasterFileNumberToCLLFileNumber( fileNumTypeId,  masterFileNumDTO.getFileNumber(),masterFileNumDTO.getMasterFileNumberId());
           if(null == fileNumId){   //JBO errors are already logged in.  No need to print here again.
                JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_UNABLE_TO_ADD_MASTERFILENUM_MSG")); 
                return fileNumId;
           }           
        } 
        return fileNumId;
    }
   
   
   
    /**
     * Finds the file number type id by code
     * 
     * @param code  File Numner Type Code
     * @return  File Number Type Id
     */
    private static  Number findFileNumberTypeId(String code){
        logger.info("Starting findFileNumberTypeId  in ViewCommentDetails.java *************");
        OperationBinding operation = ADFUtils.findOperation("getFileNumberTypeId");
        operation.getParamsMap().put("code", code);
        operation.execute();
        if (operation.getErrors().isEmpty()){
            Number fileNumTypeId = (Number)operation.getResult();
            logger.info("Found File Number Type Id : " + fileNumTypeId);
            logger.info("Ending findFileNumberTypeId  in ViewCommentDetails.java *************");
            return fileNumTypeId;
        } else {
            logger.severe("Error on finding File Number Type Id for code : " + code, operation.getErrors());
            logger.info("Ending findFileNumberTypeId  in ViewCommentDetails.java *************");
            return null;
        }
    }

    /**Invokes custom data control method  which invokes remote serice to retrieve release numbers for a master file number id
     *
     * @param masterFileNumId
     * @return list of release numbers
     */
    public static List<String> getReleaseNumsForMasterFileNumber(Number masterFileNumId){
        logger.info("Starting getReleaseNumsForMasterFileNumber....");
        List<String> relNumbers=new ArrayList<String>();
        OperationBinding operation = ADFUtils.findOperation("getReleaseNumsForMasterFileNumber"); 
        operation.getParamsMap().put("masterFileNumId", masterFileNumId);
        operation.execute();
        if (operation.getErrors().isEmpty()){  
            relNumbers=(List<String>)operation.getResult(); 
        } else {
            logger.info("Error retrieving release numbers from master file number module in  CLLUtils.getReleaseNumsForMasterFileNumber()" +operation.getErrors());
            logger.info("Ending getReleaseNumsForMasterFileNumber  in CLLUtils.java *************");
            relNumbers= null;
        }
        return relNumbers; 
    }
            
    private static Map<Number, Date> sortMapByValue(Map<Number, Date> unSortedMap){
        //Convert Map to List of Map
        List<Map.Entry<Number, Date>> sortList = new ArrayList<Map.Entry<Number, Date>>(unSortedMap.entrySet());
        
        // Sort list by Collections.sort() using custom comparator
        Collections.sort(sortList, new Comparator<Map.Entry<Number, Date>>() {
            public int compare(Map.Entry<Number, Date> m1, Map.Entry<Number, Date> m2) {
                return (m2.getValue()).compareTo(m1.getValue());
            }
        });
        
        Map<Number, Date> sortedMap = new LinkedHashMap<Number, Date>();
        for(Map.Entry<Number, Date> entry: sortList){
            sortedMap.put(entry.getKey(), entry.getValue());
        }
        
        return sortedMap;
    }
    
}




