package gov.sec.cll.view.utils;

import gov.sec.cll.view.dto.PackageInfoDTO;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import oracle.adf.share.logging.ADFLogger;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;

/**
 * Utility that supports the publishing process. It conrains methods to generates files and package them in a ZIP file.
 *
 */
public class PackageUtils {
    
    private static ADFLogger logger = ADFLogger.createADFLogger(PackageUtils.class);
    private static final String INDEX_PAGE_FILE_EXTENSION = ".htm";
    private static final String COMMENT_FILE_EXTENSION = ".htm";
    private static final String DASH = "-";
    private static final String COMMENTS_DIR_NAME = "/comments/"; 
    private static final String FORM_LETTER_PUB_SUBSTR = "_pub_formletter_";
    private static final String FORM_LETTER_UNPUB_SUBSTR = "_unpub_formletter_";
    private static final String ZIP_FILE_EXTENSION = ".zip"; 
    private static final String WUPDATE_FILENAME = "updates.txt";
    private static final ResourceBundle rb = ResourceBundle.getBundle(CllConstants.RESOURCE_BUNDLE_LOCATION);
    private static final String FORM_LETTER_FILE_NUM_PUB_SUBSTR = "_file_num_pub_formletter_";
    
    /**
     * Generates and packages needed fles for form letter publishing
     * 
     * @param infoDTO   PackageInfoDTO object that holds information for form letter index and comment pages
     * @return  Zip file name that contains all the generated files for form letter publishing
     */
    public static String createFormLetterZIP(PackageInfoDTO infoDTO){
        logger.info("Generating and packaging files for publishing... File Number : " + infoDTO.getFileNumber());
        String zipFileName = null;
        try {
            //Create temporary directory
            String tempDirName = createTempDir(infoDTO.getTargetDirectory(), infoDTO.getFileNumber(), true); //taken care special chars
            if(null == tempDirName ){
                return null;
            }
            String tempDirPath = infoDTO.getTargetDirectory() + tempDirName;

            //Generate the Form Letter Commment page

            String commntFilename = createFormLetterCommentPage(infoDTO.getFormLetterCommntInfo(), tempDirPath); //taken care special chars
            if(null == commntFilename ){
                return null;
            }
            
            //Generate the Form letter Index page 
            String idxpgFileName = createFormLetterIndexPage(infoDTO.getIndexPageInfo(), commntFilename, tempDirPath);//taken care special chars
            if(null == idxpgFileName){
                return null;
            }
            
            List<String> filenameList = new ArrayList<String>();
            filenameList.add(idxpgFileName);
            filenameList.add(commntFilename);
            
            //Generate the wupdate txt file with generated files' names
            String fileNum=infoDTO.getFileNumber();
            fileNum=CllUtils.removeSpecialCharsFromFileFolderName(fileNum);
            logger.info("fileNum after removing  special characters in createFormLetterZIP() *************** is : " +fileNum); 
            boolean flag=createWUpdateFile(tempDirPath,  fileNum, filenameList, true);   
            if(!flag) {
                return null;
            } 
            
            //Zip the temporary folder
            String fileName=zip(infoDTO.getTargetDirectory(), tempDirName); //filtered with special characters
            if(fileName == null){
                return null;
            }
            
            zipFileName = tempDirName + ZIP_FILE_EXTENSION;
        } catch (Exception e){
            e.printStackTrace();
             return  null;
        }
        logger.info("Rertuning ZIP file name : " + zipFileName);
        return zipFileName;
    } 
    
    public static String createUnPublishedFormLetterZIP(PackageInfoDTO infoDTO){
        logger.info("generating and packaging file for un-publishing. File Number : {0} :: SubType : {1}",
                    new String[] { infoDTO.getFileNumber(), infoDTO.getFormLetterSubType() });
        String zipFileName = null;
        try{
            //Create temporary directory 
            String tempDirName = createTempDir(infoDTO.getTargetDirectory(), infoDTO.getFileNumber(), false); //special chars taken care 
            if( null == tempDirName ) {
                return null;
            }
            String tempDirPath = infoDTO.getTargetDirectory() + tempDirName;
            
            List<String> filenameList = new ArrayList<String>();
            String idxFileName=createFormLetterIndexFileName(infoDTO.getFileNumber()); //special chars taken care 
            if(null == idxFileName) {
                return null;
            }
            filenameList.add(idxFileName);
            String commPageFileName=createFormLetterCommentPageFileName(infoDTO.getFileNumber(), infoDTO.getFormLetterSubType()); //special characters taken care
            if(null == commPageFileName){ 
                return null;
            }
            filenameList.add(commPageFileName);
            
            //Generate the wupdate txt file with generated files' names for unpublishing
            String fileNum=infoDTO.getFileNumber();
            fileNum=CllUtils.removeSpecialCharsFromFileFolderName(fileNum);
            logger.info("fileNum after removing  special characters inside createUnPublishedFormLetterZIP() *************** is : " +fileNum);
            boolean flag=createWUpdateFile(tempDirPath, fileNum, filenameList, false);
            if(!flag) {
                return null;
            }
            //Zip the temporary folder
            String zipfileName=zip(infoDTO.getTargetDirectory(), tempDirName);
            if(null == zipfileName){
                return null;
            }
            zipFileName = tempDirName + ZIP_FILE_EXTENSION;
        } catch (Exception e){
            e.printStackTrace();
            return null;
        }
        logger.info("Returning ZIP file name : " + zipFileName);
        return zipFileName;
    }
    
    public static String createCommentLetterZIP(String rootdir,  String subdir){
        String zipFileName = null;
        try {
            
            String fileName=zip(rootdir, subdir);
            if(null == fileName){
                return null;
            } 
            zipFileName = subdir + ZIP_FILE_EXTENSION;
        } catch (Exception e){
                 e.printStackTrace();
                 return null;
        }
        logger.info("Returning ZIP file name : " + zipFileName);
        
        return zipFileName; 
       
    }     
    
    /**Generates   comment letter index page using template
     *
     * @param info
     * @param targetDir
     */
    public  static String createCommentLetIndexPage(Map<String, String> info, String targetDir){
        logger.info("Starting  createCommentLetIndexPage   *********************"); 
        
        String htmlString =  info.get("template");
        if (StringUtils.isEmpty(htmlString)){
           logger.severe("Error while retrieving Comment Letter Index Page Template from database ********** ");
           return null;
        }
        // Changes for CASSECDEV-6075: Remove the title and release number, Have removed those in template and commenting below.
        //htmlString = htmlString.replace("$title$", info.get("title"));
        //htmlString = htmlString.replace("$release_numbers$", info.get("release_numbers"));
        // Changes for CASSECDEV-6308: Html Index file should have source code with only <tr> tags and related data of commenter (Only rows data).
        //htmlString = htmlString.replace("$file_number$", "File No. " + info.get("fileType_fileNumber"));   //with hyphens
        htmlString = htmlString.replace("$commentLinks$", info.get("comment_links")); 
        String updatedFileNumber=info.get("fileType_fileNumber").replaceAll("-", "").trim(); 
        updatedFileNumber = StringUtils.lowerCase(updatedFileNumber); 
        updatedFileNumber=CllUtils.removeSpecialCharsFromFileFolderName(updatedFileNumber);
        logger.info("updatedFileNumber  after removing  special characters inside createCommentLetIndexPage*************** is : " +updatedFileNumber);
        String filename=updatedFileNumber;
        filename = filename + INDEX_PAGE_FILE_EXTENSION; 
        File idxpgFile = new File(targetDir, filename);
        try{
            FileUtils.writeStringToFile(idxpgFile, htmlString);
        } catch (IOException e) {
            logger.severe("Error generating the Index Page file...", e);
            e.printStackTrace();
            return null;
        }
        logger.info("Ending  createCommentLetIndexPage   *********************"); 
        return filename;
    }
    
    
    public static String createCommentLetHtmlPage(Map<String, String> info, String targetDir){
        logger.info("Starting  createCommentLetIndexPage   *********************"); 
        
        String htmlString =  info.get("template");
        if (StringUtils.isEmpty(htmlString)){
            logger.severe("Error while retrieving Comment Letter Index Page Template from database ********** ");
            return null;
        } 
          
        htmlString = htmlString.replace("$name$", info.get("name"));
        htmlString = htmlString.replace("$recDate$", info.get("recDate"));
        htmlString = htmlString.replace("$subject$", info.get("subject"));
        htmlString = htmlString.replace("$affiliation$", info.get("affiliation"));
        htmlString = htmlString.replace("$comment$", info.get("comment"));
        htmlString = htmlString.replace("$attachmentLinks$", info.get("attachmentLinks"));
        String htmlFileNameForComment= info.get("htmlFileNameForComment"); 
        
        File idxpgFile = new File(targetDir, htmlFileNameForComment);
        try {
            FileUtils.writeStringToFile(idxpgFile, htmlString);
        } catch (IOException e) {
            logger.severe("Error generating the Index Page file...", e);
            e.printStackTrace();
            return null;
        }
        logger.info("Ending  createCommentLetIndexPage   *********************");
        
        return htmlFileNameForComment;
    }
    
    
    /**
     * Generates the form letter index page with the information provided to the specified directory
     *
     * @param info          Map object that holds the information for the form letter index page
     * @param tempDirPath   Directory path where the form letter index page needs to be generated to.
     * @return      File name for the generated form letter index page
     */
    public static String createFormLetterIndexPage(Map<String, String> info, String commntFilename, String tempDirPath){
        logger.info("***** START :: Creating  Index Page....");
        String htmlString = info.get("index_page_template");
        if (StringUtils.isEmpty(htmlString)){
           logger.severe(" ERROR    !!!!!!!!!!!  Form Letter Index Page Template content is empty....");
           return null;
        }
        htmlString = htmlString.replace("$title$", StringUtils.defaultString(info.get("title")));
        htmlString = htmlString.replace("$release_numbers$", info.get("release_numbers"));
        htmlString = htmlString.replace("$file_number$", "File No. " + info.get("file_number"));
        // Changes for CASSECDEV-6118: File Number Publishing of Form Letter.
        if(commntFilename == null && info.get("form_letter_file_num_pub_type_links") != null){
            htmlString = htmlString.replace("$form_letter_type_links$", info.get("form_letter_file_num_pub_type_links"));
        } else {
            htmlString = htmlString.replace("$href_link$", commntFilename);
            htmlString = htmlString.replace("$form_letter_type$", info.get("form_letter_type"));
            htmlString = htmlString.replace("$form_letter_instances$", info.get("form_letter_instances"));
        }

        String filename = createFormLetterIndexFileName(info.get("file_number")); //taken care special chars
        if(null ==filename){
            return null;
        }
        File idxpgFile = new File(tempDirPath, filename);
        try {
            FileUtils.writeStringToFile(idxpgFile, htmlString);
        } catch (IOException e) {
            logger.severe("Error generating the Index Page file...", e);
            e.printStackTrace();
            return null;
        }
        logger.info("***** END :: Creating  Index Page....");
        return filename;
    }
    
    /**
     * Generates the form letter comment page with the information provided to the specified directory
     *
     * @param info          Map object that holds the information for the form letter comment page
     * @param tempDirPath   Directory path where the form letter comment page needs to be generated to.
     * @return      File name for the generated form letter comment page
     */
    public static String createFormLetterCommentPage(Map<String, String> info, String tempDirPath){
        logger.info("***** START :: Creating  Form Letter Comment Page....");
        String htmlString = info.get("comment_page_template");
        if (StringUtils.isEmpty(htmlString)){
           logger.severe("  ERROR !!!!! Form Letter Comment Page Template content is empty....");
           return null;
        }
        htmlString = htmlString.replace("$form_letter_type$", info.get("form_letter_type"));
        htmlString = htmlString.replace("$form_letter_comment$", info.get("form_letter_comment"));
        if(info.get("file_number") != null){
            htmlString = htmlString.replace("$file_number$", info.get("file_number"));
        }
        
        String filename = createFormLetterCommentPageFileName(info.get("file_number"), info.get("form_letter_type")); // special characters taken care in the file name
        if(null ==filename){
            return null;
        }
        
        File commntpgFile = new File(tempDirPath, filename);
        try {
            FileUtils.writeStringToFile(commntpgFile, htmlString);
        } catch (IOException e) {
            logger.severe("Error generating the Form Letter Comment Page file...", e);
            e.printStackTrace();
            return null;
        }
        logger.info("***** END :: Creating  Form Letter Comment Page....");
        return filename;
    }

    /**
     * Generates the content of the updates.txt file and invokes method which finally generates the file.
     * 
     * @param targetDirPath     The directory path where the text files needs to be generated to.
     * @param fileNumber        File number which will be used as part of the generated text content
     * @param filenameList      A list of file names that will be used as part of the generated text content
     * @param isPublish         Boolean value that indicates if the generated text content is for publish ot unpublish.
     *                          True - publish; False - unpublish
     */
    public static boolean createWUpdateFile(String targetDirPath, String fileNumber, List<String> filenameList, boolean isPublish){
        logger.info("******* START Creating the content for file " + WUPDATE_FILENAME);
        //targetDirPath  is filtered already with special characters
        //fileNumber fileterd with special characters.  It is in the format  fileNumberType"-"fileNumber.  Ex :  3-2876 
        //fileNumber is used as  subdir after targetDirPath
        
        logger.info("is Publish ? : " + isPublish);
        //Create the content for the text file
       // fileNumber=fileNumber.toLowerCase(); // TODO convert to lower case
        StringBuffer content = new StringBuffer();
        fileNumber=fileNumber.toLowerCase();
        for (String filename : filenameList ){
            if (isPublish) {
                content.append(COMMENTS_DIR_NAME);
            } else {
                content.append(DASH + COMMENTS_DIR_NAME);
            }
            // Changes for CASSECDEV-6078, convert file extention (.docx or .doc) to .pdf
            filename = convertExtDocToPdf(filename);
            content.append(fileNumber + "/").append(filename).append("\r\n");   //ex  : /comments/3-124124/3124124.shtml for publishing
        }
        logger.info("Is Content Empty ? : " + content.toString().isEmpty());
        logger.info("******* END creating content for wupdate file " + WUPDATE_FILENAME);
                
        return (createWUpdateFile(targetDirPath, content.toString()));
        
    }
    
    /**
     * Generates a text file in a specified directory with a provided content.
     *
     * @param targetDirPath     The directory path where the text files needs to be generated to.
     * @param content       Text content for the file that will be generated
     */
    private static boolean createWUpdateFile(String targetDirPath, String content){ //NO more wupdate...it is now called updates.txt
        logger.info("***** START :: Creating wupdate file...");
        logger.info("====== Content ===== \n " + content);
        if (content != null && !content.trim().isEmpty()){
            try {
                File txtFile = new File(targetDirPath, WUPDATE_FILENAME);
                FileWriter fw = new FileWriter(txtFile.getAbsoluteFile());
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(content);
                bw.close();
            } catch (IOException e) {
                logger.severe("Error creating wupdate txt file", e);
                e.printStackTrace();
                return false;
            }
        }else{
            logger.severe("There are  no entries to write into  wupdate file  ***************");
            return false;
        }
        logger.info("***** END :: Creating wupdate file...");
        return true;
    }
    
    /**
     * Creates a temporary directory under a specified target directory path
     *
     * @param targetDirPath     The main directory where we need to create the temporrary folder
     * @param fileNumber        File number which is used for the generation of the temporary folder name
     * @return      Temporary directory name
     */
    private static String createTempDir(String targetDirPath, String fileNumber, boolean isPublish) {
        logger.info("Creating temporaty folder for File Number : " + fileNumber);
        String tmpDirName = "";
        String updatedFileNumber = fileNumber.replace(DASH, "");
        updatedFileNumber=CllUtils.removeSpecialCharsFromFileFolderName(updatedFileNumber);
        logger.info("File number after removing  special characters *************** is : " +updatedFileNumber); 
        updatedFileNumber = StringUtils.lowerCase(updatedFileNumber);
        
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
//        tmpDir = parentDir + updatedFileNumber + FORM_LETTER_SUBSTR + timeStamp + "/";  
        if (isPublish){
            tmpDirName = updatedFileNumber + FORM_LETTER_PUB_SUBSTR + timeStamp;      
        } else {
            tmpDirName = updatedFileNumber + FORM_LETTER_UNPUB_SUBSTR + timeStamp;      
        }
        String tmpDirPath = targetDirPath + tmpDirName; 
        File tempDir = new File(tmpDirPath);
        boolean createDir=tempDir.mkdir();
        if (!createDir){
            logger.severe(" ERROR !! There was an error creating temporaty folder. Please contact System Administartor.");
            return null;
        }
        logger.info("Temporary Directory : " + tempDir);
        return tmpDirName;
    }

    /**
     * Packages files to a ZIP file from a specific location
     * 
     * @param targetDirPath     The main directory which contains the directory to be packaged
     * @param sourceDirName     The directory name that needs to be packaged. This will be taken also 
     *                          as the zip file name.
     * @return  Zip file name
     */
    public static String zip(String targetDirPath, String sourceDirName) {
        logger.info("Param :: targetDir : " + targetDirPath);
        logger.info("Param :: sourceDirName : " + sourceDirName);
        String zipFileName = "";
        try {
            // create byte buffer
            byte[] buffer = new byte[1024];
            FileOutputStream fos = new FileOutputStream(targetDirPath + sourceDirName + ZIP_FILE_EXTENSION);
            ZipOutputStream zos = new ZipOutputStream(fos);

            File dir = new File(targetDirPath + sourceDirName);
            File[] files = dir.listFiles();
            for (int i = 0; i < files.length; i++) {
                //System.out.println("Adding file: " + files[i].getName());
                // CASSECDEV-6085 : CASSECDEV-6117 : Changes for File Number Publishing
                if(files[i].isFile()){
                    FileInputStream fis = new FileInputStream(files[i]);
                    // begin writing a new ZIP entry, positions the stream to the start of the entry data
                    zos.putNextEntry(new ZipEntry(files[i].getName()));
                    int length;
                    while ((length = fis.read(buffer)) > 0) {
                        zos.write(buffer, 0, length);
                    }
                    zos.closeEntry();
                    // close the InputStream
                    fis.close();
                }
            }
            // close the ZipOutputStream
            zos.close();
            zipFileName = dir.getName();
        } catch (IOException ioe) {
            logger.severe("Error creating zip file", ioe);
            ioe.printStackTrace();
            return null;
        }
        logger.info("Returning Zip File name : " + zipFileName);
        return zipFileName;
    }
    
    private static String createFormLetterIndexFileName(String fileNumber){
        if (fileNumber == null | StringUtils.isEmpty(fileNumber)){
            logger.severe("File Number was not provided to create file name for Form Letter Index Page");
            return null;
        }
        String filename = StringUtils.lowerCase(fileNumber);
        filename = filename.replace(DASH, "") + INDEX_PAGE_FILE_EXTENSION;
        filename=CllUtils.removeSpecialCharsFromFileFolderName(filename);
        logger.info("filename after removing  special characters inside createFormLetterIndexFileName() *************** is : " +filename);
                
        logger.info("Form Letter Index Page :: Created File Name : " + filename);
        return filename;
    }
    
    private static String createFormLetterCommentPageFileName(String fileNumber, String subType){
        if (fileNumber == null | StringUtils.isEmpty(fileNumber)){
            logger.severe("File Number was not provided to create file name for Form Letter Comment Page");
            return null;
        }
        if (subType == null | StringUtils.isEmpty(subType)){
            logger.severe("Sub was not provided to create file name for Form Le tter Comment Page");
            return null;
        }
        String filename = StringUtils.lowerCase(fileNumber);
        filename = filename.replace("-", "");
        filename = filename + DASH + subType + COMMENT_FILE_EXTENSION;
        logger.info("Form Letter Comment Page :: Created File Name : " + filename);
        filename=CllUtils.removeSpecialCharsFromFileFolderName(filename);
        logger.info("filename after removing  special characters inside  createFormLetterCommentPageFileName() *************** is : " +filename);
                
        return filename;
    }
    
    // Changes for CASSECDEV-6078, convert file extention (.docx or .doc) to .pdf
    public static boolean containsIgnoreCase(String mainStr, String findStr) {
        boolean returnValue = Boolean.FALSE;
        if(mainStr != null && findStr != null && !mainStr.isEmpty() && !findStr.isEmpty()){
            try {
                Pattern strPattern = Pattern.compile(findStr, Pattern.CASE_INSENSITIVE+Pattern.LITERAL);
                Matcher strMatcher = strPattern.matcher(mainStr);
                returnValue = strMatcher.find();
            } catch (Exception e) {
                logger.severe("Exception occurred in PackageUtils.containsIgnoreCase()... "+e.getMessage(), e);
            }
        }
        
        return returnValue;
    }
    
    public static String convertExtDocToPdf(String attachmentName){
        if(attachmentName != null && containsIgnoreCase(attachmentName, CllConstants.FILE_TYPE_EXTENSION_DOCX)){
            return attachmentName.replaceAll(CllConstants.CASE_SENSITIVE_REGEX + CllConstants.FILE_TYPE_EXTENSION_DOCX, CllConstants.FILE_TYPE_EXTENSION_PDF);
        } else if(attachmentName != null && containsIgnoreCase(attachmentName, CllConstants.FILE_TYPE_EXTENSION_DOC)){
            return attachmentName.replaceAll(CllConstants.CASE_SENSITIVE_REGEX + CllConstants.FILE_TYPE_EXTENSION_DOC, CllConstants.FILE_TYPE_EXTENSION_PDF);
        } else {
            return attachmentName;
        }
    }
    
    // CASSECDEV-6118, CASSECDEV-6475, CASSECDEV-6476 : Changes for File Number Publishing of Form Letter.
    /**
     * Creates a publishing directory under a specified target directory path
     *
     * @param targetDirPath     The main directory where we need to create the publishing folder
     * @param fileNumber        File number which is used for the generation of the publishing folder name
     * @return      Temporary directory name
     */
    public static String createFileNumPubFormLetterDir(String targetDirPath, String fileNumber) {
        logger.info("In createFileNumPubFormLetterDir.. Creating temporaty folder for File Number: " + fileNumber+ "  targetDirPath: "+targetDirPath);
        String publishDirName = "";
        String updatedFileNumber = fileNumber.replace(DASH, "");
        updatedFileNumber=CllUtils.removeSpecialCharsFromFileFolderName(updatedFileNumber);
        //logger.info("In createFileNumPubFormLetterDir.... File number after removing  special characters *************** is : " +updatedFileNumber); 
        updatedFileNumber = StringUtils.lowerCase(updatedFileNumber);
        
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
        publishDirName = updatedFileNumber + FORM_LETTER_FILE_NUM_PUB_SUBSTR + timeStamp;
        String tmpDirPath = targetDirPath + publishDirName; 
        File tempDir = new File(tmpDirPath);
        boolean createDir=tempDir.mkdir();
        if (!createDir){
            logger.severe("In createFileNumPubFormLetterDir... ERROR !! There was an error creating temporaty folder. Please contact System Administartor.");
            return null;
        }
        logger.info("In createFileNumPubFormLetterDir... return Directory : " + tempDir);
        return publishDirName;
    }
    
}
