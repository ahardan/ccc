package gov.sec.cll.view.beans;


import gov.sec.cas.sharedcomponents.view.dto.SubmitterDTO;
import gov.sec.cll.sharedcomponents.view.dto.MasterFileNumberDTO;
import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;
import gov.sec.cll.view.dto.EmailRecipientDTO;
import gov.sec.cll.view.dto.ForwardCommentDTO;
import gov.sec.cll.view.utils.CllConstants;

import gov.sec.rellog.filenumber.view.dto.ReturnMasterFileNumberDTO;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

import oracle.adf.share.logging.ADFLogger;
import oracle.jbo.domain.Number;

import org.apache.commons.lang.StringUtils;


public class CommentDetails implements Serializable{

    @SuppressWarnings("compatibility:7412279778938562090")
    private static final long serialVersionUID = 1L;

    public CommentDetails() {
        super();
    }
    
    private ForwardCommentDTO forwardComment;
    private Number commentDetId;
    private Number fileNumId;
    private String fileTypeFileNumber; //TODO: This is not used in View Comment Details 
    private String origination;
    private String moduleName=CllConstants.CLL_MODULE;
    private boolean disableAddFileNumIcon;
    private boolean disableEditFileNumIcon;
    private boolean disableSaveAppButton;
    private List<EmailRecipientDTO> emailRecipienList = new ArrayList<EmailRecipientDTO>();
    private List<SubmitterDTO> newContacts = new ArrayList<SubmitterDTO>();
    private static ADFLogger logger = ADFLogger.createADFLogger(ViewStateCommentDetails.class);
    private boolean attachmentsExist =false;
    private Number returnCommDetId;
    private ReturnMasterFileNumberDTO returnMasterFileNumDTO;
    private List<String> releaseNumberList = new ArrayList<String>();

    /** Compute the display attributes for  File Number,  Add icon, Edit icon
     *
     */
    public void initAddEditFileNumber() {
        if (commentDetId != null) {
            if (fileNumId != null) {
                updateAddIconDisplayProperty();
                updateEditIconDisplayProperty();
            }
            // updateSaveAppButtonDisplayProperty();     TODO  will use it later if needed
        }
    }
    
    public void updateSaveAppButtonDisplayProperty(){
        if( null != ADFUtils.getBoundAttributeValue("CommentStatusCode") ){
            String code=(String)ADFUtils.getBoundAttributeValue("CommentStatusCode");
            if(code.equalsIgnoreCase(CllConstants.CLL_STATUS_TYPE_CODE_PRO)){
                disableSaveAppButton=true;
            }else{
                disableSaveAppButton=false;
            }
        } 
    }
    
    /** Return the email recipients from emailRecipientList
     * 
     */
    public String getRecipients(){
        StringBuffer recipients = new StringBuffer();
        for (EmailRecipientDTO dto : emailRecipienList){
            if (recipients.toString().length() > 0){
                recipients.append(";");    
            }
            recipients.append(dto.getEmail());
        }
        return recipients.toString();
    }
    
    /** Return the email forwarded to from emailRecipientList
     * 
     */
    public String getForwardedTo(){
        StringBuffer recipients = new StringBuffer();
        for (EmailRecipientDTO dto : emailRecipienList){
            recipients.append(dto.getFirstName());
            recipients.append(" "); 
            recipients.append(dto.getLastName());
            recipients.append(", ");
            logger.info("Getting recipient " + dto.getFirstName() + " " + dto.getLastName());
            }
        int stLength = StringUtils.lastIndexOf(recipients.toString(),',');
        String stFwdTo = recipients.toString().substring(0, stLength);
        
        return stFwdTo;
    }
    
    
    public void setCommentDetId(Number commentDetId) {
        this.commentDetId = commentDetId;
        
    }

    public Number getCommentDetId() { 
        return commentDetId;
    }


    public void setFileNumId(Number fileNumId) {
        this.fileNumId = fileNumId; 
    }

    public Number getFileNumId() {
        return fileNumId;
    }

    public void setOrigination(String origination) {
        this.origination = origination;
    }

    public String getOrigination() {
        return origination;
    }


    public void setFileTypeFileNumber(String fileTypeFileNumber) {
        this.fileTypeFileNumber = fileTypeFileNumber;
    }

    public String getFileTypeFileNumber() {
        return fileTypeFileNumber;
    }


    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public String getModuleName() {
        return moduleName;
    }
    
        public void setDisableAddFileNumIcon(boolean disableAddFileNumIcon) {
            this.disableAddFileNumIcon = disableAddFileNumIcon;
        }

        public boolean isDisableAddFileNumIcon() {   
            return disableAddFileNumIcon;
        }

        public void setDisableEditFileNumIcon(boolean disableEditFileNumIcon) {
            this.disableEditFileNumIcon = disableEditFileNumIcon;
        }

        public boolean isDisableEditFileNumIcon() {
            return disableEditFileNumIcon;
        }
        
    
        
        
        
        
        /** Compute the display attribute for  Add File# icon UI component
         * 
         */
        public void updateAddIconDisplayProperty(){
            if( null != ADFUtils.getBoundAttributeValue("CllCommDetId") ){
                if( null != ADFUtils.getBoundAttributeValue("CommentTypeCode") ){
                    String commentTypeCode=(String)ADFUtils.getBoundAttributeValue("CommentTypeCode");
                    if( commentTypeCode.equalsIgnoreCase(CllConstants.CLL_TYPE_CODE_FORM_LETTER) ){
                        setDisableAddFileNumIcon(true);
                    }
                } 
                
            } 
        
        }

        /** Compute the display attribute for  Edit File# icon UI component
        *
        */
        public void updateEditIconDisplayProperty(){
        if( null != ADFUtils.getBoundAttributeValue("CllCommDetId") ){
                String fileNumber=(String)ADFUtils.getBoundAttributeValue("FileNumber");
                logger.info("File Number while loading comment detail  id :  " + ADFUtils.getBoundAttributeValue("CllCommDetId") +  "is   "+fileNumber);
                //if at all the file number is null in the binding tree, there is no point in displaying edit icon at all
                if(fileNumber == null) {
                    setDisableEditFileNumIcon(true);
                    return;
                }
                if( null != ADFUtils.getBoundAttributeValue("CommentTypeCode") ){
                    String commentTypeCode=(String)ADFUtils.getBoundAttributeValue("CommentTypeCode");
                    if( commentTypeCode.equalsIgnoreCase(CllConstants.CLL_TYPE_CODE_FORM_LETTER) ){
                        setDisableEditFileNumIcon(true);
                    }else{
                        setDisableEditFileNumIcon(false);
                    }
                }  
        } 
        
       }

    public void setEmailRecipienList(List<EmailRecipientDTO> emailRecipienList) {
        this.emailRecipienList = emailRecipienList;
    }

    public List<EmailRecipientDTO> getEmailRecipienList() {
        return emailRecipienList;
    }

    public void setNewContacts(List<SubmitterDTO> newContacts) {
        this.newContacts = newContacts;
    }

    public List<SubmitterDTO> getNewContacts() {
        return newContacts;
    }

    public void setForwardComment(ForwardCommentDTO forwardComment) {
        this.forwardComment = forwardComment;
    }

    public ForwardCommentDTO getForwardComment() {
        return forwardComment;
    }

    public void setDisableSaveAppButton(boolean disableSaveAppButton) {
        this.disableSaveAppButton = disableSaveAppButton;
    }

    public boolean isDisableSaveAppButton() {
        return disableSaveAppButton;
    }

    public void setAttachmentsExist(boolean attachmentsExist) {
        this.attachmentsExist = attachmentsExist;
    }

    public boolean isAttachmentsExist() {
        return attachmentsExist;
    }

    public void setReturnCommDetId(Number returnCommDetId) {
        this.returnCommDetId = returnCommDetId;
    }

    public Number getReturnCommDetId() {
        return returnCommDetId;
    }

   

    public void setReturnMasterFileNumDTO(ReturnMasterFileNumberDTO returnMasterFileNumDTO) {
        this.returnMasterFileNumDTO = returnMasterFileNumDTO;
    }

    public ReturnMasterFileNumberDTO getReturnMasterFileNumDTO() {
        return returnMasterFileNumDTO;
    }

    public void setReleaseNumberList(List<String> releaseNumberList) {
        this.releaseNumberList = releaseNumberList;
    }

    public List<String> getReleaseNumberList() {
        return releaseNumberList;
    }
}
