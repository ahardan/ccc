package gov.sec.cll.view.beans;

import gov.sec.rellog.filenumber.view.dto.ReturnMasterFileNumberDTO;

import java.io.Serializable;

public class InternalToSecQueue implements Serializable{
    private ReturnMasterFileNumberDTO returnMasterFileNumDTO;
    
    public InternalToSecQueue() {
        super();
    }

    public void setReturnMasterFileNumDTO(ReturnMasterFileNumberDTO returnMasterFileNumDTO) {
        this.returnMasterFileNumDTO = returnMasterFileNumDTO;
    }

    public ReturnMasterFileNumberDTO getReturnMasterFileNumDTO() {
        return returnMasterFileNumDTO;
    }
}
