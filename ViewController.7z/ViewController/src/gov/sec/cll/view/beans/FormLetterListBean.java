package gov.sec.cll.view.beans;

import gov.sec.cas.common.view.dto.Document;
import gov.sec.cas.common.view.services.RIDCService;
import gov.sec.cas.common.view.utils.SecurityUtils;
import gov.sec.cll.model.adfbc.views.CllActionTypeROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllCommentDetailsViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllCommentsListROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFileNumPubCommListROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFormLetterViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllSourceTypeROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllTypeROViewRowImpl;
import gov.sec.cll.sharedcomponents.view.bundles.DatabaseResourceBundle;
import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;
import gov.sec.cll.sharedcomponents.view.utils.JSFUtils;
import gov.sec.cll.sharedcomponents.view.utils.SharedCompConstants;
import gov.sec.cll.view.dto.PackageInfoDTO;
import gov.sec.cll.view.utils.CllConstants;
import gov.sec.cll.view.utils.CllUtils;
import gov.sec.cll.view.utils.PackageUtils;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import java.sql.SQLException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.layout.RichShowDetailItem;
import oracle.adf.view.rich.context.AdfFacesContext;
import oracle.adf.view.rich.event.DialogEvent;

import oracle.binding.OperationBinding;

import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.domain.Number;

import oracle.stellent.ridc.IdcClientException;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.myfaces.trinidad.event.ReturnEvent;
import org.apache.myfaces.trinidad.event.SelectionEvent;
import org.apache.myfaces.trinidad.model.RowKeySet;
import org.apache.myfaces.trinidad.model.RowKeySetImpl;

public class FormLetterListBean {
    private RichTable formLetterListTblBind;
    private RichShowDetailItem subTypeBind;
    private RichPopup formLtrTextBind;
    private RichPopup popupArchive;
    private String packaingErrorMsg;
    private String infoMsg;
    private static ADFLogger logger =
        ADFLogger.createADFLogger(FormLetterListBean.class);
    private static final ResourceBundle rb =
                ResourceBundle.getBundle(CllConstants.RESOURCE_BUNDLE_LOCATION);
    private RichPopup popupError;
    private RichPopup popupInfo;
    
    private String wsdlURL="";
    private String namespaceURI="";
    private String localPart="";
    private RichPopup popupProcess;
    private static final String DASH = "-";
    private RichPopup popupChgActionWarnMsg;
    private String actnChgWarnMsg;
    private String archiveWarnMsg;
    private RichPopup popupChgAction;
    private String chgActionPopUpTitle;
    private String chgActionMsg;
    private String cllTypeOtherDesc;
    private RichPopup popupApprove;
    private String ApproveWarnMsg="";

    public FormLetterListBean() {
    }

    public void setFormLetterListTblBind(RichTable formLetterListTblBind) {
        this.formLetterListTblBind = formLetterListTblBind;
    }

    public RichTable getFormLetterListTblBind() {
        return formLetterListTblBind;
    }

    /**
     * Process form letters after confirmation by clicking "Yes" in popup
     *
     * @param dialogEvent
     */
    public void processDialogListener(DialogEvent dialogEvent) {
        logger.info("Processing Form Letter.... : " + dialogEvent.getOutcome());
        if (DialogEvent.Outcome.yes == dialogEvent.getOutcome()) {
            logger.info("Start processing form letters...");
            try {
//                DatabaseResourceBundle dsbundle = new DatabaseResourceBundle();
//                Map appProps = dsbundle.getResourceBundle();
//                String wsdlURL = (String)appProps.get("CLL_FORMLETTER_URL");
//                String namespaceURI = (String)appProps.get("CLL_FORMLETTER_QNAME_NAMESPACE_URI");
//                String localPart = (String)appProps.get("CLL_FORMLETTER_QNAME_LOCALPART");
//                logger.info("wsdlURL => " + wsdlURL);
//                logger.info("nsURI => " + namespaceURI);
//                logger.info("localPart => " + localPart);
//                if (null == wsdlURL || null == namespaceURI || null == localPart) {
//                    logger.severe("ERROR : Proxy details are empty");
//                    JSFUtils.addFacesErrorMessage(rb.getString("FETCHING_PROXY_DETAILS_ERROR_MSG"));
//                } else {
                Number fileNumberId =
                    (Number)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pFileNumId");
                logger.info("FormLetterListBean.processDialogListener :: Process File Number Id : " + fileNumberId);
//                    logger.info("Invoking Form Letter Processing Proxy.");
//                    FormLetterProcessingWrapper wrapper = 
//                        new FormLetterProcessingWrapper(wsdlURL, namespaceURI, localPart);
//                    wrapper.processFormLetters(fileNumberId.intValue());
                    
                //Invoke operation binding : formLetterProcessing
                OperationBinding operFLProc = ADFUtils.findOperation("formLetterProcessing");
                operFLProc.getParamsMap().put("fileNumberId", fileNumberId);
                operFLProc.execute();
                if (!operFLProc.getErrors().isEmpty()){
                    throw new Exception("Error in Form Letter Processing : " + operFLProc.getErrors());
                }
                logger.fine("Invoking Conextual Event to Show Comment Inbox");
                ActionEvent actionEvent = new ActionEvent(dialogEvent.getComponent());
                ADFUtils.processActionEvent(actionEvent, "processFormLettersEventBinding");
//                }
            } catch (Exception e) {
                logger.severe(rb.getString("FORMLETTERLIST_PROCESSING_ERROR_MSG"), e);
                JSFUtils.addFacesErrorMessage(rb.getString("FORMLETTERLIST_PROCESSING_ERROR_MSG"));
            }
            popupProcess.hide();
        }
    }

    public void selectAllCheckBoxes(ValueChangeEvent valueChangeEvent) {
        boolean isSelected = ((Boolean)valueChangeEvent.getNewValue()).booleanValue();
        DCIteratorBinding fileNumIterator = ADFUtils.findIterator("CllCommentsListROView1Iterator"); 
        RowSetIterator rsi = fileNumIterator.getViewObject().createRowSetIterator(null);
        rsi.reset();  
        while (rsi.hasNext()) {
            Row row = rsi.next();
            row.setAttribute("SelectAttr", isSelected);
        }
        rsi.closeRowSetIterator();
        AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
    }

    public void setAssignToMe(ActionEvent actionEvent) {
        RowKeySet rksSelectedRows=formLetterListTblBind.getSelectedRowKeys(); //reusable method
        if (rksSelectedRows.size() <=0 ){
            JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_ASSIGNING_NO_FL_INSTANCE_SELECTED_MSG")); 
            return;
        }
        ArrayList<Number>  commIds =  CllUtils.getSelectedCommentsFromBulkProcess(rksSelectedRows,"CllCommentsListROView1Iterator");
        OperationBinding opb = ADFUtils.findOperation("setActiontoFormLetter");
        opb.getParamsMap().put("action", "ASSIGN");
        opb.execute();
        String rslt = (String)opb.getResult();
        if(null != rslt && rslt.equalsIgnoreCase("User Found")){
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            ADFUtils.refreshIterator("CllCommentsListROView1Iterator"); 
            AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            formLetterListTblBind.getSelectedRowKeys().removeAll();
        }else{
            packaingErrorMsg=rb.getString("ASSIGN_COMMENTS_ERROR_MSG");
            getPopupError().show(new RichPopup.PopupHints()); 
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            formLetterListTblBind.getSelectedRowKeys().removeAll();
        }
    }
    
    public List getSubTypeList(){
        ArrayList<SelectItem> list = new ArrayList<SelectItem>();
        DCIteratorBinding subTypeIter = ADFUtils.findIterator("CllFormLetterSubTypeROView1Iterator"); 
        RowSetIterator rsi = subTypeIter.getViewObject().createRowSetIterator(null);
        rsi.reset();  
        while (rsi.hasNext()) {
            Row row = rsi.next();
            SelectItem si = new SelectItem();
            si.setLabel((String)row.getAttribute("SubType"));
            si.setValue(row.getAttribute("FormLetterCount"));
            list.add(si);
        }
        rsi.closeRowSetIterator();
        return list;
    }

     /**
     * Set selected comments to archive
     *
     */
     private void setArchiving() {
     logger.info("Start ...setArchiving method with bounded operation");    
     // Set selected comments to archive
         OperationBinding opb = ADFUtils.findOperation("setArchive");
         opb.execute();
         if(opb.getErrors().isEmpty()){
             String rslt = (String)opb.getResult();
             //Reset checkboxes
             if(null != rslt){
                 logger.info("Refreshing list of comments");  
                 CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                 formLetterListTblBind.getSelectedRowKeys().removeAll();
                 ADFUtils.refreshIterator("CllCommentsListROView1Iterator"); 
                 AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
             }else{
                 packaingErrorMsg=rb.getString("COMMENTLIST_ARCHIVE_ERROR_MSG");
                 getPopupError().show(new RichPopup.PopupHints());  
             }   
         }else{ 
                JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_ARCHIVE_ERROR_MSG"));  
             }
     }

    public void subTypeDiscLstnr(ActionEvent actionEvent) {
        //Parameters for method are being taken from taskflow input parameters
        CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
        formLetterListTblBind.getSelectedRowKeys().removeAll();
        ADFUtils.refreshIterator("CllCommentsListROView1Iterator"); 
        AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
        OperationBinding opb = ADFUtils.findOperation("executeFormLetterListByType");
        opb.execute();
        AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
    }

    public void setSubTypeBind(RichShowDetailItem subTypeBind) {
        this.subTypeBind = subTypeBind;
    }

    public RichShowDetailItem getSubTypeBind() {
        return subTypeBind;
    }
 
    
    
    
    public void viewMatchText(ActionEvent actionEvent) {
        OperationBinding opb = ADFUtils.findOperation("fetchFormLtrText");
        opb.execute();
        if(opb.getErrors().isEmpty()){
            this.getFormLtrTextBind().show(new RichPopup.PopupHints());
        }
    }

    /**
     * Executes the form letter publishing in case 'Yes' is clicked in popup dialog confirmation
     * 
     * @param dialogEvent
     */
    public void publishFormLetterDialogListener(DialogEvent dialogEvent) {
        logger.info("Publishing Form Letter.... : " + dialogEvent.getOutcome());       
        
        //If 'No' is clicked, do not publish the form letter
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.no) {
            return;
        }
        //-----Retrieve the Current Form Letter Type Info
        DCIteratorBinding subTypeDC = ADFUtils.findIterator("CllCommentsListROView1Iterator");
        if(null ==subTypeDC){
            logger.info("Comment List Interator  is null  !!");
            logger.info(rb.getString("FORMLETTERLIST_PUBLISH_UNPUBLISH_ERROR_GETTING_FL_DETAILS"));
            showPopupErrorMsg(rb.getString("FORMLETTERLIST_PUBLISH_UNPUBLISH_ERROR_GETTING_FL_DETAILS"));
            return;
        }
        CllCommentsListROViewRowImpl subTypeRow = (CllCommentsListROViewRowImpl)subTypeDC.getCurrentRow();
        if(null ==subTypeRow){
            logger.info("Form Letter row is null !!");
            logger.info(rb.getString("FORMLETTERLIST_PUBLISH_UNPUBLISH_ERROR_GETTING_FL_DETAILS"));
            showPopupErrorMsg(rb.getString("FORMLETTERLIST_PUBLISH_UNPUBLISH_ERROR_GETTING_FL_DETAILS"));
            return;
        } 
         
        logger.info("Current :: Form Letter Id : {0} :: Form Letter SubType : {1}",
                    new Object[] { subTypeRow.getFormLetterId(), subTypeRow.getSubType() });
        
        try {
          
            //-----Retrieve the Comment Detail first row from the form letter list 
            //Looking for the Comment Detail by Id for the first comment in list
            DCIteratorBinding dcFormLetterList = ADFUtils.findIterator("CllCommentsListROView1Iterator");
            CllCommentsListROViewRowImpl firstComm = (CllCommentsListROViewRowImpl)dcFormLetterList.getViewObject().first();
            if (firstComm != null){
                logger.info("Comment Detail Id : {0} :: File Number Id :{1}",
                            new Object[] { firstComm.getCllCommDetId(), firstComm.getFilenumId() });
            } else {
                logger.info(rb.getString("FORMLETTERLIST_PUBLISHING_COUTING_ZERO_MSG"));
                showPopupErrorMsg(rb.getString("FORMLETTERLIST_PUBLISHING_COUTING_ZERO_MSG"));
                return;
            }
        
            //-----Retrieve more info for the first Comment Detail
            Number cllCommDetId = firstComm.getCllCommDetId();
            Number fileNumId=subTypeRow.getFilenumId();
           
            OperationBinding oper = ADFUtils.findOperation("findCommentDetailById");
            oper.getParamsMap().put("commDetId", cllCommDetId);
            oper.execute();
            if (!oper.getErrors().isEmpty()){
                logger.severe("Error on searching for Comment Detail id = " + cllCommDetId + " :: " +  oper.getErrors());
                throw new RuntimeException(rb.getString("FORMLETTERLIST_PUBLISHING_SEARCH_COMMENTDETAIL_ERROR_MSG"));
            } 
            //we are using updatable iterator  to get  comment details. 
            DCIteratorBinding dc = ADFUtils.findIterator("CllCommentDetailsView2Iterator");
            CllCommentDetailsViewRowImpl commDetRow = (CllCommentDetailsViewRowImpl)dc.getCurrentRow();
            //avoided NPE error due to comments field
            logger.info("==== Comment id ==== \n" + commDetRow.getCllCommDetId());
            
            //-----Calculate the total number of comments under the form letter subtype
            Integer numOfInstances = countApprovedFormLetterInstances(subTypeRow.getFormLetterId());
            if (numOfInstances == null){ 
                showPopupErrorMsg(rb.getString("FORMLETTERLIST_PUBLISHING_COUTING_ERROR_MSG"));
                return;
            } else if (numOfInstances == 0){
                showPopupErrorMsg(rb.getString("FORMLETTERLIST_PUBLISHING_COUTING_ZERO_MSG"));
                return;
            }
            
            //-----Lock the File Number in File Number Processing
            OperationBinding lockFileNumber = ADFUtils.findOperation("lockFileNumber");
            lockFileNumber.getParamsMap().put("fileNumberId", subTypeRow.getFilenumId());
            lockFileNumber.execute();
            if (lockFileNumber.getErrors().isEmpty()){
                Boolean success = (Boolean)lockFileNumber.getResult();
                if (!success){
                    throw new RuntimeException(rb.getString("FORMLETTERLIST_PUBLISHING_FILENUMER_LOCKED_MSG"));
                }
            } else {
                logger.severe(rb.getString("FORMLETTERLIST_PUBLISHING_FILENUMER_LOCK_ERROR_MSG") + ":: ERROR : " + lockFileNumber.getErrors());
                throw new RuntimeException(rb.getString("FORMLETTERLIST_PUBLISHING_FILENUMER_LOCK_ERROR_MSG"));
            }
            
            //-----Add up the number of form letter instances to Form Letter Published Count
            OperationBinding addUpPublishedCount = ADFUtils.findOperation("addUpPublishedCount");
            addUpPublishedCount.getParamsMap().put("formLetterId", subTypeRow.getFormLetterId());
            addUpPublishedCount.getParamsMap().put("addCount", numOfInstances.intValue());
            addUpPublishedCount.execute();
            if (!addUpPublishedCount.getErrors().isEmpty()){
                logger.severe(rb.getString("FORMLETTERLIST_PUBLISHING_ADDUP_COUNT_ERROR_MSG" + " :: " + addUpPublishedCount.getErrors()));
                unlockFileNumber(subTypeRow.getFilenumId()); 
                throw new RuntimeException(rb.getString("FORMLETTERLIST_PUBLISHING_ADDUP_COUNT_ERROR_MSG"));
            }
            Number newCount = (Number)addUpPublishedCount.getResult();
            numOfInstances = newCount.intValue();

            //-----Generate files in a folder and package (ZIP) the folder
            
            OperationBinding retrieveMasterFileNumId = ADFUtils.findOperation("findMasterFileNumId");
            retrieveMasterFileNumId.getParamsMap().put("fileNumId", subTypeRow.getFilenumId());
            retrieveMasterFileNumId.execute(); 
            Number masterFileNumId=null; 
            if (retrieveMasterFileNumId.getErrors().isEmpty()){
                    masterFileNumId = (Number)retrieveMasterFileNumId.getResult();
                    if (masterFileNumId == null){
                        logger.severe("ERROR....Error...  retrieving  Master file number id *****************");
                        unlockFileNumber(subTypeRow.getFilenumId()); 
                        throw new RuntimeException(rb.getString("FORMLETTERLIST_PUBLISHING_GET_RELEASENUMBERS_ERROR_MSG"));
                    }
             } else {
                    logger.severe("ERROR....Error...  retrieving  Master file number id *****************" + retrieveMasterFileNumId.getErrors());
                    unlockFileNumber(subTypeRow.getFilenumId()); 
                    throw new RuntimeException(rb.getString("FORMLETTERLIST_PUBLISHING_GET_RELEASENUMBERS_ERROR_MSG"));
            }
            List<String> relNums= CllUtils.getReleaseNumsForMasterFileNumber(masterFileNumId);
            
            String releaseNumbers = ""; 
            if(null != relNums){
                releaseNumbers=relNums.toString();
            }else{ //error retrieving release numbers
                 logger.severe("ERROR....Error...  retrieving  Master file number id *****************" + retrieveMasterFileNumId.getErrors());
                 unlockFileNumber(subTypeRow.getFilenumId()); 
                 throw new RuntimeException(rb.getString("FORMLETTERLIST_PUBLISHING_GET_RELEASENUMBERS_ERROR_MSG"));
             } 
            logger.info("Release Nos  fetched from master file number module is  : "  +releaseNumbers );
            if(!relNums.isEmpty()){
               releaseNumbers=releaseNumbers.substring(1, releaseNumbers.length()-1);
                releaseNumbers = "Release No. " + releaseNumbers  + "; ";   
            }
          
            PackageInfoDTO infoDTO = new PackageInfoDTO();
            String fileNumber = JSFUtils.resolveExpressionAsString("#{pageFlowScope.pFileTypeFileNumber}");
            infoDTO.setFileNumber(fileNumber);
            
            //Information for Form Letter Index Page
            Map<String,String> indexPageMap = new HashMap<String,String>();
            String title = subTypeRow.getSubject();
            if(null != title){
                title= StringEscapeUtils.escapeHtml(title.trim());  
            }
            indexPageMap.put("title", title);
            indexPageMap.put("release_numbers", releaseNumbers);
            logger.info("******* Packaging for File Number : " + fileNumber);
            indexPageMap.put("file_number", fileNumber);
            indexPageMap.put("form_letter_type", subTypeRow.getSubType());
            indexPageMap.put("form_letter_instances", numOfInstances.toString());
            indexPageMap.put("index_page_template",
                             getTemplateContentByCode(CllConstants.FORMLETTER_INDEXPAGE_TEMPLATE_CODE));
            infoDTO.setIndexPageInfo(indexPageMap);
            infoDTO.setTargetDirectory(getCommentsPackagingDir());
            
            //Information for Form Letter Comment Page
            Map<String,String> commntpgMap = new HashMap<String, String>();
            commntpgMap.put("form_letter_type", subTypeRow.getSubType());
            //avoid NPE on comments field
            String comments="";
            if(null != commDetRow.getComments()){
                 comments=commDetRow.getComments().toString().trim();
            }
            String parsedText= StringEscapeUtils.escapeHtml(comments); 
            commntpgMap.put("form_letter_comment", "<pre style=\"white-space: pre-wrap; white-space: -moz-pre-wrap; white-space: -pre-wrap; white-space: -o-pre-wrap; word-wrap: break-word;\">"+parsedText+"</pre>");
            commntpgMap.put("file_number", fileNumber);
            commntpgMap.put("comment_page_template",
                            getTemplateContentByCode(CllConstants.FORMLETTER_COMMENTPAGE_TEMPLATE_CODE));
            infoDTO.setFormLetterCommntInfo(commntpgMap);
            
            //-----Generates and packages the files
            String zipFileName = PackageUtils.createFormLetterZIP(infoDTO);
            if(null ==zipFileName){
                 logger.info(" Error   generating  zip file for publishing form letter  *****************"); 
                 showPopupErrorMsg(rb.getString("FORMLETTERLIST_ERROR_GENERATING_ZIPFLLE_FOR_PUB_FORMLETTER")); 
                 unlockFileNumber(subTypeRow.getFilenumId()); 
                 return ;  
            }
            
    
            //-----Upload the ZIP file to UCM and to Attachments
            uploadZipToUCM(infoDTO.getTargetDirectory(), zipFileName, subTypeRow.getFilenumId(), true);
            
            //-----DML Update the Status Type to Published in all Comments that are processed and approved disposition
            if (!updateStatusPublished(subTypeRow.getFormLetterId())){
                unlockFileNumber(subTypeRow.getFilenumId()); 
                throw new RuntimeException(rb.getString("FORMLETTERLIST_PUBLISHING_UPDATE_STATUS_ERROR_MSG"));
            } 
            //-----Unlock the File Number in File Number Processing
            OperationBinding unlockFileNumber = ADFUtils.findOperation("unlockFileNumber");
            unlockFileNumber.getParamsMap().put("fileNumberId", subTypeRow.getFilenumId());
            unlockFileNumber.execute();
            
            //-----Persist to DB
            if(ADFUtils.doCommit()){
                ADFUtils.refreshIterator("CllCommentsListROView1Iterator"); 
                AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
                showPopupInfoMsg(rb.getString("FORMLETTERLIST_PUBLISHING_SUCCESS_MSG"));
            } 
            
        } catch (Exception e){
            logger.severe(rb.getString("FORMLETTERLIST_PUBLISHING_FAILED_MSG"), e);
            showPopupErrorMsg(rb.getString("FORMLETTERLIST_PUBLISHING_FAILED_MSG"));
            unlockFileNumber(subTypeRow.getFilenumId()); 
            ADFUtils.doRollback();           
            AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
        }
    }

    /** Verifies whether user has selected comments to archive. If not, control goes back to UI page.
      *
      * @return
      */
     public String clickArchiveButtonAction() {
         logger.info("Archive button clicked");
         ArrayList<Number>  commIds = new ArrayList<Number> ();     
         commIds=selectedComments ();  // get selected list of comments
         if(commIds.size() > 0) {
             AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT", commIds.size());
             this.setArchiveWarnMsg( "Selected "+ commIds.size() + 
                                                " comment(s) will be archived. Do you wish to proceed? ");
             
               //RichPopup.PopupHints hints = new RichPopup.PopupHints();   
            this.getPopupArchive().show(new RichPopup.PopupHints());
         }else {
            JSFUtils.addFacesErrorMessage("Please select atleast one comment to archive.");
         }
         return null;     
    }

    /**
     * Dialog listener to confirm archiving of selected comment letters.
     * Clicking "Ok" from the popup, it will archive the comments
     * and refresh comment list/
     * 
     * @param dialogEvent
     */
    public void archivingDialogListener(DialogEvent dialogEvent) {
        logger.info("Start ................. archivingDialogListener, dialog outcome = " + dialogEvent.getOutcome());
        // Archive comments
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.yes) {
            setArchiving();
            JSFUtils.addFacesInformationMessage("Selected " +
                                                AdfFacesContext.getCurrentInstance().getViewScope().get("COMMENTS_COUNT") +
                                                " comment(s) archived successfully.");
        }else{
            this.getPopupArchive().cancel();
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            formLetterListTblBind.getSelectedRowKeys().removeAll();
            AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
        }
    }
    
    /** Retrieves  selected comments in comment list tab
     *
     * @return
     */
    public ArrayList<Number>  selectedComments () {
        RowKeySet rksSelectedRows = formLetterListTblBind.getSelectedRowKeys(); //reusable method
        ArrayList<Number>  commIds =  CllUtils.getSelectedCommentsFromBulkProcess(rksSelectedRows,"CllCommentsListROView1Iterator");
       
        return commIds;
    }




    /**Unlocks the file number from processing table
     *
     * @param fileNumId
     */
    private void unlockFileNumber(Number fileNumId){
        OperationBinding unlockFileNumber = ADFUtils.findOperation("unlockFileNumber");
        unlockFileNumber.getParamsMap().put("fileNumberId",fileNumId ); 
        unlockFileNumber.execute(); 
        if(!unlockFileNumber.getErrors().isEmpty()){
            logger.info("***************  Error while unlocking the file number *******************  "  +fileNumId); 
            showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_UNLOCKING_FILE_NUMBER"));   
        }
    }
    
    
    
    /**
     * Uploads zip file to UCM
     *
     * @param dir       Directory path where the zip file is located
     * @param fileName  Zip file name
     * @param fileNumberId  File Number Id
     */
    private void uploadZipToUCM(String dir, String fileName, Number fileNumberId, boolean isPublish) {
        try {
            File newFile = new File(dir, fileName);
            InputStream inputStream = new FileInputStream(newFile);
            logger.info("File Length : " + newFile.length());
            byte[] byteArrayFile = convertInputStreamToByeArray(inputStream);
            logger.info("Byte array length : " + byteArrayFile.length);
            
            String username = SecurityUtils.getUserNameFromSessionOrContext();
            Map<String, String> props = getApplicationProperties();        
                        
            //Prepararing document for UCM
            Document doc = new Document();
            doc.setByteArrayFile(byteArrayFile);
            doc.setFileName(fileName);
            doc.setFileLength(newFile.length()); 
            doc.setCaseId(fileNumberId.toString());
            doc.setModuleName(SharedCompConstants.CLL_PKG_MODULE); //CLLPKG
            doc.setAppName(props.get("APP_NAME_CLL"));
            doc.setDocAccount(props.get("ACCOUNT_NAME_CLL_RWD"));
            
            // Check file into UCM 
            RIDCService ridService = new RIDCService(username, props); 
            Document upDocInfo =  ridService.uploadDocument(doc);
            logger.info("ZIP File Checked In. Id = " + upDocInfo.getDocId());
            
            //Getting username
//            String username = ADFContext.getCurrent().getSecurityContext().getUserName(); 
            logger.info("Current logged in username : " + username);
            
            //Adding to attachments
            List<Map> attachments = new ArrayList<Map>(); 
            Map attachmentmap = new HashMap();
            attachmentmap.put("CaseId", fileNumberId);
            attachmentmap.put("DocumentTypeID", getDocumentType() );   //document type id 
            attachmentmap.put("OtherDocTypeDesc", null);   //even if it is NULL ************we should be fine 
            attachmentmap.put("DocName", fileName);  
            attachmentmap.put("ModuleName", doc.getModuleName()); 
            attachmentmap.put("Author", username);
            attachmentmap.put("UcmId", upDocInfo.getDocId());
            if (isPublish){
                attachmentmap.put("PubPkgFlag", "Y");    
            } else {
                attachmentmap.put("PubPkgFlag", "N");                    
            }
            
            attachments.add(attachmentmap); 
            
            //commit the  attachments in  attachment table
            if (attachments.size() > 0) {
                OperationBinding operation = ADFUtils.findOperation("addAttachments"); 
                operation.getParamsMap().put("attachments", attachments);
                operation.execute(); 
                if (operation.getErrors().isEmpty()){
                    if (!ADFUtils.performBindingAction("CommitShareComp")){
                        throw new RuntimeException("Error on commit share components.");
                    }
                } else {
                    throw new RuntimeException("Error on inserting a new attachment row for Zip file.");
                }
            } 
            
            inputStream.close();
            
        } catch (FileNotFoundException e) {
            logger.severe(rb.getString("FORMLETTERLIST_PACKAGE_FILE_NOTFOUND_ERORR_MSG"), e);
            throw new RuntimeException(e);
        } catch (IdcClientException e) {
            logger.severe(rb.getString("RIDCSERVICE_LOAD_UCM_METADATA_ERROR_MSG"), e);
            throw new RuntimeException(e);
        } catch (IOException e) {
            logger.severe(rb.getString("PACKAGE_FILE_CLOSING_STREAM_ERROR_MSG"), e);
            throw new RuntimeException(e);
        } catch (Exception e) {
            logger.severe(rb.getString("Error during the process of uploading ZIP file"), e);
            throw new RuntimeException(e);
        }
    }
    
    public Map<String, String> getApplicationProperties(){
        Map<String,String> appProps = new HashMap<String,String>();
        OperationBinding binding = ADFUtils.findOperation("getResourceBundle");
        binding.execute();
        if (binding.getErrors().isEmpty()){
            appProps = (Map<String, String>) binding.getResult();
        } else {
            JSFUtils.addFacesErrorMessage(rb.getString("APPLICATION_PROPERTIES_RETRIEVE_ERROR"));
        }
        return appProps;
    }

    /**
     * Retrieves the tenplate content by a specific code
     *
     * @return
     */
    private String getTemplateContentByCode(String code) {
        String content = "";
        OperationBinding getTemplateContent = ADFUtils.findOperation("getTemplateContent");
        getTemplateContent.getParamsMap().put("code", code);
        getTemplateContent.execute();
        if (getTemplateContent.getErrors().isEmpty()){
            content = (String)getTemplateContent.getResult();
        }
        return content;
    }
    
    /**
     * Retrieves and returns the code for meeting minutes type id from reference data
     *
     * @return
     */
    private Number getDocumentType() {
        Number docTypeId = new Number();
        OperationBinding findDocTypeId = ADFUtils.findOperation("getDocumentTypeId");
        findDocTypeId.getParamsMap().put("code", SharedCompConstants.DOC_TYPE_PUBLISHING_PACKAGE_CODE);
        findDocTypeId.execute();
        if (findDocTypeId.getErrors().isEmpty()){
            docTypeId = (Number)findDocTypeId.getResult();
        }
        return docTypeId;
    }
    
    /** Convert  input stream to byte array 
     *
     * @param is   File  input stream
     * @return
     */
    public byte[] convertInputStreamToByeArray(InputStream is){ 
      ByteArrayOutputStream bos = new ByteArrayOutputStream();  
      BufferedInputStream bIn = new BufferedInputStream(is);
        byte[] buf = new byte[1024];
        try {
            for (int readNum; (readNum = bIn.read(buf)) != -1;) {
                bos.write(buf, 0, readNum); //no doubt here is 0
                //Writes len bytes from the specified byte array starting at offset off to this byte array output stream.
                logger.finest("Read  " + readNum + " bytes,"); 
            }
            byte[] bytes = bos.toByteArray();
            return bytes;
        } catch (IOException ex) {
            logger.info(ex.toString());
             return null;
        }   
        
    }
    
    /**
     * Retrieves packaging dir from application properties and it is used to create packing for comments that get published 
     *
     * @return  packaging dir for comments
     */
    private String getCommentsPackagingDir(){
        OperationBinding appPropOper = ADFUtils.findOperation("getResourceBundle");
        appPropOper.execute();
        if (appPropOper.getErrors().isEmpty()){
            Map map = (Map)appPropOper.getResult();
            String dir = (String)map.get("CLL_PACKAGING_DIR");
            logger.info("CLL_PACKAGING_DIR = " + dir);
            return dir;
        } else {
            logger.severe("CLL_PACKAGING_DIR not found in application properties");
            return null;
        }
    }
    
    /**
     * Executes operation binding to update the status to Published for comments details
     *
     * @param formLetterId  Form Letter Id
     * @return  True/False indicating success
     */
    private boolean updateStatusPublished(Number formLetterId){
        boolean success = true;
        OperationBinding updateStatus = ADFUtils.findOperation("updateCommentDetPublishStatus");
        updateStatus.getParamsMap().put("formLetterId", formLetterId);
        updateStatus.execute();
        if (!updateStatus.getErrors().isEmpty()){
            success = false;
            logger.severe(rb.getString("FORMLETTERLIST_PUBLISHING_UPDATE_STATUS_ERROR_MSG") + " :: " + updateStatus.getErrors());
        }
        return success;
    }
    
    /**
     * Executes operation binding to count the number of form letter intances
     *
     * @param formLetterId  Form Letter Id
     * @return  Count for form letter instances
     */
    private Integer countApprovedFormLetterInstances(Number formLetterId){
        Integer count = null;
        
        OperationBinding counter = ADFUtils.findOperation("countApprovedFormLetterInstances");
        counter.getParamsMap().put("formLetterId", formLetterId);
        counter.execute();
        if (!counter.getErrors().isEmpty()){
            logger.severe(rb.getString("FORMLETTERLIST_PUBLISHING_COUTING_ERROR_MSG") + " :: " + counter.getErrors());
            return null;
        } else {
            count = (Integer)counter.getResult();            
        }
        logger.info("FormLetterListBean.countApprovedFormLetterInstances() :: count = " + count);
        return count;
    }
    
    /**
     * Executes the form letter un-publishing in case 'Yes' is clicked in popup dialog confirmation
     * 
     * @param dialogEvent
     */
    public void unpublishFormLetterDialogListener(DialogEvent dialogEvent) {
        logger.info("Un-Publishing Form Letter.... : " + dialogEvent.getOutcome());
        //If 'No' is clicked, do not un-publish the form letter
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.no) {
            return;
        }
        //-----Retrieve the Current Form Letter Type Info 
        DCIteratorBinding subTypeDC = ADFUtils.findIterator("CllCommentsListROView1Iterator");
        if(null ==subTypeDC){
            logger.info("Comment List Interator  is null  !!");
            logger.info(rb.getString("FORMLETTERLIST_PUBLISH_UNPUBLISH_ERROR_GETTING_FL_DETAILS"));
            showPopupErrorMsg(rb.getString("FORMLETTERLIST_PUBLISH_UNPUBLISH_ERROR_GETTING_FL_DETAILS"));
            return;
        }
        CllCommentsListROViewRowImpl subTypeRow = (CllCommentsListROViewRowImpl)subTypeDC.getCurrentRow();
        if(null ==subTypeRow){
            logger.info("Form Letter row is null !!");
            logger.info(rb.getString("FORMLETTERLIST_PUBLISH_UNPUBLISH_ERROR_GETTING_FL_DETAILS"));
            showPopupErrorMsg(rb.getString("FORMLETTERLIST_PUBLISH_UNPUBLISH_ERROR_GETTING_FL_DETAILS"));
            return;
        }
        logger.info("Current :: Form Letter Id : {0} :: Form Letter SubType : {1}",
                    new Object[] { subTypeRow.getFormLetterId(), subTypeRow.getSubType() });
        Number fileNumId=subTypeRow.getFilenumId();
        try{
        
            //-----Count published form letter instances for unpublishing
            Integer numOfInstances = countPublishedFormLetterInstances(subTypeRow.getFormLetterId());
            if (numOfInstances == null){
                throw new RuntimeException(rb.getString("FORMLETTERLIST_UNPUBLISHING_COUTING_ERROR_MSG"));
            } else if (numOfInstances == 0){
                logger.info(rb.getString("FORMLETTERLIST_UNPUBLISHING_COUTING_ZERO_MSG"));
                showPopupErrorMsg(rb.getString("FORMLETTERLIST_UNPUBLISHING_COUTING_ZERO_MSG"));
                return;
            }
            
            //-----Lock the File Number in File Number Processing
            OperationBinding lockFileNumber = ADFUtils.findOperation("lockFileNumber");
            lockFileNumber.getParamsMap().put("fileNumberId", subTypeRow.getFilenumId());
            lockFileNumber.execute();
            if (lockFileNumber.getErrors().isEmpty()){
                Boolean success = (Boolean)lockFileNumber.getResult();
                if (!success){
                    throw new RuntimeException(rb.getString("FORMLETTERLIST_UNPUBLISHING_FILENUMER_LOCKED_MSG"));
                }
            } else {
                logger.severe(rb.getString("FORMLETTERLIST_UNPUBLISHING_FILENUMER_LOCK_ERROR_MSG") + ":: ERROR : " + lockFileNumber.getErrors());
                throw new RuntimeException(rb.getString("FORMLETTERLIST_UNPUBLISHING_FILENUMER_LOCK_ERROR_MSG"));
            }
            
            //-----Resets the published count to zero (0)
            OperationBinding resetPublishedCount = ADFUtils.findOperation("resetPublishedCount");
            resetPublishedCount.getParamsMap().put("formLetterId", subTypeRow.getFormLetterId());
            resetPublishedCount.execute();
            if (!resetPublishedCount.getErrors().isEmpty()){
                unlockFileNumber(subTypeRow.getFilenumId());
                logger.severe(rb.getString("FORMLETTERLIST_UNPUBLISHING_RESET_COUNT_ERROR_MSG" + " :: " + resetPublishedCount.getErrors()));
                throw new RuntimeException(rb.getString("FORMLETTERLIST_UNPUBLISHING_RESET_COUNT_ERROR_MSG"));
            }

            PackageInfoDTO infoDTO = new PackageInfoDTO();
            String fileNumber = JSFUtils.resolveExpressionAsString("#{pageFlowScope.pFileTypeFileNumber}");
            infoDTO.setFileNumber(fileNumber);
            infoDTO.setFormLetterSubType(subTypeRow.getSubType());
            infoDTO.setTargetDirectory(getCommentsPackagingDir()); // is the root dir .../cas_documents/cll_packaging
            
            //-----Generates and packages the files for unpublishing
            String zipFileName = PackageUtils.createUnPublishedFormLetterZIP(infoDTO);
            if(null ==zipFileName){
                 logger.info(" Error   generating  zip file for Unpublishing form letteter  *****************"); 
                 showPopupErrorMsg(rb.getString("FORMLETTERLIST_ERROR_GENERATING_ZIPFLLE_FOR_UNPUB_FORMLETTER"));  
                 return ;  
            }
            
            
            //-----Upload the ZIP file to UCM
            uploadZipToUCM(infoDTO.getTargetDirectory(), zipFileName, subTypeRow.getFilenumId(), false);
            
            
            //-----DML Update the Status Type to Processed in all Comments that are published
            if (!updateStatusProcessed(subTypeRow.getFormLetterId())){
                unlockFileNumber(subTypeRow.getFilenumId());
                throw new RuntimeException(rb.getString("FORMLETTERLIST_UNPUBLISHING_UPDATE_STATUS_ERROR_MSG"));
            }
            
            //-----Unlock the File Number in File Number Processing
            unlockFileNumber(subTypeRow.getFilenumId()); 
            //-----Persist to DB
            if(ADFUtils.doCommit()){
                ADFUtils.refreshIterator("CllCommentsListROView1Iterator"); 
                AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
                showPopupInfoMsg(rb.getString("FORMLETTERLIST_UNPUBLISHING_SUCCESS_MSG"));
            }
        } catch(Exception e){
            logger.severe(rb.getString("FORMLETTERLIST_UNPUBLISHING_FAILED_MSG"), e);
            showPopupErrorMsg(rb.getString("FORMLETTERLIST_UNPUBLISHING_FAILED_MSG"));
            unlockFileNumber(fileNumId);
            ADFUtils.doRollback();
            AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);            
        }
    }
    
    /**
     * Executes operation binding to update the status to Published for comments details
     *
     * @param formLetterId  Form Letter Id
     * @return  True/False indicating success
     */
    private boolean updateStatusProcessed(Number formLetterId){
        boolean success = true;
        OperationBinding updateStatus = ADFUtils.findOperation("updateCommentDetProcessedStatus");
        updateStatus.getParamsMap().put("formLetterId", formLetterId);
        updateStatus.execute();
        if (!updateStatus.getErrors().isEmpty()){
            success = false;
            logger.severe(rb.getString("FORMLETTERLIST_UNPUBLISHING_UPDATE_STATUS_ERROR_MSG") + " :: " + updateStatus.getErrors());
        }
        return success;
    }
    
    /**
     * Executes operation binding to count the number of published form letter intances
     *
     * @param formLetterId  Form Letter Id
     * @return  Count for form letter instances
     */
    private Integer countPublishedFormLetterInstances(Number formLetterId){
        Integer count = null;
        
        OperationBinding counter = ADFUtils.findOperation("countPublishedFormLetterInstances");
        counter.getParamsMap().put("formLetterId", formLetterId);
        counter.execute();
        if (!counter.getErrors().isEmpty()){
            logger.severe(rb.getString("FORMLETTERLIST_UNPUBLISHING_COUTING_ERROR_MSG") + " :: " + counter.getErrors());
        } else {
            count = (Integer)counter.getResult();            
        }
        logger.info("FormLetterListBean.countPublishedFormLetterInstances() :: count = " + count);
        return count;
    }

    public void setFormLtrTextBind(RichPopup formLtrTextBind) {
        this.formLtrTextBind = formLtrTextBind;
    }

    public RichPopup getFormLtrTextBind() {
        return formLtrTextBind;
    }
    
    /** Refreshes  Form Letter list iterator
     * 
     */
    public void refreshFormLetterList(){
        ADFUtils.refreshIterator("CllCommentsListROView1Iterator");
    }

    /**
     * Opens a popup with a custom message
     */
    private void showPopupErrorMsg(String msg){
        packaingErrorMsg = msg;
        getPopupError().show(new RichPopup.PopupHints()); 
    }
    
    public void setPackaingErrorMsg(String packaingErrorMsg) {
        this.packaingErrorMsg = packaingErrorMsg;
    }

    public String getPackaingErrorMsg() {
        return packaingErrorMsg;
    }
    
    private void showPopupInfoMsg(String msg){
        infoMsg = msg;
        getPopupInfo().show(new RichPopup.PopupHints());
    }
    
    public void setInfoMsg(String infoMsg) {
        this.infoMsg = infoMsg;
    }

    public String getInfoMsg() {
        return infoMsg;
    }
    
    public void setPopupError(RichPopup popupError) {
        this.popupError = popupError;
    }

    public RichPopup getPopupError() {
        return popupError;
    }

    public void setPopupInfo(RichPopup popupInfo) {
        this.popupInfo = popupInfo;
    }

    public RichPopup getPopupInfo() {
        return popupInfo;
    }
    
    /** Retrieves webservice proxy details such as wsdl url etc from database for publishing  comments
     *
     * @return
     */
    private boolean  retrieveWebServiceProxyDetails(){
      
        DatabaseResourceBundle dsbundle = new DatabaseResourceBundle();
        Map props = dsbundle.getResourceBundle();  
        wsdlURL = (String)props.get("PUBLISHING_FORMLETTERS_WSDL_URL");
        namespaceURI = (String)props.get("PUBLISHING_FORMLETTERS_QNAME_NAMESPACE_URI");
        localPart = (String)props.get("PUBLISHING_FORMLETTERS_QNAME_LOCALPART"); 
        logger.info("wsdlURL => " + wsdlURL);
        logger.info("nsURI => " + namespaceURI);
        logger.info("localPart => " + localPart);
        if(null == wsdlURL || null == namespaceURI  || null == localPart){
            logger.severe("Error   ....Proxy details are empty  !!!**************************");
            JSFUtils.addFacesErrorMessage(rb.getString("FETCHING_PROXY_DETAILS_ERROR_MSG"));    
            return false;
        }
        return true;
    }

    public void editFormLtrTextDlgLstnr(DialogEvent dialogEvent) {
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.ok){
        ADFUtils.doCommit();
        }
    }
   
    /**Sets  the row pointer to the one which is returned by comment details task flow
         *
         * @param returnEvent
         */
    public void commentDetReturnListener(ReturnEvent returnEvent) {
             logger.info("Starting commDetIdReturnListerner   *******************************"); 
             Map map=returnEvent.getReturnParameters();         
             Number  commDetId=(Number) map.get("pCommDetId") ;          
             logger.info("Comment id returned by comment details task flow : "+commDetId);
             DCIteratorBinding dcItteratorBindings = ADFUtils.findIterator("CllCommentsListROView1Iterator");
             dcItteratorBindings.setCurrentRowWithKeyValue(commDetId.toString());
             Row row  = dcItteratorBindings.getCurrentRow();
             RowKeySetImpl newRowKeySet = new RowKeySetImpl();
             ArrayList nextLst = new ArrayList(1);
             nextLst.add(row.getKey());
             newRowKeySet.add(nextLst); 
             // set the row from comment details back  in  the comment list   ADF  Table
             formLetterListTblBind.setSelectedRowKeys(newRowKeySet);

            AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
            logger.info("Ending commDetIdReturnListerner   *******************************");
      }
    
     

    public void setPopupArchive(RichPopup popupArchive) {
        this.popupArchive = popupArchive;
    }

    public RichPopup getPopupArchive() {
        return popupArchive;
    }

    public void setPopupProcess(RichPopup popupProcess) {
        this.popupProcess = popupProcess;
    }

    public RichPopup getPopupProcess() {
        return popupProcess;
    }
    
    /**Sets the currently selected row back to the same in the iterator to avoid issue with check box check getting cleared
     *
     * @param selectionEvent
     */
    public void rowSelectionListener(SelectionEvent selectionEvent) {
        logger.info("Starting rowSelectionListener in form letter list tab  **********************");
        DCIteratorBinding dcItteratorBindings = ADFUtils.findIterator("CllCommentsListROView1Iterator");         
        RowKeySet rksSelectedRowsKeys = formLetterListTblBind.getSelectedRowKeys();   
        if(null != rksSelectedRowsKeys && !rksSelectedRowsKeys.isEmpty()){ 
           Iterator itrSelectedRows = rksSelectedRowsKeys.iterator();   
           // RowSetIterator rowSetItator = dcItteratorBindings.getRowSetIterator();             
           if (itrSelectedRows.hasNext()) { 
               Key key = (Key)((List)itrSelectedRows.next()).get(0);  
                  //if( null !=rowSetItator.getRow(key)) {  
                  //rowSetItator.setCurrentRow(row);
                   dcItteratorBindings.setCurrentRowWithKey(key.toStringFormat(true));
                   CllCommentsListROViewRowImpl  currentRow = (CllCommentsListROViewRowImpl) dcItteratorBindings.getCurrentRow();                    
                   currentRow.setSelectAttr(true);
                
           }
            
          JSFUtils.invokeMethodExpression("#{bindings.CllCommentsListROView1.collectionModel.makeCurrent}",
                                  Object.class, SelectionEvent.class,selectionEvent);
           
          logger.info("Ending rowSelectionListener in form letter list tab  **********************");
           
       } 
    }
    
    /**Clear the check box for the currently selected row before opening up comment details page.
     *
     * @param ae
     */
    public void commentLinkActionLsnr(ActionEvent ae) {
        // Add event code here...
        DCIteratorBinding dcItteratorBindings = ADFUtils.findIterator("CllCommentsListROView1Iterator");         
        CllCommentsListROViewRowImpl  currentRow = (CllCommentsListROViewRowImpl) dcItteratorBindings.getCurrentRow();                    
        currentRow.setSelectAttr(false); 
        //return null;
    }

    public void refreshIterators(ActionEvent actionEvent) {
        ADFUtils.refreshIterator("CllCommentsListROView1Iterator");
        DCIteratorBinding dcItteratorBindings = ADFUtils.findIterator("CllFormLetterView1Iterator");
        CllFormLetterViewRowImpl currentRow = (CllFormLetterViewRowImpl) dcItteratorBindings.getCurrentRow();
        if(null != currentRow){
        try {
            ADFUtils.setEL("#{pageFlowScope.pFileNumId}", new Number(currentRow.getFilenumId()));
        } catch (SQLException e) {
        }
        ADFUtils.setEL("#{pageFlowScope.pFrmLtrId}", currentRow.getCllFormLetterId().getSequenceNumber());
        OperationBinding opb = ADFUtils.findOperation("executeFormLetterListByType");
        opb.execute();
        AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
        }
    }

    /** Verifies whether user has selected comments to Change Action. If not, throws error.
     *
     * @return
     */
    public String clickChgActionLinkAction() {
        logger.info("Change Action Link clicked");
        ArrayList<Number> commIds = new ArrayList<Number>();
        commIds = selectedComments(); // get selected list of comments
        if (commIds.size() > 0) {
            AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT", commIds.size());
            this.setActnChgWarnMsg("Action will be changed in " +
                                   commIds.size() +
                                   " form letter. Do you wish to proceed?");
            this.getPopupChgActionWarnMsg().show(new RichPopup.PopupHints());
        } else {
            JSFUtils.addFacesErrorMessage("Please select atleast one form letter to change Action.");
        }
        return null;
    }

    public void setPopupChgActionWarnMsg(RichPopup popupChgActionWarnMsg) {
        this.popupChgActionWarnMsg = popupChgActionWarnMsg;
    }

    public RichPopup getPopupChgActionWarnMsg() {
        return popupChgActionWarnMsg;
    }

    public void chgActionPpDialogLstnr(DialogEvent dialogEvent) {
        logger.info("Start ................. ChgActionDialogListener, dialog outcome = " +
                    dialogEvent.getOutcome());
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.yes) {
            String action =
                (String)AdfFacesContext.getCurrentInstance().getViewScope().get("action");
            if (StringUtils.isNotBlank(action) && "ACTION".equals(action)) {
                ADFUtils.refreshIterator("CllActionTypeROView1Iterator");
                this.setChgActionPopUpTitle("Select Action Type");
                this.setChgActionMsg("Please select Action Type to be updated in the selected comments.");
            } else if (StringUtils.isNotBlank(action) &&
                       "COMMENT".equals(action)) {
                ADFUtils.refreshIterator("CllTypeROView2Iterator");
                this.setChgActionPopUpTitle("Select Comment Type");
                this.setChgActionMsg("Please select Comment Type to be updated in the selected comments.");
            } else if (StringUtils.isNotBlank(action) &&
                       "SOURCE".equals(action)) {
                ADFUtils.refreshIterator("CllSourceTypeROView1Iterator"); 
                this.setChgActionPopUpTitle("Select Source Type");
                this.setChgActionMsg("Please select Source Type to be updated in the selected comments.");
            }
            this.getPopupChgAction().show(new RichPopup.PopupHints());
        } else {
            this.getPopupChgActionWarnMsg().cancel();
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            formLetterListTblBind.getSelectedRowKeys().removeAll();
            AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
        }
    }
    
    
    /**Verifis any un approved comment is selected or not. If selected, displays confirmation window to proceed
        *
        * @param actionEvent
        */
       public void setApprove(ActionEvent actionEvent) {   
           RowKeySet rksSelectedRows = formLetterListTblBind.getSelectedRowKeys(); //reusable method
           ArrayList<Number>  commIds = getSelectedUnApprovedCommentsFromBulkProcess(rksSelectedRows,"CllCommentsListROView1Iterator");
           if(commIds.size() <= 0) {
               logger.info("num of selected form letters  :" +commIds.size()); 
               JSFUtils.addFacesErrorMessage("Please select at least one unapproved comment to approve.");
               return; 
           }
           AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT", commIds.size());
           this.setApproveWarnMsg( "Selected "+ commIds.size() + 
                                              " comment(s) will be approved. Do you wish to proceed? ");
           this.getPopupApprove().show(new RichPopup.PopupHints());
         
       }
    
    
    
    /**
         * Dialog listener to confirm approving of selected comment letters.
         * Clicking "Ok" from the popup, it will invoke method to approve the selected form letter instances
         * and refresh form letter list/
         * 
         * @param dialogEvent
         */
        public void approveDialogListener(DialogEvent dialogEvent) {
            logger.info("Start ................. approveDialogListener, dialog outcome = " + dialogEvent.getOutcome());
            // Archive comments
            if (dialogEvent.getOutcome() == DialogEvent.Outcome.yes) {
                setFormLetterApprove(); 
            }else{
                this.getPopupArchive().cancel(); 
            }
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            formLetterListTblBind.getSelectedRowKeys().removeAll();
            AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT", 0);
            AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
            logger.info("Ending............. approveDialogListener");
        }
        
        /**  Approves  selected form letter instances
         * 
         */
        public void setFormLetterApprove(){
            logger.info("Starting...... setFormLetterApprove");
            //if the file type is SR,  then we need to pass  form letter id and file num id to the approval method
            Number formLetId=null;
            Number fileNumId=null;
            String fileNumber = JSFUtils.resolveExpressionAsString("#{pageFlowScope.pFileTypeFileNumber}");
            String str[]=fileNumber.split(DASH);
            String fileNumTypeCode=str[0];
            if(fileNumTypeCode.equalsIgnoreCase(CllConstants.FILE_NUMBER_TYPE_SR_CODE)){
                    //-----Retrieve the Current Form Letter Type Info
                    DCIteratorBinding subTypeDC = ADFUtils.findIterator("CllCommentsListROView1Iterator");
                    if(null ==subTypeDC){
                        logger.info("Comment List Interator  is null  !!");  
                        return;
                    }
                    CllCommentsListROViewRowImpl subTypeRow = (CllCommentsListROViewRowImpl)subTypeDC.getCurrentRow();
                    if(null ==subTypeRow){
                        logger.info("Comment list  row is null and hence unable to retrieve  form letter Id !!");
                        logger.info(rb.getString("FORMLETTERLIST_UNABLE_TO_RETRIEVE_FL_ID"));
                        showPopupErrorMsg(rb.getString("FORMLETTERLIST_UNABLE_TO_RETRIEVE_FL_ID"));
                        return;
                    }  
                    logger.info("Current :: Form Letter Id : {0} :: Form Letter SubType : {1}",
                                new Object[] { subTypeRow.getFormLetterId(), subTypeRow.getSubType() }); 
                    
                    formLetId=subTypeRow.getFormLetterId();
                    fileNumId= subTypeRow.getFilenumId();
            }
            
            OperationBinding opb = ADFUtils.findOperation("approveFormLetterComments");
            opb.getParamsMap().put("fileNumId",fileNumId ); 
            opb.getParamsMap().put("formLetId",formLetId );   
            opb.getParamsMap().put("fileNumTypeCode",fileNumTypeCode ); 
            opb.execute();
            if(opb.getErrors().isEmpty()){
               
                ADFUtils.refreshIterator("CllCommentsListROView1Iterator"); 
                AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
                JSFUtils.addFacesInformationMessage("Selected " +
                                                    AdfFacesContext.getCurrentInstance().getViewScope().get("COMMENTS_COUNT") +
                                                    " comment(s) approved successfully.");
                
            }else {
                 ADFUtils.doRollback(); 
                 logger.info(opb.getErrors().toString());
                 JSFUtils.addFacesErrorMessage(rb.getString("FORMLETTERLIST_ERR_APPROVING_FORM_LETTERS")  );
                
            } 
            logger.info("Starting...... setFormLetterApprove");
        }
        
    /** Sets the transient attribute SelectAttr  to true for  all the comments in bulk selection which are not approved
          *
          * @param rksSelectedRows
          * @param iteratorName
          * @return selected comment Ids
          */
         
          private ArrayList<Number> getSelectedUnApprovedCommentsFromBulkProcess( RowKeySet rksSelectedRows, String iteratorName){
             ArrayList<Number>  commIds = new ArrayList<Number> ();
             if(null != rksSelectedRows && !rksSelectedRows.isEmpty() ){
                 logger.info(" Number rows selected is  :  "+ rksSelectedRows.size());
                 if(rksSelectedRows.size() <=0 ){
                     //bulk selection is not done
                     return commIds;
                 }
                 DCIteratorBinding commListIterator = ADFUtils.findIterator(iteratorName); 
                 if (null == commListIterator) {
                     return commIds;
                 }
                 RowSetIterator rsiSelectedRows = commListIterator.getRowSetIterator();
                 Iterator rksSelectedRowsIter= rksSelectedRows.iterator();
                 while(rksSelectedRowsIter.hasNext()){
                     Key key = (Key)((List)rksSelectedRowsIter.next()).get(0);
                     CllCommentsListROViewRowImpl  row=(CllCommentsListROViewRowImpl )rsiSelectedRows.getRow(key); 
                     //logger.info(" Comment id in the bulk selection  :  "+ row.getAttribute("CllCommDetId")); 
                     if(row.getDispCode() ==null || !row.getDispCode().equals(CllConstants.CLL_DISPOSITION_TYPE_APPR)) {
                        commIds.add((Number)row.getAttribute("CllCommDetId"));
                        row.setAttribute("SelectAttr",true); 
                     }
                 }
             } 
             logger.info(" Selected comments  " +commIds);
             return commIds;
             
         }

    public void setActnChgWarnMsg(String actnChgWarnMsg) {
        this.actnChgWarnMsg = actnChgWarnMsg;
    }

    public String getActnChgWarnMsg() {
        return actnChgWarnMsg;
    }

    public void setPopupChgAction(RichPopup popupChgAction) {
        this.popupChgAction = popupChgAction;
    }

    public RichPopup getPopupChgAction() {
        return popupChgAction;
    }

    public void chgActionCommentActionLstnr(ActionEvent actionEvent) {
        logger.info("Entering Change Action Method.");
        Map inputMap = new HashMap();
        String actionType = null;
        String action =
            (String)AdfFacesContext.getCurrentInstance().getViewScope().get("action");
        if (StringUtils.isNotBlank(action) && "ACTION".equals(action)) {
            DCIteratorBinding ActnTypeIter =
                ADFUtils.findIterator("CllActionTypeROView1Iterator");
            CllActionTypeROViewRowImpl ActnTypeRow =
                (CllActionTypeROViewRowImpl)ActnTypeIter.getCurrentRow();
            Number actnTypeId = ActnTypeRow.getCllActionTypeId();
            inputMap.put("CllActionTypeId", actnTypeId);
        }else if (StringUtils.isNotBlank(action) &&
                   "COMMENT".equals(action)) {
            actionType = "Comment Type";
            DCIteratorBinding commentTypeIter =
                ADFUtils.findIterator("CllTypeROView2Iterator");
            CllTypeROViewRowImpl commentTypeRow =
                (CllTypeROViewRowImpl)commentTypeIter.getCurrentRow();
            Number cllTypeId = commentTypeRow.getCllTypeId();
            String cllTypeCode = commentTypeRow.getCode();
            inputMap.put("CllTypeId", cllTypeId);
            inputMap.put("CllTypeCode", cllTypeCode);
            inputMap.put("CllTypeOtherDesc", this.getCllTypeOtherDesc());
        } else if (StringUtils.isNotBlank(action) && "SOURCE".equals(action)) {
            actionType = "Source Type";
            DCIteratorBinding sourceTypeIter =
                ADFUtils.findIterator("CllSourceTypeROView1Iterator");
            
            CllSourceTypeROViewRowImpl sourceTypeRow =
                (CllSourceTypeROViewRowImpl)sourceTypeIter.getCurrentRow();
            Number sourceTypeId = sourceTypeRow.getCllSourceTypeId();
            String sourceCode = sourceTypeRow.getCode();
            inputMap.put("sourceTypeId", sourceTypeId);
            inputMap.put("sourceTypeCode", sourceCode);

        }
        OperationBinding opb =
            ADFUtils.findOperation("updateSelectedActiontoComments");
        opb.getParamsMap().put("action", action);
        opb.getParamsMap().put("inputMap", inputMap);
        opb.execute();
        this.getPopupChgAction().cancel();
        CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
        formLetterListTblBind.getSelectedRowKeys().removeAll();
        if(null != action && "COMMENT".equals(action)){
            inputMap.remove("CllCurrTypeCode");
            this.refreshIterators(null);
            ADFUtils.refreshIterator("CllTypeROView2Iterator");
        }else{
            ADFUtils.refreshIterator("CllCommentsListROView1Iterator");
        }
        AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
        JSFUtils.addFacesInformationMessage(actionType+" changed in " +
                                            AdfFacesContext.getCurrentInstance().getViewScope().get("COMMENTS_COUNT") +
                                            " form letters successfully.");
    }

    public void cancelChgActionCommentActnLstnr(ActionEvent actionEvent) {
        this.getPopupChgAction().cancel();
        CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
        formLetterListTblBind.getSelectedRowKeys().removeAll();
        AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
    }

    public void setArchiveWarnMsg(String archiveWarnMsg) {
        this.archiveWarnMsg = archiveWarnMsg;
    }

    public String getArchiveWarnMsg() {
        return archiveWarnMsg;
    }

    public String clickChgCommentTypeAction() {
        logger.info("Change Action Link clicked");
        ArrayList<Number> commIds = new ArrayList<Number>();
        commIds = selectedComments(); // get selected list of comments
        if (commIds.size() > 0) {
            AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT", commIds.size());
            this.setActnChgWarnMsg("Comment Type will be changed in " +
                                   commIds.size() +
                                   " form letters. Do you wish to proceed?");
            this.getPopupChgActionWarnMsg().show(new RichPopup.PopupHints());
        } else {
            JSFUtils.addFacesErrorMessage("Please select atleast one form letter to change Comment Type.");
        }
        return null;
    }
    
    public String clickChgSourceTypeAction() {
        logger.info("Change Source Link clicked");
        ArrayList<Number> commIds = new ArrayList<Number>();
        commIds = selectedComments(); // get selected list of comments
        if (commIds.size() > 0) {
            AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT", commIds.size());
            this.setActnChgWarnMsg("Source Type will be changed in " +
                                   commIds.size() +
                                   " comments. Do you wish to proceed?");
            this.getPopupChgActionWarnMsg().show(new RichPopup.PopupHints());
        } else {
            JSFUtils.addFacesErrorMessage("Please select atleast one comment to change Source Type.");
        }
        return null;
    }
    
    // CASSECDEV-6118, CASSECDEV-6475, CASSECDEV-6476 : Changes for File Number Publishing of Form Letter.
    public void fileNumPubFormLetterDL(DialogEvent dialogEvent) {
        logger.info("In fileNumPubFormLetterDL.... : " + dialogEvent.getOutcome());
        //If 'No' is clicked, do not process file number publishing
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.no) {
            return;
        } else {
            fileNumPubFormLetterAction();
        }
    }
    
    private void fileNumPubFormLetterAction(){
                
        Map<String, Map<String, String>> formLtrTypeDetailsMap = new HashMap<String, Map<String, String>>();
        Number fileNumberId = (Number)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pFileNumId");
        String fileNumber = (String)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pFileTypeFileNumber");
        logger.info("In fileNumPubFormLetterAction... fileNumberId:"+fileNumberId+"  fileNumber:"+fileNumber);
        try {            
            // Lock the File Number
            OperationBinding lockFileNumber = ADFUtils.findOperation("lockFileNumber");
            lockFileNumber.getParamsMap().put("fileNumberId", fileNumberId);
            lockFileNumber.execute();
            if (lockFileNumber.getErrors().isEmpty()){
                Boolean success = (Boolean)lockFileNumber.getResult();
                if (!success){
                    showPopupErrorMsg(rb.getString("FORMLETTERLIST_PUBLISHING_FILENUMER_LOCKED_MSG"));
                    return;
                }
            } else {
                logger.severe(rb.getString("FORMLETTERLIST_PUBLISHING_FILENUMER_LOCK_ERROR_MSG") + ":: ERROR : " + lockFileNumber.getErrors());
                showPopupErrorMsg(rb.getString("FORMLETTERLIST_PUBLISHING_FILENUMER_LOCK_ERROR_MSG"));
                return;
            }
            
            OperationBinding retrieveCllTypeId = ADFUtils.findOperation("getCllTypeId");
            retrieveCllTypeId.getParamsMap().put("typeCode", CllConstants.CLL_TYPE_CODE_FORM_LETTER);
            retrieveCllTypeId.execute();
            if(!retrieveCllTypeId.getErrors().isEmpty()){
                logger.severe("In fileNumPubFormLetterAction... Got error when getting CllTypeId.."+retrieveCllTypeId.getErrors());
                unlockFileNumber(fileNumberId);
                showPopupErrorMsg(rb.getString("FORMLETTER_FILENUM_PUBLISH_ERROR_GETTING_TYPE_ID"));
                return;
            }
            Number cllTypeId = (Number)retrieveCllTypeId.getResult();
            if(cllTypeId == null || cllTypeId.intValue() <= 0){
                logger.severe("In fileNumPubFormLetterAction..... cllTypeId is Null or Zero :"+cllTypeId);
                unlockFileNumber(fileNumberId);
                showPopupErrorMsg(rb.getString("FORMLETTER_FILENUM_PUBLISH_ERROR_GETTING_TYPE_ID"));
                return;
            }
            
            DCIteratorBinding formLetterTypeListBind = ADFUtils.findIterator("FormLetterTypesCountROView1Iterator");
            if(formLetterTypeListBind.getEstimatedRowCount() <= 0){
                logger.severe("In fileNumPubFormLetterAction..... CllFormLetterView1Iterator... getEstimatedRowCount was zero or less:"+formLetterTypeListBind.getEstimatedRowCount());
                unlockFileNumber(fileNumberId);
                showPopupErrorMsg(rb.getString("FORMLETTER_FILENUM_PUBLISH_TYPES_COUNT_ZERO_MSG"));
                return;
            }
            
            RowSetIterator formLetterTypeIter = formLetterTypeListBind.getViewObject().createRowSetIterator(null);
            formLetterTypeIter.reset();
            Map<String, String> commentTypeDetailsMap;
            while(formLetterTypeIter.hasNext()){
                Row formLetterTypeRow = formLetterTypeIter.next();
                Number formLetterId = (Number)formLetterTypeRow.getAttribute("CllFormLetterId");
                String letterSubType = (String)formLetterTypeRow.getAttribute("SubType");
                Long publishedCount = (Long)formLetterTypeRow.getAttribute("PubTotalCountSum");
                //logger.info("In fileNumPubFormLetterAction... formLetterId:"+formLetterId+"  letterSubType:"+letterSubType+"  publishedCount:"+publishedCount);
                
                // Retrive the Comment details for each Letter Type.
                OperationBinding retrieveCmtDetails = ADFUtils.findOperation("getCommentDetailsForFormLetter");
                retrieveCmtDetails.getParamsMap().put("fileNumber", fileNumberId);
                retrieveCmtDetails.getParamsMap().put("typeId", cllTypeId);
                retrieveCmtDetails.getParamsMap().put("formLtrId", new Number(formLetterId.getValue()));
                retrieveCmtDetails.execute();
                if(!retrieveCmtDetails.getErrors().isEmpty()){
                    logger.severe("In fileNumPubFormLetterAction... Got error when getting comment details.."+retrieveCllTypeId.getErrors());
                    unlockFileNumber(fileNumberId);
                    showPopupErrorMsg(rb.getString("FORMLETTER_FILENUM_PUBLISH_ERROR_GET_COMMENT_DETAILS"));
                    return;
                }
                CllFileNumPubCommListROViewRowImpl commentsListRow = (CllFileNumPubCommListROViewRowImpl)retrieveCmtDetails.getResult();
                
                if(commentsListRow != null){
                    Number commentDetailsId = commentsListRow.getCllCommDetId();
                    //logger.info("In fileNumPubFormLetterAction... commentDetailsId:"+commentDetailsId);
                    commentTypeDetailsMap = new HashMap<String, String>();
                    commentTypeDetailsMap.put("formLetterId", formLetterId.toString());
                    commentTypeDetailsMap.put("letterSubType", letterSubType);
                    commentTypeDetailsMap.put("publishedCount", publishedCount.toString());
                    commentTypeDetailsMap.put("commentDetailsId", commentDetailsId.toString());
                    commentTypeDetailsMap.put("comments", (commentsListRow.getComments() != null ? commentsListRow.getComments().toString() : ""));
                    commentTypeDetailsMap.put("subject", commentsListRow.getSubject());
                    // populate the commentTypeDetailsMap to formLtrTypeDetailsMap
                    formLtrTypeDetailsMap.put(letterSubType, commentTypeDetailsMap);
                }                
            }
            // Closing the RowSetIterator
            formLetterTypeIter.closeRowSetIterator();
            
            // Check if there are any Published comments, if not show error message.
            if(formLtrTypeDetailsMap != null && formLtrTypeDetailsMap.size() <= 0){
                logger.severe("In fileNumPubFormLetterAction..... formLtrTypeDetailsMap is Null or size is Zero :"+formLtrTypeDetailsMap);
                unlockFileNumber(fileNumberId);
                showPopupErrorMsg(rb.getString("FORMLETTER_FILENUM_PUBLISH_COUNT_ZERO_MSG"));
                return;
            }
            
            //  Get releaseNumber value based on the Master File Number ID.
            OperationBinding retrieveMasterFileNumId = ADFUtils.findOperation("findMasterFileNumId");
            retrieveMasterFileNumId.getParamsMap().put("fileNumId", fileNumberId);
            retrieveMasterFileNumId.execute(); 
            Number masterFileNumId=null; 
            if (retrieveMasterFileNumId.getErrors().isEmpty()){
                masterFileNumId = (Number)retrieveMasterFileNumId.getResult();
                if (masterFileNumId == null){
                    logger.severe("ERROR....Error...  retrieving  Master file number id *****************");
                    unlockFileNumber(fileNumberId); 
                    showPopupErrorMsg(rb.getString("FORMLETTERLIST_PUBLISHING_GET_RELEASENUMBERS_ERROR_MSG"));
                    return;
                }
            } else {
                logger.severe("ERROR....Error...  retrieving  Master file number id *****************" + retrieveMasterFileNumId.getErrors());
                unlockFileNumber(fileNumberId);
                showPopupErrorMsg(rb.getString("FORMLETTERLIST_PUBLISHING_GET_RELEASENUMBERS_ERROR_MSG"));
                return;
            }
            //logger.info("In fileNumPubFormLetterAction... masterFileNumId:"+masterFileNumId);
            List<String> relNums= CllUtils.getReleaseNumsForMasterFileNumber(masterFileNumId);
            //logger.info("In fileNumPubFormLetterAction... relNums:"+relNums);
            String releaseNumbers = ""; 
            if(null != relNums){
                releaseNumbers=relNums.toString();
            } else { //error retrieving release numbers
                 logger.severe("ERROR....Error...  retrieving  Master file number id *****************" + retrieveMasterFileNumId.getErrors());
                 unlockFileNumber(fileNumberId);
                 showPopupErrorMsg(rb.getString("FORMLETTERLIST_PUBLISHING_GET_RELEASENUMBERS_ERROR_MSG"));
                 return;
             } 
            //logger.info("Release Nos  fetched from master file number module is  : "  +releaseNumbers );
            if(!relNums.isEmpty()){
                releaseNumbers=releaseNumbers.substring(1, releaseNumbers.length()-1);
                releaseNumbers = "Release No. " + releaseNumbers  + "; ";   
            }
            logger.info("In fileNumPubFormLetterAction.... releaseNumbers:"+releaseNumbers);
            
            String targetPkgDir = getCommentsPackagingDir();
            String publishDirName = PackageUtils.createFileNumPubFormLetterDir(targetPkgDir, fileNumber); 
                       
            //logger.info("In fileNumPubFormLetterAction.... targetPkgDir:"+targetPkgDir+"   publishDirName:"+publishDirName);
            // Generate Index and Content htm files, then zip the files
            String zipFileName = createFileNumPubFormLetterZIP(formLtrTypeDetailsMap, targetPkgDir, publishDirName, releaseNumbers);
            if(null ==zipFileName){
                 logger.severe("In fileNumPubFormLetterAction.... Error generating zip file for file number publishing form letter  *****************"); 
                 showPopupErrorMsg(rb.getString("FORMLETTER_FILENUM_PUBLISH_ERROR_GENERATING_ZIPFLLE")); 
                 unlockFileNumber(fileNumberId); 
                 return ;  
            }
            
            // Upload the ZIP file to UCM 
            uploadZipToUCM(targetPkgDir, zipFileName, fileNumberId, true);
            
            // Unlock the File Number
            unlockFileNumber(fileNumberId);
            
            //  Persist to DB
            if(ADFUtils.doCommit()){
                ADFUtils.refreshIterator("CllCommentsListROView1Iterator"); 
                AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
                showPopupInfoMsg(rb.getString("FORMLETTER_FILENUM_PUBLISH_SUCCESS_MSG"));
            }
            
        } catch (Exception e){
            logger.severe("In fileNumPubFormLetterAction... Exception occurred..", e);
            showPopupErrorMsg(rb.getString("FORMLETTER_FILENUM_PUBLISH_FAILED_MSG"));
            unlockFileNumber(fileNumberId); 
            ADFUtils.doRollback();           
            AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterListTblBind);
        }
    }
    
    private String createFileNumPubFormLetterZIP(Map<String, Map<String, String>> formLtrTypeDetailsMap, String targetPkgDir, String publishDirName, String releaseNumbers){
        String zipFileName = null;
        Map<String, String> commentTypeDetailsMap = null;
        try {
            logger.info("In createFileNumPubFormLetterZIP... targetPkgDir: "+targetPkgDir+"  publishDirName: "+publishDirName);
            String publishDirPath = targetPkgDir + publishDirName;
            //StringBuilder formLetterTypeLinksStr = new StringBuilder();
            //String formLetterTypeHtmlStr = "<a href=\"$href_link$\">$form_letter_type$: $form_letter_instances$</a><br><br>";
            List<String> commentPageNameList = new ArrayList<String>();
            String commentSubject = null;
            String fileNumber = JSFUtils.resolveExpressionAsString("#{pageFlowScope.pFileTypeFileNumber}");
            for(Map.Entry<String, Map<String, String>> commentTypeDetails: formLtrTypeDetailsMap.entrySet()){
                commentTypeDetailsMap = commentTypeDetails.getValue();
                /*logger.info("In createFileNumPubFormLetterZIP... formLetterId:"+commentTypeDetailsMap.get("formLetterId")+
                                   "  letterSubType:"+commentTypeDetailsMap.get("letterSubType")+
                                   "  publishedCount:"+commentTypeDetailsMap.get("publishedCount")+
                                   "  commentDetailsId:"+commentTypeDetailsMap.get("commentDetailsId")+
                                   "  comments:"+commentTypeDetailsMap.get("comments")+
                                   "  subject:"+commentTypeDetailsMap.get("subject"));*/
                
                if(commentSubject == null || commentSubject.length() <= 0){
                    commentSubject = commentTypeDetailsMap.get("subject");
                }
                
                // Creating Form Letter Comment Page
                Map<String,String> commentPageMap = new HashMap<String, String>();
                commentPageMap.put("form_letter_type", commentTypeDetailsMap.get("letterSubType"));
                String parsedText= StringEscapeUtils.escapeHtml(commentTypeDetailsMap.get("comments")); 
                commentPageMap.put("form_letter_comment", "<pre style=\"white-space: pre-wrap; white-space: -moz-pre-wrap; white-space: -pre-wrap; white-space: -o-pre-wrap; word-wrap: break-word;\">"+parsedText+"</pre>");
                commentPageMap.put("file_number", fileNumber);
                commentPageMap.put("comment_page_template", getTemplateContentByCode(CllConstants.FILENUMPUB_FORMLETTER_COMMENTPAGE_TEMPLATE_CODE));
                String commentFilename = PackageUtils.createFormLetterCommentPage(commentPageMap, publishDirPath); 
                if(null == commentFilename ){
                    return null;
                }
                commentPageNameList.add(commentFilename);
                
                // Build Form Letter Type Html String for form_letter_file_num_pub_type_links
                // CASSUP-1753 : Commenting below logic to not package Index htm and updates txt file for file number publishing
                /*String updatedTypeHtmlStr = formLetterTypeHtmlStr.replace("$href_link$", commentFilename);
                updatedTypeHtmlStr = updatedTypeHtmlStr.replace("$form_letter_type$", commentTypeDetailsMap.get("letterSubType"));
                updatedTypeHtmlStr = updatedTypeHtmlStr.replace("$form_letter_instances$", commentTypeDetailsMap.get("publishedCount"));
                formLetterTypeLinksStr.append(updatedTypeHtmlStr+System.lineSeparator());
                */
                //logger.info("In createFileNumPubFormLetterZIP.... formLetterTypeLinksStr:"+formLetterTypeLinksStr);
            }
            
            // Creating Form Letter Index Page
            // CASSUP-1753 : Commenting below logic to not package Index htm and updates txt file for file number publishing
            /*Map<String,String> indexPageMap = new HashMap<String,String>();
            String title = commentSubject;
            if(null != title){
                title= StringEscapeUtils.escapeHtml(title.trim());  
            }
            indexPageMap.put("title", title);
            indexPageMap.put("release_numbers", releaseNumbers);
            //logger.info("******* Packaging for File Number : " + fileNumber);
            indexPageMap.put("file_number", fileNumber.toString());
            indexPageMap.put("form_letter_file_num_pub_type_links", formLetterTypeLinksStr.toString());
            indexPageMap.put("index_page_template", getTemplateContentByCode(CllConstants.FILENUMPUB_FORMLETTER_INDEXPAGE_TEMPLATE_CODE));
            //logger.info("In createFileNumPubFormLetterZIP.... indexPageMap:"+indexPageMap);
            String indexFileName = PackageUtils.createFormLetterIndexPage(indexPageMap, null, publishDirPath);//taken care special chars
            if(null == indexFileName){
                return null;
            }
            
            // prepare list of file names for updates file
            List<String> updatesPageNameList = new ArrayList<String>();
            updatesPageNameList.add(indexFileName);
            for(String commentPageName: commentPageNameList){
                updatesPageNameList.add(commentPageName);
            }
            //logger.info("In createFileNumPubFormLetterZIP.... updatesPageNameList:"+updatesPageNameList);
            String fileNum=CllUtils.removeSpecialCharsFromFileFolderName(fileNumber);
            //logger.info("fileNum after removing  special characters in createFileNumPubFormLetterZIP() *************** is : " +fileNum); 
            boolean flag = PackageUtils.createWUpdateFile(publishDirPath,  fileNum, updatesPageNameList, true);   
            if(!flag) {
                return null;
            } */
            
            //Zip the temporary folder
            zipFileName = PackageUtils.createCommentLetterZIP(targetPkgDir, publishDirName); //filtered with special characters
            if(zipFileName == null){
                return null;
            }
            
        } catch (Exception e) {
            logger.severe("In createFileNumPubFormLetterZIP... Exception occurred", e);
            return null;
        }
        logger.info("In createFileNumPubFormLetterZIP *************** before return zipFileName is : " +zipFileName); 
        return zipFileName;
    }
    
    public void setChgActionPopUpTitle(String chgActionPopUpTitle) {
        this.chgActionPopUpTitle = chgActionPopUpTitle;
    }

    public String getChgActionPopUpTitle() {
        return chgActionPopUpTitle;
    }

    public void setChgActionMsg(String chgActionMsg) {
        this.chgActionMsg = chgActionMsg;
    }

    public String getChgActionMsg() {
        return chgActionMsg;
    }

    public void setCllTypeOtherDesc(String cllTypeOtherDesc) {
        this.cllTypeOtherDesc = cllTypeOtherDesc;
    }

    public String getCllTypeOtherDesc() {
        return cllTypeOtherDesc;
    }

    public void setPopupApprove(RichPopup popupApprove) {
        this.popupApprove = popupApprove;
    }

    public RichPopup getPopupApprove() {
        return popupApprove;
    }

    public void setApproveWarnMsg(String ApproveWarnMsg) {
        this.ApproveWarnMsg = ApproveWarnMsg;
    }

    public String getApproveWarnMsg() {
        return ApproveWarnMsg;
    }
    
}
