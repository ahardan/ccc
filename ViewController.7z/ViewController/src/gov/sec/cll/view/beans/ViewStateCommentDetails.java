package gov.sec.cll.view.beans;

 

import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;
import gov.sec.cll.sharedcomponents.view.utils.JSFUtils;

import gov.sec.cll.view.dto.EmailRecipientDTO;
import gov.sec.cll.view.utils.CllConstants;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import java.util.ResourceBundle;

import oracle.adf.share.logging.ADFLogger;

import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.binding.OperationBinding;

import oracle.jbo.JboException;
import oracle.jbo.domain.DBSequence;
import oracle.jbo.domain.Number;

public class ViewStateCommentDetails implements Serializable{
    
    public ViewStateCommentDetails() {
        super();
       
    }
    
    private Number fileNumId;
    private String fileTypeFileNumber;
    private static ADFLogger logger = ADFLogger.createADFLogger(ViewStateCommentDetails.class);
    private static final ResourceBundle rb =
                ResourceBundle.getBundle(CllConstants.RESOURCE_BUNDLE_LOCATION);
    private boolean readOnlyFileNumber; 
    private boolean addFileNumber;
    private String nextORPrevFlag="";
    private Number currentFileNumId;
   
    public void setFileNumId(Number fileNumId) {
        this.fileNumId = fileNumId;
        
    }

    public Number getFileNumId() {
        return fileNumId;
    } 
    
    /** Invokes  custom data control method to retrieve  FileType File Number for a  given file number ID
     *  This is  kept stand by so that we can use it when  needed
     */
    public void retrieveFileTypeNumber(){
         logger.info("Starting retrieveFileTypeNumber in ViewStateCommentDetails ********************** ");  
          
          try { 
                OperationBinding operation = ADFUtils.findOperation("getFileTypeFileNumber");
                operation.getParamsMap().put("fileNumId",fileNumId );
                operation.execute();
                fileTypeFileNumber =(String)operation.getResult();
                logger.info("File Type File Number retrieved  inside retrieveFileTypeNumber   is "+ fileTypeFileNumber);
                
            }catch (JboException e){
                 String msg=rb.getString("VIEWSTATECOMMENTDETAILS_UNABLETOGET_FILETYPE_FILENUMBER");
                 JSFUtils.addFacesErrorMessage(msg);  
             } catch (Exception e){ 
                  e.printStackTrace();
                  String msg=rb.getString("VIEWSTATECOMMENTDETAILS_UNABLETOGET_FILETYPE_FILENUMBER");
                  JSFUtils.addFacesErrorMessage(msg);   
             }  
          logger.info("Ending retrieveFileTypeNumber in ViewStateCommentDetails ********************** ") ;
    }
    

    public void setFileTypeFileNumber(String fileTypeFileNumber) {
        this.fileTypeFileNumber = fileTypeFileNumber;
    }

    public String getFileTypeFileNumber() { 
        return fileTypeFileNumber;
    }

    public void setReadOnlyFileNumber(boolean readOnlyFileNumber) {
        this.readOnlyFileNumber = readOnlyFileNumber;
    }

    public boolean isReadOnlyFileNumber() {
        return readOnlyFileNumber;
    }
     

    public void setAddFileNumber(boolean addFileNumber) {
        this.addFileNumber = addFileNumber;
    }

    public boolean isAddFileNumber() {
        return addFileNumber;
    }

    public void setNextORPrevFlag(String nextORPrevFlag) {
        this.nextORPrevFlag = nextORPrevFlag;
    }

    public String getNextORPrevFlag() {
        return nextORPrevFlag;
    }

    public void setCurrentFileNumId(Number currentFileNumId) {
        this.currentFileNumId = currentFileNumId;
    }

    public Double getCurrentFileNumId() {
        if (null !=   currentFileNumId) {
           return currentFileNumId.doubleValue(); 
        } 
        return null;
        
    }
}

