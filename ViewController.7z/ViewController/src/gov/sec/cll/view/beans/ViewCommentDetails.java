package gov.sec.cll.view.beans;

import gov.sec.cas.sharedcomponents.view.dto.EmailRequestDTO;
import gov.sec.cas.sharedcomponents.view.dto.EmailResponseDTO;
import gov.sec.cas.sharedcomponents.view.utils.NotificationUtils;
import gov.sec.cll.model.adfbc.views.CllCommentDetailsViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllCommentsListROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumCommDetViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumberCommDetailsViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllSubmitterViewRowImpl;
import gov.sec.cll.model.adfbc.views.FileNumbersForCommentDetROViewRowImpl;
import gov.sec.cas.common.view.dto.Document;
import gov.sec.cas.common.view.services.RIDCService;
import gov.sec.cas.common.view.utils.SecurityUtils;
import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;
import gov.sec.cll.sharedcomponents.view.utils.JSFUtils;
import gov.sec.cll.sharedcomponents.view.utils.SharedCompConstants;
import gov.sec.cll.view.dto.EmailRecipientDTO;
import gov.sec.cll.view.dto.ForwardCommentDTO;
import gov.sec.cll.view.utils.CllConstants;
import gov.sec.cll.view.utils.CllUtils;
import gov.sec.cll.view.utils.PackageUtils;
import gov.sec.rellog.filenumber.view.dto.ReturnMasterFileNumberDTO;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.input.RichSelectBooleanCheckbox;
import oracle.adf.view.rich.component.rich.input.RichSelectOneChoice;
import oracle.adf.view.rich.component.rich.input.RichSelectOneListbox;
import oracle.adf.view.rich.component.rich.layout.RichPanelFormLayout;
import oracle.adf.view.rich.component.rich.layout.RichPanelGroupLayout;
import oracle.adf.view.rich.component.rich.nav.RichButton;
import oracle.adf.view.rich.component.rich.nav.RichLink;
import oracle.adf.view.rich.component.rich.output.RichMessages;
import oracle.adf.view.rich.context.AdfFacesContext;
import oracle.adf.view.rich.event.DialogEvent;
import oracle.adf.view.rich.event.PopupCanceledEvent;

import oracle.binding.OperationBinding;

import oracle.jbo.JboException;
import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.Transaction;
import oracle.jbo.ViewObject;
import oracle.jbo.domain.DBSequence;
import oracle.jbo.domain.Number;

import oracle.stellent.ridc.IdcClientException;

import org.apache.commons.lang.StringUtils;
import org.apache.myfaces.trinidad.event.ReturnEvent;
import org.apache.myfaces.trinidad.event.SelectionEvent;


/**
 * Backingbean that supports the ViewCommentDetails fragment
 *
 */
public class ViewCommentDetails {

    private RichInputText fileNumberInputText;
    private RichTable fileNumbersTable;
    private RichInputText dispositionTypeOthInputText;
    private RichPanelFormLayout formSubTypePanelFormBind;
    private RichInputText prefixInputTxt;
    private RichInputText firstNameInputTxt;
    private RichInputText lastNameInputTxt;
    private RichInputText suffixInputTxt;
    private RichInputText afficilateInputTxt;
    private RichInputText jobTitleInputTxt;
    private RichInputText emailInputTxt;
    private RichInputText phoneNumbInputTxt;
    private RichInputText formLetterTextBind; 
    private RichPopup popupNoRecipients;
    private RichPopup popupEmailSent;
    private String exitAction;
    private RichPopup exitWarnPp;
    private RichButton exitButton;
    private RichPopup popupSubmitter;
    private RichButton deleteButton;
    private RichButton unDeleteButton;
    private RichButton unArchiveButton;
    private RichInputText commentInputText;
    private RichInputText countInputText;
    private  String formLetterTypeCode;
    private RichSelectOneListbox relNumListBox;
    private  String regularMailTypeCode;
    private static ADFLogger logger = ADFLogger.createADFLogger(ViewCommentDetails.class);
    private static final ResourceBundle rb =
                ResourceBundle.getBundle(CllConstants.RESOURCE_BUNDLE_LOCATION);
    private boolean countReadOnly;
    private RichInputText itFileNumber;
    private RichLink addFileNumCmdImageLink;
    private RichLink editFileNumCmdImageLink;
    private RichPopup popupFileNumber;
    private RichButton saveButton;
    private RichButton saveApproveButton;
    private String dispTypeOtherCode;
    private RichTable tbSubmitter;
    private boolean disableSaveApproveButton;
    private RichPanelGroupLayout pglComment;
    private RichTable tbSubmitterRO;
    private RichTable relNumbersTable;
    private RichPanelGroupLayout pglSubmiterForm;
    private RichSelectOneChoice commentDetailsSelectOneChoice;
    private RichPanelGroupLayout pglSubType;
    private RichPopup popupFLSaveSubmit;
    private RichPopup popupUnArchive;
    private RichSelectOneChoice socSubtype;
    private boolean attachmentsExist=false;
    private RichButton cbEnterMatchText;
    private RichPopup popupError;
    private String packaingErrorMsg;
    private RichPopup popupInfo;
    private String infoMsg;
    private String pkgingPublishDirSubString="_pub_comments_";
    private String pkgingUnPublishDirSubString="_unpub_comments_";
    private RichPopup pendingChangeWarnPP;
    private RichPopup popupDelFilNum;
    private RichTable associatedFileNumbersTable;
    private RichPanelGroupLayout statusPanelGroup;
    private RichButton unPublishCommandBtn;
    private RichMessages afMessagesMainWindow;
    private RichButton removeFileNumButton;
    private String SOURCE_REMOVE_BUTTON="REMOVE_BUTTON";
    private ReturnMasterFileNumberDTO masterFileNumDTO;
    private RichSelectBooleanCheckbox repIsThirdParty;
    private RichSelectBooleanCheckbox repIsAffiliated;

    public ViewCommentDetails() {
        super();
    }
    
    public void setFormLetterTypeCode(String formLetterTypeCode) {
        this.formLetterTypeCode = formLetterTypeCode;
    }

    public String getFormLetterTypeCode() {
        return    CllConstants.CLL_TYPE_CODE_FORM_LETTER;
    }
    
    public String previousCommDetAction(){ 
        Map<String, Object> viewScope = AdfFacesContext.getCurrentInstance().getViewScope();
        ViewStateCommentDetails viewStateCommentDetails = 
                    (ViewStateCommentDetails)viewScope.get("viewStateCommentDetails");
        viewStateCommentDetails.setNextORPrevFlag(CllConstants.PREVIOUS_COMMENT); 
        ADFUtils.markScopeDirty(viewScope);
        if (verifyPendingChanges()) {
            return null;
        }
       return navigateToPrevRecord();
    }
    
  

    public String nextCommDetAction(){
       //store the flag indicating  we came from  next button click or prev button click
       Map<String, Object> viewScope = AdfFacesContext.getCurrentInstance().getViewScope();
       ViewStateCommentDetails viewStateCommentDetails = 
                   (ViewStateCommentDetails)viewScope.get("viewStateCommentDetails");
       viewStateCommentDetails.setNextORPrevFlag(CllConstants.NEXT_COMMENT);
       ADFUtils.markScopeDirty(viewScope);
        if (verifyPendingChanges()) {
            return null;
        } 
        return navigateToNextRecord();
       
    }
    
    /** Fetches  next comment log in the comment list 
     *
     * @return control flow name
     */
    public String navigateToNextRecord(){
        OperationBinding next = ADFUtils.findOperation("Next");
        next.execute();
        if (next.getErrors().isEmpty()){
            DCIteratorBinding dcIterBind= ADFUtils.findIterator("CllCommentsListROView1Iterator");
            CllCommentsListROViewRowImpl currentRow = (CllCommentsListROViewRowImpl)dcIterBind.getCurrentRow();
            logger.info("currentRow => " + currentRow.getCllCommDetId());
            Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
            CommentDetails commentDetailsBean = (CommentDetails)pageFlowScope.get("commentDetails");
            commentDetailsBean.setCommentDetId(currentRow.getCllCommDetId());
            ADFUtils.markScopeDirty(pageFlowScope);
            return "refreshCommentDetails";
        } else {
            JSFUtils.addFacesErrorMessage("Error showing next Comment Details.");
            logger.severe("Error showing next Comment Details. ERROR : " + next.getErrors());
        }
        return null;
    }
    
    
    /**Fetches  previous comment log in the comment list
     *
     * @return control flow name or action name    
     */
    public String navigateToPrevRecord(){
        
        OperationBinding previous = ADFUtils.findOperation("Previous");
        previous.execute();
        if (previous.getErrors().isEmpty()){
            DCIteratorBinding dcIterBind= ADFUtils.findIterator("CllCommentsListROView1Iterator");
            CllCommentsListROViewRowImpl currentRow = (CllCommentsListROViewRowImpl)dcIterBind.getCurrentRow();
            logger.info("currentRow => " + currentRow.getCllCommDetId());
            Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
            CommentDetails commentDetailsBean = (CommentDetails)pageFlowScope.get("commentDetails");
            commentDetailsBean.setCommentDetId(currentRow.getCllCommDetId());
            ADFUtils.markScopeDirty(pageFlowScope);
            return "refreshCommentDetails";
        } else {
            JSFUtils.addFacesErrorMessage("Error showing previous Comment Details.");
            logger.severe("Error showing previous Comment Details. ERROR : " + previous.getErrors());
        }
        return null;
    }
    
    
    /** Indicates are there any pending changes in the comment log
     *
     * @return
     */
    public boolean verifyPendingChanges(){
        boolean flag=false;
        if (CllUtils.existIteratorPendingChangesCommDet("CllCommentDetailsView1Iterator")) {
            logger.info("Changes yet to be saved first");
            //JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_SAVE_COMMENT_MSG_TO_USER"));
            this.pendingChangeWarnPP.show(new RichPopup.PopupHints());
            flag=true;
        }
        return flag;
    }
    
    /** Action that will be executed when SAVE button is clicked
     *  It saves Comment Details master record along with all its  detail records
     */
    public void saveActionListener(ActionEvent actionEvent) {      //TODO   Be CAREFUL  while updating this method ...Very critical method
        logger.info("Starting  saveActionListener   ********************************");
        saveComment(true) ;
        logger.info("Ending  saveActionListener   ********************************");
        
    }
    
    /** Saves a comment log into database.  If disposition is entered,  updates the comment log as processed
     * 
     */ 
    public boolean saveComment(boolean displayMessage) {   
        
                    //TODO Be CAREFUL  while updating this method ...Very critical method and is called in multiple places 
                    //TODO also visit methods saveApproveListener() and saveAndSubmitActionListener to keep them in sync with this method
                   
                    logger.info("Starting  saveComment   ********************************");
                    boolean flag=false;
                    boolean newComment=false; 
                    Map<String,String> map = new HashMap<String,String>();
                     if(!isValidData()){ 
                        return false;
                     }  
                    DBSequence id=(DBSequence)ADFUtils.getBoundAttributeValue("CllCommDetId");
                    if(id != null) {
                       Number commId = id.getSequenceNumber(); 
                       logger.info("Current  comment  id  is  **********************" + commId);
                       if(commId.intValue() <=0) {
                           newComment=true;  
                       }
                    }
                    
                     map=updateDispositionForSave();
                     if(map == null ){ 
                         return false;
                     }  
                     
                     //update  comment detail with next  sequence number for SR  type if final action is approve
                     String finalActCode = (String)ADFUtils.getBoundAttributeValue("CommentDispositionCode"); 
                     if(null != finalActCode && CllConstants.CLL_DISPOSITION_TYPE_APPR.equalsIgnoreCase(finalActCode)){
                         if (!updateSRSeqNumber()) {
                             return false;
                         }
                     } 
                     String commentTypeCode= (String)ADFUtils.getBoundAttributeValue("CommentTypeCode"); 
                     
                     boolean changeInFileNum=false; 
                     if(CllUtils.existIteratorPendingChanges("CllFilenumCommDetView1Iterator")){
                         changeInFileNum=true;
                     }
                     if(ADFUtils.doCommit()) {  
                             logger.info("Comment has been successfully  commited  ***********");  
                             if(displayMessage){
                                  JSFUtils.addFacesInformationMessage(map.get("saveMsg"));   
                             }
                             if(commentTypeCode != null && !commentTypeCode.equals(getFormLetterTypeCode())){
                                 addFileNumCmdImageLink.setDisabled(false);    
                             }  
                            flag=true;
                            //if there is change in current file number 
                            if(changeInFileNum){
                                updateAvailableStatusForMasterFileNumId();  //service called only if needed
                            }
                     } else {  //commit fails
                             String msg=rb.getString("VIEWCOMMENTDETAILS_UNABLE_TOSAVE_COMMENTDETAILS_MSG");
                             JSFUtils.addFacesErrorMessage(msg);  
                             flag=false;
                     }
                     String fileNumber=(String)ADFUtils.getBoundAttributeValue("FileNumber");
                     if(fileNumber != null && (commentTypeCode != null && !commentTypeCode.equals(getFormLetterTypeCode()))) {
                        editFileNumCmdImageLink.setDisabled(false); 
                     } 
                     
                    // refresh existing file numbers list 
                    id=(DBSequence)ADFUtils.getBoundAttributeValue("CllCommDetId");
                    if(id != null) {
                        refreshFileNumbersForComment( id.getSequenceNumber());
                        logger.info("Current  comment id :" + id.getSequenceNumber());
                        if(newComment){  //if there was rollback called ad create new comment and save, stay back at new record on the screen
                            OperationBinding operation=ADFUtils.findOperation("setCurrentRowInCommDetVO");
                            operation.getParamsMap().put("commentDetId",id.getSequenceNumber()); 
                            operation.execute();
                        }
                    }
                   
                    ADFUtils.refreshIterator("CllSubmitterView1Iterator"); 
                    ADFUtils.refreshIterator("FileNumbersForCommentDetROView1Iterator");  
                    Number currentFileNumId= (Number)ADFUtils.getBoundAttributeValue("FilenumId");
                    if(null ==  currentFileNumId) {    // current file number is empty.  We need to set to first available file number
                        if(id != null) {  //if comment id is not null
                            OperationBinding operation=ADFUtils.findOperation("setFirstFileNumber");
                            operation.getParamsMap().put("commentDetId",id.getSequenceNumber()); 
                            operation.execute();
                        } 
                    }  else {
                        OperationBinding releaseNumsOper = ADFUtils.findOperation("setReleaseNumbers");
                        releaseNumsOper.getParamsMap().put("fileNumId", currentFileNumId);
                        releaseNumsOper.execute();
                        if (!releaseNumsOper.getErrors().isEmpty()){
                            String msg = rb.getString("VIEWCOMMENTDETAILS_UNABLETO_RETRIEVE_RELEASE_NUMBERS");
                            logger.severe(msg, releaseNumsOper.getErrors().toString());
                            JSFUtils.addFacesErrorMessage(msg);
                        }                        
                    }
                    clearCurrentFileNumFromBean();
                    AdfFacesContext.getCurrentInstance().addPartialTarget(itFileNumber); 
                    AdfFacesContext.getCurrentInstance().addPartialTarget(relNumbersTable); 
                    AdfFacesContext.getCurrentInstance().addPartialTarget(associatedFileNumbersTable);
                    //AdfFacesContext.getCurrentInstance().addPartialTarget(removeFileNumButton);
        
                    logger.info("Ending  ;saveComment   ********************************");
                    return flag;
    }
    
    
    /**Updates Master file number status as not available if it is currently available
     *
     * @return
     */
    private void updateAvailableStatusForMasterFileNumId(){
        if(null != ADFUtils.getBoundAttributeValue("AvailableAttr")) {
          String availableAttr= (String)ADFUtils.getBoundAttributeValue("AvailableAttr");
          if( availableAttr.equalsIgnoreCase("Y")  && null != ADFUtils.getBoundAttributeValue("MasterFileNumberId")){
                  Number masterFileNumId= (Number)ADFUtils.getBoundAttributeValue("MasterFileNumberId");  
                  ArrayList<Number> list= new ArrayList<Number>();
                   list.add(masterFileNumId);
                   CllUtils.updateAvailableMasterFileNumbers(list);   
          }
        }
    }
    
    
    
    private void  clearCurrentFileNumFromBean(){
        Map<String, Object> viewScope = AdfFacesContext.getCurrentInstance().getViewScope();
        ViewStateCommentDetails viewStateCommentDetails = 
                     (ViewStateCommentDetails)viewScope.get("viewStateCommentDetails"); 
         viewStateCommentDetails.setCurrentFileNumId(null); 
         ADFUtils.markScopeDirty(viewScope);
             
    }  
    
   /** Invoking custom data control method to retrieve next seq number for SR file number type and assign 
    * it to comment detail and add it back to file number type table
     *
     * @return
     */
    public boolean updateSRSeqNumber(){
        logger.info("Starting  updateSRSeqNumber  in  ViewCommentDetails  *********************");
        boolean flag=true;
        Number srSeqNum=null;
        boolean changeinCllFilenumCommDetView1Iterator=false;
        String currentTypeCode="";
        Number formLetId = (Number)ADFUtils.getBoundAttributeValue("CllFormLetterId");
        DCIteratorBinding iterator1 = ADFUtils.findIterator("CllFilenumCommDetView1Iterator");
        boolean seqAlreadyProcessed=false;
        //update SR seq number for  currently active   file number if it is SR type in CllFilenumCommDetView1Iterator.    
        //The view CllFilenumCommDetView has permanent view criteria set to display only current active file number. Do not distrub this setting   
         if(CllUtils.existIteratorPendingChanges("CllFilenumCommDetView1Iterator")){   
            logger.info("***************  Iterator CllFilenumCommDetView1Iterator  has changes ****************  ");
            changeinCllFilenumCommDetView1Iterator=true; 
            CllFilenumCommDetViewRowImpl currentRow = (CllFilenumCommDetViewRowImpl)iterator1.getCurrentRow(); 
            if(currentRow.getFileTypeCode().equalsIgnoreCase(CllConstants.FILE_NUMBER_TYPE_SR_CODE ) &&  null == currentRow.getCommentSeqNumber()) {
             
                     logger.info(" Current file type is  SR  type ");  
                     /*if(currentTypeCode.equalsIgnoreCase(CllConstants.CLL_TYPE_CODE_FORM_LETTER)){  // as per discussion on May 11th, every instance should be assigned with seq number
                            seqAlreadyProcessed=true;   // form letter instance  will have only one file number at any cost
                            OperationBinding opb = ADFUtils.findOperation("findRowWithSRSeqNumber");
                            opb.getParamsMap().put("fileNumId",currentRow.getFilenumId() ); 
                            opb.getParamsMap().put("formLetId",formLetId );   
                            opb.getParamsMap().put("fileNumTypeCode",currentRow.getFileTypeCode() ); 
                            opb.execute(); 
                            if(opb.getErrors().isEmpty()){
                                boolean  srSeqNumAssigned= (Boolean)opb.getResult();
                                if(srSeqNumAssigned){
                                    return true;
                                }
                            }else {
                                JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_ERROR_VERIFYING_SR_SEQ_NUMBER_FOR_FORM_LETTER"));
                                logger.info(" Error while executing data control method findRowWithSRSeqNumber() ****************** ");
                                return false;
                            }
                    }*/
                    
                    OperationBinding operation =ADFUtils.findOperation("getSetFileNumberSeqNumberNext");
                    operation.getParamsMap().put("fileNumId",currentRow.getFilenumId()); 
                    operation.execute();
                    if (operation.getErrors().isEmpty()){
                        srSeqNum= (Number) operation.getResult(); 
                        logger.info("Next  SR Seq  nubmer for SR number "+  currentRow.getFileNumber() + "is :"  +srSeqNum);
                        currentRow.setCommentSeqNumber(srSeqNum);
                        currentTypeCode = (String)ADFUtils.getBoundAttributeValue("CommentTypeCode"); 
                        if(currentTypeCode.equalsIgnoreCase(CllConstants.CLL_TYPE_CODE_FORM_LETTER)){  // as per discussion on May 11th, every instance should be assigned with seq number
                                seqAlreadyProcessed=true;   // form letter instance  will have only one file number at any cost
                        }
                    } else {
                        JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_ERR_GENERATING_SR_SEQ_NUMBER"));  
                        logger.severe("Error while retrieving SR sequence number.  " + operation.getErrors());
                        flag=false;
                   }
                
            }else{
                   currentRow.setCommentSeqNumber(null);   //just assign null so that in case of replacing SR file number with other file type, we need to ensure this col is null
            }
        }  
        //now  update SR  seq number for other associated file numbers if SEQ num is missing
        //we need to use another view CllFilenumberCommDetailsView which does not have any permanent view criteria set.
        DCIteratorBinding iterator2 = ADFUtils.findIterator("CllFilenumberCommDetailsView1Iterator"); 
        //String currentRowKeyStr=iterator2.getCurrentRowKeyString(); 
        RowSetIterator rsi = iterator2.getViewObject().createRowSetIterator(null);  
        rsi.reset();
        while (rsi.hasNext()){ 
            logger.info("***************  Inside  while loop of  RowSetIterator for  CllFilenumCommDetView1Iterator  ****************  ");
            CllFilenumberCommDetailsViewRowImpl row = (CllFilenumberCommDetailsViewRowImpl)rsi.next();
            logger.info("File Number is : "+row.getFileNumber() +" Code: "+row.getCode());
            if(row.getCode().equalsIgnoreCase(CllConstants.FILE_NUMBER_TYPE_SR_CODE) && row.getCommentSeqNumber()==null)  {
                
                currentTypeCode = (String)ADFUtils.getBoundAttributeValue("CommentTypeCode"); 
                if(currentTypeCode.equalsIgnoreCase(CllConstants.CLL_TYPE_CODE_FORM_LETTER)){
                    if(seqAlreadyProcessed){  // form letter instance  will have only one file number at any cost
                        break;
                    }
                   /* if(!seqAlreadyProcessed){ // form letter instance  will have only one file number at any cost
                       OperationBinding opb = ADFUtils.findOperation("findRowWithSRSeqNumber");
                       opb.getParamsMap().put("fileNumId",row.getFilenumId() ); 
                       opb.getParamsMap().put("formLetId",formLetId );   
                       opb.getParamsMap().put("fileNumTypeCode",row.getCode() ); 
                       opb.execute(); 
                       if(opb.getErrors().isEmpty()){
                           boolean  srSeqNumAssigned= (Boolean)opb.getResult();
                           if(srSeqNumAssigned){
                               return true;
                           }
                       }else {
                           JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_ERROR_VERIFYING_SR_SEQ_NUMBER_FOR_FORM_LETTER"));
                           logger.info(" Error while executing data control method findRowWithSRSeqNumber() ****************** ");
                           return false;
                       }
                    } */
                }
                
                OperationBinding operation =ADFUtils.findOperation("getSetFileNumberSeqNumberNext");
                operation.getParamsMap().put("fileNumId",row.getFilenumId()); 
                operation.execute();
                if (operation.getErrors().isEmpty()){
                    srSeqNum= (Number) operation.getResult(); 
                    logger.info("Next  SR Seq  nubmer  for SR file number "+  row.getFileNumber()+ " is  : "  +srSeqNum);
                    row.setCommentSeqNumber(srSeqNum); 
                    seqAlreadyProcessed=true;   
                } else {
                    JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_ERR_GENERATING_SR_SEQ_NUMBER"));
                    logger.severe("Error while retrieving SR sequence number for already associated SR file Numbers.  " + operation.getErrors());
                    flag=false;
                }
            }
        } 
        rsi.closeRowSetIterator();
       /* if(!changeinCllFilenumCommDetView1Iterator) {
            iterator1.setCurrentRowWithKey(currentRowKeyStr);
        }*/
        logger.info("Ending  updateSRSeqNumber  in  ViewCommentDetails  *********************");
        return flag;
        
    }
    
    public void popupCommentDialogListener(DialogEvent dialogEvent) {
        logger.info("PopupComment Dialog outcome = " + dialogEvent.getOutcome());
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.ok){
            AdfFacesContext.getCurrentInstance().addPartialTarget(pglComment);
        }
    }
    
    /** Retrieves  list of file numbers assigned to the comment
     *  
     * @return
     */
    private ArrayList<Number>  getFileNumList(){
            ArrayList<Number> fileNumList= new ArrayList<Number>();
         
            DBSequence id=(DBSequence)ADFUtils.getBoundAttributeValue("CllCommDetId");
            if(id != null) {
                refreshFileNumbersForComment( id.getSequenceNumber()); 
                DCIteratorBinding fileNumItr = ADFUtils.findIterator("FileNumbersForCommentDetROView1Iterator");   //CllFilenumCommDetView1Iterator gives only current file num
                ViewObject vo=fileNumItr.getViewObject();
                //vo.executeQuery();
                RowSetIterator rsi = vo.createRowSetIterator(null); 
                rsi.reset();
                while (rsi.hasNext()){
                    FileNumbersForCommentDetROViewRowImpl row = (FileNumbersForCommentDetROViewRowImpl)rsi.next();
                    fileNumList.add(row.getFilenumId());
                } 
                rsi.closeRowSetIterator();
            }
            return fileNumList; 
    }


    private Map<String, String> updateDispositionForSave() { //TODO   Be CAREFUL while updating this method ...Very critical method

        //since disposition is getting saved,  if the status is unprocesssed, change the comment status to processed
       
        String saveMsg = "";
        String currentStatusCode = (String)ADFUtils.getBoundAttributeValue("CommentStatusCode");
        if (currentStatusCode != null) {
            if (currentStatusCode.equalsIgnoreCase(CllConstants.CLL_STATUS_TYPE_CODE_UPRO)) {
                //even if disposition is set  to approve, no  notification to be sent because it is SAVE button
                if (ADFUtils.getBoundAttributeValue("CllDispositionTypeId1") != null) {
                    ADFUtils.setBoundAttributeValue("DispositionDate", ADFUtils.getCurrentJboDate());
                    saveMsg = rb.getString("VIEWCOMMENTDETAILS_COMMENT_PROCESSED"); 
                    Number statusTypeId = getCommentStatusTypeId(CllConstants.CLL_STATUS_TYPE_CODE_PRO);
                    ADFUtils.setBoundAttributeValue("CllStatusTypeId", statusTypeId);

                } else {
                    saveMsg = rb.getString("VIEWCOMMENTDETAILS_SAVED_MSG");
                }

            } else {
                saveMsg = rb.getString("VIEWCOMMENTDETAILS_SAVED_MSG");
            }
            Map<String, String> map = new HashMap<String, String>(); 
            map.put("saveMsg", saveMsg);
            return map;
        } else {
            JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_UNABLE_RETRIEVE_COMMENT_STATUS_TYPE"));
            return null;
        }

    }

    /**Computes disposition type and disposition date, forward date and comment status for  Save and Approve button clicking
     *
     * @return
     */
    private boolean updateDispositionForSaveApprove(){  
                 Number dispoTypeId=null;
                 OperationBinding operation = ADFUtils.findOperation("retrieveDispositionTypeIdApproved"); 
                 operation.execute(); 
                 if(operation.getErrors().isEmpty()){
                    dispoTypeId=(Number)operation.getResult();
                 }else{ 
                    JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_UNABLE_RETRIEVE_DISPO_ID_APPROVED"));  
                    return false;
                 } 
                 Number statusTypeId=getCommentStatusTypeId(CllConstants.CLL_STATUS_TYPE_CODE_PRO); 
                 if(null == statusTypeId){ 
                     JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_UNABLE_RETRIEVE_STATUS_TYPEID"));  
                     return false;
                 }
                 ADFUtils.setBoundAttributeValue("CllStatusTypeId", statusTypeId);
                 ADFUtils.setBoundAttributeValue("CllDispositionTypeId1",dispoTypeId); 
                 ADFUtils.setBoundAttributeValue("DispositionDate",ADFUtils.getCurrentJboDate()); 
                 ADFUtils.setBoundAttributeValue("ForwardDate",ADFUtils.getCurrentJboDate()); 
                 return true;
    }
    
     
    /** Saves the comment log in DB and sends  notification to the attornies assodicated with the file numbers
     *
     * @param actionEvent
     */
    public void saveApproveListener(ActionEvent actionEvent) {    
              //TODO   Be careful while updating this method ...Very critical method
                if(!isValidData()){
                   return;
                }  
                if( !updateDispositionForSaveApprove() ){  // if any error go back to UI
                    return ;
                } 
                
                //update  comment detail with next  sequence number for SR  type since comment gets approved here  
                if (!updateSRSeqNumber()) {
                    return ;
                } 
                
                //user may add or  edit current file number.  If so, we need to udpate  available status 
                boolean changeInFileNum=false; 
                if(CllUtils.existIteratorPendingChanges("CllFilenumCommDetView1Iterator")){
                    changeInFileNum=true;
                }
                if(ADFUtils.doCommit()) {  
                           logger.info("Comment has been successfully  commited  ***********");   
                            ArrayList<Number> fileNumList= new ArrayList<Number>();
                            fileNumList=getFileNumList();  
                            if( fileNumList !=null && fileNumList.size() >0 ){    
                                 boolean flag=sendNotification(fileNumList);
                                 if(flag){ 
                                     JSFUtils.addFacesInformationMessage(rb.getString("VIEWCOMMENTDETAILS_COMMENT_PROCESSED")); 
                                 }else{
                                    //do not stop  because of notication error...continue further ...
                                    //JSFUtils.addFacesInformationMessage(saveMsg);    
                                }
                             } else{
                                JSFUtils.addFacesInformationMessage( rb.getString("VIEWCOMMENTDETAILS_COMM_PROCESSED_NO_FILES_TO_SEND_NOTIFICATION_NOT")); 
                             }   
                            if(changeInFileNum){
                                //if there is change in current file number  
                                updateAvailableStatusForMasterFileNumId();  //service called only if needed 
                            }
                            addFileNumCmdImageLink.setDisabled(false); 
                            
                } else {  //commit fails
                        String msg=rb.getString("VIEWCOMMENTDETAILS_UNABLE_TOSAVE_COMMENTDETAILS_MSG");
                        JSFUtils.addFacesErrorMessage(msg);  
                }
                String fileNumber=(String)ADFUtils.getBoundAttributeValue("FileNumber");
                if(fileNumber != null) {
                   editFileNumCmdImageLink.setDisabled(false);
                   
                } 
                // refresh existing file numbers list 
                DBSequence id=(DBSequence)ADFUtils.getBoundAttributeValue("CllCommDetId");
                if(id != null) {
                    refreshFileNumbersForComment( id.getSequenceNumber());
                }
                clearCurrentFileNumFromBean(); 
                ADFUtils.refreshIterator("CllSubmitterView1Iterator");
                //ADFUtils.refreshIterator("FileNumbersForCommentDetROView1Iterator");
                AdfFacesContext.getCurrentInstance().addPartialTarget(associatedFileNumbersTable); 
                
    }
    
    
    
    
    /** Refreshes the Associated File Numbers  list for a given comment
     *
     * @param commentDetId
     */
    public void refreshFileNumbersForComment( Number commentDetId) {
        logger.info("Starting  refreshFileNumbersForComment  ********************");
        try { 
              OperationBinding operation = ADFUtils.findOperation("refreshFileNumbersForComment");
              operation.getParamsMap().put("commentDetId",commentDetId ); 
              operation.execute(); 
          }catch (JboException e){
               String msg=rb.getString("VIEWCOMMENTDETAILS_UNABLE_LOAD_EXISTING_FILENUMBERS");
               JSFUtils.addFacesErrorMessage(msg);  
           } catch (Exception e){ 
                String msg=rb.getString("VIEWCOMMENTDETAILS_UNABLE_LOAD_EXISTING_FILENUMBERS");
                logger.severe(msg, e);
                JSFUtils.addFacesErrorMessage(msg);   
           }          
        logger.info("Ending  refreshFileNumbersForComment  ********************");
    } 
    
    public Number getCommentStatusTypeId(String statusTypeCode){
        Number statusTypeId=null;
        try { 
              OperationBinding operation = ADFUtils.findOperation("getCommentStatusTypeId");
              operation.getParamsMap().put("statusTypeCode",statusTypeCode ); 
              operation.execute();
              statusTypeId = (Number)operation.getResult(); 
          }catch (JboException e){
               String msg=rb.getString("VIEWCOMMENTDETAILS_UNABLE_TO_FIND_STATUS_TYPE_REFERENCE_DATA");
               JSFUtils.addFacesErrorMessage(msg);  
           } catch (Exception e){ 
                String msg=rb.getString("VIEWCOMMENTDETAILS_UNABLE_TO_FIND_STATUS_TYPE_REFERENCE_DATA");
                logger.severe(msg, e);
                JSFUtils.addFacesErrorMessage(msg);   
           }          
        return statusTypeId;
    }
        

    public void countValueChangeListener(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
        boolean flag= isValidCount();
    }

    public boolean isValidCount(){
       boolean flag=true; 
        if(countInputText.getValue() == null  ){
            String msg=rb.getString("VIEWCOMMENTDETAILS_COUNT_INVALID_VALUE_MSG");
            JSFUtils.addFacesErrorMessage(msg);  
            return false;
        }
        Number count= (Number)countInputText.getValue(); 
        if(count.intValue() <= 0){
            String msg=rb.getString("VIEWCOMMENTDETAILS_COUNT_INVALID_VALUE_MSG");
            JSFUtils.addFacesErrorMessage(msg);  
            return false;
        }
        logger.info("Count value is :" + count.intValue()); 
        return flag;
        
    }
    public void setCommentInputText(RichInputText commentInputText) {
        this.commentInputText = commentInputText;
    }

    public RichInputText getCommentInputText() {
        return commentInputText;
    }

    public void setCountInputText(RichInputText countInputText) {
        this.countInputText = countInputText;
    }

    public RichInputText getCountInputText() {
        return countInputText;
    }
    
    

    public void setCountReadOnly(boolean countReadOnly) {
        this.countReadOnly = countReadOnly;
    }

    public boolean isCountReadOnly() {
        boolean countReadOnly=true;
        String commentTypeCode=(String)ADFUtils.getBoundAttributeValue("CommentTypeCode");
        String commentSourceCode=(String)ADFUtils.getBoundAttributeValue("CommentSourceCode");
          if(commentSourceCode != null && commentTypeCode!=null){
            boolean faxOrRegMail=commentSourceCode.equalsIgnoreCase( CllConstants.CLL_SOURCE_TYPE_FX) ||  commentSourceCode.equalsIgnoreCase(getRegularMailTypeCode());
            if(commentTypeCode.equalsIgnoreCase(getFormLetterTypeCode()) && faxOrRegMail) {
               countReadOnly=false;
            }else{
                countReadOnly=true; 
                Number currentCount=(Number)ADFUtils.getBoundAttributeValue("Count1");
                if(currentCount.intValue() != 1) {    // avoid iterator becoming dirty if  the count is already 1.
                   ADFUtils.setBoundAttributeValue("Count1",1);
                } 
            } 
        }
        return countReadOnly;
    }

    public void setRegularMailTypeCode(String regularMailTypeCode) {
        this.regularMailTypeCode = regularMailTypeCode;
    }

    public String getRegularMailTypeCode() {
        return CllConstants.CLL_SOURCE_TYPE_RM;
    }

    public void setItFileNumber(RichInputText itFileNumber) {
        this.itFileNumber = itFileNumber;
    }

    public RichInputText getItFileNumber() {
        return itFileNumber;
    }

    public void setAddFileNumCmdImageLink(RichLink addFileNumCmdImageLink) {
        this.addFileNumCmdImageLink = addFileNumCmdImageLink;
    }

    public RichLink getAddFileNumCmdImageLink() {
        return addFileNumCmdImageLink;
    }

    public void setEditFileNumCmdImageLink(RichLink editFileNumCmdImageLink) {
        this.editFileNumCmdImageLink = editFileNumCmdImageLink;
    }

    public RichLink getEditFileNumCmdImageLink() {
        return editFileNumCmdImageLink;
    }
         
    /**Calls  custom data control method which tetrieves  file number Id for a  given  file type and file number
     *
     * @param fileTypeId
     * @param fileNumber
     * @return
     */
    public Number  getFileNumId(Number fileTypeId, String fileNumber) {
        Number fileNumId=null;
        try { 
              OperationBinding operation = ADFUtils.findOperation("getFileNumId");
              operation.getParamsMap().put("fileNumTypeId",fileTypeId );
              operation.getParamsMap().put("inputFileNumber",fileNumber );
              operation.execute();
              fileNumId = (Number)operation.getResult(); 
          }catch (JboException e){
               String msg=rb.getString("VIEWCOMMENTDETAILS_UNABLE_TOVERIFY_FILENUMBER");
               JSFUtils.addFacesErrorMessage(msg);  
           } catch (Exception e){ 
                String msg=rb.getString("VIEWCOMMENTDETAILS_UNABLE_TOVERIFY_FILENUMBER");
                logger.severe(msg, e);
                JSFUtils.addFacesErrorMessage(msg);   
           }          
        return fileNumId;
        
    }
                 
                 
    /**Calls  method in custom data control to very a record exists in FileNumCommentDetail table
     * It verifies whether a file number exists in this table for a comment ID
     * @param commentDetId
     * @param fileNumId
     * @return
     */
    public boolean isFileNumExistForCommentDet(Number commentDetId, Number fileNumId){
        logger.info("Starting isFileNumExistForCommentDet in ViewCommentDetails ********************** ");  
        boolean flag=false;
         try { 
               OperationBinding operation = ADFUtils.findOperation("isFileNumExistForCommentDet");
               operation.getParamsMap().put("commentDetId",commentDetId );
               operation.getParamsMap().put("fileNumId",fileNumId );
               operation.execute();
               Boolean fileNumExists = (Boolean)operation.getResult();
               flag= fileNumExists.booleanValue(); 
           }catch (JboException e){
                String msg=rb.getString("VIEWCOMMENTDETAILS_UNABLE_TOVERIFY_FILENUMBER");
                JSFUtils.addFacesErrorMessage(msg);  
            } catch (Exception e){ 
                 String msg=rb.getString("VIEWCOMMENTDETAILS_UNABLE_TOVERIFY_FILENUMBER");
                 logger.severe(msg, e);
                 JSFUtils.addFacesErrorMessage(msg);   
            }  
         logger.info("Ending isFileNumExistForCommentDet in ViewCommentDetails ********************** ") ;
        
        return flag;
    }

    public void setPopupFileNumber(RichPopup popupFileNumber) {
        this.popupFileNumber = popupFileNumber;
    }

    public RichPopup getPopupFileNumber() {
        return popupFileNumber;
    }

    /**  This methods gets executed when we click Add File Number link
     *   It shows popup containing all File# Types and File Numbers 
      *
      * @return
      */
     public String addFileNumCommandLinkClickActionOld() {   //used in the past before integration with file# 
             logger.info("Starting addFileNumCommandLinkClickAction  *************");
         Map<String, Object> viewScope = AdfFacesContext.getCurrentInstance().getViewScope();
             ViewStateCommentDetails viewStateCommentDetails = 
                         (ViewStateCommentDetails)viewScope.get("viewStateCommentDetails");
             viewStateCommentDetails.setAddFileNumber(true);  
             clearViewCriteriaOnFileTypeAndFileNumber(); //first clear any filtering is done of VOs
             ADFUtils.markScopeDirty(viewScope);
             RichPopup.PopupHints ph = new  RichPopup.PopupHints();
             popupFileNumber.show(ph);
             logger.info("Ending addFileNumCommandLinkClickAction *************");
             return null;
     } 
    
    
    
    /**  This methods gets executed when we click Add File Number link
     *   It shows popup containing all File# Types and File Numbers 
      *
      * @return
      */
     public String addFileNumCommandLinkClickAction() {   
             logger.info("Starting addFileNumCommandLinkClickAction  *************");
             Map<String, Object> viewScope = AdfFacesContext.getCurrentInstance().getViewScope();
             ViewStateCommentDetails viewStateCommentDetails = 
                         (ViewStateCommentDetails)viewScope.get("viewStateCommentDetails");
             viewStateCommentDetails.setAddFileNumber(true);  
             clearViewCriteriaOnFileTypeAndFileNumber(); //first clear any filtering is done of VOs
             ADFUtils.markScopeDirty(viewScope); 
             logger.info("Ending addFileNumCommandLinkClickAction *************");
             return "retrievemasterfilenum";
     }
    
    
   
   
    
    
    public  void  addFileNumCommandLinkClickActionLsnr(ActionEvent ae) {   
            logger.info("Starting addFileNumCommandLinkClickAction  *************");
            Map<String, Object> viewScope = AdfFacesContext.getCurrentInstance().getViewScope();
            ViewStateCommentDetails viewStateCommentDetails = 
                        (ViewStateCommentDetails)viewScope.get("viewStateCommentDetails");
            viewStateCommentDetails.setAddFileNumber(true);  
            clearViewCriteriaOnFileTypeAndFileNumber(); //first clear any filtering is done of VOs
            ADFUtils.markScopeDirty(viewScope);
            //RichPopup.PopupHints ph = new  RichPopup.PopupHints();
            //popupFileNumber.show(ph);
            logger.info("Ending addFileNumCommandLinkClickAction *************");
             
    }
    
    /**  This methods gets executed when we click Edit File Number link
     *   It shows popup containing all File# Types and File Numbers 
      *
      * @return
      */
    public String editFileNumCommandLinkClickAction() {
        logger.info("Starting editFileNumCommandLinkClickAction  *************");
        Number currentFileNumId= (Number)ADFUtils.getBoundAttributeValue("FilenumId");
       
        Map<String, Object> viewScope = AdfFacesContext.getCurrentInstance().getViewScope();
        ViewStateCommentDetails viewStateCommentDetails = 
                     (ViewStateCommentDetails)viewScope.get("viewStateCommentDetails");
         viewStateCommentDetails.setAddFileNumber(false);
         viewStateCommentDetails.setCurrentFileNumId(currentFileNumId);
         clearViewCriteriaOnFileTypeAndFileNumber(); //first clear any filtering is done of VOs
         ADFUtils.markScopeDirty(viewScope);
         //RichPopup.PopupHints ph = new  RichPopup.PopupHints();
         //popupFileNumber.show(ph);
        logger.info("Starting editFileNumCommandLinkClickAction  *************");
        return "retrievemasterfilenum";
         
    }
    
    
    /**Retrieves  return parameter MasterFileNumberDTO from search file# task flow  or create file# task flow.
     * 
     */
     public void returnFromSearchOrCreateFileNum(ReturnEvent returnEvent) {
        logger.info("Starting  returnFromSearchOrCreateFileNum ***************************");
         // Add event code here... 
         logger.info("Starting ");
         Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope(); 
         CommentDetails  commDetailsBean = (CommentDetails )pageFlowScope.get("commentDetails"); 
         ReturnMasterFileNumberDTO masterFileNumDTO= commDetailsBean.getReturnMasterFileNumDTO();
         if(null == masterFileNumDTO  ) {
            // JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_NO_FILENUMBER_SELECTED_IN_SEARCH_PAGE"));
             logger.info("The  MasterFileNumber DTO  returned by  file number container is null *****************");
             return;
         }
         if(  null ==masterFileNumDTO.getMasterFileNumberId()) {
            // JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_NO_FILENUMBER_SELECTED_IN_SEARCH_PAGE"));
             logger.info("The  MasterFileNumber ID  returned by  file number container is null  ****************");
             return;
         }
         logger.info("MasterFileNumber Id returned from search page  is  :"+masterFileNumDTO.getMasterFileNumberId()); 
         String fileNumTypeCode=masterFileNumDTO.getFileNumberTypeCode();
         if(null == fileNumTypeCode){
             logger.info("ERROR  *************Master File Number  DTO  does not have  file number type Code !!  **********************");
             JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_FILENUM_TYPE_ID_NOT_FOUND"));
             return;
         }
          
          
         this.masterFileNumDTO=masterFileNumDTO;
         okClickAction();   //this  was the method called  before we integrated file# module with  comment page
                            // in orer to avoid rewrite a whole lot, same method is maintained with little modifications
         logger.info("Starting  returnFromSearchOrCreateFileNum ***************************");
     }
    
    /** Invokes custom data control method which clears the filters from File Number Type VO and File Number VO
     * 
     */
    public void  clearViewCriteriaOnFileTypeAndFileNumber(){
        logger.info("Starting clearViewCriteriaOnFileTypeAndFileNumber in ViewCommentDetails ********************** ");  
       
         try { 
               OperationBinding operation = ADFUtils.findOperation("clearViewCriteriaOnFileTypeAndFileNumber"); 
               operation.execute(); 
           }catch (JboException e){
                String msg=rb.getString("VIEWCOMMENTDETAILS_UNABLETO_CLEAR_VIEWCRITERIA_ON_FILENUMBERS");
                JSFUtils.addFacesErrorMessage(msg);  
            } catch (Exception e){ 
                 String msg=rb.getString("VIEWCOMMENTDETAILS_UNABLETO_CLEAR_VIEWCRITERIA_ON_FILENUMBERS");
                 logger.severe(msg, e);
                 JSFUtils.addFacesErrorMessage(msg);   
            }  
         logger.info("Ending clearViewCriteriaOnFileTypeAndFileNumber in ViewCommentDetails ********************** ") ; 
    }
    

    public void setSaveButton(RichButton saveButton) {
        this.saveButton = saveButton;
    }

    public RichButton getSaveButton() {
        return saveButton;
    }

    public void setFileNumberInputText(RichInputText fileNumberInputText) {
        this.fileNumberInputText = fileNumberInputText;
    }

    public RichInputText getFileNumberInputText() {
        return fileNumberInputText;
    }

    /** When a file number is selected in file number table, the input text entered by user for File Number  will be cleared 
     *
     * @param selectionEvent
     */
    public void fileNumberRowSelectonListiner(SelectionEvent selectionEvent) {
        // Add event code here...
        //selectionListener="#{bindings.CllFileNumber1View1.collectionModel.makeCurrent}"
        JSFUtils.invokeMethodExpression("#{bindings.CllFileNumber1View1.collectionModel.makeCurrent}",
                                        Object.class, SelectionEvent.class,
                                        selectionEvent); 
        
        fileNumberInputText.resetValue();
        AdfFacesContext.getCurrentInstance().addPartialTarget(fileNumberInputText);  
        
    }

    public void fileNumTypesSelectionListener(SelectionEvent selectionEvent) {
        // Add event code here...
        //"#{bindings.FileNumTypesFileNumbers.collectionModel.makeCurrent}"
        JSFUtils.invokeMethodExpression("#{bindings.FileNumTypesFileNumbers.collectionModel.makeCurrent}",
                                        Object.class, SelectionEvent.class,
                                        selectionEvent); 
        
        fileNumberInputText.resetValue();
        AdfFacesContext.getCurrentInstance().addPartialTarget(fileNumberInputText);  
    }

    public void inputFileNumberValChangeListener(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
       // fileNumbersTable.getSelectionModel().clearSelection();
        fileNumbersTable.getSelectedRowKeys().clear();
    }

    public void setFileNumbersTable(RichTable fileNumbersTable) {
        this.fileNumbersTable = fileNumbersTable;
    }

    public RichTable getFileNumbersTable() {
        return fileNumbersTable;
    }

    public void setRelNumListBox(RichSelectOneListbox relNumListBox) {
        this.relNumListBox = relNumListBox;
    }

    public RichSelectOneListbox getRelNumListBox() {
        return relNumListBox;
    }
     
     
    /**When dispositon type is changed, proper action will be taken
     *
     * @param valueChangeEvent
     */
    public void dispositionTypeChangeListener(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
        valueChangeEvent.getComponent().processUpdates(FacesContext.getCurrentInstance());
        String code = (String)ADFUtils.getBoundAttributeValue("CommentDispositionCode");
        if( code != null ){
            if(code.equalsIgnoreCase(CllConstants.CLL_DISPOSITION_TYPE_OTH)){ 
                dispositionTypeOthInputText.setDisabled(false);
                dispositionTypeOthInputText.setShowRequired(true);
            }else{
                dispositionTypeOthInputText.resetValue(); 
                dispositionTypeOthInputText.setDisabled(true);
                dispositionTypeOthInputText.setShowRequired(false);
                ADFUtils.setBoundAttributeValue("OtherDisposition", null); 
            } 
        }else{ 
            //if  disposition is blak,  change comment status to unprocessed
            Number newStatusID=getCommentStatusTypeId(CllConstants.CLL_STATUS_TYPE_CODE_UPRO); 
            if(null != newStatusID){
                ADFUtils.setBoundAttributeValue("CllStatusTypeId", newStatusID);   
            }
            dispositionTypeOthInputText.resetValue(); 
            dispositionTypeOthInputText.setDisabled(true);
            dispositionTypeOthInputText.setShowRequired(false);
            ADFUtils.setBoundAttributeValue("OtherDisposition", null);
        }
        //if disposition is changed,  the date needs to be set to current date
        ADFUtils.setBoundAttributeValue("DispositionDate",ADFUtils.getCurrentJboDate());        
        AdfFacesContext.getCurrentInstance().addPartialTarget(dispositionTypeOthInputText);  
        //AdfFacesContext.getCurrentInstance(5).addPartialTarget(dispositionTypeOthInputText);
      
    }
    
    public boolean isValidData(){
        boolean flag=true;
        flag= isValidCount();
        //if disposition type is other, enture description is entered
        String code = (String)ADFUtils.getBoundAttributeValue("CommentDispositionCode");
        if(code != null) {
            if(code.equalsIgnoreCase(CllConstants.CLL_DISPOSITION_TYPE_OTH)){ 
                String desc=(String)dispositionTypeOthInputText.getValue();
                if(desc== null || desc.isEmpty()){
                    JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_OTHER_DISPO_TYPE_EMPTY_MSG"));
                    flag=false;
                }
            }
        }
        if (!isValidSubmitters() ){
            JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_INVALID_SUBMITTER_NAME"));
            flag=false;
        }
        
        return flag;
        
    }
    
    /**Validates  first name, last name in the submitter table 
     *
     * @return
     */
    public boolean isValidSubmitters() {
         
        DCIteratorBinding bindIter = ADFUtils.findIterator("CllSubmitterView1Iterator");
        RowSetIterator rsi = bindIter.getViewObject().createRowSetIterator(null);

        rsi.reset();  
        boolean validData = true;
        String firstName="";
        String lastName="";
        while (rsi.hasNext()) {
            Row row = rsi.next();
            firstName=(String)row.getAttribute("FirstName");
            lastName=(String)row.getAttribute("LastName");
            if ( (firstName == null || firstName.isEmpty() ) &&   ( lastName == null || lastName.isEmpty())) { 
                validData = false;
                break;
            }
        }
        rsi.closeRowSetIterator();  
        return validData;
        
    }
    
    
    
    public void setDispositionTypeOthInputText(RichInputText dispositionTypeOthInputText) {
        this.dispositionTypeOthInputText = dispositionTypeOthInputText;
    }

    public RichInputText getDispositionTypeOthInputText() {
        return dispositionTypeOthInputText;
    }

    public void setDispTypeOtherCode(String dispTypeOtherCode) {
        this.dispTypeOtherCode = dispTypeOtherCode;
    }

    public String getDispTypeOtherCode() {
        return CllConstants.CLL_DISPOSITION_TYPE_OTH;
    }
    
    
    
    /**
     * Finds the file number type id by code
     * 
     * @param code  File Numner Type Code
     * @return  File Number Type Id
     */
    private Number findFileNumberTypeId(String code){
        logger.info("Starting findFileNumberTypeId  in ViewCommentDetails.java *************");
        OperationBinding operation = ADFUtils.findOperation("getFileNumberTypeId");
        operation.getParamsMap().put("code", code);
        operation.execute();
        if (operation.getErrors().isEmpty()){
            Number fileNumTypeId = (Number)operation.getResult();
            logger.info("Found File Number Type Id : " + fileNumTypeId);
            logger.info("Ending findFileNumberTypeId  in ViewCommentDetails.java *************");
            return fileNumTypeId;
        } else {
            logger.severe("Error on finding File Number Type Id for code : " + code, operation.getErrors());
            logger.info("Ending findFileNumberTypeId  in ViewCommentDetails.java *************");
            return null;
        }
    }
    
    /**
     * Finds the file number id by   type id and file number 
     * 
     * @param fileNumTypeId  
     * @param fileNumber
     * @return  File Number Id
     */
    private Number findFileNumberIdByTypeIdFileNumber(Number fileNumTypeId, String fileNumber,Number masterFileNumId){
        logger.info("Starting findFileNumberIdByTypeIdFileNumber  in ViewCommentDetails.java *************");
        OperationBinding operation = ADFUtils.findOperation("getFileNumId1");
        operation.getParamsMap().put("fileNumTypeId", fileNumTypeId);
        operation.getParamsMap().put("fileNumber", fileNumber);
        operation.getParamsMap().put("masterFileNumId", masterFileNumId);
        operation.execute();
        if (operation.getErrors().isEmpty()){
            if(null  != operation.getResult()){ 
                     Number fileNumId = (Number)operation.getResult();
                    logger.info("Found File Number   : " + fileNumId);
                    logger.info("Ending findFileNumberIdByTypeIdFileNumber  in ViewCommentDetails.java *************");
                    return fileNumId;
            }else {
                   logger.info("File number is not found in CLL  **********************");
                   logger.info("Ending findFileNumberIdByTypeIdFileNumber  in ViewCommentDetails.java *************");
                   return  new Number(0);  // to indicate  no error while searching but file number does not exist
            }
        } else {
            logger.severe("Error on finding File Number Id for file number type id  and file number : " + fileNumTypeId +  " "+ fileNumber+ "  " + operation.getErrors());
            logger.info("Ending findFileNumberIdByTypeIdFileNumber  in ViewCommentDetails.java *************");
            return null;
        }
    }
    
     
    
    /**Validates the file number selected by the user when OK button is clicked in the File Number Popup dialog
     *
     * @return String
     */
    public String okClickAction() {
            // Add event code here... 
            logger.info("Starting okClickAction  *********************"); 
            boolean userEnteredFileNum=false;
            Number fileNumId=null;   
            Number fileNumTypeId =findFileNumberTypeId(this.masterFileNumDTO.getFileNumberTypeCode());    
            if(null == fileNumTypeId){
                 JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_FILENUM_TYPE_ID_NOT_FOUND"));
                 return null;
            }
              
           //get the fileNumId from Cll file Number table. Only if error, we get null as fle number.  
           fileNumId=findFileNumberIdByTypeIdFileNumber(fileNumTypeId,masterFileNumDTO.getFileNumber(),masterFileNumDTO.getMasterFileNumberId());  
            if(null == fileNumId){
                 JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_FILENUM_ID_ERR_MSG"));
                 logger.info("Error while searchig for master file number  in CLL  file number");
                 return null;
            }
            if( fileNumId.intValue()==0 ){ 
                //insert the master file number  in  CLL  file number  and commit the record and get the file num id
                fileNumId=addNewMasterFileNumberToCLLFileNumber( fileNumTypeId,  masterFileNumDTO.getFileNumber(),masterFileNumDTO.getMasterFileNumberId());
               
            } 
            if(null == fileNumId){
                 JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_UNABLE_TO_ADD_MASTERFILENUM_MSG"));
                 return null;
            }              
        
           Map<String, Object> viewScope = AdfFacesContext.getCurrentInstance().getViewScope();
            ViewStateCommentDetails viewStateCommentDetails =  (ViewStateCommentDetails)viewScope.get("viewStateCommentDetails"); 
            //check whether file number exists already for the comment
            DCIteratorBinding dcIterBind = ADFUtils.findIterator("CllFilenumCommDetView1Iterator");
            RowSetIterator rsi = dcIterBind.getRowSetIterator(); 
           
           if(ADFUtils.getBoundAttributeValue("CllCommDetId") != null ){ 
               DBSequence dbSeqCommentDetId = (DBSequence)ADFUtils.getBoundAttributeValue("CllCommDetId");
               Number commentDetId = dbSeqCommentDetId.getSequenceNumber();  
               if(commentDetId.intValue() > 0){
                   if (isFileNumExistForCommentDet(commentDetId,fileNumId)){ 
                       JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_FILENUMBER_EXISTSERROR"));   
                       return null;
                   }
               }
           }else{
               //here control does not come each time when file number is added, user has to save the comment  
               return null;
           }
            if(viewStateCommentDetails.isAddFileNumber()){ 
                    Row newRow = rsi.createRow();
                    newRow.setAttribute("FilenumId", fileNumId); 
                    newRow.setAttribute("AvailableAttr", masterFileNumDTO.getAvailable()); 
                    rsi.insertRow(newRow);
                    rsi.setCurrentRow(newRow);
                    addFileNumCmdImageLink.setDisabled(true);  
            }else{
                Row currentRow=rsi.getCurrentRow();
                logger.info("Current record id  is :" +currentRow.getAttribute("CllFilenumCommDetId"));
                currentRow.setAttribute("FilenumId", fileNumId); 
                currentRow.setAttribute("AvailableAttr", masterFileNumDTO.getAvailable()); 
                addFileNumCmdImageLink.setDisabled(true);   
            }
             
        //syncReleaseNumbers(fileNumTypeId,fileNumId);  TODO  sync release number in sprint 7
        OperationBinding releaseNumsOper = ADFUtils.findOperation("setReleaseNumbers");
        releaseNumsOper.getParamsMap().put("fileNumId", fileNumId);
        releaseNumsOper.execute();
        if (!releaseNumsOper.getErrors().isEmpty()){
            String msg = rb.getString("VIEWCOMMENTDETAILS_UNABLETO_RETRIEVE_RELEASE_NUMBERS");
            logger.severe(msg, releaseNumsOper.getErrors().toString());
            JSFUtils.addFacesErrorMessage(msg);
        }
            
        popupFileNumber.hide(); 
            AdfFacesContext.getCurrentInstance().addPartialTarget(itFileNumber);  
            AdfFacesContext.getCurrentInstance().addPartialTarget(addFileNumCmdImageLink); 
            editFileNumCmdImageLink.setDisabled(false);   
            AdfFacesContext.getCurrentInstance().addPartialTarget(editFileNumCmdImageLink); 
            //ADFUtils.refreshIterator("CllFilenumRelFr1View1Iterator");   //DID NOT  WORK...Did not display release numbers ..kept this line of code  for information
            AdfFacesContext.getCurrentInstance().addPartialTarget(relNumbersTable);   // relNumbersTable  relNumListBox
            AdfFacesContext.getCurrentInstance().addPartialTarget(removeFileNumButton);
         
            logger.info("Ending okClickAction  ************************"); 
         
        return null;
    }


    /** Set release numbers when  file number is entered manually b the user
     *
     * @param
     */
    private void syncReleaseNumbers(Number fileNumTypeId, Number fileNumId) {
        logger.info("Starting syncReleaseNumbers in ViewCommentDetails ********************** ");

        try {
            OperationBinding operation = ADFUtils.findOperation("setReleaseNumbers");
            //               operation.getParamsMap().put("fileTypeId",fileNumTypeId );
            operation.getParamsMap().put("fileNumId", fileNumId);
            operation.execute();
            String msg = rb.getString("VIEWCOMMENTDETAILS_UNABLETO_RETRIEVE_RELEASE_NUMBERS");
            if (!operation.getErrors().isEmpty()){
                logger.severe(msg, operation.getErrors().toString());
                JSFUtils.addFacesErrorMessage(msg);
            }

        } catch (Exception e) {
            String msg = rb.getString("VIEWCOMMENTDETAILS_UNABLETO_RETRIEVE_RELEASE_NUMBERS");
            logger.severe(msg, e);
            JSFUtils.addFacesErrorMessage(msg); // this is only display purpose...so we can proceed with further execution
        }
        logger.info("Ending resetReleaseNumbers in ViewCommentDetails ********************** ");
    }

    
    
    /** Inserts new master file number into CLL repository and returns  fileNumId
     *
     * @param fileNumTypeId
     * @param fileNumber
     * @return
     */
    private Number addNewMasterFileNumberToCLLFileNumber( Number fileNumTypeId, String fileNumber, Number masterFileNumId){ 
        logger.info("Starting  addNewMasterFileNumberToCLLFileNumber  in ViewCommentDetails.java ******************");
        OperationBinding operation = ADFUtils.findOperation("addNewMasterFileNumberToCLLFileNumber"); 
        operation.getParamsMap().put("fileNumTypeId",fileNumTypeId );
        operation.getParamsMap().put("fileNumber",fileNumber );
        operation.getParamsMap().put("masterFileNumId",masterFileNumId );
        operation.execute(); 
        if (operation.getErrors().isEmpty()){
            if(null  != operation.getResult()){ 
                     Number fileNumId = (Number)operation.getResult();
                    logger.info("  File Number Id is  : " + fileNumId);
                    logger.info("Ending  addNewMasterFileNumberToCLLFileNumber  in ViewCommentDetails.java ******************");
                    return fileNumId;
            }else {
                
                 logger.severe("Error on saving master file number into CLL repository  " + fileNumTypeId +  "  "+ fileNumber+ "  " + operation.getErrors());
                 logger.info("Ending  addNewMasterFileNumberToCLLFileNumber  in ViewCommentDetails.java ******************");
                 return null;//  can  not proceed if file num id is null
            }
        } else {
            logger.severe("Error on saving master file number into CLL repository  " + fileNumTypeId +  "  "+ fileNumber+ "  " + operation.getErrors());
            logger.info("Ending  addNewMasterFileNumberToCLLFileNumber  in ViewCommentDetails.java ******************");
            return null;
        } 
        
    }


 
    /** Displays error message to the user to save  comment log
     * 
     */
    public  void  refreshCommentDetails(boolean commentLogModified){    
        if(commentLogModified)  {
             JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_SAVE_COMMENT_MSG_TO_USER")); 
        } 
     
        
    }
    
    /**Resets the release numbers when user clicks CANCEL when OK button is clicked in the File Number Popup dialog
     *
     * @return
     */
    public String cancelClickAction() {
        // Add event code here...
        //since no file number selected, release numbers should be filtered by curreent file number
        popupFileNumber.hide();  
        resetReleaseNumbers();
        return null;
    }


    /** Invokes  custom data control method to set the release numbers based on file type id and file number id
     *
     */
    public void resetReleaseNumbers() {
        logger.info("Starting resetReleaseNumbers in ViewCommentDetails ********************** ");

        Number currentFileNumId = (Number)ADFUtils.getBoundAttributeValue("FilenumId");
        Number currentFileFileTypeId = (Number)ADFUtils.getBoundAttributeValue("FilenumTypeId");
        logger.info("Current  file number  when  cancel button is clicked in popup  :" + currentFileNumId);
        logger.info("Current  file number Type Id when  cancel button is clicked in popup  :" + currentFileFileTypeId);
        try {
            OperationBinding operation = ADFUtils.findOperation("setReleaseNumbers");
            //               operation.getParamsMap().put("fileTypeId",currentFileFileTypeId );
            operation.getParamsMap().put("fileNumId", currentFileNumId);
            operation.execute();
            String msg = rb.getString("VIEWCOMMENTDETAILS_UNABLETO_RETRIEVE_RELEASE_NUMBERS");
            if (!operation.getErrors().isEmpty()){
                logger.severe(msg, operation.getErrors().toString());
                JSFUtils.addFacesErrorMessage(msg);
            }
        } catch (Exception e) {
            String msg = rb.getString("VIEWCOMMENTDETAILS_UNABLETO_RETRIEVE_RELEASE_NUMBERS");
            logger.severe(msg, e);
            JSFUtils.addFacesErrorMessage(msg);
        }
        logger.info("Ending resetReleaseNumbers in ViewCommentDetails ********************** ");
    }

    /**
     * Hide/unhide the dropdown type. Unhide and default dropdown Subtype to first subtype NEW
     * 
     * @param valueChangeEvent
     */
    public void commentTypeValueChangeListener(ValueChangeEvent valueChangeEvent) {
        Number currentFileNumId = (Number)ADFUtils.getBoundAttributeValue("FilenumId");
        //only for  comment of type form letter,  we must ensure that  file number is  available because form letters exist only for file numbers
        if ((currentFileNumId == null) &&
            (null != valueChangeEvent.getNewValue() && valueChangeEvent.getNewValue().equals(1))) {  //means CllFilenumCommDetView1Iterator is not refreshed
          
            JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_FORM_LETTER_TYPE_SELECTION_MSG"));
            Integer oldTypeIndexId = (Integer)valueChangeEvent.getOldValue();
            logger.info("Old comment type is  " + oldTypeIndexId.intValue());
            ((RichSelectOneChoice)valueChangeEvent.getComponent()).resetValue();
            AdfFacesContext.getCurrentInstance().addPartialTarget(commentDetailsSelectOneChoice); 
            return;
        }
        
        if (null != valueChangeEvent.getNewValue() && valueChangeEvent.getNewValue().equals(1)) { //Form Letter
                //if comment has multiple file numbers, do not convert to FL
                if(commentHasMultilpleFileNums()) {
                        logger.info("Comment has multiple file numbers and hence can not be converted to  Form Letter !!");
                        String txt=rb.getString("VIEWCOMMENTDETAILS_COMMENT_CANNOT_BE_CONVERTED_TO_FL");
                        JSFUtils.addFacesErrorMessage(txt);
                        Integer oldTypeIndexId = (Integer)valueChangeEvent.getOldValue();
                        logger.info("Old comment type is  " + oldTypeIndexId.intValue());
                        ((RichSelectOneChoice)valueChangeEvent.getComponent()).resetValue();
                         AdfFacesContext.getCurrentInstance().addPartialTarget(commentDetailsSelectOneChoice); 
                        AdfFacesContext.getCurrentInstance().addPartialTarget(afMessagesMainWindow); 
                        return;
                }
        }
        if (currentFileNumId != null) {
            valueChangeEvent.getComponent().processUpdates(FacesContext.getCurrentInstance());
            logger.info("Comment Type Selected Idx = " + valueChangeEvent.getNewValue());

            DBSequence dbseq = (DBSequence)ADFUtils.getBoundAttributeValue("CllCommDetId");
            Number commDetId = null;
            if (null != dbseq) {
                commDetId = dbseq.getSequenceNumber();
            } 
            
         String selectedTypeCode = (String)JSFUtils.resolveExpression("#{bindings.CllTypeId.selectedValue.attributeValues[1]}");
         logger.info("Selected Type Code = " + selectedTypeCode); 
         if (null != selectedTypeCode && CllConstants.CLL_TYPE_CODE_FORM_LETTER.equals(selectedTypeCode)) { //Form Letter 
                //Run the SubTypeRO VO to have always available subtype list
                OperationBinding cllFormLetterSubType = ADFUtils.findOperation("ExecuteCllFormLetterSubtype");
                cllFormLetterSubType.getParamsMap().put("bindFileNum", currentFileNumId);
                cllFormLetterSubType.execute();

                addFileNumCmdImageLink.setDisabled(true);
                editFileNumCmdImageLink.setDisabled(true);
                OperationBinding opb1 = ADFUtils.findOperation("getSubType");
                opb1.getParamsMap().put("fileNumId", currentFileNumId);
                opb1.execute();
                String subType = (String)opb1.getResult();
                if (null == subType) {
                    AdfFacesContext.getCurrentInstance().addPartialTarget(saveButton);
                    AdfFacesContext.getCurrentInstance().addPartialTarget(saveApproveButton);
                }
            } else {
                // ensure that   accidently user will not add another file number when already a file number is added but comment
                //is not saved
                DBSequence dbseqFileId=(DBSequence)ADFUtils.getBoundAttributeValue("CllFilenumCommDetId");  //is it new file number  ?
                Number currentFileNumCommDetId=  dbseqFileId.getSequenceNumber();
                if (null == commDetId || commDetId.intValue() <= 0 || currentFileNumCommDetId ==null || currentFileNumCommDetId.intValue() <=0 ) {
                    addFileNumCmdImageLink.setDisabled(true);
                } else {
                    addFileNumCmdImageLink.setDisabled(false);
                }
                editFileNumCmdImageLink.setDisabled(false);

                remvoeFormLetterTypeReference();
                
            }
            removeTypeOtherDescription();
            AdfFacesContext.getCurrentInstance().addPartialTarget(addFileNumCmdImageLink);
            AdfFacesContext.getCurrentInstance().addPartialTarget(editFileNumCmdImageLink);
            AdfFacesContext.getCurrentInstance().addPartialTarget(pglSubType);
        }
    }
    
       /**Checks whether comment as multiple file numbers including currently editable file number
         *
         * @return boolean
         */
        public boolean commentHasMultilpleFileNums(){
            boolean flag=false; 
            DCIteratorBinding dcIterBindItr = ADFUtils.findIterator("FileNumbersForCommentDetROView1Iterator");
            long count = dcIterBindItr.getEstimatedRowCount();
            if (count <=0 ){
                return false;
            }
            if(count >1){
                return true;
            }
            Number currentFileNumId=(Number)ADFUtils.getBoundAttributeValue("FilenumId");
            if(null == currentFileNumId){    // for any reason if current file number is not pointing to any valid record
                return false;                 // which means only one file number is assigned to comment
            }
            DBSequence currentFileNumCommDetId=(DBSequence)ADFUtils.getBoundAttributeValue("CllFilenumCommDetId");  
            if(currentFileNumCommDetId.getSequenceNumber().intValue() < 0  ) { // new file number is getting added
                return true; 
            }  
            FileNumbersForCommentDetROViewRowImpl row = (FileNumbersForCommentDetROViewRowImpl)dcIterBindItr.getCurrentRow();
            //compare file nubmer in RO view  with  file number in updatable view object CllFilenumCommDetView
            if( row.getCllFilenumCommDetId().intValue() == currentFileNumCommDetId.getSequenceNumber().intValue()){
                return false;
            }
                 
            /* boolean currentFileNumExists=false;
            RowSetIterator rsi= dcIterBindItr.getViewObject().createRowSetIterator(null);
            rsi.reset();
            while (rsi.hasNext()){
                row = (FileNumbersForCommentDetROViewRowImpl)rsi.next();
                if( null == currentFileNumId ){  
                    currentFileNumExists=true;
                    break;
                }
                if(  row.getFilenumId().equals(currentFileNumId)) {
                    currentFileNumExists=true;
                    break;
                }
            }
            rsi.closeRowSetIterator();
            if( currentFileNumExists ){
                    flag=false;
            }else{
                return true;
            }*/
            
            return flag;
    }
    
    public void removeTypeOtherDescription(){
        logger.info("Starting removeTypeOtherDescription************************");
        //System.out.println("Starting removeTypeOtherDescription************************");
        String currentTypeCode = (String)ADFUtils.getBoundAttributeValue("CommentTypeCode");
        logger.info("currentTypeOtherDesc: "+ currentTypeCode);
        //System.out.println("currentTypeOtherDesc: "+ currentTypeCode);
        if(currentTypeCode != null && !currentTypeCode.equalsIgnoreCase(CllConstants.CLL_TYPE_CODE_OTHER)){
            ADFUtils.setBoundAttributeValue("CllTypeOtherDesc", null);
            
        }
    }
    
    /**If the  current type is changed to any type other than form letter type, set the form letter type reference in the comment to null
     * 
     */
    public void remvoeFormLetterTypeReference(){
        logger.info("Starting remvoeFormLetterTypeReference  ************************");
        String currentTypeCode = (String)ADFUtils.getBoundAttributeValue("CommentTypeCode");
        logger.info("Current type code =" + currentTypeCode);
        if(currentTypeCode != null && !currentTypeCode.equalsIgnoreCase(CllConstants.CLL_TYPE_CODE_FORM_LETTER)){
            ADFUtils.setBoundAttributeValue("CllFormLetterId", null);
            
        }
        
    }

    public void setFormSubTypePanelFormBind(RichPanelFormLayout formSubTypePanelFormBind) {
        this.formSubTypePanelFormBind = formSubTypePanelFormBind;
    }

    public RichPanelFormLayout getFormSubTypePanelFormBind() {
        return formSubTypePanelFormBind;
    }
    
     

    public void setTbSubmitter(RichTable tbSubmitter) {
        this.tbSubmitter = tbSubmitter;
    }

    public RichTable getTbSubmitter() {
        return tbSubmitter;
    }

    
    
    
    /**
     * Popup dialog listener that marks the comment log as deleted if "Yes" was clicked in popup.
     *  
     * @param dialogEvent
     */
    public void deleteDialogListener(DialogEvent dialogEvent) {
        logger.info("Starting deleteDialogListener");
        logger.info("Dialog outcome = " + dialogEvent.getOutcome());
        
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.yes){
            logger.info("Deleting comment log.....");
            Number statusTypeId=getCommentStatusTypeId(CllConstants.CLL_STATUS_TYPE_CODE_DEL);
            ADFUtils.setBoundAttributeValue("CllStatusTypeId", statusTypeId); 
            /*if (!updateSRSeqNumber()) {
                return ;
            }*/
            if(ADFUtils.doCommit()) {  
                logger.info("Comment has been successfully  commited  ***********"); 
                //unDeleteButton.setDisabled(false);
                // deleteButton.setDisabled(true);
            } else {
                String msg=rb.getString("VIEWCOMMENTDETAILS_UNABLE_TOSAVE_COMMENTDETAILS_MSG");
                JSFUtils.addFacesErrorMessage(msg);  
                return ;
            }
            
            AdfFacesContext.getCurrentInstance().addPartialTarget(unDeleteButton);
            AdfFacesContext.getCurrentInstance().addPartialTarget(deleteButton);
            ADFUtils.refreshIterator("FileNumbersForCommentDetROView1Iterator");
            AdfFacesContext.getCurrentInstance().addPartialTarget(associatedFileNumbersTable);
        }
        logger.info("Ending deleteDialogListener");
        
    }
    
    /**
     * Popup dialog listener that unarchive the comment if "Yes" was clicked in popup.
     *  
     * @param dialogEvent
     */
    public void unArchiveDialogListener(DialogEvent dialogEvent) {
        logger.info("Starting unArchiveDialogListener");
        logger.info("Dialog outcome = " + dialogEvent.getOutcome());
        
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.yes){
            logger.info("Unarchiving comment ...");
            ADFUtils.setBoundAttributeValue("Archived",null);   
            //update  comment detail with next  sequence number for SR  type if comment is approved
            String finalActCode = (String)ADFUtils.getBoundAttributeValue("CommentDispositionCode");
            if(null != finalActCode && CllConstants.CLL_DISPOSITION_TYPE_APPR.equalsIgnoreCase(finalActCode)){
                if (!updateSRSeqNumber()) {
                    return ;
                }
            } 
           //user may add or  edit current file number.  If so, we need to udpate  available status when comment is saved
           boolean changeInFileNum=false; 
           if(CllUtils.existIteratorPendingChanges("CllFilenumCommDetView1Iterator")){
               changeInFileNum=true;
           }
           if (ADFUtils.doCommit()){ 
               if(changeInFileNum){
                   //if there is change in current file number  
                   updateAvailableStatusForMasterFileNumId();  //service called only if needed 
               }
           }else{
               JSFUtils.addFacesErrorMessage("Error while  unarchiving the comment. Please contact System Administrator.");
               logger.info("Error while un archiving comment **************************");
               
           }
           
        } 
        String commentTypeCode= (String)ADFUtils.getBoundAttributeValue("CommentTypeCode");  
        if(commentTypeCode != null && !commentTypeCode.equals(getFormLetterTypeCode())){
             addFileNumCmdImageLink.setDisabled(false);   
             AdfFacesContext.getCurrentInstance().addPartialTarget(addFileNumCmdImageLink);
         } 
        AdfFacesContext.getCurrentInstance().addPartialTarget(unArchiveButton);
        ADFUtils.refreshIterator("FileNumbersForCommentDetROView1Iterator");
        AdfFacesContext.getCurrentInstance().addPartialTarget(associatedFileNumbersTable);
        logger.info("Ending unArchiveDialogListener");
    }


    /**
     * Popup dialog listener that marks the comment log as processed or unprocessed if "Yes" was clicked in popup.
     *  
     * @param dialogEvent
     */
    public void unDeleteDialogListener(DialogEvent dialogEvent) {
        logger.info("Starting unDeleteDialogListener");
        logger.info("Dialog outcome = " + dialogEvent.getOutcome());
        
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.yes){
            logger.finest("Undeleting comment log.....");
            Number newStatusID=(Number)ADFUtils.getBoundAttributeValue("CllStatusTypeId"); //retain current status itself if any error
            String code = (String)ADFUtils.getBoundAttributeValue("CommentDispositionCode");
            if( code == null  || code.isEmpty() ){ 
              newStatusID=getCommentStatusTypeId(CllConstants.CLL_STATUS_TYPE_CODE_UPRO); //if no disposition is entered, make the comment unprocessed
            }else{
                newStatusID=getCommentStatusTypeId(CllConstants.CLL_STATUS_TYPE_CODE_PRO);
            } 
            ADFUtils.setBoundAttributeValue("CllStatusTypeId", newStatusID);   
            //update  comment detail with next  sequence number for SR  type if comment is approved
            String finalActCode = (String)ADFUtils.getBoundAttributeValue("CommentDispositionCode");
            if(null != finalActCode && CllConstants.CLL_DISPOSITION_TYPE_APPR.equalsIgnoreCase(finalActCode)){ 
                if (!updateSRSeqNumber()) {
                    return ;
                }
            }
           
            //user may add or  edit current file number.  If so, we need to udpate  available status when comment is saved
            boolean changeInFileNum=false; 
            if(CllUtils.existIteratorPendingChanges("CllFilenumCommDetView1Iterator")){
                changeInFileNum=true;
            }
            if(ADFUtils.doCommit()) {  
                //unDeleteButton.setDisabled(true);
               // deleteButton.setDisabled(false);
                logger.info("Comment has been successfully  commited  ***********"); 
            } else {
                String msg=rb.getString("VIEWCOMMENTDETAILS_UNABLE_TOSAVE_COMMENTDETAILS_MSG");
                JSFUtils.addFacesErrorMessage(msg);  
                return ;
            }
            
            if(changeInFileNum){
                //if there is change in current file number  
                updateAvailableStatusForMasterFileNumId();  //service called only if needed
                
            }
            
            String commentTypeCode= (String)ADFUtils.getBoundAttributeValue("CommentTypeCode");  
            if(commentTypeCode != null && !commentTypeCode.equals(getFormLetterTypeCode())){
                 addFileNumCmdImageLink.setDisabled(false); 
                 AdfFacesContext.getCurrentInstance().addPartialTarget(addFileNumCmdImageLink);
             } 
            AdfFacesContext.getCurrentInstance().addPartialTarget(unDeleteButton);
            AdfFacesContext.getCurrentInstance().addPartialTarget(deleteButton);
            ADFUtils.refreshIterator("FileNumbersForCommentDetROView1Iterator");
            AdfFacesContext.getCurrentInstance().addPartialTarget(associatedFileNumbersTable);
        }
        logger.info("Ending unDeleteDialogListener");
    }

    /**
     * Opens the editing submitter popup and focus selection to first submitter
     * 
     * @param actionEvent
     */
    public void editPopupSubmitterActionListener(ActionEvent actionEvent){
        DCIteratorBinding dcIterBind = ADFUtils.findIterator("CllSubmitterView1Iterator");
        long count = dcIterBind.getEstimatedRowCount();
        if (count > 0){
            RowSetIterator rsi = dcIterBind.getRowSetIterator();
            Row firstRow = rsi.first();
            rsi.setCurrentRow(firstRow);
        } 
        popupSubmitter.show(new RichPopup.PopupHints());
    }
    
    /**
     * Returns a row index for a new incomplete submitter. An incomplete submitter row is the
     * one that has last name missing.
     * 
     * @return
     */
    private Integer findNewSubmitterIndex(){
        Integer newIdx = null;
        DCIteratorBinding dcIterBind = ADFUtils.findIterator("CllSubmitterView1Iterator");
        RowSetIterator rsi= dcIterBind.getViewObject().createRowSetIterator(null);
        rsi.reset();
        while (rsi.hasNext()){
            CllSubmitterViewRowImpl row = (CllSubmitterViewRowImpl)rsi.next();
            rsi.setCurrentRow(row);
            //CASSECDEV-6336  CLL � Persist CLL Metadata for Commenter�s Name into Last Name
			//Remove validation for mandatory submitter's first name 
            if (StringUtils.trimToEmpty(row.getLastName()).isEmpty()) {
                newIdx = rsi.getCurrentRowIndex();
                logger.info("New incomplete submitter was found. Row index = " + newIdx);
                break;
            }
        }
        rsi.closeRowSetIterator();
        logger.info("Returning New incomplete submitter index row = " + newIdx);
        return newIdx;
    }

    /**
     * It verifies if there is a pending incomplete submitter (missing last and first name). 
     * If a pending submitter is found, the sumitter form is brought. Otherwise,
     * It creates a blank new submitter row and insert it at the end of table.
     * 
     * @param actionEvent
     */
    public void createSubmitterActionListener(ActionEvent actionEvent){
        DCIteratorBinding dcIterBind = ADFUtils.findIterator("CllSubmitterView1Iterator");
        RowSetIterator rsi = dcIterBind.getRowSetIterator();
        Integer newIdx = findNewSubmitterIndex();
        if (newIdx == null) {
            Row newRow = rsi.createRow();
            Row lastRow = rsi.last();
            if (lastRow != null) {
                rsi.setCurrentRow(lastRow);
                int idx = rsi.getCurrentRowIndex();
                rsi.insertRowAtRangeIndex(idx + 1, newRow);
                rsi.setCurrentRow(newRow);
            } else {
                rsi.insertRow(newRow);
            }
        } else {
            rsi.setCurrentRowAtRangeIndex(newIdx);
        }
    }
    
    /**
     * Removes rows that doesn't have required last name
     * 
     * @param popupCanceledEvent
     */
    public void popupSubmitterCancelListener(PopupCanceledEvent popupCanceledEvent) {
        logger.info("Cancelling Submitter...");
        DCIteratorBinding dcIterBind = ADFUtils.findIterator("CllSubmitterView1Iterator");
        RowSetIterator rsi = dcIterBind.getViewObject().createRowSetIterator(null);
        rsi.reset();
        while (rsi.hasNext()) {
            CllSubmitterViewRowImpl row = (CllSubmitterViewRowImpl)rsi.next();
            //CASSECDEV-6336  CLL � Persist CLL Metadata for Commenter�s Name into Last Name 
			//Remove validation for mandatory submitter's first name 
            if (StringUtils.trimToEmpty(row.getLastName()).isEmpty()) {
                row.remove();
            }
        }
        rsi.closeRowSetIterator();
        ADFUtils.addPartialTarget(tbSubmitterRO);
    }
    
    /**
     * It verifies if there is a incomplete submitter (missing last name). 
     * If there is an incomplete submitter, the submitter is brought and a 
     * message is displayed.
     * Refreshes the Submitter read only table in Comment Details after clicking 'Ok' in popup
     *
     * @param dialogEvent
     */
    public void popupSubmitterDialogListener(DialogEvent dialogEvent) {
        logger.info("Dialog outcome = " + dialogEvent.getOutcome());
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.ok) {            
            DCIteratorBinding dcIterBind = ADFUtils.findIterator("CllSubmitterView1Iterator");
            RowSetIterator rsi = dcIterBind.getRowSetIterator();
            Integer newIdx = findNewSubmitterIndex();
            if (newIdx == null) {
                ADFUtils.addPartialTarget(tbSubmitterRO);
            } else {
                rsi.setCurrentRowAtRangeIndex(newIdx);
                ADFUtils.addPartialTarget(tbSubmitter);
                ADFUtils.addPartialTarget(pglSubmiterForm);
                //CASSECDEV-6336  CLL � Persist CLL Metadata for Commenter�s Name into Last Name 
				//Remove validation for mandatory submitter's first name 
                JSFUtils.addFacesErrorMessage("Last Name is required.");
            }
        } 
    }

    public void setPrefixInputTxt(RichInputText prefixInputTxt) {
        this.prefixInputTxt = prefixInputTxt;
    }

    public RichInputText getPrefixInputTxt() {
        return prefixInputTxt;
    }

    public void setFirstNameInputTxt(RichInputText firstNameInputTxt) {
        this.firstNameInputTxt = firstNameInputTxt;
    }

    public RichInputText getFirstNameInputTxt() {
        return firstNameInputTxt;
    }

    public void setLastNameInputTxt(RichInputText lastNameInputTxt) {
        this.lastNameInputTxt = lastNameInputTxt;
    }

    public RichInputText getLastNameInputTxt() {
        return lastNameInputTxt;
    }

    public void setSuffixInputTxt(RichInputText suffixInputTxt) {
        this.suffixInputTxt = suffixInputTxt;
    }

    public RichInputText getSuffixInputTxt() {
        return suffixInputTxt;
    }

    public void setAfficilateInputTxt(RichInputText afficilateInputTxt) {
        this.afficilateInputTxt = afficilateInputTxt;
    }

    public RichInputText getAfficilateInputTxt() {
        return afficilateInputTxt;
    }

    public void setJobTitleInputTxt(RichInputText jobTitleInputTxt) {
        this.jobTitleInputTxt = jobTitleInputTxt;
    }

    public RichInputText getJobTitleInputTxt() {
        return jobTitleInputTxt;
    }

    public void setEmailInputTxt(RichInputText emailInputTxt) {
        this.emailInputTxt = emailInputTxt;
    }

    public RichInputText getEmailInputTxt() {
        return emailInputTxt;
    }

    public void setPhoneNumbInputTxt(RichInputText phoneNumbInputTxt) {
        this.phoneNumbInputTxt = phoneNumbInputTxt;
    }

    public RichInputText getPhoneNumbInputTxt() {
        return phoneNumbInputTxt;
    }

    public void clearErrorMessages(ActionEvent actionEvent) {
        FacesContext.getCurrentInstance().getMessages().remove();
    }  
    
    /**
     * Sends forward comment notification to all email recipients thru Notification Proxy
     *
     */
    private boolean  sendNotification(ArrayList<Number> fileNumList) {
        // Get Notification metadata from application properties table
        List<EmailRecipientDTO> emailRecipienList = new ArrayList<EmailRecipientDTO>();
        try {
            logger.info("Start .............sendNotification for ViewCommentDetails. "); 
            
            //Map props = getApplicationProperties();
//            DatabaseResourceBundle dsbundle = new DatabaseResourceBundle();
//            Map props = dsbundle.getResourceBundle();  
//            if(null == props){
//                logger.severe("Error   ....UCM  properties are empty  !!!**************************");
//                JSFUtils.addFacesErrorMessage(rb.getString("PUBLISHINGQUEUE_ERR_FETCHING_UCMPROPERTIE"));    //this mesg already exists in resource bundle
//                return false;
//            }
            String to = "";
            String content = "";  
            
            ForwardCommentDTO forwardComment = new ForwardCommentDTO();
//            String wsdlURL = (String)props.get("NOTIFICATION_WSDL_URL");
//            String nsURI = (String)props.get("NOTIFICATION_QNAME_NAMESPACE_URI");
//            String localPart = (String)props.get("NOTIFICATION_QNAME_LOCALPART");
//            logger.info("wsdlURL => " + wsdlURL);
//            logger.info("nsURI => " + nsURI);
//            logger.info("localPart => " + localPart);
//            if(null == wsdlURL || null == nsURI  || null == localPart){ 
//                logger.severe("Error   ....UCM  properties are empty  !!!**************************");
//                JSFUtils.addFacesErrorMessage(rb.getString("PUBLISHINGQUEUE_ERR_FETCHING_UCMPROPERTIE"));    //this mesg already exists in resource bundle
//                return false;
//            }
            // Get contents of notification 
            // Fetch recipientList
            try {
                DBSequence dbSeqCommDetId = (DBSequence)ADFUtils.getBoundAttributeValue("CllCommDetId");
                Number commDetId = dbSeqCommDetId.getSequenceNumber();
                logger.info("Retrieve email recipients for Comment Id : " + commDetId);
                OperationBinding operation = ADFUtils.findOperation("retrieveMultipleFilenumRecipientList");
                operation.getParamsMap().put("commDetId", commDetId);
                operation.execute();
                if (operation.getErrors().isEmpty()) {
                    emailRecipienList = (List<EmailRecipientDTO>)operation.getResult();
                }
            } catch (JboException e) {
                logger.severe(rb.getString("VIEWFORWARDCOMMENT_INVALID_TO_MSG"), e);
                JSFUtils.addFacesErrorMessage(rb.getString("VIEWFORWARDCOMMENT_INVALID_TO_MSG"));
                return false;
            }


            if (emailRecipienList.size() > 0) {
                 to = this.getRecipients(emailRecipienList);
            } else { 
                 JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_NO_RECIPIENT_MSG"));
                 //JSFUtils.addFacesInformationMessage(rb.getString("VIEWFORWARDCOMMENT_INVALID_TO_MSG")); 
                 return false; 
            }
            logger.info("to = " + to);
            // Fetch subject & content
            // Get current row from CllCommentDetailsView1
            String currentTypeCode = (String)ADFUtils.getBoundAttributeValue("CommentTypeCode");
            logger.info("Current type code =" + currentTypeCode);
            Number formLetterId = (Number)ADFUtils.getBoundAttributeValue("CllFormLetterId");
            logger.info("formLetterId =" + formLetterId);
            try {
                OperationBinding op =
                    ADFUtils.findOperation("prepareViewForwardCommentData");  
                op.execute();
                if (op.getErrors().isEmpty()) {
                    forwardComment = (ForwardCommentDTO)op.getResult();
                }
            } catch (JboException e) { 
                 logger.severe(rb.getString("VIEWCOMMENTDETAILS_UNABLETO_RETRIEVE_PARENT_COMMENT"), e);
                 JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_UNABLETO_RETRIEVE_PARENT_COMMENT"));   
                 return false;
            }
            String subject = forwardComment.getSubject();
            logger.info("subject = " + subject);
            content = forwardComment.getComment();
            // Maintain line breaks in email
            content = content.replaceAll("\n", "<BR>");
            logger.info("Content = " + content);

           // List<String> ucmIdList = getSelectedDocIds();
            logger.info("to => " + to);
            logger.info("subject => " + subject);
            logger.info("content => " + content);
           // logger.info("UCM Doc Id List => " + ucmIdList);

            logger.info("Preparing Email...");
            EmailRequestDTO request = new EmailRequestDTO();
            // Assign To
            request.setToEmailAddress(to);
            // Assisn Subject
            if (subject != null) {
                request.setSubject(subject);
            } else {
                subject = "";
            }
            // Assign Content
            if (content != null) {
                request.setBody(content);
            } else {
                content = "";
            }
            //Assign Attachments
            DBSequence dbSeq=(DBSequence)ADFUtils.getBoundAttributeValue("CllCommDetId");
            Number commId=dbSeq.getSequenceNumber();
            request.setDocIdList(getSelectedDocIds(commId));

            logger.info("Sending Email....");
            // Send Email

//            EmailResponseDTO response = wrapper.sendEmailNotification(request);
            NotificationUtils notifUtils = new NotificationUtils();
            EmailResponseDTO response = notifUtils.sendEmail(request);
            logger.info("Email was sent....");

            logger.info("Response Status = " + response.getStatus());
            if (response.getStatus().equalsIgnoreCase(CllConstants.PROXY_STATUS_SUCCESS)) { 
                //CAS-1257 CLL- Save & Approve is not working if there are form letter type defined for the file number.
                //Adding exception handler for update forward info
                //Display update forward error message instead of notification error message
                JSFUtils.addFacesInformationMessage(rb.getString("VIEWCOMMENTDETAILS_EMAIL_SENT_MSG"));
                try{
                    this.updateForwardedStatus(emailRecipienList);
                } catch (Exception e){
                    JSFUtils.addFacesErrorMessage(rb.getString("VIEWFORWARDCOMMENT_UPDATE_ERROR_MSG"));
                    e.printStackTrace();
                    logger.severe("ERROR updating forward info. " + e);
                }
            } else {
                JSFUtils.addFacesErrorMessage(rb.getString("VIEWFORWARDCOMMENT_NOTIFICATION_ERROR"));
                logger.severe("ERROR. Response Fault Info = " + response.getFaultInfo());
                return false;
            }

        } catch (Exception e) {
                logger.severe(rb.getString("VIEWFORWARDCOMMENT_NOTIFICATION_ERROR"), e);
                JSFUtils.addFacesErrorMessage(rb.getString("VIEWFORWARDCOMMENT_NOTIFICATION_ERROR")); 
                return false;
        }
        
        return true;
    }
    
    /** Return the email recipients from emailRecipientList
     * 
     */
    public String getRecipients(List<EmailRecipientDTO> emailRecipienList){
        StringBuffer recipients = new StringBuffer();
        for (EmailRecipientDTO dto : emailRecipienList){
            if (recipients.toString().length() > 0){
                recipients.append(";");    
            }
            recipients.append(dto.getEmail());
        }
        return recipients.toString();
    }
    
    /** Return the email forwarded to from emailRecipientList
     * 
     */
    public String getForwardedTo(List<EmailRecipientDTO> emailRecipienList){
        StringBuffer recipients = new StringBuffer();
        for (EmailRecipientDTO dto : emailRecipienList){
            recipients.append(dto.getFirstName());
            recipients.append(" "); 
            recipients.append(dto.getLastName());
            recipients.append(", ");
            logger.info("Getting recipient " + dto.getFirstName() + " " + dto.getLastName());
            }
        int stLength = StringUtils.lastIndexOf(recipients.toString(),',');
        String stFwdTo = recipients.toString().substring(0, stLength);
        return stFwdTo;
    }
    
    /** Prepares viewForwardComment
     *
     */
    public void updateForwardedStatus(List<EmailRecipientDTO> emailRecipienList) {
        logger.info("START... updateForwardedStatus for viewCommentDetails");
        String msg = "";
        // Get whom forwarded to
        String to = this.getForwardedTo(emailRecipienList);
        logger.info("Forwarded To List =" + to);

        //CAS-1257 CLL- Save & Approve is not working if there are form letter type defined for the file number.
        //This code runs only for Save & Approve. This funcionlaity is only for Comments and not for Form Letters
        //Code was commented.
        
        // Of Form Letter Type 
//        if(ADFUtils.getBoundAttributeValue("CllFormLetterId") != null ) {
//            // Of Form Letter Type 
//            Number formLetterId = (Number)ADFUtils.getBoundAttributeValue("CllFormLetterId");
//            try {
//                OperationBinding op = ADFUtils.findOperation("retrieveCommDetFormLetter");
//                op.getParamsMap().put("parameter_name", formLetterId);
//                op.execute();
//            }catch (JboException e){
//                msg=rb.getString("VIEWFORWARDCOMMENT_UNABLETO_RETRIEVE_FORMLETTERLIST");
//                JSFUtils.addFacesErrorMessage(msg);
//            }
//            if (msg.isEmpty()) { // if no exception
//                
//                DCIteratorBinding commDetIter2 = ADFUtils.findIterator("CllCommentDetailsView2Iterator");
//                RowSetIterator rsi = commDetIter2.getViewObject().createRowSetIterator(null);
//                rsi.reset();
//                while (rsi.hasNext()){
//                    CllCommentDetailsViewRowImpl row = (CllCommentDetailsViewRowImpl)rsi.next();
//                    row.setForwardDate(ADFUtils.getCurrentJboDate());
//                    row.setForwardedTo(to);
//                }
//                rsi.closeRowSetIterator();
//                
//                DCIteratorBinding formLetterIter = ADFUtils.findIterator("CllFormLetterView1Iterator");
//                Row formLetterRow = formLetterIter.getCurrentRow();
//                formLetterRow.setAttribute("ForwardDate", ADFUtils.getCurrentJboDate());
//                logger.info("Updated Form Letter");
//            }
//        } else {
            // Of Comment Log type  
                DCIteratorBinding commDetIter1 = ADFUtils.findIterator("CllCommentDetailsView1Iterator");
                Row commDetRow = commDetIter1.getCurrentRow();
                commDetRow.setAttribute("ForwardDate", ADFUtils.getCurrentJboDate());
                commDetRow.setAttribute("ForwardedTo", to);
                logger.info("Updated Comment");
//        }
        
        Boolean committed = ADFUtils.doCommit();
        logger.info("UpdateForwardedStatus committed = " + committed);
    }
    
    /**
     * Dialog listener for the popup dialog that confirms the Notification was sent.
     * Clicking "Ok" from the popup, it will navigates to ViewCommentsDetail fragment.
     * 
     * @param dialogEvent
     */
    public void noRecipientsDialogListener(DialogEvent dialogEvent) {
        logger.info("Dialog outcome = " + dialogEvent.getOutcome());
        JSFUtils.handleNavigation("goViewForwardComment");
    } 
    
    /**
     * Dialog listener for the popup dialog that confirms the Notification was sent.
     * Clicking "Ok" from the popup, it will navigates to ViewCommentsDetail fragment.
     * 
     * @param dialogEvent
     */
    public void emailSentDialogListener(DialogEvent dialogEvent) {
        logger.info("Dialog outcome = " + dialogEvent.getOutcome());
        return;
    }
    
    /**
     * Returns the selected doc Ids from the Attachment table to be included in the Notification.
     *
     * @return  String list of document (UCM)Ids
     */
    private List<String> getSelectedDocIds(Number commId){
        logger.info("Starting getSelectedDocIds  ******************** ");
        List<String> docIdList = new ArrayList<String>();
        
        OperationBinding operation = ADFUtils.findOperation("getSelectedDocIds");
        operation.getParamsMap().put("caseId", commId);
        operation.getParamsMap().put("modName", CllConstants.CLL_MODULE);
        operation.execute();
        if (operation.getErrors().isEmpty()){
            docIdList = (ArrayList)operation.getResult();
        }  
        logger.info("Ending getSelectedDocIds  ******************** ");
        return docIdList;
    }
    
    /**
     * Retrieves and returns the key-value application properties from DB.
     *
     * @return  Map with application properties
     */
    private Map getApplicationProperties(){
        Map map = new HashMap();
        OperationBinding operation = ADFUtils.findOperation("getResourceBundle");
        operation.execute();
        if (operation.getErrors().isEmpty()){
            map = (Map)operation.getResult();
        }
        return map;
    }

    public void setFormLetterTextBind(RichInputText formLetterTextBind) {
        this.formLetterTextBind = formLetterTextBind;
    }

    public RichInputText getFormLetterTextBind() {
        return formLetterTextBind;
    }

    /**
     * Close and reset match text popup 
     * 
     * @param actionEvent
     */
    public void matchTextCancelActionListener(ActionEvent actionEvent){
        logger.info("Canceling match text....");
        formLetterTextBind.resetValue();
        AdfFacesContext.getCurrentInstance().addPartialTarget(formLetterTextBind);
        popupFLSaveSubmit.hide();
    }

    /**
     * Creates a NEW form letter with a next alphabetic letter and the match text entered.
     * Associates the new form letter to comment by getting the new CllFormLetterId and assign it to comment
     * 
     * @param actionEvent
     */
    public void saveAndSubmitActionListener(ActionEvent actionEvent) {
        if (!isValidData()) {
            return;
        }
        Map<String, String> map = new HashMap<String, String>();
        map = updateDispositionForSave();
        if (map == null) {
            return;
        } 
        
        //user may add or  edit current file number.  If so, we need to udpate  available status when comment is saved
        boolean changeInFileNum=false; 
        if(CllUtils.existIteratorPendingChanges("CllFilenumCommDetView1Iterator")){
            changeInFileNum=true;
        }
        
        //there is  Approval task in Form Tab for all form letters and sequence number is taken care and hence below code is commented out.
        /*if (!updateSRSeqNumber()) {
            return ;
        }*/ 
        
        //Validate if comment is Type Form Letter and Sub Type New before proceeding
        //Also, match text is required
        if (isValidSaveSubmitState()){
            oracle.jbo.domain.ClobDomain matchText = (oracle.jbo.domain.ClobDomain)formLetterTextBind.getValue();
            Number currentFileNumId = (Number)ADFUtils.getBoundAttributeValue("FilenumId");
            logger.info("Current FileNumId = " + currentFileNumId);

            //Create Form Letter Record
            OperationBinding createNewFormLetter = ADFUtils.findOperation("createNewFormLetter");
            createNewFormLetter.getParamsMap().put("fileNumId", currentFileNumId);
            createNewFormLetter.getParamsMap().put("matchText", matchText);
            createNewFormLetter.execute();
            
            if (!createNewFormLetter.getErrors().isEmpty()){
                logger.severe("Error on creating new form letter :: " + createNewFormLetter.getErrors());
                JSFUtils.addFacesErrorMessage(rb.getString("CREATE_FORMLETTER_ERROR_MSG") );
            } else {
                Number newFormLetterId = (Number)createNewFormLetter.getResult();
                logger.info("Created New FormLetter Id = " + newFormLetterId);

                //Associates the new form letter to comment. Get new CllFormLetterId and assign it to comment
                ADFUtils.setBoundAttributeValue("CllFormLetterId", newFormLetterId); 
               
                
                if (ADFUtils.doCommit()) {
                    logger.info("Comment has been successfully  commited  ***********");
                    JSFUtils.addFacesInformationMessage(map.get("saveMsg"));
                    // refresh existing file numbers list
                    DBSequence id = (DBSequence)ADFUtils.getBoundAttributeValue("CllCommDetId");
                    if (id != null) {
                        refreshFileNumbersForComment(id.getSequenceNumber());
                    }
                    //Refresh CllFormLetterSubtype to have latest in list
                    OperationBinding cllFormLetterSubType = ADFUtils.findOperation("ExecuteCllFormLetterSubtype");
                    cllFormLetterSubType.getParamsMap().put("bindFileNum", currentFileNumId);
                    cllFormLetterSubType.execute();  
                    //if there is change in current file number 
                    if(changeInFileNum){
                        updateAvailableStatusForMasterFileNumId();  //service called only if needed
                    } 
                    popupFLSaveSubmit.hide();
                    
                    
                } else { //commit fails
                    String msg = rb.getString("VIEWCOMMENTDETAILS_UNABLE_TOSAVE_COMMENTDETAILS_MSG");
                    JSFUtils.addFacesErrorMessage(msg);
                }
                //ADFUtils.refreshIterator("FileNumbersForCommentDetROView1Iterator");
                AdfFacesContext.getCurrentInstance().addPartialTarget(associatedFileNumbersTable); 
            }
        } 

        ADFUtils.refreshIterator("CllSubmitterView1Iterator");
        
        AdfFacesContext.getCurrentInstance().addPartialTarget(saveApproveButton);
        AdfFacesContext.getCurrentInstance().addPartialTarget(addFileNumCmdImageLink);
        AdfFacesContext.getCurrentInstance().addPartialTarget(editFileNumCmdImageLink);
        AdfFacesContext.getCurrentInstance().addPartialTarget(saveButton);
        AdfFacesContext.getCurrentInstance().addPartialTarget(pglSubType);        
        AdfFacesContext.getCurrentInstance().addPartialTarget(socSubtype);
        AdfFacesContext.getCurrentInstance().addPartialTarget(cbEnterMatchText);
    }
    
    /**
     * Validates if the comment is Type Form Letter and Sub Type New.
     * Also, match text is required
     * 
     * @return
     */
    private boolean isValidSaveSubmitState(){
        boolean isValid = true;
        String commentTypeCode = (String)ADFUtils.getBoundAttributeValue("CommentTypeCode");
        logger.info("isValidSaveSubmitState() :: commentTypeCode = " + commentTypeCode);
        if (null != commentTypeCode && !CllConstants.CLL_TYPE_CODE_FORM_LETTER.equals(commentTypeCode)){
            isValid = (isValid && false);
            JSFUtils.addFacesErrorMessage("Comment Type is not Form Letter.");
        }
        Integer subTypeIdx = (Integer)socSubtype.getValue();
        logger.info("isValidSaveSubmitState() :: subTypeIdx = " + subTypeIdx);
        if (null != subTypeIdx && subTypeIdx != 0){
            isValid = (isValid && false);
            JSFUtils.addFacesErrorMessage("Comment Sub Type is not 'New'.");
        }
        oracle.jbo.domain.ClobDomain matchText = (oracle.jbo.domain.ClobDomain)formLetterTextBind.getValue();
        String strMatchText = matchText.toString();
        if (StringUtils.trimToNull(strMatchText) == null){
            isValid = (isValid && false);
            JSFUtils.addFacesErrorMessage("Match Text is required.");
        }
        return isValid;
    }
    
    public String forwardCommentAction(){
        logger.info("Forwarding Comment Action ...");
      
            if (!CllUtils.existIteratorPendingChangesCommDet("CllCommentDetailsView1Iterator")) {
                ADFContext.getCurrent().getRequestScope().put("commDetId",ADFUtils.getBoundAttributeValue("CllCommDetId"));
                return "goViewForwardComment";
            } else {
                logger.info("Changes yet to be saved first");
                JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_UNSAVED_DATA_MSG"));
                return null;
            }
    }

    /**
     * Validates if the comment has disposition selected
     * 
     * @return
     */
    private boolean existDisposition(){
        logger.info("Validating Comment Forwarding...");
        boolean isValid = true;
        String dispositionCode=(String)ADFUtils.getBoundAttributeValue("CommentDispositionCode");
        if(dispositionCode== null || dispositionCode.isEmpty()) {
            isValid=false; 
        } else {
            if(dispositionCode.equalsIgnoreCase(CllConstants.CLL_DISPOSITION_TYPE_OTH)){ 
            String desc=(String)dispositionTypeOthInputText.getValue();
            if(desc== null || desc.isEmpty()){
                isValid=false;
                }
            }
        }
        
        if (!isValid){
            logger.info("Need disposition before forwarding");
            JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_INVALID_FORWARD_MSG"));
        }
        logger.info("existDeisposition isValid = " + isValid);
        return isValid;
    }

    public void exitActionListner(ActionEvent actionEvent) {
       //if any pending change in comment details record, prompt the user about pending changes
        
        if(pendingChangesExist()){
          //if(verifyPendingChanges()){  can not use this.  There are conflicts
            this.exitWarnPp.show(new RichPopup.PopupHints());
        }else{
            String str=(String)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pHidePag");
            if (!(null != str && str.equalsIgnoreCase("true") ) ){
                updateCommentDetId();
            } 
            this.setExitAction("exit");
        }
    }
    
    private Transaction getCommentLogDataCntrlTrx(){
        return ADFUtils.getApplicationModuleForDataControl("CommentLogAppModuleDataControl").getTransaction();
    }
    
    private boolean pendingChangesExist(){
        return this.getCommentLogDataCntrlTrx().isDirty();
    }

    public void setExitAction(String exitAction) {
        this.exitAction = exitAction;
    }

    public String getExitAction() {
        return exitAction;
    }

    public void setExitWarnPp(RichPopup exitWarnPp) {
        this.exitWarnPp = exitWarnPp;
    }

    public RichPopup getExitWarnPp() {
        return exitWarnPp;
    }

    public void exitNoActionLsitner(ActionEvent actionEvent) {
        this.exitWarnPp.hide();
    }

    public void setPopupEmailSent(RichPopup popupEmailSent) {
        this.popupEmailSent = popupEmailSent;
    }

    public RichPopup getPopupEmailSent() {
        return popupEmailSent;
    }

     

    public void setPopupNoRecipients(RichPopup popupNoRecipients) {
        this.popupNoRecipients = popupNoRecipients;
    }

    public RichPopup getPopupNoRecipients() {
        return popupNoRecipients;
    }

    public void setSaveApproveButton(RichButton saveApproveButton) {
        this.saveApproveButton = saveApproveButton;  
    }

    public RichButton getSaveApproveButton() {
        return saveApproveButton;
    }
    
    public String getCommentStatusCodeProcessed(){
        return   CllConstants.CLL_STATUS_TYPE_CODE_PRO;
    } 
    
    public String getCommentTypeCodeCL(){
        return   CllConstants.CLL_TYPE_CODE_COMMENT_LETTER;
    }

    public void setExitButton(RichButton exitButton) { 
        this.exitButton = exitButton; 
    }

    public RichButton getExitButton() {  
        return exitButton;
    }
    
    public void setDisableSaveApproveButton(boolean disableSaveApproveButton) {
        this.disableSaveApproveButton = disableSaveApproveButton; 
    }
 
    public String getDeletedQOriginnation(){
        return CllConstants.ORIGINATION_DELETED_Q;
    }
    
    public String getCommentStatusCodeDeleted(){
        return   CllConstants.CLL_STATUS_TYPE_CODE_DEL;
    }

    public void setPopupSubmitter(RichPopup popupSubmitter) {
        this.popupSubmitter = popupSubmitter;
    }

    public RichPopup getPopupSubmitter() {
        return popupSubmitter;
    }

    public void setDeleteButton(RichButton deleteButton) {
        this.deleteButton = deleteButton;
    }

    public RichButton getDeleteButton() {
        return deleteButton;
    }

    public void setUnDeleteButton(RichButton unDeleteButton) {
        this.unDeleteButton = unDeleteButton;
    }

    public RichButton getUnDeleteButton() {
        return unDeleteButton;
    }

    public void setPglComment(RichPanelGroupLayout pglComment) {
        this.pglComment = pglComment;
    }

    public RichPanelGroupLayout getPglComment() {
        return pglComment;
    }

    public void setTbSubmitterRO(RichTable tbSubmitterRO) {
        this.tbSubmitterRO = tbSubmitterRO;
    }

    public RichTable getTbSubmitterRO() {
        return tbSubmitterRO;
    }

    public void setRelNumbersTable(RichTable relNumbersTable) {
        this.relNumbersTable = relNumbersTable;
    }

    public RichTable getRelNumbersTable() {
        return relNumbersTable;
    }
 

    /**If any pending changes in Comment Letter,  it will be rolledback
     *
     * @return
     */
    public String rollbackAndExitAction() {
            logger.info("Starting rollbackAndExitAction ****************** "); 
            DBSequence dbSeq=(DBSequence)ADFUtils.getBoundAttributeValue("CllCommDetId");
            Number commId=dbSeq.getSequenceNumber(); 
            DCIteratorBinding commListIterator =    ADFUtils.findIterator("CllCommentsListROView1Iterator");
            Key parentKey =null;
            String currentRowKeyStr="";
            int currentRowIndex=0;
            boolean pHidePagination=false;
            String str=(String)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pHidePag");
            if(null != str && str.equalsIgnoreCase("true")){
                pHidePagination=true;
            }
            
            //if the comment is opened from comment list or form letter list
            if(commId.intValue() > 0 && !pHidePagination ) {   //if  it is existing comment ie.,  not a new  comment

                CllCommentsListROViewRowImpl currentCommListRow = (CllCommentsListROViewRowImpl)commListIterator.getCurrentRow();
                Number currentCommId = currentCommListRow.getCllCommDetId();
                currentRowKeyStr = commListIterator.getCurrentRowKeyString();
                currentRowIndex = commListIterator.getCurrentRowIndexInRange(); 
                logger.info("Current row in the list is  :" +currentCommListRow.getCllCommDetId()); 
                parentKey = commListIterator.getCurrentRow().getKey();  
                updateCommentDetId();
            }
            if(ADFUtils.doRollback()) { 
                if(commId.intValue() > 0 && !pHidePagination ) {  
                       commListIterator.executeQuery();  
                       commListIterator.setCurrentRowWithKey(parentKey.toStringFormat(true));
                       commListIterator.setCurrentRowIndexInRange(currentRowIndex);
                       getCommentLogDataCntrlTrx().setClearCacheOnRollback(false);   
                }
                logger.info("Ending rollbackAndExitAction ****************** "); 
                return "exit";
            }else {  //commit fails
                 String msg=rb.getString("VIEWCOMMENTDETAILS_UNABLE_TOSAVE_COMMENTDETAILS_MSG");
                 JSFUtils.addFacesErrorMessage(msg);  
                 logger.info("Ending rollbackAndExitAction ****************** "); 
                 return null;
                 
           } 
         // return "exit";
     }

    public void setPglSubmiterForm(RichPanelGroupLayout pglSubmiterForm) {
        this.pglSubmiterForm = pglSubmiterForm;
    }

    public RichPanelGroupLayout getPglSubmiterForm() {
        return pglSubmiterForm;
    }

    public void setCommentDetailsSelectOneChoice(RichSelectOneChoice commentDetailsSelectOneChoice) {
        this.commentDetailsSelectOneChoice = commentDetailsSelectOneChoice;
    }

    public RichSelectOneChoice getCommentDetailsSelectOneChoice() {
        return commentDetailsSelectOneChoice;
    }

    public void setPglSubType(RichPanelGroupLayout pglSubType) {
        this.pglSubType = pglSubType;
    }

    public RichPanelGroupLayout getPglSubType() {
        return pglSubType;
    }

    public void setPopupFLSaveSubmit(RichPopup popupFLSaveSubmit) {
        this.popupFLSaveSubmit = popupFLSaveSubmit;
    }

    public RichPopup getPopupFLSaveSubmit() {
        return popupFLSaveSubmit;
    }

   
    /**When OK button is clicked on attachments popup, updates the indicator for the comment regarding any attachment exists
     *
     * @param dialogEvent
     */
    public void exitAttachmentDialogListener(DialogEvent dialogEvent) {
        // Add event code here...  
        if( null != ADFUtils.getBoundAttributeValue("CllCommDetId") ){
            DBSequence dbseq= (DBSequence)ADFUtils.getBoundAttributeValue("CllCommDetId");
            Number commDetId=dbseq.getSequenceNumber();
            OperationBinding operation = ADFUtils.findOperation("attachmentsExists"); 
            operation.getParamsMap().put("commentDetId",commDetId);
            operation.execute(); 
            if(operation.getErrors().isEmpty()){
               Boolean result= (Boolean)operation.getResult();
               attachmentsExist=result.booleanValue();
               //to ensure that taskflow bean is reflected with latest attacments status because this is used in the EL in JSF page
                Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
                CommentDetails commentDetailsBean = (CommentDetails)pageFlowScope.get("commentDetails");
                commentDetailsBean.setAttachmentsExist(attachmentsExist);  //bean instance can not be null because we are already in the page now
                ADFUtils.markScopeDirty(pageFlowScope);
            } 
        }
         
    } 

    public void setAttachmentsExist(boolean attachmentsExist) {
        this.attachmentsExist = attachmentsExist; 
    }

    public void setSocSubtype(RichSelectOneChoice socSubtype) {
        this.socSubtype = socSubtype;
    }

    public RichSelectOneChoice getSocSubtype() {
        return socSubtype;
    }

    public boolean isAttachmentsExist() { 
        return attachmentsExist;
    }

    public void setCbEnterMatchText(RichButton cbEnterMatchText) {
        this.cbEnterMatchText = cbEnterMatchText;
    }

    public RichButton getCbEnterMatchText() {
        return cbEnterMatchText;
    }

    public void unPublishComment(ActionEvent actionEvent) {
        // Add event code here...
    }
    
    public ArrayList<Number>  selectedCommentsToPublish () {
            ArrayList<Number>  commIds = new ArrayList<Number> ();
            DCIteratorBinding commListIterator = ADFUtils.findIterator("CllCommentsListROView1Iterator"); 
//            RowSetIterator rsi = commListIterator.getViewObject().createRowSetIterator(null);
//        DCIteratorBinding dcIterBind= ADFUtils.findIterator("CllCommentsListROView1Iterator");
        CllCommentsListROViewRowImpl currentRow = (CllCommentsListROViewRowImpl)commListIterator.getCurrentRow();
                        Number commId = currentRow.getCllCommDetId(); 
                        commIds.add(commId);
        return commIds;
    }
    
    

    //TODO currently single comment is getting unpublished and hence  in this method,  piece of code is changed
    //to update single comment  due to conflict in  transaction.    
    public void unPublishDialogListener(DialogEvent dialogEvent) {
        String fileTypeFileNum="";
        Number fileNumId=null;
        String updatedFileNumber="";
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        CommentDetails commentDetailsBean = (CommentDetails)pageFlowScope.get("commentDetails"); //initially we used to unpublish from comment list itslef
        if(null != commentDetailsBean && commentDetailsBean.getFileTypeFileNumber() !=null && null !=commentDetailsBean.getFileNumId() ) {
              fileTypeFileNum = commentDetailsBean.getFileTypeFileNumber();
              fileNumId = commentDetailsBean.getFileNumId();
              updatedFileNumber = fileTypeFileNum.replaceAll("-", "").trim().toLowerCase(); //to create folder, we removed "-"
        }else{  //retrieve file num type and file num id from binding layer and proceed if they are not null 
                if(null == ADFUtils.getBoundAttributeValue("FilenumId")){
                  JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_UNABLE_RETRIEVE_FILE_NUMBER_ID"));
                  return;
                }
                fileNumId=(Number)ADFUtils.getBoundAttributeValue("FilenumId");
                if(null == ADFUtils.getBoundAttributeValue("FileTypeCode")){
                    JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_UNABLE_RETRIEVE_FILE_NUMTYPE_CODE"));
                    return;
                }
                if(null == ADFUtils.getBoundAttributeValue("FileNumber")){
                    JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_UNABLE_RETRIEVE_FILE_NUMBER"));
                    return;
                }
                String fileTypeCode =(String)ADFUtils.getBoundAttributeValue("FileTypeCode");
                String fileNumber=(String)ADFUtils.getBoundAttributeValue("FileNumber");
                if(CllConstants.CLL_TYPE_CODE_OTHER.equalsIgnoreCase(fileTypeCode)){
                    updatedFileNumber=fileNumber.trim().toLowerCase();
                    fileTypeFileNum=fileNumber.trim().toLowerCase();
                }else{
                        fileTypeFileNum=fileTypeCode +"-"+fileNumber.trim();
                        updatedFileNumber=fileTypeCode.toLowerCase()+fileNumber.trim().toLowerCase();
                    }
        } 
        
        updatedFileNumber=CllUtils.removeSpecialCharsFromFileFolderName(updatedFileNumber);
        if( null == updatedFileNumber){
                    return ;
                }
        logger.info("File number after removing  special characters *************** is : " +updatedFileNumber);
        ArrayList<Number>  commIds = new ArrayList<Number> (); 
        Map <Number, ArrayList<String>> publishedNamesForAttachments=new HashMap<Number, ArrayList<String>>();
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.yes){
            
            //commIds=selectedCommentsToPublish ();   //TODO when we  unpublish  multiple comments, we had this logic 
            // now no more we invoke unbpulish in  Comment List
            DBSequence commIdDBSeq=(DBSequence)ADFUtils.getBoundAttributeValue("CllCommDetId");
            Number commId=commIdDBSeq.getSequenceNumber();
            commIds.add(commId);   // TODO list is still maintained as  provision to  unpublish multiple comments in future
            
            String downloadLocation = getCommentsPackagingDir();   
            if(null == downloadLocation){ 
                logger.info("***************  Error while retrieving application property CLL_PACKAGING_DIR from database *******************"); 
                showPopupErrorMsg(rb.getString("COMMENTLIST_UNABLE_TO_CREATE_TEMP_DIR_FOR_PACKAGING"));
                return  ;
            }
            //create tmp dir
            Map<String,String> map = new HashMap<String,String>();
            map=createTempDir(downloadLocation,updatedFileNumber ,false); 
            if(null == map) {
               return ;   //already  error popup is invoked
            }
            String subDir=map.get("subDir");
            String subDirName=map.get("subDirName");
            
            //TODO below code is needed if Unpublish is on comment page itself.  Before locking the file number and committing the changes,  store the current CllFilenumCommDetId
            Number currentFileNumId=null;
            if(null != ADFUtils.getBoundAttributeValue("FilenumId")){
                //DBSequence seq=(DBSequence)ADFUtils.getBoundAttributeValue("CllFilenumCommDetId"); 
                  currentFileNumId= (Number)ADFUtils.getBoundAttributeValue("FilenumId"); 
            }
            
            //Lock the file number  
            if( !lockFileNumberForProcessing(fileNumId) ){
               return;
            } 
            publishedNamesForAttachments=getPublishedNamesForAttachments(commIds); 
            if(null == publishedNamesForAttachments) {   
                 unlockFileNumber(fileNumId);
                 return ;    //already  error popup is invoked.   You will get null only if error. Else at least empty object if no attachments.
             }
            
            // generate  package for  un publishing comments
             boolean flag=generatePackageForUnPublishingComments(commIds,publishedNamesForAttachments, fileNumId,fileTypeFileNum,
                                                    downloadLocation,subDir,subDirName);
             if(!flag){
                 unlockFileNumber(fileNumId);
                 logger.info("***************  Error while ...*******************"); 
                 showPopupErrorMsg( rb.getString("VIEWCOMMENTDETAILS_ERR_UNPUBLISHING_COMMENT"));
               return;   ///error
             }                   
              
            //package is created..now ensure that SR seq is added if  there is SR number added if comment is approved  
            String finalActCode = (String)ADFUtils.getBoundAttributeValue("CommentDispositionCode");
            if(null != finalActCode && CllConstants.CLL_DISPOSITION_TYPE_APPR.equalsIgnoreCase(finalActCode)){ 
                if (!updateSRSeqNumber()) {   //unpbulish is done in the comment details page. So, only current comment id is considered
                    //we can not unlock  file number here...because we have to call commit on only one  table  which is file processing table
                    //which is NOT  POSSIBLE...
                    return ;
                }
            }
            
            // update  status for  comments  as published
            
            //TODO Donot remove this code... Tomorrow if we unpublish  mutiple comments,  below code needs to be revisited and used
            //currently due to conflict with transaction (SR seq update), below code is commented since it is not needed as of now.
            /*String commIdsStr=getCommDelemitedCommIds(commIds);            
            OperationBinding operation = ADFUtils.findOperation("updateStatusForUnPublishedComments");
            operation.getParamsMap().put("commentIds",commIdsStr );
            operation.execute();
            if(!operation.getErrors().isEmpty()){
                unlockFileNumber(fileNumId);
               logger.info("***************  Error while updating comment status as  processed *******************"); 
               showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_UPDATING_COMMENTS_AS_UNPUBLISHED")); 
               return ;
            }
            if(null ==  operation.getResult() ||  (Integer)operation.getResult() ==0 ){
                unlockFileNumber(fileNumId);
               logger.info("***************  Error while updating comment status as processed  *******************"); 
               showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_UPDATING_COMMENTS_AS_UNPUBLISHED")); 
               return ;
            }  */
            
            Number processedSatusTypeId = getCommentStatusTypeId(CllConstants.CLL_STATUS_TYPE_CODE_PRO);
            ADFUtils.setBoundAttributeValue("CllStatusTypeId", processedSatusTypeId);
            
            //UnLock  file number without commit  
            OperationBinding unlockOperation = ADFUtils.findOperation("unlockFileNumberNoCommit");
            unlockOperation.getParamsMap().put("fileNumberId",fileNumId );
            unlockOperation.execute();
            if(!unlockOperation.getErrors().isEmpty()){ 
               logger.info("***************  Error while unlocking file itself *******************"); 
               showPopupErrorMsg(rb.getString("Error while unlocking the file after creating package for unpublishing a comment. Please contact system admin.")); 
               return ;
            }  
            if (ADFUtils.doCommit()){  
                // Here, We do not call service to update  status for  Master file number id because we should not be messing up
                //with current file number while  unpublishing a comment...  We should not add or edit current file number
            
            
                //Below code is needed if Unpublish is on comment page itself. while locking the file number, commit takes place
                //hence,  the file number is not pointing to recently added or modified file number  
                if(null != currentFileNumId){
                    DBSequence seq=(DBSequence)ADFUtils.getBoundAttributeValue("CllCommDetId");  // it can not be null at any cost
                    Number commDetId= seq.getSequenceNumber();
                    OperationBinding setFileNumOperation = ADFUtils.findOperation("setFileNumCommentDet");
                    setFileNumOperation.getParamsMap().put("commentDetId",commDetId );
                    setFileNumOperation.getParamsMap().put("fileNumId",currentFileNumId );
                    setFileNumOperation.execute();
                    if(!unlockOperation.getErrors().isEmpty()){ 
                       logger.info("***************  Error while unlocking file itself *******************");  
                       // do nothing if we can not point to right file number...no major issue
                    }
                }
                
                //NOTE   we can not invoke  update  available status for the file number here.   User should not add or edit file number while
                //unpublishing a comment.  It will be like messing up.   Publishing and unbpublishing has to invoked from a particular file number Q.
                
                ADFUtils.refreshIterator("CllCommentDetailsView1Iterator");
                addFileNumCmdImageLink.setDisabled(false);    
                AdfFacesContext.getCurrentInstance().addPartialTarget(statusPanelGroup);
                AdfFacesContext.getCurrentInstance().addPartialTarget(unPublishCommandBtn);
                ADFUtils.refreshIterator("FileNumbersForCommentDetROView1Iterator"); 
                AdfFacesContext.getCurrentInstance().addPartialTarget(associatedFileNumbersTable);
             showPopupInfoMsg(rb.getString("COMMENTLIST_UNPUBLISHING_SUCCESS_MSG"));
            }else{
                 logger.info("***************  Error while committing comment log *******************  ");  
                 showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_PERSISTING_PUBLISHED_COMMENTS"));  
                 return  ;
            }
        }
    }
    
    public boolean unlockFileNumber(Number fileNumId){
        OperationBinding unlockFileNumber = ADFUtils.findOperation("unlockFileNumber");
        unlockFileNumber.getParamsMap().put("fileNumberId",fileNumId );
        unlockFileNumber.execute();
        if(!unlockFileNumber.getErrors().isEmpty()){
          logger.info("***************  Error while unlocking the file number *******************  "  +fileNumId);  
          showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_UNLOCKING_FILE_NUMBER"));  
          return false ;
        }else{
            return true;
        }
    }
    
    private String getCommentsPackagingDir(){
        OperationBinding appPropOper = ADFUtils.findOperation("getResourceBundle");
        appPropOper.execute();
        if (appPropOper.getErrors().isEmpty()){
            Map map = (Map)appPropOper.getResult();
            String dir = (String)map.get("CLL_PACKAGING_DIR");
            logger.info("CLL_PACKAGING_DIR = " + dir);
            return dir;
        } else {
            logger.severe("CLL_PACKAGING_DIR not found in application properties");
            return null;
        }
    }

    public void setPopupError(RichPopup popupError) {
        this.popupError = popupError;
    }

    public RichPopup getPopupError() {
        return popupError;
    }

    public void setPackaingErrorMsg(String packaingErrorMsg) {
        this.packaingErrorMsg = packaingErrorMsg;
    }

    public String getPackaingErrorMsg() {
        return packaingErrorMsg;
    }
    
    private void showPopupErrorMsg(String msg){
        packaingErrorMsg = msg;
        getPopupError().show(new RichPopup.PopupHints()); 
    }

    public void setPopupInfo(RichPopup popupInfo) {
        this.popupInfo = popupInfo;
    }

    public RichPopup getPopupInfo() {
        return popupInfo;
    }

    public void setInfoMsg(String infoMsg) {
        this.infoMsg = infoMsg;
    }

    public String getInfoMsg() {
        return infoMsg;
    }
    
    private void showPopupInfoMsg(String msg){
        infoMsg = msg;
        getPopupInfo().show(new RichPopup.PopupHints());
    }
    
    private  Map  createTempDir(String downloadLocation, String updatedFileNumber, boolean isPublish ){ 
        logger.info("Starting  createTempDir  ********************");
        Map<String,String> map = new HashMap<String,String>();
        RichPopup.PopupHints hints = new RichPopup.PopupHints(); 
        String subDir=null; 
        String subDirName=null; 
        //remove special characters 
        updatedFileNumber=CllUtils.removeSpecialCharsFromFileFolderName(updatedFileNumber);
        if( null == updatedFileNumber){
                    return null;
        }
        logger.info("File number after removing  special characters *************** is : " +updatedFileNumber);
        //create  tmp folder   
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date()); 
        if(isPublish){ 
             subDir=downloadLocation+updatedFileNumber+pkgingPublishDirSubString+timeStamp+"//";
             // subDir=downloadLocation+updatedFileNumber+pkgingPublishDirSubString+timeStamp+"\\";  
             subDirName=updatedFileNumber+pkgingPublishDirSubString+timeStamp; 
        }else{
            subDir=downloadLocation+updatedFileNumber+pkgingUnPublishDirSubString+timeStamp+"//"; 
            // subDir=downloadLocation+updatedFileNumber+pkgingUnPublishDirSubString+timeStamp+"\\";
            subDirName=updatedFileNumber+pkgingUnPublishDirSubString+timeStamp;
        } 
        map.put("subDir",subDir);
        map.put("subDirName",subDirName );
        File tempDir = new File(subDir);
        boolean createDir=tempDir.mkdir(); 
        if(!createDir){
            logger.info("***************  Error while creating packaging dir  "  +subDir + ".  It may exist already  **************" );  
            packaingErrorMsg=rb.getString("COMMENTLIST_ERR_WHILE_CREATING_TEMP_DIR");
            getPopupError().show(hints); 
            return null ;
        }
        logger.info("***************  Created   tmp  dir     *******************");   
        logger.info("Ending  createTempDir  ********************");
       return map; 
    }
    
    private boolean lockFileNumberForProcessing(Number fileNumId){ 
        logger.info(" inside lockFileNumberForProcessing  ********************");
        OperationBinding lockFileNum = ADFUtils.findOperation("lockFileNumber");
        lockFileNum.getParamsMap().put("fileNumberId",fileNumId ); 
        lockFileNum.execute(); 
        if(!lockFileNum.getErrors().isEmpty()){
            logger.info("***************  Error while Locking the file number *******************  "  +fileNumId);   
            showPopupInfoMsg(rb.getString("COMMENTLIST_ERR_WHILE_LOCKING_FILE_NUMBER"));
            return false ;
        }
        Boolean flag=(Boolean)lockFileNum.getResult();
        if(!flag.booleanValue()) {  
            showPopupInfoMsg(rb.getString("COMMENTLIST_FILE_NUMBER_ALREADY_LOCKED"));
            return  false; 
        }
        return true;
    }
    
    private Map<Number, ArrayList<String>> getPublishedNamesForAttachments(ArrayList<Number> commIds){
            logger.info("Starting  getPublishedNamesForAttachments  ********************");
            Map<Number, ArrayList<String>> publishedNamesForAttachments= new HashMap<Number, ArrayList<String>>();
         
            //UnLock  file number        
            OperationBinding publishedNamesOpBinding = ADFUtils.findOperation("getPublishedNamesForComments");
            publishedNamesOpBinding.getParamsMap().put("commentIds",commIds ); 
            publishedNamesOpBinding.execute(); 
            if(!publishedNamesOpBinding.getErrors().isEmpty()){
                logger.info("***************  Error while retrieving  published names for attachments for comments  *******************  ");  
                showPopupErrorMsg(rb.getString("COMMENTlIST_ERR_RETRIEVING_PUBLISHED_NAMES_FOR_ATTACHMENTS"));  
                return null ;
            }
            publishedNamesForAttachments=(HashMap<Number, ArrayList<String>>)publishedNamesOpBinding.getResult();
            logger.info("Ending  getPublishedNamesForAttachments  ********************");
            return publishedNamesForAttachments;
    }
    
    private boolean generatePackageForUnPublishingComments(ArrayList<Number> commIds, Map <Number, ArrayList<String>> publishedNamesForAttachments, 
                                                           Number fileNumId, String fileTypeFileNumber,
                                                           String downloadLocation, String subDir, String subDirName){
        
        logger.info("Starting   generatePackageForUnPublishingComments  ********************");
        String updatedFileNum=fileTypeFileNumber.replaceAll("-", "").trim();   //we did not send it as  parameter because  too many parameters 
        updatedFileNum=StringUtils.lowerCase(updatedFileNum);
        updatedFileNum=CllUtils.removeSpecialCharsFromFileFolderName(updatedFileNum);
        if( null == updatedFileNum){
                    return false;
        }
        logger.info("updatedFileNum  after removing  special characters *************** is : " +updatedFileNum);  
        ArrayList<String> fileNamesForWupdateFile=new ArrayList<String>();
        String htmlFileNameForComment="";
        try {
                for(Number commId:commIds){
                    
                        //htmlFileNameForComment=updatedFileNum+"-"+commId+".htm"; 
                        //fileNamesForWupdateFile.add(htmlFileNameForComment);
                        ArrayList<String>  attachments = new ArrayList<String>();
                        attachments = publishedNamesForAttachments.get(commId);  
                        if(null == attachments || attachments.size() > 1 || attachments.size() ==0){ 
                               htmlFileNameForComment=updatedFileNum+"-"+commId+".htm"; 
                               fileNamesForWupdateFile.add(htmlFileNameForComment);
                               if(null != attachments ){
                                   logger.info("Number of attachments  is "+attachments.size());
                               }
                               if(null != attachments && attachments.size() > 0 ){  
                                     for(String s:attachments){
                                        fileNamesForWupdateFile.add(s);
                                   }
                               } 
                               
                        }else if (attachments.size()==1){    //if  one attachment,  link should point to this attachment
                                  fileNamesForWupdateFile.add(attachments.get(0)); 
                        } 
                     
                } 
        }catch(Exception e){
            e.printStackTrace();
            return false;  
        }
        fileTypeFileNumber=CllUtils.removeSpecialCharsFromFileFolderName(fileTypeFileNumber);
        if( null == fileTypeFileNumber){
            return false;
        }
        logger.info("fileTypeFileNumber after removing  special characters *************** is : " +fileTypeFileNumber); 
        boolean flag =PackageUtils.createWUpdateFile(subDir, fileTypeFileNumber, fileNamesForWupdateFile, false); // subdir - is entire path
                                                                                                                  //  with no special characters 
        if(!flag){
           logger.info(" Error creating  wupdate file for  unpublishing comments *****************"); 
           showPopupErrorMsg(rb.getString("COMMENTLIST_ERROR_CREATING_WUPDATE_FOR_COMMENTS"));  
           return false;  
        }  
        
        String zipFileName=PackageUtils.createCommentLetterZIP(downloadLocation,subDirName); //downloadLocation is ../cas_documents/cll_packaging
        if(null ==zipFileName){
             logger.info(" Error   generating  zip file for Unpublishing comments  *****************"); 
             showPopupErrorMsg(rb.getString("COMMENTLIST_ERROR_GENERATING_ZIPFLLE_FOR_UNPUB_COMMENTS"));  
             return false;  
        }
        
        //commit the pkg in  database and in UCM
         flag=uploadZipToUCM(downloadLocation, zipFileName,fileNumId, false);
         if(!flag){
            logger.info(" Error checking in  unpublishing package zip file into UCM and in database *****************"); 
            showPopupErrorMsg(rb.getString("COMMENTLIST_ERROR_CHECKING_ZIPFLLE_FOR_COMMENTS"));  
            return false;  
        }
        logger.info("Ending  generatePackageForUnPublishingComments  ********************");
        return true;                                                      
                                
    }
    
    private boolean uploadZipToUCM(String dir, String fileName, Number fileNumberId, boolean isPublish) {
        logger.info ("Starting uploadZipToUCM   ******************************  ");
        try {
            File newFile = new File(dir, fileName);
            InputStream inputStream = new FileInputStream(newFile);
            logger.info("File Length : " + newFile.length());
            byte[] byteArrayFile = convertInputStreamToByeArray(inputStream);
            int fileSize=byteArrayFile.length/(1024 *1024);
            logger.info("Comments zip  file byte array length : " + byteArrayFile.length);
            logger.info("  The Comments zip  file size  is  in MB  ***************** " +fileSize);
            
            String username = SecurityUtils.getUserNameFromSessionOrContext();
            Map<String, String> props = getApplicationProperties();  
            
            //Prepararing document for UCM
            Document doc= new Document();
            doc.setByteArrayFile(byteArrayFile);
            doc.setFileName(fileName);
            doc.setFileLength(newFile.length()); 
            doc.setCaseId(fileNumberId.toString());
            doc.setModuleName(SharedCompConstants.CLL_PKG_MODULE); //CLLPKG 
            doc.setAppName(props.get("APP_NAME_CLL"));
            doc.setDocAccount(props.get("ACCOUNT_NAME_CLL_RWD"));
            
            RIDCService ridService = new RIDCService(username, props); 
            Document upDocInfo =  ridService.uploadDocument(doc);  
            logger.info("ZIP File Checked In. Id = " + upDocInfo.getDocId());
            
            //Getting username
//            String username = ADFContext.getCurrent().getSecurityContext().getUserName(); 
            logger.info("Current logged in username : " + username);
            
            //Adding to attachments
            List<Map> attachments = new ArrayList<Map>(); 
            Map attachmentmap = new HashMap();
            attachmentmap.put("CaseId", fileNumberId);
            attachmentmap.put("DocumentTypeID", getDocumentType() );   //document type id 
            attachmentmap.put("OtherDocTypeDesc", null);   //even if it is NULL ************we should be fine 
            attachmentmap.put("DocName", fileName);  
            attachmentmap.put("ModuleName", doc.getModuleName()); 
            attachmentmap.put("Author", username);
            attachmentmap.put("UcmId", upDocInfo.getDocId());
            if (isPublish){
                attachmentmap.put("PubPkgFlag", "Y");    
            } else {
                attachmentmap.put("PubPkgFlag", "N");                    
            }
            
            attachments.add(attachmentmap); 
            
            //commit the  attachments in  attachment table
            if (attachments.size() > 0) {
                OperationBinding operation = ADFUtils.findOperation("addAttachments"); 
                operation.getParamsMap().put("attachments", attachments);
                operation.execute(); 
                if (operation.getErrors().isEmpty()){
                    if (!ADFUtils.performBindingAction("SharedCompCommit")){
                       // throw new RuntimeException("Error on commit share components.");
                        return false;
                    }
                } else {
                    //throw new RuntimeException("Error on inserting a new attachment row for Zip file.");
                    return false;
                }
            } 
            
            inputStream.close();
            
        } catch (FileNotFoundException e) {
            logger.severe(rb.getString("FORMLETTERLIST_PACKAGE_FILE_NOTFOUND_ERORR_MSG"), e);
            return false;
        } catch (IdcClientException e) {
            logger.severe(rb.getString("RIDCSERVICE_LOAD_UCM_METADATA_ERROR_MSG"), e);
           // throw new RuntimeException(e);
           return false;
        } catch (IOException e) {
            logger.severe(rb.getString("PACKAGE_FILE_CLOSING_STREAM_ERROR_MSG"), e);
           //throw new RuntimeException(e);
            return false;
        } catch (Exception e) {
            logger.severe(rb.getString("Error during the process of uploading ZIP file"), e);
            return false;
        }
        
        logger.info ("Ending uploadZipToUCM   ******************************  ");
        return true;
    }
    
    public byte[] convertInputStreamToByeArray(InputStream is){ 
      ByteArrayOutputStream bos = new ByteArrayOutputStream();  
      BufferedInputStream bIn = new BufferedInputStream(is);
        byte[] buf = new byte[1024];
        try {
            for (int readNum; (readNum = bIn.read(buf)) != -1;) {
                bos.write(buf, 0, readNum); //no doubt here is 0
                //Writes len bytes from the specified byte array starting at offset off to this byte array output stream.
                logger.finest("Read  " + readNum + " bytes,"); 
            }
            byte[] bytes = bos.toByteArray();
            return bytes;
        } catch (IOException ex) {
            logger.info(ex.toString());
             return null;
        }   
        
    }
    
    private Number getDocumentType() {
        Number docTypeId = new Number();
        OperationBinding findDocTypeId = ADFUtils.findOperation("getDocumentTypeId");
        findDocTypeId.getParamsMap().put("code", SharedCompConstants.DOC_TYPE_PUBLISHING_PACKAGE_CODE);
        findDocTypeId.execute();
        if (findDocTypeId.getErrors().isEmpty()){
            docTypeId = (Number)findDocTypeId.getResult();
        }
        return docTypeId;
    }
    
    private String getCommDelemitedCommIds(ArrayList<Number> commIds){
        String commIdsStr=null;
        for(Number id:commIds) {
            if(null == commIdsStr){
                commIdsStr="("+id.toString();
            }else{
                commIdsStr=commIdsStr+","+id.toString();
            }
        }
        commIdsStr=commIdsStr+")";
        return commIdsStr;
    }

    public void setPendingChangeWarnPP(RichPopup pendingChangeWarnPP) {
        this.pendingChangeWarnPP = pendingChangeWarnPP;
    }

    public RichPopup getPendingChangeWarnPP() {
        return pendingChangeWarnPP;
    }
    
    /**If any pending changes in Comment Letter,  it will be commit the changes
     *
     * @return
     */
    public String savePendingAction() {  
             logger.info("Starting   savePendingAction   **************************");
             this.pendingChangeWarnPP.hide(); 
             String commentTypeCode= (String)ADFUtils.getBoundAttributeValue("CommentTypeCode");
             if(commentTypeCode != null && commentTypeCode.equals(getFormLetterTypeCode())   ) { 
                 Integer formLetSubType= (Integer)ADFUtils.getBoundAttributeValue("CllFormLetterSubType");
                 if(formLetSubType == null ||formLetSubType.intValue()==0 ) { 
                         String msg=rb.getString("VIEWCOMMENTDETAILS_COMMENT_TYPE_CHANGED_TO_FORM_LETTER");
                         JSFUtils.addFacesErrorMessage(msg);  
                         logger.info("Ending   savePendingAction   **************************");
                         return null;  
                 }
                 
             } 
             if(!saveComment(false)) {   //if saving comment log fails,  stay back in the current comment log
                 logger.info("Ending   savePendingAction   **************************");
                 return "";
             }
             Map<String, Object> viewScope = AdfFacesContext.getCurrentInstance().getViewScope();
             ViewStateCommentDetails viewStateCommentDetails = 
                         (ViewStateCommentDetails)viewScope.get("viewStateCommentDetails");
             if(viewStateCommentDetails.getNextORPrevFlag().equalsIgnoreCase(CllConstants.NEXT_COMMENT)  ){
                 logger.info("Ending   savePendingAction   **************************");
                 return navigateToNextRecord();
             }else{
                   logger.info("Ending   savePendingAction   **************************");
                   return navigateToPrevRecord();
            } 
            
            
     }
    
    /**If any pending changes in Comment Letter,  it will be rollback the changes and goes to next comment
     *
     * @return
     */
   /* public String noSavePendingAction() {
               logger.info("Starting   noSavePendingAction   **************************");
               this.pendingChangeWarnPP.hide();
               String commentTypeCode= (String)ADFUtils.getBoundAttributeValue("CommentTypeCode");
               if(commentTypeCode != null && !commentTypeCode.equals(getFormLetterTypeCode())){
                   addFileNumCmdImageLink.setDisabled(false);
                   editFileNumCmdImageLink.setDisabled(false);
               }
              //before rollback get the current row key
               DCIteratorBinding commListIterator = ADFUtils.findIterator("CllCommentsListROView1Iterator");
               CllCommentsListROViewRowImpl commentsListRow = (CllCommentsListROViewRowImpl)commListIterator.getCurrentRow();
               //DBSequence commentIDDBSeq = (DBSequence)commentsListRow.getCllCommDetId();
               //Number commId=commentIDDBSeq.getSequenceNumber();
               Number commId=commentsListRow.getCllCommDetId();
               logger.info("Current row in the list is  :" +commId);
               String currentRowKey = commListIterator.getCurrentRowKeyString();
               if(ADFUtils.doRollback()) {
                   commListIterator.setCurrentRowWithKeyValue(currentRowKey);

                   AdfFacesContext.getCurrentInstance().addPartialTarget(saveApproveButton);
                   ViewStateCommentDetails viewStateCommentDetails =
                               (ViewStateCommentDetails)AdfFacesContext.getCurrentInstance().getViewScope().get("viewStateCommentDetails");

                   if(viewStateCommentDetails.getNextORPrevFlag().equalsIgnoreCase(CllConstants.NEXT_COMMENT)  ){
                       logger.info("Ending   noSavePendingAction   **************************");
                       return navigateToNextRecord();
                   }else{
                       logger.info("Ending   noSavePendingAction   **************************");
                       return navigateToPrevRecord();
                   }
                }else {  //rollback fails
                     String msg=rb.getString("VIEWCOMMENTDETAILS_UNABLE_TOSAVE_COMMENTDETAILS_MSG");
                     JSFUtils.addFacesErrorMessage(msg);
                     logger.info("Ending   noSavePendingAction   **************************");
                     return null;
               }

     } */

    public String noSavePendingAction() {
        logger.info("Starting   noSavePendingAction   **************************");
        this.pendingChangeWarnPP.hide();
        DCIteratorBinding commListIterator =    ADFUtils.findIterator("CllCommentsListROView1Iterator");
        CllCommentsListROViewRowImpl currentCommListRow = (CllCommentsListROViewRowImpl)commListIterator.getCurrentRow();
        String currentRowKeyStr = commListIterator.getCurrentRowKeyString();
        int currentRowIndex = commListIterator.getCurrentRowIndexInRange(); 
        logger.info("Current row in the list is  :" +currentCommListRow.getCllCommDetId()); 
        Key parentKey = commListIterator.getCurrentRow().getKey();  

        if (ADFUtils.doRollback()) {
            commListIterator.executeQuery(); 
            Row row = commListIterator.findRowByKeyString(currentRowKeyStr);
            logger.info("Comment id is " + row.getAttribute("CllCommDetId"));  
            commListIterator.setCurrentRowWithKey(parentKey.toStringFormat(true));
            commListIterator.setCurrentRowIndexInRange(currentRowIndex);
            getCommentLogDataCntrlTrx().setClearCacheOnRollback(false);

            String commentTypeCode =
                (String)ADFUtils.getBoundAttributeValue("CommentTypeCode");
            if (commentTypeCode != null &&
                !commentTypeCode.equals(getFormLetterTypeCode())) {
                addFileNumCmdImageLink.setDisabled(false);
                editFileNumCmdImageLink.setDisabled(false);
            }
            AdfFacesContext.getCurrentInstance().addPartialTarget(saveApproveButton);
            Map<String, Object> viewScope = AdfFacesContext.getCurrentInstance().getViewScope();
            ViewStateCommentDetails viewStateCommentDetails =
                (ViewStateCommentDetails)viewScope.get("viewStateCommentDetails");

            if (viewStateCommentDetails.getNextORPrevFlag().equalsIgnoreCase(CllConstants.NEXT_COMMENT)) {
                logger.info("Ending   noSavePendingAction   **************************");
                return navigateToNextRecord();
            } else {
                logger.info("Ending   noSavePendingAction   **************************");
                return navigateToPrevRecord();
            }
        } else { //rollback fails
            String msg =
                rb.getString("VIEWCOMMENTDETAILS_UNABLE_TOSAVE_COMMENTDETAILS_MSG");
            JSFUtils.addFacesErrorMessage(msg);
            logger.info("Ending   noSavePendingAction   **************************");
            return null;
        }

    }
    
    /**If any pending changes in Comment Letter,  control stays back in  current comment
     *
     * @return control flow name or action name   
     */
    public String cancelPendingAction() { 
        this.pendingChangeWarnPP.hide();
        return null;
     }

    public void setUnArchiveButton(RichButton unArchiveButton) {
        this.unArchiveButton = unArchiveButton;
    }

    public RichButton getUnArchiveButton() {
        return unArchiveButton;
    }

    public void setPopupUnArchive(RichPopup popupUnArchive) {
        this.popupUnArchive = popupUnArchive;
    }

    public RichPopup getPopupUnArchive() {
        return popupUnArchive;
    }

    public void setAssociatedFileNumbersTable(RichTable associatedFileNumbersTable) {
        this.associatedFileNumbersTable = associatedFileNumbersTable;
    }

    public RichTable getAssociatedFileNumbersTable() {
        return associatedFileNumbersTable;
    }

    public void setStatusPanelGroup(RichPanelGroupLayout statusPanelGroup) {
        this.statusPanelGroup = statusPanelGroup;
    }

    public RichPanelGroupLayout getStatusPanelGroup() {
        return statusPanelGroup;
    }

    public void setUnPublishCommandBtn(RichButton unPublishCommandBtn) {
        this.unPublishCommandBtn = unPublishCommandBtn;
    }

    public RichButton getUnPublishCommandBtn() {
        return unPublishCommandBtn;
    }

    public void setAfMessagesMainWindow(RichMessages afMessagesMainWindow) {
        this.afMessagesMainWindow = afMessagesMainWindow;
    }

    public RichMessages getAfMessagesMainWindow() {
        return afMessagesMainWindow;
    }
    private void updateCommentDetId(){
           DBSequence id=(DBSequence)ADFUtils.getBoundAttributeValue("CllCommDetId");
           if(id != null) {
              Number commId = id.getSequenceNumber(); 
              logger.info("Current  comment  id  is  **********************" + commId);
               //show indicator if there is any attachment in the comment
               Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
               CommentDetails commDetBean =
                       (CommentDetails)pageFlowScope.get("commentDetails"); 
               if (null != commDetBean) {
                       commDetBean.setReturnCommDetId(commId);
                       ADFUtils.markScopeDirty(pageFlowScope);
               }
           }
        }
    
    /*public static void main(String[] args) {
        String removeChars="[\\/|:*?\"<>]";
        String myString="OtherFile#   /|:*?\"<>    ";
        myString = myString.replaceAll(removeChars, "");
        System.out.println(myString);

    }*/

    public String removeFileNumAction( ) {
            // Add event code here...
            DCIteratorBinding fileNumItr = ADFUtils.findIterator("CllFilenumberCommDetailsView1Iterator"); 
            Row row= fileNumItr.getCurrentRow();
            if(null == row) {
                 return null ;
            }
            
           //if  comment type is form letter  change the type back to comment ?
            
           // String currentTypeCode = (String)ADFUtils.getBoundAttributeValue("CommentTypeCode");
           //logger.info("currentTypeOtherDesc: "+ currentTypeCode);
           RichPopup.PopupHints hints=new RichPopup.PopupHints();
          // hints.add(RichPopup.PopupHints.HintTypes.HINT_ALIGN_ID,dispositionTypeOthInputText.getClientId(FacesContext.getCurrentInstance()));
           this.popupDelFilNum.show(hints);
           return null;
           
           
          /* fileNumItr.removeCurrentRow();
           ADFUtils.refreshIterator("CllFilenumberCommDetailsView1Iterator");
      
           ADFUtils.refreshIterator("CllFilenumCommDetView1Iterator");
           AdfFacesContext.getCurrentInstance().addPartialTarget( associatedFileNumbersTable); */
            
        
      }
    
    /**
     * Popup dialog listener that removes a file number from a comment   if "YES" was clicked in popup.
     *
     */    
    public void deleteFileNumberDialogListener(DialogEvent dialogEvent){
        logger.info("Starting deleteFileNumberDialogListener"); 
        boolean invalidData=false;
        DCIteratorBinding fileNumItr = ADFUtils.findIterator("CllFilenumberCommDetailsView1Iterator"); 
        Row row= fileNumItr.getCurrentRow();
        if(null == row) { 
             return  ;
        } 
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.yes){
            fileNumItr.removeCurrentRow(); 
            saveComment(false) ;
            
            JSFUtils.addFacesInformationMessage(rb.getString( "VIEWCOMMENTDETAILS_DELETE_FILENUM_SAVE_MSG"));   
            
        }
        logger.info("Ending deleteFileNumberDialogListener"); 
    }
    

    public void setRemoveFileNumButton(RichButton removeFileNumButton) {
        this.removeFileNumButton = removeFileNumButton;
    }

    public RichButton getRemoveFileNumButton() {
        return removeFileNumButton;
    }

    public void setPopupDelFilNum(RichPopup popupDelFilNum) {
        this.popupDelFilNum = popupDelFilNum;
    }

    public RichPopup getPopupDelFilNum() {
        return popupDelFilNum;
    }
    
    public boolean getSeqNotNull(){
        boolean flag=false;
        DCIteratorBinding fileNumItr = ADFUtils.findIterator("CllFilenumberCommDetailsView1Iterator"); 
        Row row= fileNumItr.getCurrentRow();
        if(null == row) {
             flag= false ;
        }
        if(null != row.getAttribute("CommentSeqNumber")){
            flag= true;
        }
        return flag;
         
    }


    public void setMasterFileNumDTO(ReturnMasterFileNumberDTO masterFileNumDTO) {
        this.masterFileNumDTO = masterFileNumDTO;
    }

    public ReturnMasterFileNumberDTO getMasterFileNumDTO() {
        return masterFileNumDTO;
    }

    public void setRepIsThirdParty(RichSelectBooleanCheckbox repIsThirdParty) {
        this.repIsThirdParty = repIsThirdParty;
    }

    public RichSelectBooleanCheckbox getRepIsThirdParty() {
        return repIsThirdParty;
    }

    public void setRepIsAffiliated(RichSelectBooleanCheckbox repIsAffiliated) {
        this.repIsAffiliated = repIsAffiliated;
    }

    public RichSelectBooleanCheckbox getRepIsAffiliated() {
        return repIsAffiliated;
    }
}
