package gov.sec.cll.view.beans;

import gov.sec.cas.sharedcomponents.view.dto.SubmitterDTO;
import gov.sec.cll.model.adfbc.views.CllFileNumberViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumRelFrViewRowImpl;
import gov.sec.cll.sharedcomponents.view.dto.ReleaseNumberDTO;
import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;

import gov.sec.cll.sharedcomponents.view.utils.JSFUtils;

import gov.sec.cll.view.utils.CllConstants;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.ResourceBundle;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import javax.faces.event.ValueChangeEvent;

import oracle.adf.model.binding.DCIteratorBinding;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.input.RichSelectOneChoice;

import oracle.adf.view.rich.component.rich.nav.RichButton;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.binding.OperationBinding;

import oracle.jbo.RowSetIterator;
import oracle.jbo.Transaction;
import oracle.jbo.server.EntityImpl;
import oracle.jbo.server.ViewRowImpl;

import org.apache.commons.lang.StringUtils;
import org.apache.myfaces.trinidad.event.ReturnEvent;

public class CreateFileNumberBean {
    private RichSelectOneChoice fileNumTypeBind;
    private RichInputText fileNumberBind;
    private RichTable filenumRelTableBind;
    private RichTable filenumAttyTblBind;
    private String exitAction;
    private RichPopup unSavedDataWarnPp;
    private RichButton cbSearch;
    private static ADFLogger logger = ADFLogger.createADFLogger(CreateFileNumberBean.class);
    private static final ResourceBundle rb =
                ResourceBundle.getBundle(CllConstants.RESOURCE_BUNDLE_LOCATION);

    public CreateFileNumberBean() {
    }

    public void saveActionLstnr(ActionEvent actionEvent) {
        String fileNumber = (String)ADFUtils.evaluateEL("#{bindings.FileNumber.inputValue}");
        fileNumber = StringUtils.trimToNull(fileNumber);
        ADFUtils.setBoundAttributeValue("FileNumber", fileNumber);

        DCIteratorBinding fileNumberIter = ADFUtils.findIterator("CllFileNumberView1Iterator");
        CllFileNumberViewRowImpl fileNumRow = (CllFileNumberViewRowImpl)fileNumberIter.getCurrentRow();
        String code = fileNumRow.getCode();
        if ("CLL".equals(code) || (null != fileNumber && !"CLL".equals(code))) {
            if (existIteratorPendingChanges("CllFileNumberView1Iterator")) {
                OperationBinding dupChkOpb = ADFUtils.findOperation("checkDuplicateFileNumber");
                dupChkOpb.execute();
                if (null != dupChkOpb.getResult() && dupChkOpb.getResult().equals(false)) {
                    ADFUtils.findOperation("insertFileNumber").execute();
                    OperationBinding opb = ADFUtils.findOperation("commitTransaction");
                    opb.execute();
                    if (opb.getResult() != null && opb.getResult().equals(true)) {
                        fileNumTypeBind.setDisabled(true);
                        cbSearch.setDisabled(true);
                        AdfFacesContext.getCurrentInstance().addPartialTarget(fileNumTypeBind);
                        if (!"CLL".equals(code)){
                            fileNumberBind.setDisabled(true);
                            cbSearch.setDisabled(true);
                        }
                        AdfFacesContext.getCurrentInstance().addPartialTarget(fileNumberBind);
                        AdfFacesContext.getCurrentInstance().addPartialTarget(cbSearch);
                        AdfFacesContext.getCurrentInstance().addPartialTarget(filenumRelTableBind);
                        AdfFacesContext.getCurrentInstance().addPartialTarget(filenumAttyTblBind);
                        ADFUtils.findOperation("executeFileNUmberQueue").execute();
                        JSFUtils.addFacesInformationMessage("File Number Created Successfully.");
                    } else {
                        JSFUtils.addFacesInformationMessage("Unable to create File Number. Please contact System Administrator");
                    }
                } else {
                    JSFUtils.addFacesErrorMessage("File Number already exists.");
                }
            } else {
                if (existIteratorPendingChanges("CllFilenumRelFrView1Iterator") ||
                    existIteratorPendingChanges("CllFilenumAttyView1Iterator"))
                    ADFUtils.findOperation("insertFileNumber").execute();
                OperationBinding opb = ADFUtils.findOperation("commitTransaction");
                opb.execute();
                if (opb.getResult() != null && opb.getResult().equals(true)) {
                    JSFUtils.addFacesInformationMessage("Changes Saved Successfully");
                }
            }
        } else {
            JSFUtils.addFacesErrorMessage("Please Enter File Number.");
        }
    }

    private boolean existIteratorPendingChanges(final String iteratorName) {
        boolean changesExist = false;
        DCIteratorBinding iterator = ADFUtils.findIterator(iteratorName);
        ViewRowImpl currentRow = (ViewRowImpl)iterator.getCurrentRow();
        if (currentRow != null) {
            EntityImpl entityImpl = currentRow.getEntity(0);
            byte entityState = entityImpl.getEntityState();
            logger.info("Entity State = " + entityState);
            if (EntityImpl.STATUS_NEW == entityState) {
               // JSFUtils.addFacesErrorMessage("Pending changes exist. Save or cancel changes.");
                changesExist = true;
            } else {
                logger.info("Changes do not exist in the iterator .."+iteratorName);
                changesExist = false;
            }
        }
        return changesExist;
    }

    public void setFileNumTypeBind(RichSelectOneChoice fileNumTypeBind) {
        this.fileNumTypeBind = fileNumTypeBind;
    }

    public RichSelectOneChoice getFileNumTypeBind() {
        return fileNumTypeBind;
    }

    public void searchAddReturnListener(ReturnEvent returnEvent) {
        Map paramsMap = new HashMap();
        FileNumberBean filenumberBean = (FileNumberBean)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("FileNumberBean");
        List<SubmitterDTO> newSubmitters = filenumberBean.getNewSubmitters();
            for (SubmitterDTO submitter : newSubmitters) {
                    paramsMap.put("FIRST_NAME", submitter.getFirstName());
                    paramsMap.put("LAST_NAME", submitter.getLastName());
                    paramsMap.put("EMAIL", submitter.getEmail());
                    paramsMap.put("PHONE_NUMBER", submitter.getPhoneNumber());
                    paramsMap.put("SUFFIX", submitter.getSuffix());
            OperationBinding opb = ADFUtils.findOperation("addAttorneytoFile");
            opb.getParamsMap().put("paramsMap", paramsMap);
            opb.execute();
            }
    }
    
    /**
     * Searches for release numbers by the entered file number code and file number
     * It opens a widget which shows the search results.
     * File number code and file number values are passed to the widget which invokes 
     * Release Log web Service to search for the release log associated for the file number
     *
     * @return  Navigation outcome to opens search release numbers widget
     */
    public String searchRelNumAction() {
        String fileNumberCode = (String)JSFUtils.evaluateEL("#{bindings.FilenumTypeId.selectedValue.attributeValues[1]}");
        logger.info("Selected File Number Code : " + fileNumberCode);
        String fileNumber = (String)ADFUtils.getBoundAttributeValue("FileNumber");
        logger.info("Entered File Number : " + fileNumber);
        if (StringUtils.trimToEmpty(fileNumberCode).isEmpty() || StringUtils.trimToEmpty(fileNumber).isEmpty()) {
            JSFUtils.addFacesErrorMessage(rb.getString("CREATEFILENUMBER_SEARCH_RELEASENUMBERS_VALIDATION_MSG")); 
            return null;
        }
        //Passing the needed Widget TF input parameters to request scope
        Map requestScope = ADFContext.getCurrent().getRequestScope();
        requestScope.put("fileNumberCode", fileNumberCode);
        requestScope.put("fileNumber", fileNumber.trim());
        return "searchRelNums";
    }

    /**
     * Adds the selected relase number from widget to the File Number view.
     * Methods runs after the widget is closed. Widget passes the list of relase numbers 
     * to pageflowscope managed bean, and from there, data is add to table
     * 
     * @param returnEvent
     */
    public void searchRelNumsReturnListener(ReturnEvent returnEvent) {
        logger.info("Returned from Search Release Numbers widget...");
        FileNumberBean bean =
            (FileNumberBean)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("FileNumberBean");
        logger.info("Adding # of Release Numbers : " + bean.getNewReleaseNumbers().size());
        if (bean.getNewReleaseNumbers().size() > 0){
            DCIteratorBinding dciter = ADFUtils.findIterator("CllFilenumRelFrView1Iterator");
            RowSetIterator rsi = dciter.getRowSetIterator();
            for (ReleaseNumberDTO relNumDTO : bean.getNewReleaseNumbers()){
                CllFilenumRelFrViewRowImpl newRow = (CllFilenumRelFrViewRowImpl)rsi.createRow();
                newRow.setRelnum(relNumDTO.getRelNumber());
                newRow.setRellogId(relNumDTO.getRellogId());
                if (relNumDTO.getFrPubDate() != null){
                    newRow.setFrPubDate(ADFUtils.getJboDate(relNumDTO.getFrPubDate()));
                }
                rsi.insertRow(newRow);
            }
            ADFUtils.addPartialTarget(filenumRelTableBind);
        }
    }

    public void setFileNumberBind(RichInputText fileNumberBind) {
        this.fileNumberBind = fileNumberBind;
    }

    public RichInputText getFileNumberBind() {
        return fileNumberBind;
    }

    public void fileTypeValueChgLstnr(ValueChangeEvent valueChangeEvent) {
        valueChangeEvent.getComponent().processUpdates(FacesContext.getCurrentInstance());
        DCIteratorBinding fileNumberIter =  ADFUtils.findIterator("CllFileNumberView1Iterator");
        CllFileNumberViewRowImpl fileNumRow = (CllFileNumberViewRowImpl)fileNumberIter.getCurrentRow();
        String fileTypeNum = fileNumRow.getCode();
        if(fileTypeNum !=  null && !"CLL".equals(fileTypeNum)){
            fileNumberBind.setDisabled(false);
            cbSearch.setDisabled(false);
        }else{
            String fileNumber = (String)ADFUtils.evaluateEL("#{bindings.FileNumber.inputValue}");
            if(null != fileNumber)
                ADFUtils.setEL("#{bindings.FileNumber.inputValue}", null);
            fileNumberBind.setDisabled(true);
            cbSearch.setDisabled(true);
        }
        AdfFacesContext.getCurrentInstance().addPartialTarget(cbSearch);
        AdfFacesContext.getCurrentInstance().addPartialTarget(fileNumberBind);
    }

    public void createRelActionLstnr(ActionEvent actionEvent) {
        ADFUtils.findOperation("createReleaseNumber").execute();
    }

    public void setFilenumRelTableBind(RichTable filenumRelTableBind) {
        this.filenumRelTableBind = filenumRelTableBind;
    }

    public RichTable getFilenumRelTableBind() {
        return filenumRelTableBind;
    }

    public void deleteRelActionLstnr(ActionEvent actionEvent) {
        ADFUtils.findOperation("deleteReleaseNumber").execute();
    }

    public void deleteAttyActionLstnr(ActionEvent actionEvent) {
        ADFUtils.findOperation("deleteAttorneyDetails").execute();
    }

    public void setFilenumAttyTblBind(RichTable filenumAttyTblBind) {
        this.filenumAttyTblBind = filenumAttyTblBind;
    }

    public RichTable getFilenumAttyTblBind() {
        return filenumAttyTblBind;
    }

    public void exitActionLstnr(ActionEvent actionEvent) {
        if(this.pendingChangesExist()){
        this.getUnSavedDataWarnPp().show(new RichPopup.PopupHints());
        }else{
            this.setExitAction("exit");
        }
    }
    
    private Transaction getCommentLogDataCntrlTrx(){
        return ADFUtils.getApplicationModuleForDataControl("CommentLogAppModuleDataControl").getTransaction();
    }
    
    private boolean pendingChangesExist(){
        return this.getCommentLogDataCntrlTrx().isDirty();
    }

    public void setExitAction(String exitAction) {
        this.exitAction = exitAction;
    }

    public String getExitAction() {
        return exitAction;
    }

    public void setUnSavedDataWarnPp(RichPopup unSavedDataWarnPp) {
        this.unSavedDataWarnPp = unSavedDataWarnPp;
    }

    public RichPopup getUnSavedDataWarnPp() {
        return unSavedDataWarnPp;
    }

    public void NoActionLstnr(ActionEvent actionEvent) {
        this.getUnSavedDataWarnPp().hide();
    }

    public void setCbSearch(RichButton cbSearch) {
        this.cbSearch = cbSearch;
    }

    public RichButton getCbSearch() {
        return cbSearch;
    }

}
