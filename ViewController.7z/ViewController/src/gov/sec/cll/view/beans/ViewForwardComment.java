package gov.sec.cll.view.beans;


import gov.sec.cas.common.view.dto.Document;
import gov.sec.cas.common.view.services.RIDCService;
import gov.sec.cas.common.view.utils.SecurityUtils;
import gov.sec.cas.sharedcomponents.view.dto.EmailRequestDTO;
import gov.sec.cas.sharedcomponents.view.dto.EmailResponseDTO;
import gov.sec.cas.sharedcomponents.view.dto.SubmitterDTO;
import gov.sec.cas.sharedcomponents.view.utils.NotificationUtils;
import gov.sec.cll.model.adfbc.views.CllCommentDetailsViewRowImpl;
import gov.sec.cll.sharedcomponents.model.adfbc.views.AttachmentViewRowImpl;
import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;
import gov.sec.cll.sharedcomponents.view.utils.JSFUtils;
import gov.sec.cll.view.dto.EmailRecipientDTO;
import gov.sec.cll.view.utils.CllConstants;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.nav.RichButton;
import oracle.adf.view.rich.context.AdfFacesContext;
import oracle.adf.view.rich.event.DialogEvent;

import oracle.binding.OperationBinding;

import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewObject;
import oracle.jbo.domain.Number;

import org.apache.myfaces.trinidad.event.ReturnEvent;
import org.apache.myfaces.trinidad.render.ExtendedRenderKitService;
import org.apache.myfaces.trinidad.util.Service;

public class ViewForwardComment {
    
    private static ADFLogger logger = ADFLogger.createADFLogger(ViewForwardComment.class);
    private static final ResourceBundle rb = ResourceBundle.getBundle(CllConstants.RESOURCE_BUNDLE_LOCATION);
    private RichInputText itSubject;
    private RichInputText itStaffNote;
    private RichInputText itMessage;
    private RichTable tbRecipients;
    private RichTable tbDocuments;
    private RichPopup popupSend;
    private RichPopup popupEmailSent;
    
    private final String CONTENT_TYPE_PARAM = "contentType";
    private final String FILE_NAME_PARAM = "filename";
    private final String FILE_ABSOLUTE_PATH = "fileAbsolutePath";
    private RichButton fileDownloadButton;

    public ViewForwardComment() {
        super();
    }
  

    /**
     * Adds email addresses brought from Search Contact Widget. After email addresses are selected from widget,
     * these are added to Email Recipients UI table.
     * 
     * @param returnEvent
     */
    public void searchReturnListener(ReturnEvent returnEvent) {
        logger.info("Adding email receipients");
        CommentDetails commentDetailsBean =
            (CommentDetails)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("commentDetails");
        List<SubmitterDTO> newRecipients = commentDetailsBean.getNewContacts();
        logger.info("Adding total recipients = " + newRecipients.size());
        List<EmailRecipientDTO> emailRecipienList = commentDetailsBean.getEmailRecipienList();
        for (SubmitterDTO recipient : newRecipients){
            logger.info(String.format("Adding => First Name [%s] Last Name [%s] Email [%s]", recipient.getFirstName(),
                                      recipient.getLastName(), recipient.getEmail()));
            EmailRecipientDTO emailRec = new EmailRecipientDTO();
            emailRec.setFirstName(recipient.getFirstName());
            emailRec.setLastName(recipient.getLastName());
            emailRec.setEmail(recipient.getEmail());
            emailRecipienList.add(emailRec);
        }
        ADFUtils.addPartialTarget(tbRecipients);
    }

    /**
     * Removes a selected email recipient from Email Receipient table.
     * 
     * @param actionEvent
     */
    public void removeActionListener(ActionEvent actionEvent) {
        EmailRecipientDTO selectedEmail = (EmailRecipientDTO)tbRecipients.getSelectedRowData();
        if (selectedEmail != null){
            CommentDetails commentDetailsBean =
                (CommentDetails)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("commentDetails");
            List<EmailRecipientDTO> emailRecipienList = commentDetailsBean.getEmailRecipienList();
            emailRecipienList.remove(selectedEmail);
        }
    }

    /**
     * 1.Sends forward release notification to all email recipients thru Notification Proxy
     * 
     * @param actionEvent
     */
    public void sendActionListener(ActionEvent actionEvent) {
        logger.info("Start .................. sendActionListener ");
        if (isValidEntry()){
            RichPopup.PopupHints hints = new RichPopup.PopupHints();
            popupSend.show(hints);
        }
    }
   
    /**
     * Validates To and Subject before sending notification.
     * 'To' and 'Subject' are required
     * @return
     */
    private boolean isValidEntry(){
        logger.info("Start .................. isValidEntry before forwarding ");
        CommentDetails commentDetailsBean =
            (CommentDetails)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("commentDetails");
        String to = commentDetailsBean.getRecipients();
        String subject = (String)itSubject.getValue();
        logger.info("to => " + to);
        logger.info("subject => " + subject);
        boolean valid = true;
        if (to == null || to.isEmpty() ) {
            logger.info("To has no recipients.");
            valid = false;
            JSFUtils.addFacesErrorMessage(rb.getString("VIEWFORWARDCOMMENT_INVALID_TO_MSG"));
        }
        if (subject == null || subject.isEmpty()) {
            logger.info("Subject has no recipients.");
            valid = false;
            JSFUtils.addFacesErrorMessage(rb.getString("VIEWFORWARDCOMMENT_INVALID_SUBJECT_MSG"));
        }
        logger.info("Entry Validation= " + valid);
        return valid;
    }
    
    /**
     * Dialog listener to confirm sending comment/form letter.
     * Clicking "Ok" from the popup, it will send the notification to attorneys
     * and return to ViewCommentDetails
     * 
     * @param dialogEvent
     */
    public void sendDialogListener(DialogEvent dialogEvent) {
        logger.info("Start ................. sendDialogListener, dialog outcome = " + dialogEvent.getOutcome());
        //Sends Notification
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.yes) {
            sendNotification();
        }
    }

    /**
     * Sends forward comment notification to all email recipients thru Notification Proxy
     *
     */
    private void sendNotification() {
        // Get Notification metadata from application properties table
        try {
            Map props = getApplicationProperties();
            String message = "";
//            String wsdlURL = (String)props.get("NOTIFICATION_WSDL_URL");
//            String nsURI = (String)props.get("NOTIFICATION_QNAME_NAMESPACE_URI");
//            String localPart = (String)props.get("NOTIFICATION_QNAME_LOCALPART");
            String contentBreaker = (String)props.get("NOTIFICATION_CONTENT_BREAKER");
//            logger.info("wsdlURL => " + wsdlURL);
//            logger.info("nsURI => " + nsURI);
//            logger.info("localPart => " + localPart);

            // Get contents of notification
            CommentDetails commentDetailsBean =
                (CommentDetails)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("commentDetails");
            String to = commentDetailsBean.getRecipients();
            String subject = (String)itSubject.getValue();
            if (itStaffNote == null || itStaffNote.getValue() == null || itStaffNote.toString().trim().equals("")) {
                message = (String)itMessage.getValue();
                message = message.replaceAll("\n", "<BR>");
                logger.info("message = " + message);
            } else {
                message =
                        (String)itStaffNote.getValue() + "<BR>" + contentBreaker + "<BR>" + (String)itMessage.getValue();
                message = message.replaceAll("\n", "<BR>");
                logger.info("message = " + message);
            }
            List<String> ucmIdList = getSelectedDocIds();
            logger.info("to => " + to);
            logger.info("subject => " + subject);
            logger.info("message => " + message);
            logger.info("UCM Doc Id List => " + ucmIdList);

            logger.info("Preparing Email...");
            EmailRequestDTO request = new EmailRequestDTO();
            // Assign To
            request.setToEmailAddress(to);
            // Assisn Subject
            if (subject != null) {
                request.setSubject(subject);
            } else {
                subject = "";
            }
            // Assign Message
            if (message != null) {
                request.setBody(message);
            } else {
                message = "";
            }
            //Assign Attachments
            request.setDocIdList(ucmIdList);

            logger.info("Sending Email....");
            // Send Email

//            EmailResponseDTO response = wrapper.sendEmailNotification(request);
            NotificationUtils notifUtils = new NotificationUtils();
            EmailResponseDTO response = notifUtils.sendEmail(request);
            logger.info("Email was sent....");

            logger.info("Response Status = " + response.getStatus());
            if (response.getStatus().equalsIgnoreCase(CllConstants.PROXY_STATUS_SUCCESS)) {
                RichPopup.PopupHints hints = new RichPopup.PopupHints();
                updateForwardedStatus();
                popupEmailSent.show(hints);
            } else {
                JSFUtils.addFacesErrorMessage(rb.getString("VIEWFORWARDCOMMENT_NOTIFICATION_ERROR"));
                logger.severe("ERROR. Response Fault Info = " + response.getFaultInfo());
            }
        } catch (Exception e) {
            logger.severe(rb.getString("VIEWFORWARDCOMMENT_NOTIFICATION_ERROR"), e);
            JSFUtils.addFacesErrorMessage(rb.getString("VIEWFORWARDCOMMENT_NOTIFICATION_ERROR"));
        }
    }
    
    
    /** Prepares viewForwardComment
     *
     */
    public void updateForwardedStatus() {
        logger.info("START... updateForwardedStatus");
        String msg = "";
        // Get whom forwarded to
        CommentDetails commentDetailsBean = (CommentDetails)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("commentDetails");
        String to = commentDetailsBean.getForwardedTo();
        
        // Of Form Letter Type
        if(ADFUtils.getBoundAttributeValue("CllFormLetterId") != null ) {
            Number formLetterId = (Number)ADFUtils.getBoundAttributeValue("CllFormLetterId");
            try {
                OperationBinding op = ADFUtils.findOperation("retrieveCommDetFormLetter");
                op.getParamsMap().put("parameter_name", formLetterId);
                op.execute();
            }catch (JboException e){
                msg=rb.getString("VIEWFORWARDCOMMENT_UNABLETO_RETRIEVE_FORMLETTERLIST");
                JSFUtils.addFacesErrorMessage(msg);
            }
            if (msg.isEmpty()) { // if no exception     
                DCIteratorBinding commDetIter2 = ADFUtils.findIterator("CllCommentDetailsView2Iterator");
                RowSetIterator rsi = commDetIter2.getViewObject().createRowSetIterator(null);
                rsi.reset();
                // Populate comment(s0 with forwardDate & forwarded_to
                while (rsi.hasNext()){
                    CllCommentDetailsViewRowImpl row = (CllCommentDetailsViewRowImpl)rsi.next();
                    row.setForwardDate(ADFUtils.getCurrentJboDate());
                    row.setForwardedTo(to);  
                }
                rsi.closeRowSetIterator();
                // Populate formLetter table with forwardDate
                DCIteratorBinding formLetterIter = ADFUtils.findIterator("CllFormLetterView1Iterator");
                Row formLetterRow = formLetterIter.getCurrentRow();
                formLetterRow.setAttribute("ForwardDate", ADFUtils.getCurrentJboDate());
                logger.info("Updated Form Letter");
            }
        } else {    
          // Of Comment Log type  
                DCIteratorBinding commDetIter1 = ADFUtils.findIterator("CllCommentDetailsView1Iterator");
                Row commDetRow = commDetIter1.getCurrentRow();
                commDetRow.setAttribute("ForwardDate", ADFUtils.getCurrentJboDate());
                commDetRow.setAttribute("ForwardedTo", to);
                logger.info("Updated Comment");
        }
        Boolean committed = ADFUtils.doCommit();
        logger.info("UpdateForwardedStatus committed = " + committed);
    }
     
     
    /**
     * Dialog listener for the popup dialog that confirms the Notification was sent.
     * Clicking "Ok" from the popup, it will navigates to ViewCommentsDetail fragment.
     * 
     * @param dialogEvent
     */
    public void emailSentDialogListener(DialogEvent dialogEvent) {
        logger.info("Dialog outcome = " + dialogEvent.getOutcome());
        JSFUtils.handleNavigation("goViewCommentDetails");
    }
    
    /**
     * Returns the selected doc Ids from the Attachment table to be included in the Notification.
     *
     * @return  String list of document (UCM)Ids
     */
    private List<String> getSelectedDocIds(){
        List<String> docIdList = new ArrayList<String>();
        DCIteratorBinding dcIter = ADFUtils.findIterator("AttachmentView1Iterator");
        ViewObject vo = dcIter.getViewObject();
        Row[] selectedRows = vo.getFilteredRows("Selected", true);
        for (Row row : selectedRows){
            AttachmentViewRowImpl attachmentRow = (AttachmentViewRowImpl)row;
            String ucmId = attachmentRow.getUcmId();
            logger.info("Adding to List :: UcmId  = " + ucmId);
            docIdList.add(ucmId);
        }
        return docIdList;
    }
    
    /**
     * Retrieves and returns the key-value application properties from DB.
     *
     * @return  Map with application properties
     */
    private Map getApplicationProperties(){
        Map map = new HashMap();
        OperationBinding operation = ADFUtils.findOperation("getResourceBundle");
        operation.execute();
        if (operation.getErrors().isEmpty()){
            map = (Map)operation.getResult();
        }
        return map;
    }
    
    /**
     * This method downloads first the document in server and then it invoke
     * programmatically a hidden button which uses the af:fileDownloadActionListener to download the
     * document in browser
     * 
     * @param actionEvent
     */
    public void docLinkActionListener(ActionEvent actionEvent) {
        //Get Current row from selected row
        DCIteratorBinding attachDCIter = gov.sec.cas.common.view.utils.ADFUtils.findIterator("AttachmentView1Iterator");
        AttachmentViewRowImpl row = (AttachmentViewRowImpl)attachDCIter.getCurrentRow();
        logger.info("ViewForwardComment.docLinkActionListener :: Clicked Link for Doc Id : " + row.getUcmId());
        logger.info("ViewForwardComment.docLinkActionListener :: Clicked Link for Content Id : " + row.getContentId());
        
        //Download attachment in server so that it can be downloaded from there in browser
        try {
            Map<String, String> props = getApplicationProperties();
            String currentUsername = SecurityUtils.getUserNameFromSessionOrContext();
            RIDCService ridc = new RIDCService(currentUsername, props);
            Document latestDocInfo = ridc.downloadLatestDoc(row.getContentId(), row.getUcmId());
            if (null == latestDocInfo){
                gov.sec.cas.common.view.utils.JSFUtils.addFacesErrorMessage("Document could not be downloaded. Please contact the System Administrator.");
                return;
            }
            logger.fine("ViewForwardComment.docLinkActionListener :: Downloaded File name : " + latestDocInfo.getFileName());
            logger.info("ViewForwardComment.docLinkActionListener :: Downloaded File Content-Type : " + latestDocInfo.getContentType());
            logger.fine("ViewForwardComment.docLinkActionListener :: Downloaded File Absolute Path : " + latestDocInfo.getFileAbsolutePath());
            
            //Add filename and content type in view scope to be used in af:fileDownloadActionListerner attributes
            ADFContext.getCurrent().getViewScope().put(FILE_NAME_PARAM, latestDocInfo.getFileName());
            ADFContext.getCurrent().getViewScope().put(CONTENT_TYPE_PARAM, latestDocInfo.getContentType());
            ADFContext.getCurrent().getViewScope().put(FILE_ABSOLUTE_PATH, latestDocInfo.getFileAbsolutePath());
            
            //Programmatically click the hidden buttton that executes af:fileDownloadActionListerner
            FacesContext fctx = FacesContext.getCurrentInstance();
            String buttonId = getFileDownloadButton().getClientId(fctx);
            StringBuilder script = new StringBuilder();
            script.append("var dlButton = AdfPage.PAGE.findComponentByAbsoluteId('" + buttonId + "');");
            script.append("dlEvent = new AdfActionEvent(dlButton);");
            script.append("dlButton.queueEvent(dlEvent, true);");
            ExtendedRenderKitService erks = Service.getService(fctx.getRenderKit(), ExtendedRenderKitService.class);
            erks.addScript(fctx, script.toString());

        } catch (Exception e){
            e.printStackTrace();
            logger.severe("ViewForwardComment.docLinkActionListener :: ERROR : " + e);
            gov.sec.cas.common.view.utils.JSFUtils.addFacesErrorMessage("Error in downloading document. Please contact System Administrator.");
        }
    }

    /**
     * This method is used along the docLinkActionListener method.
     * Open downloaded file in browser. The button that is using the download action listener is hidden.
     * Hidden button is invoked programmatically in docLinkActionListener method after file is downloaded 
     * in specified location.
     * 
     * @param facesContext
     * @param outputStream
     */
    public void fileDownloadActionListener(FacesContext facesContext, OutputStream outputStream) {
        logger.info("ViewForwardComment.fileDownloadActionListener :: START opening document...");
        try {
            String absoluteFilePath = (String)ADFContext.getCurrent().getViewScope().get(FILE_ABSOLUTE_PATH);
            logger.fine("ViewForwardComment.fileDownloadActionListener :: File Absolute Path : " + absoluteFilePath);
            File file = new File(absoluteFilePath);
            
            //Downloading generated file...
            FileInputStream fis = new FileInputStream(file);
            byte[] b;
            int n;
            while ((n = fis.available()) > 0) {
                b = new byte[n];
                int result = fis.read(b);
                outputStream.write(b, 0, b.length);
                if (result == -1) {
                    break;
                }
            }
            outputStream.flush();
            outputStream.close();
            fis.close();
            //After file is open, delete it from location
            if (file.delete()){
                logger.fine("ViewForwardComment.fileDownloadActionListener :: File was deleted from temp folder ");
            } else {
                logger.warning("ViewForwardComment.fileDownloadActionListener :: File was NOT deleted");
            }
            logger.info("ViewForwardComment.fileDownloadActionListener :: Opening document completed...");
        } catch (Exception e) {
            e.printStackTrace();
            gov.sec.cas.common.view.utils.JSFUtils.addFacesErrorMessage("Error while opening downloaded document. Please contact System Administrator.");
            logger.severe("ViewForwardComment.fileDownloadActionListener :: ERROR : " + e);
        }
    }

    /**
     * Returns the content-type for downloaded file from View Scope.
     * Value was added in docLinkActionListener method.
     * 
     * @return
     */
    public String getContentType() {
        String contentType= (String)ADFContext.getCurrent().getViewScope().get(CONTENT_TYPE_PARAM);
        return contentType;
    }

    /**
     * Returns the filename for downloaded file from View Scope.
     * Value was added in docLinkActionListener method.
     * 
     * @return
     */
    public String getFilename() {
        String filename = (String)ADFContext.getCurrent().getViewScope().get(FILE_NAME_PARAM);
        return filename;
    }

    public void setItSubject(RichInputText itSubject) {
        this.itSubject = itSubject;
    }

    public RichInputText getItSubject() {
        return itSubject;
    }

    public void setItMessage(RichInputText itMessage) {
        this.itMessage = itMessage;
    }

    public RichInputText getItMessage() {
        return itMessage;
    }

    public void setTbRecipients(RichTable tbRecipients) {
        this.tbRecipients = tbRecipients;
    }

    public RichTable getTbRecipients() {
        return tbRecipients;
    }

    public void setTbDocuments(RichTable tbDocuments) {
        this.tbDocuments = tbDocuments;
    }

    public RichTable getTbDocuments() {
        return tbDocuments;
    }

    public void setPopupEmailSent(RichPopup popupEmailSent) {
        this.popupEmailSent = popupEmailSent;
    }

    public RichPopup getPopupEmailSent() {
        return popupEmailSent;
    }

    public void setItStaffNote(RichInputText itStaffNote) {
        this.itStaffNote = itStaffNote;
    }

    public RichInputText getItStaffNote() {
        return itStaffNote;
    }

    public void setPopupSend(RichPopup popupSend) {
        this.popupSend = popupSend;
    }

    public RichPopup getPopupSend() {
        return popupSend;
    }

    public void setFileDownloadButton(RichButton fileDownloadButton) {
        this.fileDownloadButton = fileDownloadButton;
    }

    public RichButton getFileDownloadButton() {
        return fileDownloadButton;
    }
}
