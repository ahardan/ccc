package gov.sec.cll.view.beans;

import gov.sec.cas.sharedcomponents.view.dto.EmailRequestDTO;
import gov.sec.cas.sharedcomponents.view.dto.EmailResponseDTO;
import gov.sec.cas.sharedcomponents.view.utils.NotificationUtils;
import gov.sec.cll.model.adfbc.views.CllActionTypeROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllCommentsListROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllDispositionTypeROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllSourceTypeROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllTypeROViewRowImpl;
import gov.sec.cll.sharedcomponents.view.bundles.DatabaseResourceBundle;
import gov.sec.cas.common.view.dto.Document;
import gov.sec.cas.common.view.services.RIDCService;
import gov.sec.cas.common.view.utils.SecurityUtils;
import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;
import gov.sec.cll.sharedcomponents.view.utils.JSFUtils;
import gov.sec.cll.sharedcomponents.view.utils.SharedCompConstants;
import gov.sec.cll.view.dto.EmailRecipientDTO;
import gov.sec.cll.view.dto.ForwardCommentDTO;
import gov.sec.cll.view.utils.CllConstants;
import gov.sec.cll.view.utils.CllUtils;
import gov.sec.cll.view.utils.PackageUtils;
import gov.sec.rellog.filenumber.view.dto.ReturnMasterFileNumberDTO;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.component.UIComponent;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.nav.RichButton;
import oracle.adf.view.rich.context.AdfFacesContext;
import oracle.adf.view.rich.event.DialogEvent;

import oracle.binding.OperationBinding;

import oracle.jbo.JboException;
import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.domain.Number;

import oracle.stellent.ridc.IdcClientException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.myfaces.trinidad.event.ReturnEvent;
import org.apache.myfaces.trinidad.event.SelectionEvent;
import org.apache.myfaces.trinidad.model.RowKeySet;
import org.apache.myfaces.trinidad.model.RowKeySetImpl;

public class CommentListBean {
    private RichTable commentListTblbind;
    private static ADFLogger logger = ADFLogger.createADFLogger(CommentListBean.class);
    private RichPopup popupExit;
    private RichPopup popupError;
    private RichPopup popupPublish;
    private RichPopup popupUnPublish;
    private RichPopup popupArchive;
    private RichPopup popupInfo;
    private boolean disablePublishButton=false;
    private static final ResourceBundle rb =
                ResourceBundle.getBundle(CllConstants.RESOURCE_BUNDLE_LOCATION);
    private RichButton publishCommandButton;
    private RichButton unPublishCommandButton;
    private static final String DASH = "-";
    private static final String COMMENT_LETTER_PUB_SUBSTR = "_pub_comments_";
    private static final String COMMENT_LETTER_UNPUB_SUBSTR = "_unpub_ comments_"; 
    private String packaingErrorMsg;
    private String actnChgWarnMsg;
    private String archiveWarnMsg;
    private String ADD_FILE_NUM_ACTION="AddFileNum";
    private String CHANGE_FILE_NUM_ACTION="ChangeFileNum";
    private String DELETE_FILE_NUM_ACTION="DeleteFileNum";
    
    private String infoMsg;
    
    private String wsdlURL="";
    private String namespaceURI="";
    private String localPart="";
    private RichPopup popupChgAction;
    private RichPopup popupChgActionWarnMsg;
    private String chgActionPopUpTitle;
    private String chgActionMsg;
    private String cllTypeOtherDesc;
    private String cllFinalActionOtherDesc;
    private RichPopup popupFileNum;
    private String fileNumPopupTitle;
    private String fileNumPopupMsg;
    
    private RichPopup popupfileNumPublish;
    private RichPopup popupfileNumPublishWithComments;
    private static final String COMMENT_LETTER_FILE_NUM_PUB_SUBSTR = "_file_num_pub_comments_";

    public CommentListBean() {
    }
    
    /** Disables  the publish button if filter is not set  to Approve comments
     *
     * @param index
     */
    public void updatePublishButton(Integer index){
        logger.info("Starting ... updatePublishButton  ................");
        OperationBinding opb = ADFUtils.findOperation("getStatusCode");
        opb.getParamsMap().put("index", index);
        opb.execute();
        String selectedStatusCode=(String)opb.getResult();
        if(null != selectedStatusCode){
            logger.info("Status code in filter  is : "+selectedStatusCode);
            if(   selectedStatusCode.equalsIgnoreCase(CllConstants.CLL_DISPOSITION_TYPE_APPR) ) {
                //disablePublishButton=false;
                DCIteratorBinding fileNumIterator = ADFUtils.findIterator("CllCommentsListROView1Iterator"); 
                logger.info("Num of records " + fileNumIterator.getEstimatedRowCount());
                if(fileNumIterator.getEstimatedRowCount() >0){
                      publishCommandButton.setDisabled(false);
                }
                logger.info("Ending ... updatePublishButton  ................");
                return;
            }
        } 
        publishCommandButton.setDisabled(true);
        logger.info("Ending ... updatePublishButton  ................");
        return;
        
    }
    
    /** Disables  the un publish button if filter is not set  to Approve comments
     *
     * @param index
     */
    public void updateUnPublishButton(Integer index){
        logger.info("Starting ... updateUnPublishButton  ................");
        OperationBinding opb = ADFUtils.findOperation("getStatusCode");
        opb.getParamsMap().put("index", index);
        opb.execute();
        String selectedStatusCode=(String)opb.getResult();
        if(null != selectedStatusCode){
            logger.info("Status code in filter  is : "+selectedStatusCode);
            if(   selectedStatusCode.equalsIgnoreCase(CllConstants.CLL_STATUS_TYPE_CODE_PUB) ) { 
                DCIteratorBinding fileNumIterator = ADFUtils.findIterator("CllCommentsListROView1Iterator"); 
                logger.info("Num of records " + fileNumIterator.getEstimatedRowCount());
                if(fileNumIterator.getEstimatedRowCount() >0){
                      unPublishCommandButton.setDisabled(false);
                }
                logger.info("Ending ... updateUnPublishButton  ................");
                return;
            }
        } 
        unPublishCommandButton.setDisabled(true);
        logger.info("Ending ... updateUnPublishButton  ................");
        return;
        
    }

    public void setCommentListTblbind(RichTable commentListTblbind) {
        this.commentListTblbind = commentListTblbind;
    }

    public RichTable getCommentListTblbind() {
        return commentListTblbind;
    }

    public void selectAllCheckBoxes(ValueChangeEvent valueChangeEvent) {
        boolean isSelected = ((Boolean)valueChangeEvent.getNewValue()).booleanValue();
        DCIteratorBinding fileNumIterator = ADFUtils.findIterator("CllCommentsListROView1Iterator"); 
        RowSetIterator rsi = fileNumIterator.getViewObject().createRowSetIterator(null);
        rsi.reset();  
        while (rsi.hasNext()) {
            Row row = rsi.next();
            row.setAttribute("SelectAttr", isSelected);
        }
        rsi.closeRowSetIterator();
        AdfFacesContext.getCurrentInstance().addPartialTarget(commentListTblbind);
    }

    public void setAssignToMe(ActionEvent actionEvent) {
        RowKeySet rksSelectedRows=commentListTblbind.getSelectedRowKeys(); 
        if (rksSelectedRows.size() <=0 ){
            JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_ASSIGNING_NO_COMMENT_SELECTED_MSG")); 
            return;
        }
        ArrayList<Number>  commIds =  CllUtils.getSelectedCommentsFromBulkProcess(rksSelectedRows,"CllCommentsListROView1Iterator");       
        OperationBinding opb = ADFUtils.findOperation("setActiontoComment");
        opb.getParamsMap().put("action", "ASSIGN");
        opb.execute();
        String rslt = (String)opb.getResult();
        if(null != rslt && rslt.equalsIgnoreCase("User Found")){
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            ADFUtils.refreshIterator("CllCommentsListROView1Iterator"); 
            AdfFacesContext.getCurrentInstance().addPartialTarget(commentListTblbind);
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            commentListTblbind.getSelectedRowKeys().removeAll();
        }else{
            packaingErrorMsg=rb.getString("ASSIGN_COMMENTS_ERROR_MSG");
            getPopupError().show(new RichPopup.PopupHints());  
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            commentListTblbind.getSelectedRowKeys().removeAll();
        }
    }
    
        /**
        * Set selected comments to archive
        *
        */
     private void setArchiving() {
        logger.info("Start ...setArchiving method with bounded operation");    
        // Set selected comments to archive
            OperationBinding opb = ADFUtils.findOperation("setArchive");
            opb.execute();
            if(opb.getErrors().isEmpty()){
                String rslt = (String)opb.getResult();
                //Reset checkboxes
                if(null != rslt){
                    logger.info("Refreshing list of comments");  
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                    commentListTblbind.getSelectedRowKeys().removeAll();
                    ADFUtils.refreshIterator("CllCommentsListROView1Iterator"); 
                    AdfFacesContext.getCurrentInstance().addPartialTarget(commentListTblbind);
                }else{
                    packaingErrorMsg=rb.getString("COMMENTLIST_ARCHIVE_ERROR_MSG");
                    getPopupError().show(new RichPopup.PopupHints());  
                }   
            }else{ 
                   JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_ARCHIVE_ERROR_MSG"));  
                }
        }

    /** Retrieves  selected comments in comment list tab
     *
     * @return
     */
    public ArrayList<Number>  selectedComments () {
        RowKeySet rksSelectedRows = commentListTblbind.getSelectedRowKeys(); //reusable method
        ArrayList<Number>  commIds =  CllUtils.getSelectedCommentsFromBulkProcess(rksSelectedRows,"CllCommentsListROView1Iterator");
        return commIds;
    }
    
    /** Refreshes  Comment list iterator
     * 
     */
    public void refreshCommentList(){
        String fileNumId = (String)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pFileNumId");
        String typeCode = (String)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pTypeCode");

        OperationBinding opb = ADFUtils.findOperation("executeCommentsList");
        opb.getParamsMap().put("filerNumId", fileNumId);
        opb.getParamsMap().put("typeCode", typeCode);
        opb.execute();
        
    }
    
    /** Fires  contextual event  based on user response in the pop up  for save/rollback/cancel     //TODO will be used in phase 2
     *
     * @param dialogEvent
     */
    public void exitDialogListener(DialogEvent dialogEvent){    //TODO     will be used in phase 2 based on user comments
           // Add event code here...
            popupExit.hide();
            DCIteratorBinding commDetIterator = ADFUtils.findIterator("CllCommentsListROView1Iterator"); 
            CllCommentsListROViewRowImpl commentsListRow = (CllCommentsListROViewRowImpl)commDetIterator.getCurrentRow();
            logger.info("Current row in the list is  : " + commentsListRow.getCllCommDetId()); 
            String currentRowKey = commDetIterator.getCurrentRowKeyString();   //we already clicked on next row. So, it is next row key
           
            Boolean autoCommit=false;
            if(dialogEvent.getOutcome() == DialogEvent.Outcome.yes){ 
                 autoCommit=true; 
            }else{   //flag is set to false already
               // Boolean rollbackSuccess = ADFUtils.doRollback();   
            }                                                          
                                                                        
            commDetIterator.setCurrentRowWithKeyValue(currentRowKey); 
            Row row  = commDetIterator.getCurrentRow(); 
            RowKeySetImpl newRowKeySet = new RowKeySetImpl();
            ArrayList nextLst = new ArrayList(1);
            nextLst.add(row.getKey());
            newRowKeySet.add(nextLst); 
            // set the new selectedRow
            commentListTblbind.setSelectedRowKeys(newRowKeySet); 
           
            ActionEvent ac = new ActionEvent(dialogEvent.getComponent());
           
            UIComponent component = dialogEvent.getComponent();
            Map<String, Object> attributes = component.getAttributes();
            attributes.put("autoCommit", autoCommit); 
            attributes.put("rowKeyInCommList",currentRowKey);
            ADFUtils.processActionEvent(ac, "refreshCommDetEventBinding");
    
    }
    
    public void setCurrentRowKey(String rowKey){
        DCIteratorBinding commDetIterator = ADFUtils.findIterator("CllCommentsListROView1Iterator");
        commDetIterator.setCurrentRowWithKeyValue(rowKey);  
    }
    
    
    public void setPopupExit(RichPopup popupExit) {
        this.popupExit = popupExit;
    }

    public RichPopup getPopupExit() {
        return popupExit;
    }

    public void setPopupPublish(RichPopup popupPublish) {
        this.popupPublish = popupPublish;
    }

    public RichPopup getPopupPublish() {
        return popupPublish;
    }
    
    
    //TODO  initially unpublishing was invoked from comment list.  ie., multiple comments.  Now this method is not used. but kept it for future purpose
    //TODO  initially unpublishing was invoked from comment list.  ie., multiple comments.  Now this method is not used. but kept it for future purpose
    private boolean generatePackageForUnPublishingComments(ArrayList<Number> commIds, Map <Number, ArrayList<String>> publishedNamesForAttachments, 
                                                           Number fileNumId, String fileTypeFileNumber,
                                                           String downloadLocation, String subDir, String subDirName){
        
        logger.info("Starting   generatePackageForUnPublishingComments  ********************");
        String updatedFileNum=fileTypeFileNumber.replaceAll("-", "").trim();   //we did not send it as  parameter because  too many parameters
        updatedFileNum=StringUtils.lowerCase(updatedFileNum);
        updatedFileNum=CllUtils.removeSpecialCharsFromFileFolderName(updatedFileNum);
        logger.info("updatedFileNum  after removing  special characters *************** is : " +updatedFileNum);  
        ArrayList<String> fileNamesForWupdateFile=new ArrayList<String>();
        String htmlFileNameForComment="";
        for(Number commId:commIds){
                htmlFileNameForComment=updatedFileNum+"-"+commId+".htm"; 
                fileNamesForWupdateFile.add(htmlFileNameForComment); 
                ArrayList<String>  attachments = new ArrayList<String>();
                attachments = publishedNamesForAttachments.get(commId);
                if(null != attachments || attachments.size()>0 ){  
                       for(String s:attachments){
                          fileNamesForWupdateFile.add(s);
                      }
                } 
            
        } 
        fileTypeFileNumber=CllUtils.removeSpecialCharsFromFileFolderName(fileTypeFileNumber);
        logger.info("fileTypeFileNumber after removing  special characters *************** is : " +fileTypeFileNumber);
        boolean flag =PackageUtils.createWUpdateFile(subDir, fileTypeFileNumber, fileNamesForWupdateFile, false); // subdir - is entire path
                                                                                                                  //  with no special characters 
        if(!flag){
           logger.info(" Error creating  wupdate file for  unpublishing comments *****************"); 
           showPopupErrorMsg(rb.getString("COMMENTLIST_ERROR_CREATING_WUPDATE_FOR_COMMENTS"));  
           return false;  
        }
         
        
        String zipFileName=PackageUtils.createCommentLetterZIP(downloadLocation,subDirName);
        if(null ==zipFileName){
             logger.info(" Error   generating  zip file for Unpublishing comments  *****************"); 
             showPopupErrorMsg(rb.getString("COMMENTLIST_ERROR_GENERATING_ZIPFLLE_FOR_UNPUB_COMMENTS"));  
             return false;  
        }
        
        //commit the pkg in  database and in UCM
         flag=uploadZipToUCM(downloadLocation, zipFileName,fileNumId, false);
         if(!flag){
            logger.info(" Error checking in  unpublishing package zip file into UCM and in database *****************"); 
            showPopupErrorMsg(rb.getString("COMMENTLIST_ERROR_CHECKING_ZIPFLLE_FOR_COMMENTS"));  
            return false;  
        }
        logger.info("Ending  generatePackageForUnPublishingComments  ********************");
        return true;                                                      
                                
    }  
    
    
    /** Retrieves  published names for all the attachments for selected comments
     *
     * @param commIds
     * @return Map 
     */
    private Map<Number, ArrayList<String>> getPublishedNamesForAttachments(ArrayList<Number> commIds){
            logger.info("Starting  getPublishedNamesForAttachments  ********************");
            Map<Number, ArrayList<String>> publishedNamesForAttachments= new HashMap<Number, ArrayList<String>>();
         
            //UnLock  file number        
            OperationBinding publishedNamesOpBinding = ADFUtils.findOperation("getPublishedNamesForComments");
            publishedNamesOpBinding.getParamsMap().put("commentIds",commIds ); 
            publishedNamesOpBinding.execute(); 
            if(!publishedNamesOpBinding.getErrors().isEmpty()){
                logger.info("***************  Error while retrieving  published names for attachments for comments  *******************  ");  
                showPopupErrorMsg(rb.getString("COMMENTlIST_ERR_RETRIEVING_PUBLISHED_NAMES_FOR_ATTACHMENTS"));  
                return null ;
            }
            publishedNamesForAttachments=(HashMap<Number, ArrayList<String>>)publishedNamesOpBinding.getResult();
            logger.info("Ending  getPublishedNamesForAttachments  ********************");
            return publishedNamesForAttachments;
    }
    
    
    /**  Prepares the comments that are selected for publishing. 
     *    
     *   
     * @param dialogEvent
     */ 
    
    public void publishDialogListener(DialogEvent dialogEvent){    
                   // Add event code here...
                   logger.info("Starting  publishDialogListener  ********************");
                   //If 'No' is clicked, do not publish the form letter
                   if (dialogEvent.getOutcome() == DialogEvent.Outcome.no) {
                       CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                       commentListTblbind.getSelectedRowKeys().removeAll();
                       return;
                   }
                   popupPublish.hide(); 
                   String fileTypeFileNumber= (String) AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pFileTypeFileNumber");
                   Number fileNumId= (Number) AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pFileNumId"); 
                   Map <Number, ArrayList<String>> commentAttachments=new HashMap<Number, ArrayList<String>>();
                   ArrayList<Number>  commIds = new ArrayList<Number> ();    
                   String updatedFileNumber=fileTypeFileNumber.replaceAll("-", "").trim(); 
                   updatedFileNumber = StringUtils.lowerCase(updatedFileNumber); 
                   updatedFileNumber=CllUtils.removeSpecialCharsFromFileFolderName(updatedFileNumber);
                   logger.info("File number after removing  special characters *************** is : " +updatedFileNumber);
           
                     //let's lock the file number  so that  someone else will not start working on the comments while publishing is in progress
                     RichPopup.PopupHints hints = new RichPopup.PopupHints();  
                     OperationBinding lockFileNum = ADFUtils.findOperation("lockFileNumberRetInt");
                     lockFileNum.getParamsMap().put("fileNumberId",fileNumId ); 
                     lockFileNum.execute(); 
                     //System.out.println("After lockFileNumber.... fileNumId: "+fileNumId+"  getErrors: "+lockFileNum.getErrors());
                     if(!lockFileNum.getErrors().isEmpty()){
                         logger.info("***************  Error while Locking the file number *******************  "  +fileNumId);  
                         packaingErrorMsg=rb.getString("COMMENTLIST_ERR_WHILE_LOCKING_FILE_NUMBER");
                         getPopupError().show(hints);
                         commentAttachments=null;
                         CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                         commentListTblbind.getSelectedRowKeys().removeAll();
                         return  ;
                     }
                  
                     Integer fileLockFlag=(Integer)lockFileNum.getResult(); 
                     if(fileLockFlag == 0) { 
                           packaingErrorMsg=rb.getString("COMMENTLIST_FILE_NUMBER_ALREADY_LOCKED");
                           getPopupError().show(hints);
                           commentAttachments=null;
                           CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                           commentListTblbind.getSelectedRowKeys().removeAll();
                           return ; 
                      }
                     
                     commIds=selectedComments ();    //control does not even come here if commIds is  empty. 
                     String downloadLocation = getCommentsPackagingDir();   
                     if(null == downloadLocation){ 
                         logger.info("***************  Error while retrieving application property CLL_PACKAGING_DIR from database *******************"); 
                         showPopupErrorMsg(rb.getString("COMMENTLIST_UNABLE_TO_CREATE_TEMP_DIR_FOR_PACKAGING"));   
                         unlockFileNumber( fileNumId);
                         CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                         commentListTblbind.getSelectedRowKeys().removeAll();
                         return  ;
                     } 
                     Map<String,String> map = new HashMap<String,String>();
                     map=createTempDir(downloadLocation,updatedFileNumber ,true); 
                     if(null == map) { 
                         unlockFileNumber( fileNumId);
                         CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                         commentListTblbind.getSelectedRowKeys().removeAll();
                         return ;    
                     }
                     String subDir=map.get("subDir");  // subDir is with full path.  Ex: cas_documents/cll_packaging/10222_pub_comments_2016.11.29.11.10.52
                                                       //  It is already filtered from special characters
                     String subDirName=map.get("subDirName");  // subDirName isname of the subdir. Ex : 10222_pub_comments_2016.11.29.11.10.52
                                                               //  It is already filtered from special characters
                     commentAttachments=downloadAttachments(commIds,subDir,fileNumId,updatedFileNumber); 
                     if(null == commentAttachments) { 
                          unlockFileNumber( fileNumId);
                          CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                          commentListTblbind.getSelectedRowKeys().removeAll();
                          return ;     
                      } 
                     boolean flag=generatePackageForComments(commIds,commentAttachments, fileNumId,fileTypeFileNumber,
                                                          downloadLocation,subDir,subDirName, Boolean.FALSE); 
                     if(!flag){
                         unlockFileNumber( fileNumId);
                         CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                         commentListTblbind.getSelectedRowKeys().removeAll();
                         return;   ///error
                     } 
                     
                      
                   // update  status for  comments  as published 
                   String commIdsStr=getCommDelemitedCommIds(commIds); 
                   OperationBinding operation = ADFUtils.findOperation("updateStatusForPublishedComments");
                   operation.getParamsMap().put("commentIds",commIdsStr ); 
                   operation.execute(); 
                   if(!operation.getErrors().isEmpty()){
                        logger.info("***************  Error while updating comment status as published  *******************");
                        showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_UPDATING_COMMENTS_AS_PUBLISHED"));  
                        unlockFileNumber( fileNumId);
                        CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                        commentListTblbind.getSelectedRowKeys().removeAll();
                        return ;
                   }
                   if(null ==  operation.getResult() ||  (Integer)operation.getResult() ==0 ){  //method returns count for updated rows
                       logger.info("***************  Error while updating comment status as published  *******************");
                       showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_UPDATING_COMMENTS_AS_PUBLISHED"));
                       unlockFileNumber( fileNumId);
                       CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                       commentListTblbind.getSelectedRowKeys().removeAll();
                       return ;
                   }    
                  // even though unlocking file number fails, we need to update comments as published since packaging is done and 
                  //checked into UCM
                  if(ADFUtils.doCommit()){ 
                      if(commIds.size() >1) {
                          showPopupInfoMsg( "The selected "+ commIds.size() +" comments are published successfully. Open the Published Packages Queue to download the package.");
                      }else{
                          showPopupInfoMsg("The selected comment is published successfully. Open the Published Packages Queue to download the package.");
                      }
                      unlockFileNumber( fileNumId); 
                  }else{
                      logger.info("***************  Error while committing comment log *******************  ");  
                      showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_PERSISTING_PUBLISHED_COMMENTS")); 
                      unlockFileNumber( fileNumId); 
                  }   
                
               CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
               commentListTblbind.getSelectedRowKeys().removeAll();
               //ADFUtils.refreshIterator("CllCommentsListROView1Iterator"); 
               AdfFacesContext.getCurrentInstance().addPartialTarget(commentListTblbind); 
              logger.info("Ending  publishDialogListener  ********************");
       }
    
    
    
    
     /**  Prepares the comments that are selected for Un publishing. 
         *   Retrieves  published names for attachments
         *   
         * @param dialogEvent
         */
      public void unPublishDialogListener(DialogEvent dialogEvent){    
              // Add event code here...
              logger.info("Starting  unPublishDialogListener  ********************");
               popupPublish.hide(); 
               String fileTypeFileNumber= (String) AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pFileTypeFileNumber");
               Number fileNumId= (Number) AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pFileNumId"); 
               Map <Number, ArrayList<String>> publishedNamesForAttachments=new HashMap<Number, ArrayList<String>>();
               ArrayList<Number>  commIds = new ArrayList<Number> ();    
               String updatedFileNumber=fileTypeFileNumber.replaceAll("-", "").trim(); 
               updatedFileNumber=CllUtils.removeSpecialCharsFromFileFolderName(updatedFileNumber);
               logger.info("File number after removing  special characters *************** is : " +updatedFileNumber);
               updatedFileNumber = StringUtils.lowerCase(updatedFileNumber);
               if(dialogEvent.getOutcome() == DialogEvent.Outcome.yes){  
                   
                     commIds=selectedComments ();    //control does not even come here if commIds is  empty 
                     String downloadLocation = getCommentsPackagingDir();   
                     if(null == downloadLocation){ 
                         logger.info("***************  Error while retrieving application property CLL_PACKAGING_DIR from database *******************"); 
                         showPopupErrorMsg(rb.getString("COMMENTLIST_UNABLE_TO_CREATE_TEMP_DIR_FOR_PACKAGING"));
                         return  ;
                     }
                     //create tmp dir
                     Map<String,String> map = new HashMap<String,String>();
                     map=createTempDir(downloadLocation,updatedFileNumber ,false); 
                     if(null == map) {
                        return ;   //already  error popup is invoked
                     }
                     String subDir=map.get("subDir"); // special chars already removed
                     String subDirName=map.get("subDirName");  // special chars already removed
                     //Lock the file number  
                     if( !lockFileNumberForProcessing(fileNumId) ){
                         return;
                     } 
                     publishedNamesForAttachments=getPublishedNamesForAttachments(commIds); 
                     if(null == publishedNamesForAttachments) {  
                          unlockFileNumber( fileNumId);
                          return ;    //already  error popup is invoked.   You will get null only if error. Else at least empty object if no attachments.
                      }
                     
                    // generate  package for  un publishing comments  
                      boolean flag=generatePackageForUnPublishingComments(commIds,publishedNamesForAttachments, fileNumId,fileTypeFileNumber,
                                                             downloadLocation,subDir,subDirName);
                      if(!flag){
                          unlockFileNumber( fileNumId);
                          return;   ///error
                      }                   
                      
                   // update  status for  comments  as published 
                   String commIdsStr=getCommDelemitedCommIds(commIds); 
                   OperationBinding operation = ADFUtils.findOperation("updateStatusForUnPublishedComments");
                   operation.getParamsMap().put("commentIds",commIdsStr ); 
                   operation.execute(); 
                   if(!operation.getErrors().isEmpty()){
                        logger.info("***************  Error while updating comment status as  processed *******************"); 
                        showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_UPDATING_COMMENTS_AS_UNPUBLISHED")); 
                        unlockFileNumber( fileNumId);
                        return ;
                   }
                   if(null ==  operation.getResult() ||  (Integer)operation.getResult() ==0 ){
                        logger.info("***************  Error while updating comment status as processed  *******************"); 
                        showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_UPDATING_COMMENTS_AS_UNPUBLISHED")); 
                        unlockFileNumber( fileNumId);
                        return ;
                   }  
                   
                   
                   //UnLock  file number        
                   OperationBinding unlockFileNumber = ADFUtils.findOperation("unlockFileNumber");
                   unlockFileNumber.getParamsMap().put("fileNumberId",fileNumId ); 
                   unlockFileNumber.execute(); 
                   if(!unlockFileNumber.getErrors().isEmpty()){
                       logger.info("***************  Error while unlocking the file number *******************  "  +fileNumId);  
                       showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_UNLOCKING_FILE_NUMBER"));
                       unlockFileNumber( fileNumId);
                       return  ;
                   }
                   
                  if(ADFUtils.doCommit()){ 
                      showPopupInfoMsg(rb.getString("COMMENTLIST_UNPUBLISHING_SUCCESS_MSG"));
                      unlockFileNumber( fileNumId);
                  }else{
                      logger.info("***************  Error while committing comment log *******************  ");  
                      showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_PERSISTING_PUBLISHED_COMMENTS"));  
                      unlockFileNumber( fileNumId);
                      return  ;
                  }
                       
              }  
              
               //clear out check boxes
               //this.getSelAllHdrChckBox().setValue(false);  
               DCIteratorBinding commListIterator = ADFUtils.findIterator("CllCommentsListROView1Iterator"); 
               RowSetIterator rsi = commListIterator.getViewObject().createRowSetIterator(null);
               rsi.reset();  
               while (rsi.hasNext()) {
                   Row row = rsi.next();
                   row.setAttribute("SelectAttr", false);
               } 
               rsi.closeRowSetIterator();
               
               //ADFUtils.refreshIterator("CllCommentsListROView1Iterator"); 
               AdfFacesContext.getCurrentInstance().addPartialTarget(commentListTblbind); 
              logger.info("Ending  unPublishDialogListener  ********************");
    }
       
    
    public Map<String, String> getApplicationProperties(){
        Map<String,String> appProps = new HashMap<String,String>();
        OperationBinding binding = ADFUtils.findOperation("getResourceBundle");
        binding.execute();
        if (binding.getErrors().isEmpty()){
            appProps = (Map<String, String>) binding.getResult();
        } else {
            JSFUtils.addFacesErrorMessage(rb.getString("APPLICATION_PROPERTIES_RETRIEVE_ERROR"));
        }
        return appProps;
    }
    
    /**Unlocks the file number from processing table
     *
     * @param fileNumId
     */
    private void unlockFileNumber(Number fileNumId){
        OperationBinding unlockFileNumber = ADFUtils.findOperation("unlockFileNumber");
        unlockFileNumber.getParamsMap().put("fileNumberId",fileNumId ); 
        unlockFileNumber.execute(); 
        if(!unlockFileNumber.getErrors().isEmpty()){
            logger.info("***************  Error while unlocking the file number *******************  "  +fileNumId); 
            showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_UNLOCKING_FILE_NUMBER"));   
        }
    }
    
    
    /** Generates  required pages for  for  publishing comments
     *
     * @param commIds
     * @param commentAttachments
     * @param fileNumId
     */
    private boolean generatePackageForComments(ArrayList<Number> commIds, Map <Number, ArrayList<String>>  commentAttachments, 
                                             Number fileNumId, String fileTypeFileNumber, String downloadLocation,String subDir,
                                                              String subDirName, boolean fileNumPublishFlag){
        logger.info("Starting  generatePackageForComments  ********************");
        
        RichPopup.PopupHints hints = new RichPopup.PopupHints();   
        
        OperationBinding retrieveMasterFileNumId = ADFUtils.findOperation("findMasterFileNumId");
        retrieveMasterFileNumId.getParamsMap().put("fileNumId", fileNumId);
        retrieveMasterFileNumId.execute(); 
        Number masterFileNumId=null; 
        if (retrieveMasterFileNumId.getErrors().isEmpty()){
                masterFileNumId = (Number)retrieveMasterFileNumId.getResult();
                if (masterFileNumId == null){
                    logger.severe("ERROR....Error...  retrieving  Master file number id *****************");
                    unlockFileNumber(fileNumId); 
                    throw new RuntimeException(rb.getString("FORMLETTERLIST_PUBLISHING_GET_RELEASENUMBERS_ERROR_MSG"));
                }
         } else {
                logger.severe("ERROR....Error...  retrieving  Master file number id *****************" + retrieveMasterFileNumId.getErrors());
                packaingErrorMsg=rb.getString("FORMLETTERLIST_PUBLISHING_GET_RELEASENUMBERS_ERROR_MSG");
                getPopupError().show(hints); 
                return false;
        }
        List<String> relNums= CllUtils.getReleaseNumsForMasterFileNumber(masterFileNumId);
        String releaseNumbers = ""; 
        if(null != relNums){
            releaseNumbers=relNums.toString();
        }else{ //error retrieving release numbers
            packaingErrorMsg=rb.getString("FORMLETTERLIST_PUBLISHING_GET_RELEASENUMBERS_ERROR_MSG");
            getPopupError().show(hints); 
            return false;
        }
        logger.info("Release Nos  fetched from master file number module is  : "  +releaseNumbers );
        if(!relNums.isEmpty()){
           releaseNumbers=releaseNumbers.substring(1, releaseNumbers.length()-1);
            releaseNumbers = "Release Nos. " + releaseNumbers  + "; ";   
        } 
        
        Map<Number, Map<String, String>> commDetails =new HashMap<Number, Map<String, String>>();
        //get links for each comment and link for each comment is mapped to the submitter displayed in indiex page
        commDetails=generateIndexPageLinksForComments(commIds,commentAttachments,fileTypeFileNumber);
        if(null == commDetails || commDetails.isEmpty() || commDetails.size() ==0){
             logger.info(" Error   retrieving   details of comments in getDetailsOfComments()  *****************");
             packaingErrorMsg=rb.getString("COMMENTLIST_ERR_WHILE_RETRIEVING_COMMENTDETAILS_FOR_PUBLISHING");
             
             getPopupError().show(hints); 
             return false; 
        }
        String commLinks = getCommentLinksForIndexPage(commIds,commDetails);  // one index page containing the links for all selected comments
        
        
        
        String indexPgTemplateStr=getTemplateContentByCode( CllConstants.COMMENTlETTER_INDEXPAGE_TEMPLATE_CODE );
        String htmlPgTemplateStr=getTemplateContentByCode( CllConstants.COMMENTlETTER_HTMLPAGE_TEMPLATE_CODE );
        if(indexPgTemplateStr.isEmpty() ||htmlPgTemplateStr.isEmpty()) { 
            logger.info(" Error   retrieving  html/index templates from database *****************");
             packaingErrorMsg=rb.getString("COMMENTLIST_ERROR_RETRIEVING_TEMPLATES_FOR_COMMENTS");
             getPopupError().show(hints); 
             return false;  
        }
        String title=getSubjectForFileNum(fileNumId);
        if(null == title) {
            return false;
        } 
        title= StringEscapeUtils.escapeHtml(title.trim());  
        ArrayList<String> fileNamesForPackaging =new ArrayList<String>();
        Map<String,String> indexPageMap = new HashMap<String,String>();
        String idxpgFileName = "";
        // CASSUP-1753 : Commenting below logic to not package Index htm file for file number publishing
        if(!fileNumPublishFlag){
            indexPageMap.put("template", indexPgTemplateStr);
            // Changes for CASSECDEV-6075: Remove the title and release number, Have removed those in template and commenting below.
            //indexPageMap.put("title", title);    
            //indexPageMap.put("release_numbers", releaseNumbers);
            indexPageMap.put("fileType_fileNumber", fileTypeFileNumber);
            indexPageMap.put("comment_links", commLinks);  
            idxpgFileName=PackageUtils.createCommentLetIndexPage(indexPageMap,subDir);
            if(idxpgFileName == null) { 
                 logger.info(" Error   generating  index page for comments *****************"); 
                 showPopupErrorMsg(rb.getString("COMMENTLIST_ERROR_GENEERATING_INDEX_PAGE_COMMENTS"));  
                 return false;  
            }
            fileNamesForPackaging.add(idxpgFileName); 
        }
        ArrayList<String>  attachments = new ArrayList<String>();
        Map<String,String> commentInfo; 
        for(Number commId:commIds) { 
            commentInfo=commDetails.get(commId);    //already  checked for null object while retrieving result from data control method itself
            if(!commentInfo.get("htmlFileNameForComment").isEmpty()) {   // genrate  html for comments
                indexPageMap = new HashMap<String,String>();
                indexPageMap.put("template",htmlPgTemplateStr);
                indexPageMap.put("name",commentInfo.get("name"));
                indexPageMap.put("recDate",commentInfo.get("receivedDate"));
                indexPageMap.put("subject",commentInfo.get("subject"));     
                indexPageMap.put("affiliation",commentInfo.get("affiliation")); 
                indexPageMap.put("comment",commentInfo.get("comment"));     
                indexPageMap.put("attachmentLinks",commentInfo.get("attachmentLinks")); //links are filtered with special characters
                indexPageMap.put("htmlFileNameForComment",commentInfo.get("htmlFileNameForComment"));   //file name is filtered with special chars
                idxpgFileName=PackageUtils.createCommentLetHtmlPage(indexPageMap,subDir);
                if(idxpgFileName == null) { 
                     logger.info(" Error   generating  html page for the comment *****************"  +commId); 
                     showPopupErrorMsg(rb.getString("COMMENTLIST_ERROR_GENEERATING_HTML_PAGE_COMMENTS"));  
                     return false;  
                }
                fileNamesForPackaging.add(idxpgFileName);
            } 
            //Add all attachment names to the updates.txt
            attachments = commentAttachments.get(commId);     
            if(attachments !=null ) { 
                for(String s:attachments){
                        fileNamesForPackaging.add(s);
                }
            }
             
        } 
        fileTypeFileNumber=CllUtils.removeSpecialCharsFromFileFolderName(fileTypeFileNumber);
        logger.info("fileTypeFileNumber  after removing  special characters *************** is : " +fileTypeFileNumber);
        
        // CASSUP-1753 : Commenting below logic to not package Updates txt file for file number publishing
        boolean flag = Boolean.FALSE;
        if(!fileNumPublishFlag){
            flag = PackageUtils.createWUpdateFile(subDir, fileTypeFileNumber, fileNamesForPackaging, true); //subdir is the complete path with sub dir name 
                                                                                                               //where updates.txt file will be created
            if(!flag){
               logger.severe(" Error creating wupdate file for comments *****************"); 
                showPopupErrorMsg(rb.getString("COMMENTLIST_ERROR_CREATING_WUPDATE_FOR_COMMENTS"));  
                return false;  
            }
        }
        
        // CASSECDEV-6085 : CASSECDEV-6117 : Changes for File Number Publishing
        // Zip and upload file to UCM only for Comments Publishing and not for File Number Publishing
        if(!fileNumPublishFlag){
            String zipFileName=PackageUtils.createCommentLetterZIP(downloadLocation,subDirName); //downloadLocation is ../cas_documents/cll_packaging
            if(null ==zipFileName){
                logger.info(" Error   generating  zip file for publishing comments  *****************"); 
                 showPopupErrorMsg(rb.getString("COMMENTLIST_ERROR_GENERATING_ZIPFLLE_FOR_COMMENTS"));  
                 return false;  
            }
            
            //  upload   the package into UCM
             flag=uploadZipToUCM(downloadLocation, zipFileName,fileNumId, true);
             if(!flag){
                logger.info(" Error checking in  publishing package zip file into UCM and in database *****************"); 
                showPopupErrorMsg(rb.getString("COMMENTLIST_ERROR_CHECKING_ZIPFLLE_FOR_COMMENTS"));  
                 return false;  
            }
        }
        
        logger.info("Ending  generatePackageForComments  ********************");
        return true;
    }
    
    
    private String getSubjectForFileNum(Number fileNumId){
        logger.info("Starting getSubjectForFileNum  ****************************** ");
        String subject=""; 
        OperationBinding retrieveFileSubject = ADFUtils.findOperation("retrieveFileSubject");
        retrieveFileSubject.getParamsMap().put("fileNumId", fileNumId);
        retrieveFileSubject.execute(); 
        if (retrieveFileSubject.getErrors().isEmpty()){
            subject = (String)retrieveFileSubject.getResult(); 
            if(null == subject) {
                subject="";
            }  
        }else {
             logger.severe("Error  whiile retieving  file subject  for the file number "+fileNumId);
             showPopupErrorMsg(rb.getString("COMMENTLIST_ERROR_GETTING_SUBJECT_FOR_FILE"));  
             return null;
        } 
        logger.info("Ending getSubjectForFileNum  ****************************** ");
        return subject; 
    }
    
    /**
     * Uploads zip file to UCM
     *
     * @param dir       Directory path where the zip file is located
     * @param fileName  Zip file name
     * @param fileNumberId  File Number Id
     */
    private boolean uploadZipToUCM(String dir, String fileName, Number fileNumberId, boolean isPublish) {
        logger.info ("Starting uploadZipToUCM   ******************************  ");
        try {
            File newFile = new File(dir, fileName);
            InputStream inputStream = new FileInputStream(newFile);
            logger.info("File Length : " + newFile.length());
            byte[] byteArrayFile = convertInputStreamToByeArray(inputStream);
            int fileSize=byteArrayFile.length/(1024 *1024);
            logger.info("Comments zip  file byte array length : " + byteArrayFile.length);
            logger.info("  The Comments zip  file size  is  in MB  ***************** " +fileSize);
            
            String username = SecurityUtils.getUserNameFromSessionOrContext();
            Map<String, String> props = getApplicationProperties();
            
            //Prepararing document for UCM
            Document doc= new Document();
            doc.setByteArrayFile(byteArrayFile);
            doc.setFileName(fileName);
            doc.setFileLength(newFile.length()); 
            doc.setCaseId(fileNumberId.toString());
            doc.setModuleName(SharedCompConstants.CLL_PKG_MODULE); //CLLPKG 
            doc.setAppName(props.get("APP_NAME_CLL"));
            doc.setDocAccount(props.get("ACCOUNT_NAME_CLL_RWD"));

            RIDCService ridService = new RIDCService(username, props); 
            Document upDocInfo = ridService.uploadDocument(doc);  
            logger.info("ZIP File Checked In. Id = " + upDocInfo.getDocId());
            
            //Getting username
//            String username = ADFContext.getCurrent().getSecurityContext().getUserName(); 
            logger.info("Current logged in username : " + username);
            
            //Adding to attachments
            List<Map> attachments = new ArrayList<Map>(); 
            Map attachmentmap = new HashMap();
            attachmentmap.put("CaseId", fileNumberId);
            attachmentmap.put("DocumentTypeID", getDocumentType() );   //document type id 
            attachmentmap.put("OtherDocTypeDesc", null);   //even if it is NULL ************we should be fine 
            attachmentmap.put("DocName", fileName);  
            attachmentmap.put("ModuleName", doc.getModuleName()); 
            attachmentmap.put("Author", username);
            attachmentmap.put("UcmId", upDocInfo.getDocId());
            if (isPublish){
                attachmentmap.put("PubPkgFlag", "Y");    
            } else {
                attachmentmap.put("PubPkgFlag", "N");                    
            }
            
            attachments.add(attachmentmap); 
            
            //commit the  attachments in  attachment table
            if (attachments.size() > 0) {
                OperationBinding operation = ADFUtils.findOperation("addAttachments"); 
                operation.getParamsMap().put("attachments", attachments);
                operation.execute(); 
                if (operation.getErrors().isEmpty()){
                    if (!ADFUtils.performBindingAction("SharedCompCommit")){
                       // throw new RuntimeException("Error on commit share components.");
                        return false;
                    }
                } else {
                    //throw new RuntimeException("Error on inserting a new attachment row for Zip file.");
                    return false;
                }
            } 
            
            inputStream.close();
            
        } catch (FileNotFoundException e) {
            logger.severe(rb.getString("FORMLETTERLIST_PACKAGE_FILE_NOTFOUND_ERORR_MSG"), e);
            e.printStackTrace();
            return false;
        } catch (IdcClientException e) {
            logger.severe(rb.getString("RIDCSERVICE_LOAD_UCM_METADATA_ERROR_MSG"), e);
            e.printStackTrace();
           // throw new RuntimeException(e);
           return false;
        } catch (IOException e) {
            logger.severe(rb.getString("PACKAGE_FILE_CLOSING_STREAM_ERROR_MSG"), e);
            e.printStackTrace();
           //throw new RuntimeException(e);
            return false;
        } catch (Exception e) {
            logger.severe(rb.getString("Error during the process of uploading ZIP file"), e);
            e.printStackTrace();
            return false;
        }
        logger.info ("Ending uploadZipToUCM   ******************************  ");
        return true;
    }
    
    
    
    /**
     * Retrieves and returns the code for meeting minutes type id from reference data
     *
     * @return
     */
    private Number getDocumentType() {
        Number docTypeId = new Number();
        OperationBinding findDocTypeId = ADFUtils.findOperation("getDocumentTypeId");
        findDocTypeId.getParamsMap().put("code", SharedCompConstants.DOC_TYPE_PUBLISHING_PACKAGE_CODE);
        findDocTypeId.execute();
        if (findDocTypeId.getErrors().isEmpty()){
            docTypeId = (Number)findDocTypeId.getResult();
        }
        return docTypeId;
    }
    
    
    /** Convert  input stream to byte array 
     *
     * @param is   File  input stream
     * @return
     */
    public byte[] convertInputStreamToByeArray(InputStream is){ 
      ByteArrayOutputStream bos = new ByteArrayOutputStream();  
      BufferedInputStream bIn = new BufferedInputStream(is);
        byte[] buf = new byte[1024];
        try {
            for (int readNum; (readNum = bIn.read(buf)) != -1;) {
                bos.write(buf, 0, readNum); //no doubt here is 0
                //Writes len bytes from the specified byte array starting at offset off to this byte array output stream.
                logger.finest("Read  " + readNum + " bytes,"); 
            }
            byte[] bytes = bos.toByteArray();
            return bytes;
        } catch (IOException ex) {
            logger.info(ex.toString());
             return null;
        }   
        
    }
   
                         
   /**Invokes custom data control method to get all the details  for selected comments.  The method also generates required
     *links for html  and index pages
     * @param commIds
     * @param commentAttachments
     * @param fileTypeFileNumber
     * @return
     */
    private  Map<Number, Map<String, String>> generateIndexPageLinksForComments(ArrayList<Number> commIds, Map <Number, ArrayList<String>>  commentAttachments,
                                                                   String fileTypeFileNumber){ 
        Map<Number, Map<String, String>> commDetails =new HashMap<Number, Map<String, String>>();
        OperationBinding detailsOfComments = ADFUtils.findOperation("getCommentDetails");
        detailsOfComments.getParamsMap().put("commIds",commIds );
        detailsOfComments.getParamsMap().put("commentAttachments",commentAttachments );
        detailsOfComments.getParamsMap().put("fileTypeFileNumber",fileTypeFileNumber );
        detailsOfComments.execute();
        if(!detailsOfComments.getErrors().isEmpty()){
            logger.info(" Error  retrieving   details of comments in getDetailsOfComments()  *****************");
            return null;
        } 
        if(null == detailsOfComments.getResult()){
            return null;
        }
        commDetails =(Map<Number, Map<String, String>>)detailsOfComments.getResult();   
        
        return commDetails;
        
    }
    
    /**Generates  comment links for index page
     *
     * @param commIds
     * @param commentDetails
     * @return String
     */
    private String getCommentLinksForIndexPage(ArrayList<Number> commIds, Map<Number, Map<String, String>> commentDetails){
        
       // String orgiHtmlTrTagStr= "<tr onMouseOver=\"this.bgcolor='#E0E0E0'\" on MouseOut=\"this.bgColor='#FFFFFF'\" bgcolor=\"#FFFFFF\" valign=\"top\"> <td nowrap>$recDate$</td> <td><a href=\"$link$\" class=\"subCat9\">$name$</a></td></tr>";
        
        String  orgiHtmlTrTagStr = "<tr><td class=\"nobreak\">$recDate$</td> <td><a href=\"$link$\">$name$</a></td></tr>";  
        String commLinks="";
        String recDate="";
        String link="";
        String name="";
        String htmlTrTagStr1 =orgiHtmlTrTagStr;
        for(Number commId:commIds) {
            Map<String, String> currentCommDetails= new HashMap<String, String>();
            currentCommDetails=commentDetails.get(commId);
            // This 'receivedDate' parameter returns Letter Date value. It just an wrong parameter name usage, The parameter value is Comment Letter Date.
            recDate=currentCommDetails.get("receivedDate");
            // Changes for CASSECDEV-6072: Changed the get parameter for name variable value from submitter to allSubmitters.
            // Changes for CASSECDEV-6077: Added condition based on memoStaffNotes, which will exist only for comment type Memos.
            logger.info("In getCommentLinksForIndexPage.... allSubmitters:"+currentCommDetails.get("allSubmitters")
                        +" memoStaffNotes:"+currentCommDetails.get("memoStaffNotes"));
            if(currentCommDetails.get("memoStaffNotes") != null){
                name=currentCommDetails.get("memoStaffNotes");
            } else {
                name=currentCommDetails.get("allSubmitters");
            }
            link = StringUtils.trimToEmpty(currentCommDetails.get("link")); 
            htmlTrTagStr1=htmlTrTagStr1.replace("$recDate$", recDate);
            htmlTrTagStr1=htmlTrTagStr1.replace("$name$", name);
            htmlTrTagStr1=htmlTrTagStr1.replace("$link$", link.toLowerCase());
            commLinks=commLinks+htmlTrTagStr1+System.lineSeparator()+System.lineSeparator();
            htmlTrTagStr1=orgiHtmlTrTagStr;
        }
        
        return commLinks;  
        
        
    }
    
   /** Creates  comma delimited string of  Comment Ids
     *
     * @param commIds
     * @return String
     */
    private String getCommDelemitedCommIds(ArrayList<Number> commIds){
        String commIdsStr=null;
        for(Number id:commIds) {
            if(null == commIdsStr){
                commIdsStr="("+id.toString();
            }else{
                commIdsStr=commIdsStr+","+id.toString();
            }
        }
        commIdsStr=commIdsStr+")";
        return commIdsStr;
    }
   
    
    
    
    /**Creates  temporary dir for packaging comments
     *
     * @param downloadLocation
     * @return 
     */
    private  Map  createTempDir(String downloadLocation, String updatedFileNumber, boolean isPublish ){ 
        logger.info("Starting  createTempDir  ********************");
        Map<String,String> map = new HashMap<String,String>();
        RichPopup.PopupHints hints = new RichPopup.PopupHints(); 
        String subDir=null; 
        String subDirName=null;  
        //create  tmp folder  
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date()); 
        if(isPublish){ 
             subDir=downloadLocation+updatedFileNumber+COMMENT_LETTER_PUB_SUBSTR+timeStamp+"//";
             // subDir=downloadLocation+updatedFileNumber+pkgingPublishDirSubString+timeStamp+"\\";  
             subDirName=updatedFileNumber+COMMENT_LETTER_PUB_SUBSTR+timeStamp; 
        }else{
            subDir=downloadLocation+updatedFileNumber+COMMENT_LETTER_UNPUB_SUBSTR+timeStamp+"//"; 
            // subDir=downloadLocation+updatedFileNumber+pkgingUnPublishDirSubString+timeStamp+"\\";
            subDirName=updatedFileNumber+COMMENT_LETTER_UNPUB_SUBSTR+timeStamp;
        } 
        map.put("subDir",subDir);
        map.put("subDirName",subDirName );
        File tempDir = new File(subDir);
        boolean createDir=tempDir.mkdir(); 
        if(!createDir){
            logger.info("***************  Error while creating packaging dir  "  +subDir + ".  It may exist already  **************" );  
            packaingErrorMsg=rb.getString("COMMENTLIST_ERR_WHILE_CREATING_TEMP_DIR");
            getPopupError().show(hints); 
            return null ;
        }
        logger.info("***************  Created   tmp  dir     *******************");   
        logger.info("Ending  createTempDir  ********************");
       return map; 
    }
   
   /** Iterates through each comment  and invokes a method which in turn downloads and renames the attachments for each comment
     *
     * @param commIds
     * @param subDir
     */
    private Map <Number, ArrayList<String>> downloadAttachments(ArrayList<Number> commIds,String subDir,Number fileNumId, String upatedFileNumber){
        
        logger.info("Starting  downloadAttachments  ********************");
        int  numOfAttachments;
        RichPopup.PopupHints hints = new RichPopup.PopupHints(); 
        Map <Number, ArrayList<String>> commentAttachments=new HashMap<Number, ArrayList<String>>();
        Map<String,String> attachmentNewNames=new HashMap <String,String>(); 
        try {
              String username = SecurityUtils.getUserNameFromSessionOrContext();
              Map<String, String> props = getApplicationProperties();
              RIDCService ridService = new RIDCService(username, props);
            
               for(Number commId:commIds){
                    numOfAttachments=0; 
                    
                     Map<String,String> docIDs= new HashMap<String,String>(); 
                    //get document ids for  each comment
                     OperationBinding operation = ADFUtils.findOperation("getDocIDsForComment");
                     operation.getParamsMap().put("commentID",commId ); 
                     operation.execute(); 
                     if(!operation.getErrors().isEmpty()){
                         logger.info("***************  Error while accessing ATTACHMENT table to retrieve document IDs *******************");
                          packaingErrorMsg=rb.getString("COMMENTLIST_ERR_WHILE_RETRIEVING_ATTACHMENTS");
                          getPopupError().show(hints);  
                          commentAttachments=null;
                          return null;
                     }
                     docIDs=(Map<String,String>)operation.getResult();  
                     if(docIDs.size() >0) { 
                         ArrayList<String> fileNames= new ArrayList<String>(); 
                         for(Map.Entry<String, String> entry : docIDs.entrySet()){  
                             String docName=entry.getValue();
                             String extension = FilenameUtils.getExtension(docName);
                             String newDocName=upatedFileNumber+"-"+entry.getKey()+"-"+commId+"."+extension; 
                             String newFileName= subDir+newDocName; 
                             ridService.downloadFile(entry.getKey(), newFileName);
                             fileNames.add(newDocName); 
                             attachmentNewNames.put(entry.getKey(), newDocName);
                             
                         } 
                         commentAttachments.put(commId,fileNames); 
                     }  
              } 
              if(attachmentNewNames != null && attachmentNewNames.size() >0) {
                  boolean flag= updateNewNamesForAttachments(attachmentNewNames);
                    if(!flag){   
                        return null;
                    }
              } 
              return commentAttachments;  
            
          } catch (IdcClientException e) {
              String msg=rb.getString("COMMENTLIST_UNABLE_DOWNLOAD_ATTACHMENT");
              JSFUtils.addFacesErrorMessage(msg);  
          }catch (JboException e){
             String msg=rb.getString("COMMENTLIST_UNABLE_DOWNLOAD_ATTACHMENT");
             JSFUtils.addFacesErrorMessage(msg);  
         } catch (Exception e){ 
              e.printStackTrace();
              String msg=rb.getString("COMMENTLIST_UNABLE_DOWNLOAD_ATTACHMENT");
              JSFUtils.addFacesErrorMessage(msg);   
         } 
        logger.info("Ending  downloadAttachments  ********************");
       return null;
    } 
   
   
   private boolean lockFileNumberForProcessing(Number fileNumId){ 
       logger.info(" inside lockFileNumberForProcessing  ********************");
       OperationBinding lockFileNum = ADFUtils.findOperation("lockFileNumber");
       lockFileNum.getParamsMap().put("fileNumberId",fileNumId ); 
       lockFileNum.execute(); 
       if(!lockFileNum.getErrors().isEmpty()){
           logger.info("***************  Error while Locking the file number *******************  "  +fileNumId);   
           showPopupInfoMsg(rb.getString("COMMENTLIST_ERR_WHILE_LOCKING_FILE_NUMBER"));
           return false ;
       }
       Boolean flag=(Boolean)lockFileNum.getResult();
       if(!flag.booleanValue()) {  
           showPopupInfoMsg(rb.getString("COMMENTLIST_FILE_NUMBER_ALREADY_LOCKED"));
           return  false; 
       }
       return true;
   }
   
   /** Updates  attachments wiith new  names generated for publishing comments
     *
     * @param attachmentNewNames
     * @return boolean
     */
   private boolean  updateNewNamesForAttachments( Map<String,String> attachmentNewNames){
           logger.info("Calling  updateAttachments custom method in  updateNewNamesForAttachments  ********************");
           //data control mehtod  has bug accepting  Map.    Conver to List
           List< Map<String,String> > list=  new ArrayList< Map<String,String> >();
           for(Map.Entry<String, String> entry : attachmentNewNames.entrySet()){ 
                Map<String,String> map = new     HashMap<String,String> ();
                 map.put(entry.getKey(), entry.getValue());
                 list.add(map);
            }    
           OperationBinding operation = ADFUtils.findOperation("updateAttachments"); 
           operation.getParamsMap().put("docs", list);
           operation.execute(); 
           if (!operation.getErrors().isEmpty()){      
                   logger.severe("Error  while updating  attachments with new names generated  !!  ******************");
                    return false; 
           }else{ 
               boolean flag=(Boolean)operation.getResult();
               if(!flag) { 
                   logger.severe("Error  while updating  attachments with new names generated  !!  ************.");
                   return false;
               }
          }  
        return true;
   }
   
   
   /**Locks the file number by adding it  to processing table
     *
     * @param fileNumberId
     */
   public void locFileumber(String fileNumberId){ 
       OperationBinding operation = ADFUtils.findOperation("lockFileNumber");
       operation.getParamsMap().put("fileNumberId",fileNumberId ); 
       operation.execute(); 
   }
   
    /**
     * Retrieves packaging dir from application properties and it is used to create packing for comments that get published 
     *
     * @return  packaging dir for comments
     */
    private String getCommentsPackagingDir(){
        OperationBinding appPropOper = ADFUtils.findOperation("getResourceBundle");
        appPropOper.execute();
        if (appPropOper.getErrors().isEmpty()){
            Map map = (Map)appPropOper.getResult();
            String dir = (String)map.get("CLL_PACKAGING_DIR");
            logger.info("CLL_PACKAGING_DIR = " + dir);
            return dir;
        } else {
            logger.severe("CLL_PACKAGING_DIR not found in application properties");
            return null;
        }
    }
    
   
    /**
     *
     * @param disablePublishButton
     */
    public void setDisablePublishButton(boolean disablePublishButton) {
        this.disablePublishButton = disablePublishButton;
    }

    public boolean isDisablePublishButton() {
        return disablePublishButton;
    }

    public void setPublishCommandButton(RichButton publishCommandButton) {
        this.publishCommandButton = publishCommandButton;
    }

    public RichButton getPublishCommandButton() {
        return publishCommandButton;
    }

   /**Verifies whether user has selected  comments to publish. 
    * If not, control goes back to UI page.
    * If comments are selected,  confirmation popup will be displayed
     *
     * @return
     */
    public String clickPublishButtonAction() {
        // Add event code here...
        ArrayList<Number>  commIds = new ArrayList<Number> ();     
        commIds=selectedComments (); 
        if(commIds.size() > 0) {
              RichPopup.PopupHints hints = new RichPopup.PopupHints();   
              getPopupPublish().show(hints); 
        }else {
            JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_PUBLISHING_NO_COMMENT_SELECTED_MSG"));
        }
        return null;
    }
   
   /** returns  warning message for popup for publishing button
    * 
    */
   public String getPublishWarningMsg(){
        ArrayList<Number>  commIds  =selectedComments(); 
        return "This file number will be locked while publishing is in process for the "+ commIds.size() +" selected comments. Do you want to continue?"; 
                                                                                             
   }


    /**Verifies whether user has selected  comments to unpublish. If not, control goes back to UI page.
      *
      * @return
      */
     public String clickUnPublishButtonAction() {
         // Add event code here...
         ArrayList<Number>  commIds = new ArrayList<Number> ();     
         commIds=selectedComments (); 
         if(commIds.size() > 0) {
               RichPopup.PopupHints hints = new RichPopup.PopupHints();   
               getPopupUnPublish().show(hints);
         } 
         return null;
     }
    
    /** Verifies whether user has selected comments to archive. If not, control goes back to UI page.
      *
      * @return
      */
     public String clickArchiveButtonAction() {
         logger.info("Archive button clicked");
         ArrayList<Number>  commIds = new ArrayList<Number> ();     
         commIds=selectedComments ();  // get selected list of comments
         if(commIds.size() > 0) {
             AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT", commIds.size());
             this.setArchiveWarnMsg( "Selected "+ commIds.size() + 
                                                " comment(s) will be archived. Do you wish to proceed? ");
             
               //RichPopup.PopupHints hints = new RichPopup.PopupHints();   
            this.getPopupArchive().show(new RichPopup.PopupHints());
         }else {
            JSFUtils.addFacesErrorMessage("Please select at least one comment to archive.");
        }
        return null;
        }

    /**
     * Dialog listener to confirm archiving of selected comment letters.
     * Clicking "Ok" from the popup, it will archive the comments
     * and refresh comment list/
     * 
     * @param dialogEvent
     */
    public void archivingDialogListener(DialogEvent dialogEvent) {
        logger.info("Start ................. archivingDialogListener, dialog outcome = " + dialogEvent.getOutcome());
        // Archive comments
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.yes) {
            setArchiving();
            
                JSFUtils.addFacesInformationMessage("Selected " +
                                                    AdfFacesContext.getCurrentInstance().getViewScope().get("COMMENTS_COUNT") +
                                                    " comment(s) archived successfully.");
            }else{
                this.getPopupArchive().cancel();
                CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                commentListTblbind.getSelectedRowKeys().removeAll();
                AdfFacesContext.getCurrentInstance().addPartialTarget(commentListTblbind);
            
            }
    }

    public void setPopupError(RichPopup popupError) {
        this.popupError = popupError;
    }

    public RichPopup getPopupError() {
        return popupError;
    }

    public void setPackaingErrorMsg(String packaingErrorMsg) {
        this.packaingErrorMsg = packaingErrorMsg;
    }

    public String getPackaingErrorMsg() {
        return packaingErrorMsg;
    }
    
    /**
     * Retrieves the tenplate content by a specific code
     *
     * @return
     */
    private String getTemplateContentByCode(String code) {
        String content = "";
        OperationBinding getTemplateContent = ADFUtils.findOperation("getTemplateContent");
        getTemplateContent.getParamsMap().put("code", code);
        getTemplateContent.execute();
        if (getTemplateContent.getErrors().isEmpty()){
            content = (String)getTemplateContent.getResult();
        }
        return content;
    }

    public void setPopupInfo(RichPopup popupInfo) {
        this.popupInfo = popupInfo;
    }

    public RichPopup getPopupInfo() {
        return popupInfo;
    }

    public void setInfoMsg(String infoMsg) {
        this.infoMsg = infoMsg;
    }

    public String getInfoMsg() {
        return infoMsg;
    }
    
    private void showPopupInfoMsg(String msg){
        infoMsg = msg;
        getPopupInfo().show(new RichPopup.PopupHints());
    }

    public void setUnPublishCommandButton(RichButton unPublishCommandButton) {
        this.unPublishCommandButton = unPublishCommandButton;
    }

    public RichButton getUnPublishCommandButton() {
        return unPublishCommandButton;
    }

    public void setPopupUnPublish(RichPopup popupUnPublish) {
        this.popupUnPublish = popupUnPublish;
    }

    public RichPopup getPopupUnPublish() {
        return popupUnPublish;
    }
    
    /**Opens a error popup with a custom message
     *
     * @param msg
     */
    private void showPopupErrorMsg(String msg){
        packaingErrorMsg = msg;
        getPopupError().show(new RichPopup.PopupHints()); 
    }
    
    
    /** Retrieves webservice proxy details such as wsdl url etc from database for publishing  comments
     *
     * @return
     */
    private boolean  retrieveWebServiceProxyDetails(){
      
        DatabaseResourceBundle dsbundle = new DatabaseResourceBundle();
        Map props = dsbundle.getResourceBundle();  
        wsdlURL = (String)props.get("PUBLISHING_COMMENTS_WSDL_URL");
        namespaceURI = (String)props.get("PUBLISHING_COMMENTS_QNAME_NAMESPACE_URI");
        localPart = (String)props.get("PUBLISHING_COMMENTS_QNAME_LOCALPART"); 
        logger.info("wsdlURL => " + wsdlURL);
        logger.info("nsURI => " + namespaceURI);
        logger.info("localPart => " + localPart);
        if(null == wsdlURL || null == namespaceURI  || null == localPart){
            logger.severe("Error   ....Proxy details are empty  !!!**************************");
            JSFUtils.addFacesErrorMessage(rb.getString("FETCHING_PROXY_DETAILS_ERROR_MSG"));     
            return false;
        }
        return true;
    }

    /**Sets  the row pointer to the one which is returned by comment details task flow
         *
         * @param returnEvent
         */
    public void commDetIdReturnListerner(ReturnEvent returnEvent) {
             logger.info("Starting commDetIdReturnListerner   *******************************"); 
             Map map=returnEvent.getReturnParameters();         
             Number  commDetId=(Number) map.get("pCommDetId") ;          
             logger.info("Comment id returned by comment details task flow : "+commDetId);
             DCIteratorBinding dcItteratorBindings = ADFUtils.findIterator("CllCommentsListROView1Iterator");
             dcItteratorBindings.setCurrentRowWithKeyValue(commDetId.toString());
             Row row  = dcItteratorBindings.getCurrentRow();
             RowKeySetImpl newRowKeySet = new RowKeySetImpl();
             ArrayList nextLst = new ArrayList(1);
             nextLst.add(row.getKey());
             newRowKeySet.add(nextLst); 
             // set the row from comment details back  in  the comment list   ADF  Table
             commentListTblbind.setSelectedRowKeys(newRowKeySet);

            AdfFacesContext.getCurrentInstance().addPartialTarget(commentListTblbind);
            logger.info("Ending commDetIdReturnListerner   *******************************");
      }
            

    public void setPopupArchive(RichPopup popupArchive) {
        this.popupArchive = popupArchive;
    }

    public RichPopup getPopupArchive() {
        return popupArchive;
    }
    
    /**Sets the currently selected row back to the same in the iterator to avoid issue with check box check getting cleared
     *
     * @param selectionEvent
     */
    public void rowSelectionListener(SelectionEvent selectionEvent) {
        logger.info("Starting rowSelectionListener in comment list tab  **********************");
        DCIteratorBinding dcItteratorBindings = ADFUtils.findIterator("CllCommentsListROView1Iterator");         
        RowKeySet rksSelectedRowsKeys = commentListTblbind.getSelectedRowKeys();   
        if(null != rksSelectedRowsKeys && !rksSelectedRowsKeys.isEmpty()){ 
           Iterator itrSelectedRows = rksSelectedRowsKeys.iterator();   
           // RowSetIterator rowSetItator = dcItteratorBindings.getRowSetIterator();             
           if (itrSelectedRows.hasNext()) { 
               Key key = (Key)((List)itrSelectedRows.next()).get(0);  
                  //if( null !=rowSetItator.getRow(key)) {  
                  //rowSetItator.setCurrentRow(row);
                   dcItteratorBindings.setCurrentRowWithKey(key.toStringFormat(true));
                   CllCommentsListROViewRowImpl  currentRow = (CllCommentsListROViewRowImpl) dcItteratorBindings.getCurrentRow();                    
                   currentRow.setSelectAttr(true);
                
           }
            
          JSFUtils.invokeMethodExpression("#{bindings.CllCommentsListROView1.collectionModel.makeCurrent}",
                                  Object.class, SelectionEvent.class,selectionEvent);
           
          logger.info("Ending rowSelectionListener in comment inbox  **********************");
           
       } 
        
    }

    /**Clear the check box for the currently selected row before opening up comment details page.
     *
     * @param ae
     */
    public void commentLinkActionLsnr(ActionEvent ae) {
        // Add event code here...
        DCIteratorBinding dcItteratorBindings = ADFUtils.findIterator("CllCommentsListROView1Iterator");         
        CllCommentsListROViewRowImpl  currentRow = (CllCommentsListROViewRowImpl) dcItteratorBindings.getCurrentRow();                    
        currentRow.setSelectAttr(false); 
        //return null;
    }
    
    /** Verifies whether user has selected comments to add/change/delete a file number. If not, throws error.
     *
     * @return
     */
    public String clickAddChgDelFileNumLinkAction() {
        logger.info("Change Action Link clicked");
        ArrayList<Number> commIds = new ArrayList<Number>();
        commIds = selectedComments(); // get selected list of comments  
        String option=(String)ADFContext.getCurrent().getRequestScope().get("fileNumOption");
        if (commIds.size() > 0) {
            //AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT", commIds.size());
            if(option.equalsIgnoreCase(ADD_FILE_NUM_ACTION)){
                         if(commIds.size()==1){
                              setFileNumPopupMsg("File Number will be added to 1 comment. Do you wish to proceed?"); 
                         }else{
                             setFileNumPopupMsg("File Number will be added to " + commIds.size() + " comments. Do you wish to proceed?"); 
                         }
                         setFileNumPopupTitle("Add a File#");
            }else if(option.equalsIgnoreCase(DELETE_FILE_NUM_ACTION)){
                        if(commIds.size()==1){
                                setFileNumPopupMsg("File Number will be removed from 1 comment. Do you wish to proceed?"); 
                        }else{
                                setFileNumPopupMsg("File Number will be removed from " + commIds.size() + " comments. Do you wish to proceed?"); 
                         }
                        setFileNumPopupTitle("Remove File#");
            }else{
                        if(commIds.size()==1){
                              setFileNumPopupMsg("File Number will be changed in 1 comments. Do you wish to proceed?"); 
                        }else{
                             setFileNumPopupMsg("File Number will be changed in " + commIds.size() + " comments. Do you wish to proceed?"); 
                         }
                        setFileNumPopupTitle("Change File#");
            }
            //store current action  in  bean CommentList  so that later we can refer it under  dialog listener 
            Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
            CommentList  commList =(CommentList )pageFlowScope.get("commentList");  
            if (null != commList) {
                    commList.setFileNumberAction(option);
                    ADFUtils.markScopeDirty(pageFlowScope);
            }
            popupFileNum.show(new RichPopup.PopupHints());   
        } else {
            if(option.equalsIgnoreCase(ADD_FILE_NUM_ACTION)){
                  JSFUtils.addFacesErrorMessage("Please select at least one comment to add a file number.");
            }else if(option.equalsIgnoreCase(DELETE_FILE_NUM_ACTION)){
                JSFUtils.addFacesErrorMessage("Please select at least one comment to remove file number.");
            }else{
                JSFUtils.addFacesErrorMessage("Please select at least one comment to change file number.");
            }
        }
        return null;
    }
     
   /** Invokes  search file number task flow when Yes button is clicked in the confirmation window
     *
     * @return
     */
    public String yesFileNumAction(){
        String option="";
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        CommentList  commList =(CommentList )pageFlowScope.get("commentList");    //task flow  bean
        popupFileNum.hide(); 
        ArrayList<Number> commIds = selectedComments();  
        if (null != commList) {
                    option=commList.getFileNumberAction();   // retrieve what action it is  -ADD,Delete, Change 
            if(option.equalsIgnoreCase(ADD_FILE_NUM_ACTION)){
                    return "searchfilenumber";
            }else if(option.equalsIgnoreCase(DELETE_FILE_NUM_ACTION)){ 
                    commList.setFileNumberAction("");   
                    ADFUtils.markScopeDirty(pageFlowScope); 
                    removeFileNum(commIds);
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                    commentListTblbind.getSelectedRowKeys().removeAll();
                    ADFUtils.refreshIterator("CllCommentsListROView1Iterator");
                    AdfFacesContext.getCurrentInstance().addPartialTarget(commentListTblbind);
                    return "";
            }else{   // change current file # 
                   return "searchfilenumber"; 
            }
            
        }       
        return "";
                           
    }
   
    /**  Delete file number from each of the comment
      *
      * @param commIds
      * @param commIds
      */
     private void removeFileNum(List<Number> commIds){
         
         Number fileNumId= (Number) AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pFileNumId"); 
         OperationBinding opb = ADFUtils.findOperation("removeFileNumFromComments"); 
         opb.getParamsMap().put("commIds",commIds );   
         opb.getParamsMap().put("fileNumid",fileNumId );   
         opb.execute();  
         if(opb.getErrors().isEmpty()){
                 if(ADFUtils.doCommit()) {  
                     logger.info("File number ID has been successfully  removed from  the comments  ***********"); 
                     if(commIds.size() ==1) {
                         JSFUtils.addFacesInformationMessage("File# has been removed from " + commIds.size()  +  " comment successfully" );
                     }else{
                         JSFUtils.addFacesInformationMessage("File# has been removed from " + commIds.size()  +  " comments successfully" );
                     } 
                     
                 } else { 
                        JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_UNABLE_TO_REMOVE_FILE_NUMBER_MSG"));
                        Boolean b = ADFUtils.doRollback();
                        return  ;
                 }
         }else{
             JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_UNABLE_TO_REMOVE_FILE_NUMBER_MSG"));
             logger.info(" ERROR ****** while changing file number  in bulk selection  ****************** " );
             logger.info("" +opb.getErrors()); 
             Boolean b = ADFUtils.doRollback();
         }
         
         
     }
    
    /**Clears  the bulk selection if user do not want to  proceed with bulk selection
     *
     * @return
     */
    public String  noFileNumAction(){
        
        CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
        commentListTblbind.getSelectedRowKeys().removeAll();
        return "";
    }
    
   
    
    /**Retrieves  return parameter MasterFileNumberDTO from search file# task flow  or create file# task flow.
     * 
     */
     public void returnFromSearchOrCreateFileNum(ReturnEvent returnEvent) {
         logger.info("Starting  returnFromSearchOrCreateFileNum in CommentListBean***************************"); 
         Number fileNumId=CllUtils.getMasterFileNumberIdFromDTO(CllConstants.ORIGINATION_COMMENT_LIST_TAB);  //DTO is  in the task flow bean
         if(null ==fileNumId){
             CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
             commentListTblbind.getSelectedRowKeys().removeAll();
             AdfFacesContext.getCurrentInstance().addPartialTarget(commentListTblbind);
             return; 
         } 
         Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
         CommentList  commList =(CommentList )pageFlowScope.get("commentList");  
         String option=commList.getFileNumberAction();   // retrieve what action it is  -ADD,Delete, Change 
         commList.setFileNumberAction("");
         ADFUtils.markScopeDirty(pageFlowScope);
         ArrayList<Number> commIds = new ArrayList<Number>();
         commIds = selectedComments(); // get selected list of comments  
         ReturnMasterFileNumberDTO masterFileNumDTO= commList.getReturnMasterFileNumDTO();  
         if(option.equalsIgnoreCase(ADD_FILE_NUM_ACTION)){
           CllUtils.addFileNumToComments(  commIds,  fileNumId, masterFileNumDTO.getFileNumberTypeCode(), masterFileNumDTO.getAvailable(), masterFileNumDTO.getMasterFileNumberId(), CllConstants.ORIGINATION_COMMENT_LIST_TAB);
             
         }else {   // else it is to change current file#
              Number fileNumIdOld= (Number) AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pFileNumId");
              CllUtils.changeFileNumInComments(  commIds, fileNumIdOld,  fileNumId); 
         }
         CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
         commentListTblbind.getSelectedRowKeys().removeAll();
         ADFUtils.refreshIterator("CllCommentsListROView1Iterator");
         AdfFacesContext.getCurrentInstance().addPartialTarget(commentListTblbind);
         
     }
    
    
    /**
     * Finds the file number type id by code
     * 
     * @param code  File Numner Type Code
     * @return  File Number Type Id
     */
    private Number findFileNumberTypeId(String code){
        logger.info("Starting findFileNumberTypeId  in ViewCommentDetails.java *************");
        OperationBinding operation = ADFUtils.findOperation("getFileNumberTypeId");
        operation.getParamsMap().put("code", code);
        operation.execute();
        if (operation.getErrors().isEmpty()){
            Number fileNumTypeId = (Number)operation.getResult();
            logger.info("Found File Number Type Id : " + fileNumTypeId);
            logger.info("Ending findFileNumberTypeId  in ViewCommentDetails.java *************");
            return fileNumTypeId;
        } else {
            logger.severe("Error on finding File Number Type Id for code : " + code, operation.getErrors());
            logger.info("Ending findFileNumberTypeId  in ViewCommentDetails.java *************");
            return null;
        }
    }
    
    public void chgActionCommentActionLstnr(ActionEvent actionEvent) {
        logger.info("Entering Change Action Method.");
        Map inputMap = new HashMap();
        String actionType = null;
        String action =
            (String)AdfFacesContext.getCurrentInstance().getViewScope().get("action");
        String dispTypeCode = null;
        
        //Get fileNumTypeCode
        String fileNumber = JSFUtils.resolveExpressionAsString("#{pageFlowScope.pFileTypeFileNumber}");
        String str[] = fileNumber.split(DASH);
        String fileNumTypeCode = str[0];
        logger.info("CommentListBean.chgActionCOmmetnActionLstnr :: Action : " + action);
        logger.info("CommentListBean.chgActionCOmmetnActionLstnr :: fileNumber : " + fileNumber);
        logger.info("CommentListBean.chgActionCOmmetnActionLstnr :: fileNumTypeCode : " + fileNumTypeCode);
        
        //Get fileNumId
        DCIteratorBinding commentROIter = ADFUtils.findIterator("CllCommentsListROView1Iterator");
        CllCommentsListROViewRowImpl commentRow = (CllCommentsListROViewRowImpl)commentROIter.getCurrentRow();
        Number fileNumId = commentRow.getFilenumId();
        logger.info("CommentListBean.chgActionCOmmetnActionLstnr :: filenumId : " + fileNumId);

        if (StringUtils.isNotBlank(action) && "ACTION".equals(action)) {
            actionType = "Action";
            DCIteratorBinding ActnTypeIter =
                ADFUtils.findIterator("CllActionTypeROView1Iterator");
            CllActionTypeROViewRowImpl ActnTypeRow =
                (CllActionTypeROViewRowImpl)ActnTypeIter.getCurrentRow();
            Number actnTypeId = ActnTypeRow.getCllActionTypeId();
            inputMap.put("CllActionTypeId", actnTypeId);
        } else if (StringUtils.isNotBlank(action) && "FINAL_ACTION".equals(action)) {
            actionType = "Final Action";
            DCIteratorBinding dispTypeIter = ADFUtils.findIterator("CllDispositionTypeROView1Iterator");
            CllDispositionTypeROViewRowImpl dispTypeRow = (CllDispositionTypeROViewRowImpl)dispTypeIter.getCurrentRow();
            dispTypeCode = dispTypeRow.getCode();
            logger.info("CommentListBean.chgActionCOmmetnActionLstnr :: fileNumTypeCode : " + dispTypeCode);

            //Validation for required Final Action Other Desc
            if (!StringUtils.trimToEmpty(dispTypeCode).isEmpty() &&
                CllConstants.CLL_DISPOSITION_TYPE_OTH.equals(dispTypeCode) &&
                StringUtils.trimToEmpty(getCllFinalActionOtherDesc()).isEmpty()) {
                return;
            }
            
            Number dispTypeId = dispTypeRow.getCllDispositionTypeId();
            inputMap.put("CllDispositionTypeId", dispTypeId);
            inputMap.put("DispTypeCode", dispTypeRow.getCode());
            inputMap.put("OtherDisposition", this.getCllFinalActionOtherDesc());
            inputMap.put("fileNumTypeCode", fileNumTypeCode);
            inputMap.put("fileNumId", fileNumId);
        } else if (StringUtils.isNotBlank(action) &&
                   "COMMENT".equals(action)) {
            actionType = "Comment Type";
            DCIteratorBinding commentTypeIter =
                ADFUtils.findIterator("CllTypeROView2Iterator");
            CllTypeROViewRowImpl commentTypeRow =
                (CllTypeROViewRowImpl)commentTypeIter.getCurrentRow();
            Number cllTypeId = commentTypeRow.getCllTypeId();
            String cllTypeCode = commentTypeRow.getCode();
            inputMap.put("CllTypeId", cllTypeId);
            inputMap.put("CllTypeCode", cllTypeCode);
            inputMap.put("CllTypeOtherDesc", this.getCllTypeOtherDesc());
        } else if (StringUtils.isNotBlank(action) && "SOURCE".equals(action)) {
            actionType = "Source Type";
            DCIteratorBinding sourceTypeIter =
                ADFUtils.findIterator("CllSourceTypeROView1Iterator");
            
            CllSourceTypeROViewRowImpl sourceTypeRow =
                (CllSourceTypeROViewRowImpl)sourceTypeIter.getCurrentRow();
            Number sourceTypeId = sourceTypeRow.getCllSourceTypeId();
            String sourceCode = sourceTypeRow.getCode();
            inputMap.put("sourceTypeId", sourceTypeId);
            inputMap.put("sourceTypeCode", sourceCode);
            

        }
        OperationBinding opb =
            ADFUtils.findOperation("updateSelectedActiontoComments");
        opb.getParamsMap().put("action", action);
        opb.getParamsMap().put("inputMap", inputMap);
        opb.execute();
        this.getPopupChgAction().cancel();
        
        if(opb.getErrors().isEmpty()){
            //Add send notification for Final Action Approve
            sendNotification(action, dispTypeCode);
            
            JSFUtils.addFacesInformationMessage(actionType+" changed in " +
                                                AdfFacesContext.getCurrentInstance().getViewScope().get("COMMENTS_COUNT") +
                                                " comments successfully.");
        } else {
            ADFUtils.doRollback(); 
            logger.severe(opb.getErrors().toString());
            JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_ERROR_UPDATING_BULK_ACTION")  );
        }
        
        CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
        commentListTblbind.getSelectedRowKeys().removeAll();
        ADFUtils.refreshIterator("CllCommentsListROView1Iterator");
        AdfFacesContext.getCurrentInstance().addPartialTarget(commentListTblbind);

    }
    
    /**
     * Send notification 
     *
     * @param action
     * @param dispTypeCode
     */
    private void sendNotification(String action, String dispTypeCode){
        logger.info(String.format("CommentsListBean.sendNotification :: action : %s - Disp Code : %s", action,
                                         dispTypeCode));
        if (StringUtils.isNotBlank(action) && "FINAL_ACTION".equals(action) &&
            CllConstants.CLL_DISPOSITION_TYPE_APPR.equals(dispTypeCode)) {
            
            DCIteratorBinding dcIter = ADFUtils.findIterator("CllCommentsListROView1Iterator");
            RowSetIterator rowSetIter = dcIter.getRowSetIterator();
            RowKeySet keySet = commentListTblbind.getSelectedRowKeys();
            System.out.println("Total selected comments : " + keySet.size());
            Iterator selectedIter = keySet.iterator();
            if (keySet.size() > 0){
                
                //Get application properties
                OperationBinding appPropOper = ADFUtils.findOperation("getResourceBundle");
                appPropOper.execute();
                if (!appPropOper.getErrors().isEmpty()){
                    logger.severe("There was ane error retrieving application properties for sending notitification. ERROR : " +
                                  appPropOper.getErrors());
                    JSFUtils.addFacesErrorMessage(rb.getString("There was ane error retrieving application properties for sending notitification. Please contact the System Administrator."));
                    return;
                } else {
                    //Retrieve application properties for notification
//                    Map props = (Map)appPropOper.getResult();
//                    String wsdlURL = (String)props.get("NOTIFICATION_WSDL_URL");
//                    String nsURI = (String)props.get("NOTIFICATION_QNAME_NAMESPACE_URI");
//                    String localPart = (String)props.get("NOTIFICATION_QNAME_LOCALPART");
//                    logger.info("wsdlURL => " + wsdlURL);
//                    logger.info("nsURI => " + nsURI);
//                    logger.info("localPart => " + localPart);
                                        
                    //Iterate throught the selected keys and make current each comment by Key
                    boolean isEmailSent = false;
                    while(selectedIter.hasNext()){
                        ForwardCommentDTO forwardComment = new ForwardCommentDTO();
                        
                        Key key = (Key)((List)selectedIter.next()).get(0);
                        System.out.println("Key => " + key);
                        CllCommentsListROViewRowImpl row = (CllCommentsListROViewRowImpl)rowSetIter.getRow(key);
                        Number cllCommDetId = row.getCllCommDetId();
                        System.out.println("CommentsListBean.sendNotification :: CllCommDetId : " + cllCommDetId);
                        
                        //Send Notification and update forward info ONLY if this is null
                        String forwardedTo = StringUtils.trimToEmpty(row.getForwardedTo());
                        logger.info("CommentListBean.sendNotification :: Current comment forwardedTo : " + forwardedTo);
                        if (!forwardedTo.isEmpty()){
                            continue;
                        }

                        //Search for CllCommentDetailsView1 by cllCommDetId
                        //Set current row to have it ready for all following binding operations which use it.
                        //Reusing same operations used in CommentDetails
                        OperationBinding operBind = ADFUtils.findOperation("retrieveCommentDetaisbyId");
                        operBind.getParamsMap().put("commentDetId", cllCommDetId);
                        operBind.execute();

                        //Retrieving the required email receipient list for the comment
                        logger.info("Retrieve email recipients for Comment Id : " + cllCommDetId);
                        List<EmailRecipientDTO> emailRecipienList = new ArrayList<EmailRecipientDTO>();
                        OperationBinding operation = ADFUtils.findOperation("retrieveMultipleFilenumRecipientList");
                        operation.getParamsMap().put("commDetId", cllCommDetId);
                        operation.execute();
                        if (!operation.getErrors().isEmpty()) {
                            logger.severe("There was ane error retrieving recipient list for commment Id : " + cllCommDetId);
                            logger.severe("ERROR : " + operation.getErrors());
                            //FORCE TO CONTINUE TO THE NEXT COMMENT ID FOR SENDING NOTIFICATION
                            continue;
                        } else {
                            emailRecipienList = (List<EmailRecipientDTO>)operation.getResult();
                            if (!CollectionUtils.isNotEmpty(emailRecipienList)){
                                logger.info(rb.getString("VIEWCOMMENTDETAILS_NO_RECIPIENT_MSG") + " :: CllCommDetId : " + cllCommDetId);
                                JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTDETAILS_NO_RECIPIENT_MSG"));
                                break;
                            } else {
                                String emailTo = getRecipients(emailRecipienList);
                                String emailSubject = "";
                                String emailContent = "";
                                                                
                                OperationBinding op = ADFUtils.findOperation("prepareViewForwardCommentData");  
                                op.execute();
                                if (!op.getErrors().isEmpty()) {
                                    logger.severe("There was an error preparing notification request for comment id : " + cllCommDetId);
                                    continue;
                                } else {
                                    forwardComment = (ForwardCommentDTO)op.getResult();
                                    emailSubject = StringUtils.trimToEmpty(forwardComment.getSubject());
                                    emailContent = StringUtils.trimToEmpty(forwardComment.getComment());
                                    
                                    logger.info("to => " + emailTo);
                                    logger.info("subject => " + emailSubject);
                                    logger.info("content => " + emailContent);
                                    
                                    EmailRequestDTO request = new EmailRequestDTO();
                                    request.setToEmailAddress(emailTo);
                                    request.setSubject(emailSubject);
                                    request.setBody(emailContent);
                                    request.setDocIdList(getSelectedDocIds(cllCommDetId));
                                    //EmailResponseDTO response = wrapper.sendEmailNotification(request);
                                    NotificationUtils notifUtils = new NotificationUtils();
                                    EmailResponseDTO response = notifUtils.sendEmail(request);
                                    
                                    //Update comment with forward info
                                    if (response.getStatus().equalsIgnoreCase(CllConstants.PROXY_STATUS_SUCCESS)) {
                                        isEmailSent = (isEmailSent || true); //to know at least one email sent
                                        String fwdTo = this.getForwardedTo(emailRecipienList);
                                        OperationBinding operUpdFwd = ADFUtils.findOperation("updateCommentForwardInfo");
                                        operUpdFwd.getParamsMap().put("commentDetId", cllCommDetId);
                                        operUpdFwd.getParamsMap().put("fwdTo", fwdTo);
                                        operUpdFwd.execute();
                                    }
                                }
                            }
                        }
                    }
                    if (isEmailSent){
                        JSFUtils.addFacesInformationMessage(rb.getString("VIEWCOMMENTDETAILS_EMAIL_SENT_MSG"));
                    } 
                }
            }    
        }
    }
    
    /** Return the email recipients from emailRecipientList
     * 
     */
    private String getRecipients(List<EmailRecipientDTO> emailRecipienList){
        StringBuffer recipients = new StringBuffer();
        for (EmailRecipientDTO dto : emailRecipienList){
            if (recipients.toString().length() > 0){
                recipients.append(";");    
            }
            recipients.append(dto.getEmail());
        }
        return recipients.toString();
    }
    
    /** Return the email forwarded to from emailRecipientList
     * 
     */
    public String getForwardedTo(List<EmailRecipientDTO> emailRecipienList){
        StringBuffer recipients = new StringBuffer();
        for (EmailRecipientDTO dto : emailRecipienList){
            recipients.append(dto.getFirstName());
            recipients.append(" "); 
            recipients.append(dto.getLastName());
            recipients.append(", ");
            logger.info("Getting recipient " + dto.getFirstName() + " " + dto.getLastName());
            }
        int stLength = StringUtils.lastIndexOf(recipients.toString(),',');
        String stFwdTo = recipients.toString().substring(0, stLength);
        return stFwdTo;
    }
    
    /**
     * Returns the selected doc Ids from the Attachment table to be included in the Notification.
     *
     * @return  String list of document (UCM)Ids
     */
    private List<String> getSelectedDocIds(Number commId){
        logger.info("Starting getSelectedDocIds  ******************** ");
        List<String> docIdList = new ArrayList<String>();
        
        OperationBinding operation = ADFUtils.findOperation("getSelectedDocIds");
        operation.getParamsMap().put("caseId", commId);
        operation.getParamsMap().put("modName", CllConstants.CLL_MODULE);
        operation.execute();
        if (operation.getErrors().isEmpty()){
            docIdList = (ArrayList)operation.getResult();
        }  
        logger.info("Ending getSelectedDocIds  ******************** ");
        return docIdList;
    }    
    
     /** Verifies whether user has selected comments to add/change/delete a file number. If comments are selected, it will display confirmation message. 
      * If not, throws error.
      *
      * @return
      */
    public String clickChgActionLinkAction() {
        logger.info("Change Action Link clicked");
        ArrayList<Number> commIds = new ArrayList<Number>();
        commIds = selectedComments(); // get selected list of comments
        if (commIds.size() > 0) {
            AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT", commIds.size());
            this.setActnChgWarnMsg("Action will be changed in " +
                                   commIds.size() +
                                   " comments. Do you wish to proceed?");
            this.getPopupChgActionWarnMsg().show(new RichPopup.PopupHints());
        } else {
            JSFUtils.addFacesErrorMessage("Please select at least one comment to change Action.");
        }
        return null;
    }
     
    /**
     * Verify if user has selected comments. If comments are selected, it will display confirmation message. 
     * If not, throws error.
     * 
     * @return
     */
    public String clickChgFinalActionLinkAction() {
        logger.info("Change Final Action Link clicked");
        ArrayList<Number> commIds = new ArrayList<Number>();
        commIds = selectedComments(); // get selected list of comments
        if (commIds.size() > 0) {
            AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT", commIds.size());
            this.setActnChgWarnMsg("Final Action will be changed in " +
                                   commIds.size() +
                                   " comments. Do you wish to proceed?");
            this.getPopupChgActionWarnMsg().show(new RichPopup.PopupHints());
        } else {
            JSFUtils.addFacesErrorMessage("Please select at least one comment to change Final Action.");
        }
        return null;
    }     

    public void chgActionPpDialogLstnr(DialogEvent dialogEvent) {
        logger.info("Start ................. ChgActionDialogListener, dialog outcome = " +
                    dialogEvent.getOutcome());
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.yes) {
            String action =
                (String)AdfFacesContext.getCurrentInstance().getViewScope().get("action");
            if (StringUtils.isNotBlank(action) && "ACTION".equals(action)) {
                ADFUtils.refreshIterator("CllActionTypeROView1Iterator");
                this.setChgActionPopUpTitle("Select Action Type");
                this.setChgActionMsg("Please select Action Type to be updated in the selected comments.");
            } else if (StringUtils.isNotBlank(action) && "FINAL_ACTION".equals(action)) {
                ADFUtils.refreshIterator("CllDispositionTypeROView1Iterator");
                this.setChgActionPopUpTitle("Select Final Action Type");
                this.setChgActionMsg("Please select Final Action Type to be updated in the selected comments.");               
            } else if (StringUtils.isNotBlank(action) &&
                       "COMMENT".equals(action)) {
                ADFUtils.refreshIterator("CllTypeROView2Iterator");
                this.setChgActionPopUpTitle("Select Comment Type");
                this.setChgActionMsg("Please select Comment Type to be updated in the selected comments.");
            } else if (StringUtils.isNotBlank(action) &&
                       "SOURCE".equals(action)) {
                ADFUtils.refreshIterator("CllSourceTypeROView1Iterator"); 
                this.setChgActionPopUpTitle("Select Source Type");
                this.setChgActionMsg("Please select Source Type to be updated in the selected comments.");
            }
            this.getPopupChgAction().show(new RichPopup.PopupHints());
        } else {
            this.getPopupChgActionWarnMsg().cancel();
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            commentListTblbind.getSelectedRowKeys().removeAll();
            AdfFacesContext.getCurrentInstance().addPartialTarget(commentListTblbind);
        }
    }

    public void setPopupChgAction(RichPopup popupChgAction) {
        this.popupChgAction = popupChgAction;
    }

    public RichPopup getPopupChgAction() {
        return popupChgAction;
    }

    public void cancelChgActionCommentActnLstnr(ActionEvent actionEvent) {
        this.getPopupChgAction().cancel();
        CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
        commentListTblbind.getSelectedRowKeys().removeAll();
        AdfFacesContext.getCurrentInstance().addPartialTarget(commentListTblbind);
    }

    public void setPopupChgActionWarnMsg(RichPopup popupChgActionWarnMsg) {
        this.popupChgActionWarnMsg = popupChgActionWarnMsg;
    }

    public RichPopup getPopupChgActionWarnMsg() {
        return popupChgActionWarnMsg;
    }

    public void setActnChgWarnMsg(String actnChgWarnMsg) {
        this.actnChgWarnMsg = actnChgWarnMsg;
    }

    public String getActnChgWarnMsg() {
        return actnChgWarnMsg;
    }

    public void setArchiveWarnMsg(String archiveWarnMsg) {
        this.archiveWarnMsg = archiveWarnMsg;
    }

    public String getArchiveWarnMsg() {
        return archiveWarnMsg;
    }

    public String clickChgCommentTypeAction() {
        logger.info("Change Action Link clicked");
        ArrayList<Number> commIds = new ArrayList<Number>();
        commIds = selectedComments(); // get selected list of comments
        if (commIds.size() > 0) {
            AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT", commIds.size());
            this.setActnChgWarnMsg("Comment Type will be changed in " +
                                   commIds.size() +
                                   " comments. Do you wish to proceed?");
            this.getPopupChgActionWarnMsg().show(new RichPopup.PopupHints());
        } else {
            JSFUtils.addFacesErrorMessage("Please select at least one comment to change Comment Type.");
        }
        return null;
    }

    public String clickChgSourceTypeAction() {
        logger.info("Change Source Link clicked");
        ArrayList<Number> commIds = new ArrayList<Number>();
        commIds = selectedComments(); // get selected list of comments
        if (commIds.size() > 0) {
            AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT", commIds.size());
            this.setActnChgWarnMsg("Source Type will be changed in " +
                                   commIds.size() +
                                   " comments. Do you wish to proceed?");
            this.getPopupChgActionWarnMsg().show(new RichPopup.PopupHints());
        } else {
            JSFUtils.addFacesErrorMessage("Please select at least one comment to change Source Type.");
        }
        return null;
    }
    
    
    public void setChgActionPopUpTitle(String chgActionPopUpTitle) {
        this.chgActionPopUpTitle = chgActionPopUpTitle;
    }

    public String getChgActionPopUpTitle() {
        return chgActionPopUpTitle;
    }

    public void setChgActionMsg(String chgActionMsg) {
        this.chgActionMsg = chgActionMsg;
    }

    public String getChgActionMsg() {
        return chgActionMsg;
    }

    public void setCllTypeOtherDesc(String cllTypeOtherDesc) {
        this.cllTypeOtherDesc = cllTypeOtherDesc;
    }

    public String getCllTypeOtherDesc() {
        return cllTypeOtherDesc;
    }
    
    public void setCllFinalActionOtherDesc(String cllFinalActionOtherDesc) {
        this.cllFinalActionOtherDesc = cllFinalActionOtherDesc;
    }

    public String getCllFinalActionOtherDesc() {
        return cllFinalActionOtherDesc;
    }

    public void setPopupFileNum(RichPopup popupFileNum) {
        this.popupFileNum = popupFileNum;
    }

    public RichPopup getPopupFileNum() {
        return popupFileNum;
    }

    public void setFileNumPopupTitle(String fileNumPopupTitle) {
        this.fileNumPopupTitle = fileNumPopupTitle;
    }

    public String getFileNumPopupTitle() {
        return fileNumPopupTitle;
    }

    public void setFileNumPopupMsg(String fileNumPopupMsg) {
        this.fileNumPopupMsg = fileNumPopupMsg;
    }

    public String getFileNumPopupMsg() {
        return fileNumPopupMsg;
    }

    public void setADD_FILE_NUM_ACTION(String ADD_FILE_NUM_ACTION) {
        this.ADD_FILE_NUM_ACTION = ADD_FILE_NUM_ACTION;
    }

    public String getADD_FILE_NUM_ACTION() {
        return ADD_FILE_NUM_ACTION;
    }

    public void setCHANGE_FILE_NUM_ACTION(String CHANGE_FILE_NUM_ACTION) {
        this.CHANGE_FILE_NUM_ACTION = CHANGE_FILE_NUM_ACTION;
    }

    public String getCHANGE_FILE_NUM_ACTION() {
        return CHANGE_FILE_NUM_ACTION;
    }

    public void setDELETE_FILE_NUM_ACTION(String DELETE_FILE_NUM_ACTION) {
        this.DELETE_FILE_NUM_ACTION = DELETE_FILE_NUM_ACTION;
    }

    public String getDELETE_FILE_NUM_ACTION() {
        return DELETE_FILE_NUM_ACTION;
    }
    
    
    // CASSECDEV-6085 : CASSECDEV-6117 : Changes for File Number Publishing
    public void clickFileNumPublishButtonAL(ActionEvent actionEvent) {
        ArrayList<Number>  commIds = new ArrayList<Number>();     
        commIds = selectedComments(); 
        logger.info("In clickFileNumPublishButtonAL... commIds size "+commIds.size());
        RichPopup.PopupHints hints = new RichPopup.PopupHints();
        if(commIds.size() > 0) {
            getPopupfileNumPublishWithComments().show(hints); 
            logger.info("In clickFileNumPublishButtonAL... fileNumPublish with selected comments");
        } else {
            getPopupfileNumPublish().show(hints);
        }
    }
    
    /**  Prepares the File Number Published comments that are publishing.
     * @param dialogEvent
     */
    public void fileNumPublishDL(DialogEvent dialogEvent) {
        logger.info("Starting  fileNumPublishDL  ********************");
        //If 'No' is clicked, do not publish the Comment letter
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.no) {
            return;
        }
        popupfileNumPublish.hide();
        fileNumerPublishAction(Boolean.FALSE);
        logger.info("Ending  fileNumPublishDL  ********************");
    }
    
    /**  Prepares the File Number Publish with selected comments that are publishing.
     * @param dialogEvent
     */
    public void fileNumPublishWithCommentsDL(DialogEvent dialogEvent){
        logger.info("Starting  fileNumPublishWithCommentsDL  ********************");
        //If 'No' is clicked, do not publish the Comment letter
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.no) {
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            commentListTblbind.getSelectedRowKeys().removeAll();
            return;
        }
        popupfileNumPublishWithComments.hide();
        fileNumerPublishAction(Boolean.TRUE);
        logger.info("Ending  fileNumPublishWithCommentsDL  ********************");
    }
    
    private void fileNumerPublishAction(boolean selectCommentsFlag){
        String fileTypeFileNumber = (String)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pFileTypeFileNumber");
        Number fileNumId = (Number)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pFileNumId");
        logger.info("In fileNumPublishDL... fileTypeFileNumber:"+fileTypeFileNumber+"  fileNumId:"+fileNumId+"  selectCommentsFlag: "+selectCommentsFlag);
        try {            
            Map<Number, ArrayList<String>> fileNumPubCommentAttachments = new HashMap<Number, ArrayList<String>>();
            Map<Number, ArrayList<String>> commentAttachments = new HashMap<Number, ArrayList<String>>();
            ArrayList<Number> fileNumPubCommIds = new ArrayList<Number>();
            ArrayList<Number> commIds = new ArrayList<Number>();
            String updatedFileNumber = fileTypeFileNumber.replaceAll("-", "").trim();
            updatedFileNumber = StringUtils.lowerCase(updatedFileNumber);
            updatedFileNumber = CllUtils.removeSpecialCharsFromFileFolderName(updatedFileNumber);
            logger.info("File number after removing  special characters *************** is : " +updatedFileNumber);
            
            RichPopup.PopupHints hints = new RichPopup.PopupHints();
            // Get File Number Publish Comment Id List
            OperationBinding fileNumCommList = ADFUtils.findOperation("getFileNumPublishCommentIdList");
            fileNumCommList.execute();
            if (!fileNumCommList.getErrors().isEmpty()) {
                logger.info("***************  Error while retriving the file number publish comments *******************  " + fileNumId);
                packaingErrorMsg = rb.getString("COMMENTLIST_ERR_WHILE_GET_FILE_NUMBER_PUB_COMMENTS");
                getPopupError().show(hints);
                if(selectCommentsFlag){
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                    commentListTblbind.getSelectedRowKeys().removeAll();
                }
                return;
            }
            fileNumPubCommIds = (ArrayList<Number>) fileNumCommList.getResult();
            logger.info("In fileNumerPublishAction... fileNumCommList.. size."+fileNumPubCommIds.size()+"     Ids:"+fileNumPubCommIds);
            if (fileNumPubCommIds == null || fileNumPubCommIds.size() == 0) {
                packaingErrorMsg = rb.getString("COMMENTLIST_ERR_NO_FILE_NUMBER_PUB_COMMENTS");
                getPopupError().show(hints);
                if(selectCommentsFlag){
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                    commentListTblbind.getSelectedRowKeys().removeAll();
                }
                return;
            }
            
            
            //let's lock the file number  so that  someone else will not start working on the comments while publishing is in progress
            OperationBinding lockFileNum = ADFUtils.findOperation("lockFileNumberRetInt");
            lockFileNum.getParamsMap().put("fileNumberId", fileNumId);
            lockFileNum.execute();
            if (!lockFileNum.getErrors().isEmpty()) {
                logger.info("***************  Error while Locking the file number *******************  " + fileNumId);
                packaingErrorMsg = rb.getString("COMMENTLIST_ERR_WHILE_LOCKING_FILE_NUMBER");
                getPopupError().show(hints);
                fileNumPubCommentAttachments = null;
                commentAttachments = null;
                if(selectCommentsFlag){
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                    commentListTblbind.getSelectedRowKeys().removeAll();
                }
                return;
            }
            //System.out.println("In fileNumerPublishAction.... lockFileNum : "+lockFileNum +" lockFileNum.getResult():"+lockFileNum.getResult());
            Integer fileLockFlag = (Integer)lockFileNum.getResult();
            //System.out.println("In fileNumerPublishAction.... fileLockFlag: "+fileLockFlag);
            if (fileLockFlag == 0) {
                packaingErrorMsg = rb.getString("COMMENTLIST_FILE_NUMBER_ALREADY_LOCKED");
                getPopupError().show(hints);
                fileNumPubCommentAttachments = null;
                commentAttachments = null;
                if(selectCommentsFlag){
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                    commentListTblbind.getSelectedRowKeys().removeAll();
                }
                return;
            }
                        
            String fileNumDownloadLocation = getCommentsPackagingDir();
            if (null == fileNumDownloadLocation) {
                logger.severe("***************  Error while retrieving application property CLL_PACKAGING_DIR from database *******************");
                showPopupErrorMsg(rb.getString("COMMENTLIST_UNABLE_TO_CREATE_TEMP_DIR_FOR_PACKAGING"));
                unlockFileNumber(fileNumId);
                if(selectCommentsFlag){
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                    commentListTblbind.getSelectedRowKeys().removeAll();
                }
                return;
            }
            logger.info("In fileNumerPublishAction... fileNumDownloadLocation:"+fileNumDownloadLocation);
            Map<String, String> fileNumPubMap = new HashMap<String, String>();
            fileNumPubMap = createTempDirForFileNumPub(fileNumDownloadLocation, updatedFileNumber);
            if (null == fileNumPubMap) {
                showPopupErrorMsg(rb.getString("COMMENTLIST_UNABLE_TO_CREATE_TEMP_DIR_FOR_PACKAGING"));
                unlockFileNumber(fileNumId);
                if(selectCommentsFlag){
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                    commentListTblbind.getSelectedRowKeys().removeAll();
                }
                return;
            }
            String fileNumPubSubDir = fileNumPubMap.get("subDir"); // fileNumPubSubDir is with full path.  Ex: cas_documents/cll_packaging/318120_file_num_pub_comments_2020.11.27.16.54.25
            //  It is already filtered from special characters
            String fileNumPubSubDirName = fileNumPubMap.get("subDirName"); // fileNumPubSubDirName is name of the subdir. Ex : 318120_file_num_pub_comments_2020.11.27.16.54.25
            logger.info("In fileNumerPublishAction... fileNumPubSubDir:"+fileNumPubSubDir+"   fileNumPubSubDirName:"+fileNumPubSubDirName);
            
            // Packaging selected comments to publish
            // CASSUP-1753 : Commenting below logic to not package selected comments to publish
            /*if(selectCommentsFlag){
                logger.severe("In fileNumerPublishAction..  ###### Packaging selected comments to publish ");
                commIds=selectedComments();    //control does not even come here if commIds is  empty. 
                logger.info("In fileNumerPublishAction... selectedComments.. commIds size."+commIds.size()+"     Ids:"+commIds);
                String downloadLocation = fileNumPubSubDir.substring(0, fileNumPubSubDir.length()-1);   
                if(null == downloadLocation){ 
                    logger.info("***************  Error while retrieving application property CLL_PACKAGING_DIR from database *******************"); 
                    showPopupErrorMsg(rb.getString("COMMENTLIST_UNABLE_TO_CREATE_TEMP_DIR_FOR_PACKAGING"));   
                    unlockFileNumber( fileNumId);
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                    commentListTblbind.getSelectedRowKeys().removeAll();
                    return  ;
                }
                Map<String,String> map = new HashMap<String,String>();
                map=createTempDir(downloadLocation,updatedFileNumber ,true); 
                if(null == map) { 
                    showPopupErrorMsg(rb.getString("COMMENTLIST_UNABLE_TO_CREATE_TEMP_DIR_FOR_PACKAGING"));
                    unlockFileNumber( fileNumId);
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                    commentListTblbind.getSelectedRowKeys().removeAll();
                    return ;    
                }
                String subDir=map.get("subDir");  // subDir is with full path.  Ex: cas_documents/cll_packaging/10222_pub_comments_2016.11.29.11.10.52
                                                  //  It is already filtered from special characters
                String subDirName=map.get("subDirName");  // subDirName is name of the subdir. Ex : 10222_pub_comments_2016.11.29.11.10.52
                                                          //  It is already filtered from special characters
                logger.info("In fileNumerPublishAction... subDir:"+subDir+"   subDirName:"+subDirName);
                // download attachments for selected processed status comments
                commentAttachments=downloadAttachments(commIds,subDir,fileNumId,updatedFileNumber); 
                if(null == commentAttachments) {
                    unlockFileNumber( fileNumId);
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                    commentListTblbind.getSelectedRowKeys().removeAll();
                    return ;     
                }
                // Generate files and package for selected processed status comments.
                boolean flag = generatePackageForComments(commIds,commentAttachments, fileNumId,fileTypeFileNumber,
                                                     downloadLocation,subDir,subDirName, Boolean.TRUE);
                if(!flag){
                    unlockFileNumber( fileNumId);
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                    commentListTblbind.getSelectedRowKeys().removeAll();
                    return;
                }
                
                // Zip the selected comments publish package
                String zipFileName=PackageUtils.createCommentLetterZIP(downloadLocation, subDirName); //downloadLocation is ../cas_documents/cll_packaging/318120_file_num_pub_comments_2020.11.27.16.54.25
                if(null ==zipFileName){
                    logger.info(" Error   generating  zip file for publishing comments  *****************"); 
                    showPopupErrorMsg(rb.getString("COMMENTLIST_ERROR_GENERATING_ZIPFLLE_FOR_COMMENTS"));
                    unlockFileNumber( fileNumId);
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                    commentListTblbind.getSelectedRowKeys().removeAll();
                    return ;
                }
                 
                // update  status for  comments  as published
                String commIdsStr=getCommDelemitedCommIds(commIds);
                OperationBinding operation = ADFUtils.findOperation("updateStatusForPublishedComments");
                operation.getParamsMap().put("commentIds",commIdsStr );
                operation.execute();
                if(!operation.getErrors().isEmpty()){
                   logger.info("***************  Error while updating comment status as published  *******************");
                   showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_UPDATING_COMMENTS_AS_PUBLISHED"));  
                   unlockFileNumber( fileNumId);
                   CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                   commentListTblbind.getSelectedRowKeys().removeAll();
                   return ;
                }
                if(null ==  operation.getResult() ||  (Integer)operation.getResult() ==0 ){  //method returns count for updated rows
                  logger.info("***************  Error while updating comment status as published  *******************");
                  showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_UPDATING_COMMENTS_AS_PUBLISHED"));
                  unlockFileNumber( fileNumId);
                  CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                  commentListTblbind.getSelectedRowKeys().removeAll();
                  return ;
                }
            } */
            
            // Download attachments for published status comments
            fileNumPubCommentAttachments = downloadAttachments(fileNumPubCommIds, fileNumPubSubDir, fileNumId, updatedFileNumber);
            if (null == fileNumPubCommentAttachments) {
                unlockFileNumber(fileNumId);
                if(selectCommentsFlag){
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator"); 
                    commentListTblbind.getSelectedRowKeys().removeAll();
                }
                return;
            }
            // Generate files and package for published status comments.
            boolean successFlag = generatePackageForComments(fileNumPubCommIds,fileNumPubCommentAttachments, fileNumId, fileTypeFileNumber,
                                                 fileNumDownloadLocation, fileNumPubSubDir, fileNumPubSubDirName, Boolean.TRUE);
            logger.info("In fileNumerPublishAction.... generatePackageForComments   flag:"+successFlag);
            if (!successFlag) {
                unlockFileNumber(fileNumId);
                if(selectCommentsFlag){
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                    commentListTblbind.getSelectedRowKeys().removeAll();
                }
                return; 
            }
            logger.info("In fileNumerPublishAction.... fileNumDownloadLocation:"+fileNumDownloadLocation+"   fileNumPubSubDirName:"+fileNumPubSubDirName);
            
            // Zip the file number publish package
            String zipFileName=PackageUtils.createCommentLetterZIP(fileNumDownloadLocation, fileNumPubSubDirName); //fileNumDownloadLocation is ../cas_documents/cll_packaging
            if(null ==zipFileName){
                logger.info(" Error   generating  zip file for publishing comments  *****************"); 
                showPopupErrorMsg(rb.getString("COMMENTLIST_ERROR_GENERATING_ZIPFLLE_FOR_COMMENTS"));
                unlockFileNumber(fileNumId);
                if(selectCommentsFlag){
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                    commentListTblbind.getSelectedRowKeys().removeAll();
                }
                return;
            }
            //  upload the file number publish package into UCM
            successFlag = uploadZipToUCM(fileNumDownloadLocation, zipFileName,fileNumId, true);
            if(!successFlag){
                logger.info(" Error checking in  publishing package zip file into UCM and in database *****************"); 
                showPopupErrorMsg(rb.getString("COMMENTLIST_ERROR_CHECKING_ZIPFLLE_FOR_COMMENTS"));
                unlockFileNumber(fileNumId);
                if(selectCommentsFlag){
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                    commentListTblbind.getSelectedRowKeys().removeAll();
                }
                return;
            }
            
            //checked into UCM
            if (ADFUtils.doCommit()) {
                if (commIds.size() > 1) {
                    showPopupInfoMsg("The selected " + commIds.size() +
                                     " comments are published with file number successfully. Open the Published Packages Queue to download the package.");
                } else {
                    showPopupInfoMsg("The selected file number is published successfully. Open the Published Packages Queue to download the package.");
                }
                unlockFileNumber(fileNumId);
            } else {
                logger.info("***************  Error while committing comment log *******************  ");
                showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_PERSISTING_PUBLISHED_COMMENTS"));
                unlockFileNumber(fileNumId);
            }
            
            if(selectCommentsFlag){
                CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                commentListTblbind.getSelectedRowKeys().removeAll();
                AdfFacesContext.getCurrentInstance().addPartialTarget(commentListTblbind);
            }
        } catch (Exception e) {
            logger.severe("In fileNumerPublishAction... Exception:"+e.getMessage(), e);
            showPopupErrorMsg(rb.getString("COMMENTLIST_ERR_WHILE_PERSISTING_PUBLISHED_COMMENTS"));
            unlockFileNumber(fileNumId);
            if(selectCommentsFlag){
                CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                commentListTblbind.getSelectedRowKeys().removeAll();
            }
        }
    }
    
    
    
    /**Creates  temporary dir for File Number packaging comments
     *
     * @param downloadLocation
     * @return 
     */
    private  Map  createTempDirForFileNumPub(String downloadLocation, String updatedFileNumber){ 
        logger.info("Starting  createTempDir  ********************");
        Map<String,String> map = new HashMap<String,String>();
        RichPopup.PopupHints hints = new RichPopup.PopupHints(); 
        String subDir=null; 
        String subDirName=null;  
        //create  tmp folder  
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
        subDir=downloadLocation+updatedFileNumber+COMMENT_LETTER_FILE_NUM_PUB_SUBSTR+timeStamp+"//";
        subDirName=updatedFileNumber+COMMENT_LETTER_FILE_NUM_PUB_SUBSTR+timeStamp; 
        map.put("subDir",subDir);
        map.put("subDirName",subDirName );
        File tempDir = new File(subDir);
        boolean createDir=tempDir.mkdir(); 
        if(!createDir){
            logger.info("***************  Error while creating packaging dir  "  +subDir + ".  It may exist already  **************" );  
            packaingErrorMsg=rb.getString("COMMENTLIST_ERR_WHILE_CREATING_TEMP_DIR");
            getPopupError().show(hints); 
            return null ;
        }
        logger.info("***************  Created   tmp  dir     *******************");   
        logger.info("Ending  createTempDir  ********************");
       return map; 
    }

    public void setPopupfileNumPublish(RichPopup popupfileNumPublish) {
        this.popupfileNumPublish = popupfileNumPublish;
    }

    public RichPopup getPopupfileNumPublish() {
        return popupfileNumPublish;
    }

    public void setPopupfileNumPublishWithComments(RichPopup popupfileNumPublishWithComments) {
        this.popupfileNumPublishWithComments = popupfileNumPublishWithComments;
    }

    public RichPopup getPopupfileNumPublishWithComments() {
        return popupfileNumPublishWithComments;
    }
}
