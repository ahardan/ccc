package gov.sec.cll.view.beans;

import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;

import gov.sec.cll.sharedcomponents.view.utils.JSFUtils;

import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import javax.faces.event.ValueChangeEvent;

import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.binding.OperationBinding;

public class searchFileNumbers {
    public searchFileNumbers() {
    }

    public void selectedFileClickActionLstnr(ActionEvent actionEvent) {
        Number fileNumberId = (Number)AdfFacesContext.getCurrentInstance().getViewScope().get("fileNumberId");
        UIComponent component = actionEvent.getComponent();
        Map<String, Object> attributes = component.getAttributes();
        attributes.put("fileNumberId", fileNumberId);
        attributes.put("SearchFileNumbers", "FILENUMBERS");
        ADFUtils.processActionEvent(actionEvent, "viewFileNumberDetailsEventBinding");
    }

    public void searchActionListner(ActionEvent actionEvent) {
        String fileNum =
            (String)ADFUtils.evaluateEL("#{bindings.FileNumber.inputValue}");
        String relNum =
            (String)ADFUtils.evaluateEL("#{bindings.ReleaseNumber.inputValue}");
        String sub =
            (String)ADFUtils.evaluateEL("#{bindings.Subject.inputValue}");
        Integer fileType =
            (Integer)ADFUtils.evaluateEL("#{bindings.FileType.inputValue}");
        String lName =
            (String)ADFUtils.evaluateEL("#{bindings.LastName.inputValue}");
        String fName =
            (String)ADFUtils.evaluateEL("#{bindings.FirstName.inputValue}");
        String aPhone =
            (String)ADFUtils.evaluateEL("#{bindings.AttorneyPhone.inputValue}");
        if (null == fileNum && null == relNum && null == sub &&
            null == lName && null == fName && null == aPhone) {
            JSFUtils.addFacesErrorMessage("Please enter at least one search field. For file number, please ensure that file type is selected.");
        } else if (null != fileNum && fileType == 0) {
            JSFUtils.addFacesErrorMessage("Please select valid File Number Type");
        } else if (null == fileNum && fileType != 0) {
            JSFUtils.addFacesErrorMessage("Please select valid File Number");
        } else {
            this.searchFileNumbers(fileType);
        }
    }
    
    public void searchFileNumbers(Integer fileType){
        OperationBinding opb = ADFUtils.findOperation("searchFileNumbers");
        opb.getParamsMap().put("index", fileType);
        opb.execute();
    }

    public void resetActionListner(ActionEvent actionEvent) {
        ADFUtils.findOperation("resetFileNumberSearch").execute();
    }

    public void fileTypeValueChangeListner(ValueChangeEvent valueChangeEvent) {
        valueChangeEvent.getComponent().processUpdates(FacesContext.getCurrentInstance());
        if (valueChangeEvent.getNewValue().equals(0)) {
            ADFUtils.setBoundAttributeValue("FileNumber", null);
            AdfFacesContext.getCurrentInstance().getViewScope().put("fileType",
                                                                    null);
        } else {
            AdfFacesContext.getCurrentInstance().getViewScope().put("fileType",
                                                                    valueChangeEvent.getNewValue());
        }
    }
}
