package gov.sec.cll.view.beans;

import gov.sec.cas.sharedcomponents.view.dto.SubmitterDTO;
import gov.sec.cll.sharedcomponents.view.dto.ReleaseNumberDTO;

import oracle.jbo.domain.Number;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

public class FileNumberBean implements Serializable {
    @SuppressWarnings("compatibility:-1503288151716084018")
    private static final long serialVersionUID = 1L;
    
    private List<SubmitterDTO> newSubmitters = new ArrayList<SubmitterDTO>();
    private Number fileNumberId;
    private List<ReleaseNumberDTO> newReleaseNumbers = new ArrayList<ReleaseNumberDTO>();
    
    public FileNumberBean() {
        super();
    }

    public void setNewSubmitters(List<SubmitterDTO> newSubmitters) {
        this.newSubmitters = newSubmitters;
    }

    public List<SubmitterDTO> getNewSubmitters() {
        return newSubmitters;
    }

    public void setFileNumberId(Number fileNumberId) {
        this.fileNumberId = fileNumberId;
    }

    public Number getFileNumberId() {
        return fileNumberId;
    }

    public void setNewReleaseNumbers(List<ReleaseNumberDTO> newReleaseNumbers) {
        this.newReleaseNumbers = newReleaseNumbers;
    }

    public List<ReleaseNumberDTO> getNewReleaseNumbers() {
        return newReleaseNumbers;
    }
}
