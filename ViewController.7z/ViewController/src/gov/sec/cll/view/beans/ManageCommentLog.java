package gov.sec.cll.view.beans;


import java.io.Serializable;

import oracle.jbo.domain.Number;


public class ManageCommentLog implements Serializable{

    @SuppressWarnings("compatibility:732127876095552819")
    private static final long serialVersionUID = 1L;

    public ManageCommentLog() {
        super();
    }
    
    private Number fileNumId;
    private String fileTypeFileNumber;   // we need it to dislay on comment page even before loading the page
    private String origination;
    private Number commentDetId;
    private String search;
    private String subType;
    private Number formLetterId;
    private String typeCode;
    private String dispCode;

    public void setFileNumId(Number fileNumId) {
        this.fileNumId = fileNumId;
    }

    public Number getFileNumId() {
      //  this.fileNumId = new Number(2);
        return fileNumId;
    }

    public void setOrigination(String origination) {
        this.origination = origination;
    }

    public String getOrigination() {
        return origination;
    }

    public void setCommentDetId(Number commentDetId) {
        this.commentDetId = commentDetId;
    }

    public Number getCommentDetId() {  
     // this.commentDetId=new Number(51);  //TODO  remove this  later   Form letter
        //this.commentDetId=new Number(65);
        return commentDetId;
    }


    public void setFileTypeFileNumber(String fileTypeFileNumber) {
        this.fileTypeFileNumber = fileTypeFileNumber;
    }

    public String getFileTypeFileNumber() {
        return fileTypeFileNumber;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    public String getSearch() {
        return search;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }

    public String getSubType() {
        return subType;
    }

    public void setFormLetterId(Number formLetterId) {
        this.formLetterId = formLetterId;
    }

    public Number getFormLetterId() {
        return formLetterId;
    }

    public void setTypeCode(String typeCode) {
        this.typeCode = typeCode;
    }

    public String getTypeCode() {
        return typeCode;
    }

    public void setDispCode(String dispCode) {
        this.dispCode = dispCode;
    }

    public String getDispCode() {
        return dispCode;
    }
}

