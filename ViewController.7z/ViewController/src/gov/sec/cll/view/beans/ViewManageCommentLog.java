package gov.sec.cll.view.beans;

import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;

import gov.sec.cll.view.dc.ManageCommntLogDC;

import javax.faces.event.ActionEvent;

import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.component.rich.nav.RichLink;
import oracle.adf.view.rich.event.DialogEvent;

public class ViewManageCommentLog {
     

    public ViewManageCommentLog() {
        super();
    }
    
    
   
}
