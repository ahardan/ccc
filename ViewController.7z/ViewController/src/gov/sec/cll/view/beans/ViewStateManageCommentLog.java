package gov.sec.cll.view.beans;


import gov.sec.cll.sharedcomponents.view.bundles.DatabaseResourceBundle;
import gov.sec.cll.sharedcomponents.view.utils.ADFUtils; 
import gov.sec.cll.sharedcomponents.view.utils.JSFUtils;
import gov.sec.cll.view.utils.CllConstants;

import java.io.Serializable;

import java.util.Map;

import oracle.adf.controller.TaskFlowId;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.context.AdfFacesContext;
import oracle.adf.view.rich.event.RegionNavigationEvent;
import javax.faces.context.FacesContext;

import javax.faces.event.ActionEvent;
import oracle.jbo.Transaction;

import org.apache.myfaces.trinidad.render.ExtendedRenderKitService;
import org.apache.myfaces.trinidad.util.Service;

public class ViewStateManageCommentLog implements Serializable {
    @SuppressWarnings("compatibility:-7139580972484166560")
    private static final long serialVersionUID = 1L;

    public ViewStateManageCommentLog() {
        super();
    }
    
    private String taskFlowId ;
    private String origination;
    private Number commentDetId;
    
    private final String COMMENT_INBOX_TF_ID = "/WEB-INF/gov/sec/cll/view/taskflows/comment-inbox-btf.xml#comment-inbox-btf";
    private final String FILENUMBER_QDETAILS_TF_ID = "/WEB-INF/gov/sec/cll/view/taskflows/filenumber-qdetails-btf.xml#filenumber-qdetails-btf";
    private final String COMMENT_DETAILS_TF_ID=  "/WEB-INF/gov/sec/cll/view/taskflows/comment-details-btf.xml#comment-details-btf";
    private final String MISSING_FILENUMB_QUEUE_TF_ID=  "/WEB-INF/gov/sec/cll/view/taskflows/missimg-filenumber-qlist-btf.xml#missimg-filenumber-qlist-btf";
    private final String CREATE_FILENUMB_TF_ID=  "/WEB-INF/gov/sec/cll/view/taskflows/create-filenumber-btf.xml#create-filenumber-btf";
    private final String DELETED_COMMENTS_QUEUE_TF_ID = "/WEB-INF/gov/sec/cll/view/taskflows/deleted-comments-qlist-btf.xml#deleted-comments-qlist-btf";
    private final String SEARCH_COMMENTS_TF_ID = "/WEB-INF/gov/sec/cll/view/taskflows/search-comments-btf.xml#search-comments-btf";
    private final String SEARCH_FILENUMBER_TF_ID = "/WEB-INF/gov/sec/cll/view/taskflows/search-filenumber-btf.xml#search-filenumber-btf";
    private final String INTERNAL_SECQ_TF_ID = "/WEB-INF/gov/sec/cll/view/taskflows/internal-secq-btf.xml#internal-secq-btf";
    private final String PUBLISHING_QUEUE_TF_ID = "/WEB-INF/gov/sec/cll/view/taskflows/publishing-queue-btf.xml#publishing-queue-btf";
    private final String FILE_NUMBER_PUBLISHING_QUEUE_TF_ID = "/WEB-INF/gov/sec/cll/view/taskflows/filenumber-pub-queue-btf.xml#filenumber-pub-queue-btf";
    private final String FILENUMBER_PUBLISHING_QDETAILS_TF_ID = "/WEB-INF/gov/sec/cll/view/taskflows/filenumber-pub-qdetails-btf.xml#filenumber-pub-qdetails-btf";
 
    private static ADFLogger logger =
        ADFLogger.createADFLogger(ViewStateManageCommentLog.class);
    
    /**
     * Passes the task flow id to dynamic region binding.
     *
     * @return
     */ 
    public TaskFlowId getDynamicTaskFlowId() {
        if (taskFlowId == null){  
             taskFlowId = COMMENT_INBOX_TF_ID; 
             
        }
        return TaskFlowId.parse(taskFlowId);
    }

    public void setTaskFlowId(String taskFlowId) {
        this.taskFlowId = taskFlowId;
    }

    public String getTaskFlowId() {
        return taskFlowId;
    }
    
    /**
     * Assigns the Comment Inbox task flow id to dynamic region
     *
     * @return
     */
    public String commentInboxClickAction() {
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        ManageCommentLog manageLog = (ManageCommentLog)pageFlowScope.get("manageCommentLog"); 
        manageLog.setOrigination("");   //initialize  this so that old data will not cause issue
        manageLog.setTypeCode(CllConstants.CLL_STATUS_TYPE_CODE_UPRO);
        manageLog.setDispCode(null);
        ADFUtils.markScopeDirty(pageFlowScope);
        if (pendingChangesExist()) {
            Boolean rollbackSuccess = ADFUtils.doRollback(); 
            logger.info("Rollback success ? "+rollbackSuccess); 
        }
       taskFlowId = COMMENT_INBOX_TF_ID; 
       return null;
    }
    
    public String publishingQueue(){
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        ManageCommentLog manageLog = (ManageCommentLog)pageFlowScope.get("manageCommentLog");
        manageLog.setOrigination("");  //initialize  this so that old data will not cause issue
        if(pendingChangesExist()){
            Boolean rollbackSuccess = ADFUtils.doRollback(); 
            logger.info("Rollback success ? "+rollbackSuccess); 
        }
        manageLog.setTypeCode(CllConstants.CLL_STATUS_TYPE_CODE_PRO);
        manageLog.setDispCode(CllConstants.CLL_DISPOSITION_TYPE_APPR);
        ADFUtils.markScopeDirty(pageFlowScope);
        taskFlowId = COMMENT_INBOX_TF_ID; 
        return null;
    }
    
    public String fileNumberPublishingQueue() {
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        ManageCommentLog manageLog = (ManageCommentLog)pageFlowScope.get("manageCommentLog");
        if(pendingChangesExist()){
            Boolean rollbackSuccess = ADFUtils.doRollback(); 
            logger.info("Rollback success ? "+rollbackSuccess); 
        }
        manageLog.setOrigination(CllConstants.ORIGINATION_FROM_FILE_NUMBER_PUB);  //initialize  this so that old data will not cause issue
        manageLog.setTypeCode(CllConstants.CLL_STATUS_TYPE_CODE_PRO);
        manageLog.setDispCode(CllConstants.CLL_DISPOSITION_TYPE_APPR);
        ADFUtils.markScopeDirty(pageFlowScope);
        taskFlowId = FILE_NUMBER_PUBLISHING_QUEUE_TF_ID; 
        return null;
    }
    
    public String unPublishingQueue(){
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        ManageCommentLog manageLog = (ManageCommentLog)pageFlowScope.get("manageCommentLog");
        manageLog.setOrigination("");  //initialize  this so that old data will not cause issue
        if(pendingChangesExist()){
            Boolean rollbackSuccess = ADFUtils.doRollback(); 
            logger.info("Rollback success ? "+rollbackSuccess); 
        }
        manageLog.setTypeCode(CllConstants.CLL_STATUS_TYPE_CODE_PUB);
        manageLog.setDispCode(CllConstants.CLL_DISPOSITION_TYPE_APPR);
        ADFUtils.markScopeDirty(pageFlowScope);
        taskFlowId = COMMENT_INBOX_TF_ID; 
        return null;
    }

    /**  
     * Assigns the Missing File Number Comment List task flow id to dynamic region 
     * @return
     */
     public String MissingFileNumberQueueClickAction() {
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        ManageCommentLog manageLog = (ManageCommentLog)pageFlowScope.get("manageCommentLog");
        manageLog.setOrigination("");  //initialize  this so that old data will not cause issue
        ADFUtils.markScopeDirty(pageFlowScope);
        if (pendingChangesExist()) {
            Boolean rollbackSuccess = ADFUtils.doRollback(); 
            logger.info("Rollback success ? "+rollbackSuccess); 
        } 
       taskFlowId = MISSING_FILENUMB_QUEUE_TF_ID; 
       return null;
    } 
    
    /**
     * Assigns the Internal To Sec Comment List task flow id to dynamic region 
     * @return
     */
     public String InternalToSecCommentsClickAction(){
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        ManageCommentLog manageLog = (ManageCommentLog)pageFlowScope.get("manageCommentLog");
        manageLog.setOrigination("");  //initialize  this so that old data will not cause issue
        ADFUtils.markScopeDirty(pageFlowScope);
        if(pendingChangesExist()){
            Boolean rollbackSuccess = ADFUtils.doRollback(); 
            logger.info("Rollback success ? "+rollbackSuccess); 
        }
        taskFlowId = INTERNAL_SECQ_TF_ID; 
        return null;
    } 
    
    /**
        * Assigns the Deleted Comment List task flow id to dynamic region
        *
        * @return
        */
       public String deletedCommentsQueueClickAction() {
           Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
           ManageCommentLog manageLog = (ManageCommentLog)pageFlowScope.get("manageCommentLog");
           manageLog.setOrigination(CllConstants.ORIGINATION_DELETED_Q);  //initialize  this so that old data will not cause issue
           ADFUtils.markScopeDirty(pageFlowScope);
           if (pendingChangesExist()) {
               Boolean rollbackSuccess = ADFUtils.doRollback(); 
               logger.info("Rollback success ? "+rollbackSuccess); 
           }
          taskFlowId = DELETED_COMMENTS_QUEUE_TF_ID; 
          return null;
       }
    
    
    /**
        * Brings up task flow having Publishing packages UI page
        *
        * @return
        */
       public String publishingQueueClickAction() {
           Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
           ManageCommentLog manageLog = (ManageCommentLog)pageFlowScope.get("manageCommentLog");
           manageLog.setOrigination("");  //initialize  this so that old data will not cause issue
           ADFUtils.markScopeDirty(pageFlowScope);
           if (pendingChangesExist()) {
               Boolean rollbackSuccess = ADFUtils.doRollback(); 
               logger.info("Rollback success ? "+rollbackSuccess); 
           } 
          taskFlowId = PUBLISHING_QUEUE_TF_ID; 
          return null;
       }
    
    
    /**
     * Assigns the File# Q details task flow id to dynamic region
     *
     * @return
     */
    public String fileNumberQDetailsBTF(){ 
        taskFlowId = FILENUMBER_QDETAILS_TF_ID;  
        return null;
    }
    
    public String commentDetailsBTF(){ 
        taskFlowId = COMMENT_DETAILS_TF_ID;  
        return null;
    }
    
    public String fileNumberDetailsBTF(){
        taskFlowId = CREATE_FILENUMB_TF_ID;  
        return null;
    }

    public void setOrigination(String origination) {
        this.origination = origination;
    }

    public String getOrigination() {
        return origination;
    }

    public void setCommentDetId(Number commentDetId) {
        this.commentDetId = commentDetId;
    }

    public Number getCommentDetId() {
        return commentDetId;
    }
    
    
    
    public String newFileNumbeClickAction(){
        if (pendingChangesExist()) {
            Boolean rollbackSuccess = ADFUtils.doRollback(); 
            logger.info("Rollback success ? "+rollbackSuccess); 
        } 
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        ManageCommentLog manageLog = (ManageCommentLog)pageFlowScope.get("manageCommentLog");
        manageLog.setFileNumId(null);
        manageLog.setOrigination("");
        ADFUtils.markScopeDirty(pageFlowScope);
        taskFlowId = CREATE_FILENUMB_TF_ID;
        return null;
    }
    
    public String searchCommentsClickAction(){
        if (pendingChangesExist()) {
            Boolean rollbackSuccess = ADFUtils.doRollback(); 
            logger.info("Rollback success ? "+rollbackSuccess); 
        } 
        AdfFacesContext.getCurrentInstance().getPageFlowScope().put("search", null);
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        ManageCommentLog manageLog = (ManageCommentLog)pageFlowScope.get("manageCommentLog");
        manageLog.setOrigination("");
        ADFUtils.markScopeDirty(pageFlowScope);
        taskFlowId = SEARCH_COMMENTS_TF_ID;
        return null;
    }
    
    public String searchFileNumberClickAction(){
        if (pendingChangesExist()) {
            Boolean rollbackSuccess = ADFUtils.doRollback(); 
            logger.info("Rollback success ? "+rollbackSuccess); 
        } 
        AdfFacesContext.getCurrentInstance().getPageFlowScope().put("search", null);
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        ManageCommentLog manageLog = (ManageCommentLog)pageFlowScope.get("manageCommentLog");
        manageLog.setOrigination("");
        ADFUtils.markScopeDirty(pageFlowScope);
        taskFlowId = SEARCH_FILENUMBER_TF_ID;
        return null;
    }

    public void dynamicTFRegNavLstnr(RegionNavigationEvent regionNavigationEvent) {
        if(regionNavigationEvent.getNewViewId() == null){
            Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
            ManageCommentLog manageLog = (ManageCommentLog)pageFlowScope.get("manageCommentLog");
            String search = manageLog.getSearch();
            manageLog.setSearch(null);
            if(null != search && search.equals("COMMENTS")){
                AdfFacesContext.getCurrentInstance().getPageFlowScope().put("search", search);
                taskFlowId = SEARCH_COMMENTS_TF_ID;
            }else if(null != search && search.equals("FILENUMBERS")){
                AdfFacesContext.getCurrentInstance().getPageFlowScope().put("search", search);
                taskFlowId = SEARCH_FILENUMBER_TF_ID;
            }else{
            taskFlowId = COMMENT_INBOX_TF_ID; 
            }
        }
    }
    
    private Transaction getCommentLogDataCntrlTrx(){
        return ADFUtils.getApplicationModuleForDataControl("CommentLogAppModuleDataControl").getTransaction();
    }
    
    private boolean pendingChangesExist(){
        return this.getCommentLogDataCntrlTrx().isDirty();
    }
    

    /**
     * Open CLL Online Help in a new window 
     */
    public void onlineHelp(ActionEvent actionEvent) {    
        DatabaseResourceBundle dsbundle = new DatabaseResourceBundle();
        Map map = dsbundle.getResourceBundle();  
        if(null==map || map.size() <=0) {
            // if at least one property is not fetched that means, issue with fetching properties from database
            JSFUtils.addFacesErrorMessage("Unable to retrieve UCM properties. Please contact System Administrator.");
            //gov.sec.cas.common.view.utils.JSFUtils.addFacesErrorMessage(rb.getString("Template.online_help_action.errFetchingDBProperties"));
        }
        
        String url = (String)map.get("ONLINE_HELP_CLL_URL")+ map.get("ONLINE_HELP_CLL_DOCNAME");
        String result = "window.open('"+url+ "');";    
        FacesContext fcs = FacesContext.getCurrentInstance();
        ExtendedRenderKitService service = Service.getRenderKitService(fcs, ExtendedRenderKitService.class);
        service.addScript(fcs, result);
    }

    public void newCommentClickAction(ActionEvent actionEvent) {
        if(pendingChangesExist()){
            Boolean rollbackSuccess = ADFUtils.doRollback(); 
            logger.info("Rollback success ? "+rollbackSuccess); 
            this.commentInboxClickAction();
        }
    }
    
    /**
     * Assigns the File# Publisher Q details task flow id to dynamic region
     *
     * @return
     */
    public String fileNumberPubQDetailsBTF(){ 
        taskFlowId = FILENUMBER_PUBLISHING_QDETAILS_TF_ID;  
        return null;
    }
}
