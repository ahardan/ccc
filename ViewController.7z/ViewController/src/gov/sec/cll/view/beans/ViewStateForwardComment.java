package gov.sec.cll.view.beans;


import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;
import gov.sec.cll.view.dto.EmailRecipientDTO;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import java.util.Map;

import oracle.adf.share.logging.ADFLogger;

import oracle.binding.OperationBinding;

public class ViewStateForwardComment implements Serializable {
    
    private static ADFLogger logger = ADFLogger.createADFLogger(ViewStateForwardComment.class);
    
    public ViewStateForwardComment() {
        super();
    }
    
    public String getDocURL(){
        StringBuffer buffer = new StringBuffer();
        Map map = new HashMap();
        OperationBinding operation = ADFUtils.findOperation("getResourceBundle");
        operation.execute();
        if (operation.getErrors().isEmpty()){
            map = (Map)operation.getResult();
            String docURL = (String)map.get("DOC_URL");
            logger.info("DocURL => " + docURL);
            buffer.append(docURL);
        }
        return buffer.toString();
    }
    
}
