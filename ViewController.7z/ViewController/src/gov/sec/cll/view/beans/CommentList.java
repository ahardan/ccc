package gov.sec.cll.view.beans;

import gov.sec.rellog.filenumber.view.dto.ReturnMasterFileNumberDTO;

import java.io.Serializable;

import oracle.adf.share.logging.ADFLogger;

public class CommentList implements Serializable{
    public CommentList() {
        super();
    }
    
    private static ADFLogger logger = ADFLogger.createADFLogger(ViewStateCommentDetails.class);
    private ReturnMasterFileNumberDTO returnMasterFileNumDTO;
    private String fileNumberAction;

    public void setReturnMasterFileNumDTO(ReturnMasterFileNumberDTO returnMasterFileNumDTO) {
        this.returnMasterFileNumDTO = returnMasterFileNumDTO;
    }

    public ReturnMasterFileNumberDTO getReturnMasterFileNumDTO() {
        return returnMasterFileNumDTO;
    }

    public void setFileNumberAction(String fileNumberAction) {
        this.fileNumberAction = fileNumberAction;
    }

    public String getFileNumberAction() {
        return fileNumberAction;
    }
}
