package gov.sec.cll.view.beans;

import gov.sec.cll.model.adfbc.views.FileNumberPubQueueROViewRowImpl;
import gov.sec.cll.model.adfbc.views.FileNumberQueueROViewRowImpl;
import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;

import gov.sec.cll.sharedcomponents.view.utils.JSFUtils;

import gov.sec.cll.view.utils.CllConstants;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.component.UIComponent;
import javax.faces.event.ActionEvent;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.component.rich.data.RichTable;

import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.jbo.Key;
import oracle.jbo.domain.Number;

import org.apache.myfaces.trinidad.event.SelectionEvent;
import org.apache.myfaces.trinidad.model.RowKeySet;

/**
 * Backing bean that supports ViewFileNUmberPubQueue fragment
 *
 */
public class ViewFileNumberPubQueue {

    private static ADFLogger logger = ADFLogger.createADFLogger(ViewFileNumberPubQueue.class);
    private static final ResourceBundle rb = ResourceBundle.getBundle(CllConstants.RESOURCE_BUNDLE_LOCATION);
    private RichTable fileNumberTable;

    public ViewFileNumberPubQueue() {
        super();
    }

    public void rowSelectionListener(SelectionEvent selectionEvent) {
        logger.info("Starting rowSelectionListener in ViewFileNumberPubQueue  **********************");
        DCIteratorBinding dcItteratorBindings = ADFUtils.findIterator("FileNumberPubQueueROView1Iterator");         
        RowKeySet rksSelectedRowsKeys = fileNumberTable.getSelectedRowKeys();  
        if(null != rksSelectedRowsKeys && !rksSelectedRowsKeys.isEmpty()){ 
           Iterator itrSelectedRows = rksSelectedRowsKeys.iterator();   
           // RowSetIterator rowSetItator = dcItteratorBindings.getRowSetIterator();             
           if (itrSelectedRows.hasNext()) { 
               Key key = (Key)((List)itrSelectedRows.next()).get(0);  
                  //if( null !=rowSetItator.getRow(key)) {  
                  //rowSetItator.setCurrentRow(row);
                   dcItteratorBindings.setCurrentRowWithKey(key.toStringFormat(true));
                   FileNumberPubQueueROViewRowImpl  currentRow = (FileNumberPubQueueROViewRowImpl) dcItteratorBindings.getCurrentRow();                    
                   currentRow.setSelectRowTransAttr(true);
                   logger.info("File number inside Row Selection listener  is : "+currentRow.getFilenumber());
           }
           
        } 
          
        JSFUtils.invokeMethodExpression("#{bindings.bindings.FileNumberPubQueueROView1.collectionModel.makeCurrent}",
                                  Object.class, SelectionEvent.class,selectionEvent);

        logger.info("Ending rowSelectionListener in ViewFileNumberPubQueue  **********************");
    }

    public void setFileNumberTable(RichTable fileNumberTable) {
        this.fileNumberTable = fileNumberTable;
    }

    public RichTable getFileNumberTable() {
        return fileNumberTable;
    }

    public void fileNumLinkActionListener(ActionEvent actionEvent) {
        //logger.info("Starting  fileNumLinkActionListener in ViewCommentInbox ******************");
        DCIteratorBinding dcBindIter = ADFUtils.findIterator("FileNumberPubQueueROView1Iterator"); 
        FileNumberPubQueueROViewRowImpl currentRow = (FileNumberPubQueueROViewRowImpl)dcBindIter.getCurrentRow();
        if(null != currentRow.getAttribute("Processing")){
            JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTINBOX_FILE_CANOT_OPEN_MSG")); 
            return;
        } 
        Number fileNumId = currentRow.getFilenumId(); 
        
        String fileTypeFileNumber=currentRow.getFilenumber();
        
        logger.info("In fileNumLinkActionListener..  fileNumId:" + fileNumId+"  fileTypeFileNumber:"+fileTypeFileNumber);
        UIComponent component = actionEvent.getComponent();
        Map<String, Object> attributes = component.getAttributes();
        attributes.put("fileNumId", fileNumId);
        attributes.put("fileTypeFileNumber", fileTypeFileNumber);
        attributes.put("dispCode", AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pDispCode"));
        attributes.put("origination", CllConstants.ORIGINATION_FROM_FILE_NUMBER_PUB);
        
        ADFUtils.processActionEvent(actionEvent, "viewFileNumPubEventBinding");
        //logger.info("Ending  fileNumLinkActionListener in ViewCommentInbox ******************");
    }
}
