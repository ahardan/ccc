package gov.sec.cll.view.beans;

import gov.sec.cll.model.adfbc.views.CllFilenumCommDetViewRowImpl;

import javax.faces.component.UIComponent;
import javax.faces.event.ActionEvent;
import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;

import gov.sec.cll.sharedcomponents.view.utils.JSFUtils;
import gov.sec.cll.model.adfbc.views.FileNumberQueueROViewRowImpl; 
import gov.sec.cll.view.utils.CllConstants;
import gov.sec.cll.view.utils.CllUtils;

import java.util.Iterator;
import java.util.List;
import java.util.Map; 
import java.util.ResourceBundle; 
import javax.faces.event.ValueChangeEvent; 
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger; 
import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.input.RichSelectBooleanCheckbox;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.binding.OperationBinding; 
import oracle.jbo.JboException;
import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.domain.Number;

import org.apache.myfaces.trinidad.event.SelectionEvent;
import org.apache.myfaces.trinidad.model.RowKeySet;


public class ViewCommentInbox {
    private RichTable fileNumberTable;
    private RichTable queuesTable;
     

    public ViewCommentInbox() {
        super();
    }
    private static ADFLogger logger = ADFLogger.createADFLogger(ViewCommentInbox.class);
    private static final ResourceBundle rb =
                ResourceBundle.getBundle(CllConstants.RESOURCE_BUNDLE_LOCATION);
    /**
     *
     * @param actionEvent
     */
    public void viewFileNumberActionLsnr(ActionEvent actionEvent) { 
        // Add event code here...
        logger.info("Starting  viewFileNumberActionLsnr in ViewCommentInbox ******************");
        DCIteratorBinding dcBindIter = ADFUtils.findIterator("FileNumberQueueROView1Iterator"); 
        FileNumberQueueROViewRowImpl currentRow = (FileNumberQueueROViewRowImpl)dcBindIter.getCurrentRow();
        logger.info("Selected file number in the command link action  ******************  is "+currentRow.getFilenumber());
        if(null != currentRow.getAttribute("Processing")){
            JSFUtils.addFacesErrorMessage(rb.getString("VIEWCOMMENTINBOX_FILE_CANOT_OPEN_MSG")); 
            return;
        } 
        Number fileNumId = currentRow.getFilenumId(); 
        
        String fileTypeFileNumber=currentRow.getFilenumber();
        
        logger.info("Selected File Number Id in the command link action  ****************** = " + fileNumId);
        
        UIComponent component = actionEvent.getComponent();
        Map<String, Object> attributes = component.getAttributes();
        attributes.put("fileNumId", fileNumId);
        attributes.put("fileTypeFileNumber", fileTypeFileNumber);
//        attributes.put("typeCode", AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pTypeCode"));
        attributes.put("dispCode", AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pDispCode"));
        //ttributes.put("origination", CllConstants.ORIGINATION_COMMENTS_INBOX_Q);
        
        ADFUtils.processActionEvent(actionEvent, "viewFileNumEventBinding");
        logger.info("Ending  viewFileNumberActionLsnr in ViewCommentInbox ******************");
    }

    /** Enables  all check boxes as  checked when top most check box is checked
     * CAS-1261  Changes in the Comment Inbox - 'File Number' Section
     * @param valueChangeEvent
     */
    /*public void selectAllCheckBoxes(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
        logger.info("Starting  selectAllCheckBoxes in ViewCommentInbox ******************");  
        logger.info("  In selectAllCheckBoxes, do we select all records ?   = "+ valueChangeEvent.getNewValue());
        boolean isSelected = ((Boolean)valueChangeEvent.getNewValue()).booleanValue();
        DCIteratorBinding fileNumIterator = ADFUtils.findIterator("FileNumberQueueROView1Iterator"); 
        RowSetIterator rsi = fileNumIterator.getViewObject().createRowSetIterator(null);
        rsi.reset();  
        while (rsi.hasNext()) {
            Row row = rsi.next();
            row.setAttribute("SelectRowTransAttr", isSelected);
        }
        rsi.closeRowSetIterator();
        
        logger.info("Ending  selectAllCheckBoxes in ViewCommentInbox ******************");
    }*/
    
    
    /** Assign all selected file numbers to current user
     * CAS-1261  Changes in the Comment Inbox - 'File Number' Section
     */
    /*public String assignFileNumbersToUser(){ 
            // Add event code here... 
            logger.info("Starting assignFileNumbersToUser   **************************");
            Boolean rowSelected; 
            Number staffId=getStaffId(); 
            //Number staffId = new Number(2);
            if(staffId == null){
                String msg=rb.getString("VIEWCOMMENTINBOX_USER_DOES_NOT_EXIST_IN_STAFFTABLE");
                 JSFUtils.addFacesErrorMessage(msg);   
                return null;
            }
            DCIteratorBinding fileNumIterator = ADFUtils.findIterator("FileNumberQueueROView1Iterator");  
            RowSetIterator rsi = fileNumIterator.getViewObject().createRowSetIterator(null);
            rsi.reset();  
            while (rsi.hasNext()) {
                Row row = rsi.next();
                //logger.info("Current file num is "+row.getAttribute("FilenumId"));
                rowSelected=(Boolean)row.getAttribute("SelectRowTransAttr");
                if( rowSelected !=null ){ 
                    //if file is under processing...ignore it   becasue Select All check box considers all files in the iterator is considered  
                    if(null != row.getAttribute("Processing")){
                        continue;
                    } 
                    Number fileNumId=(Number)row.getAttribute("FilenumId");  
                    if(rowSelected.booleanValue()) { 
                        // if currently not assigned  then insert row  in  CLL_FILENUM_ASSIGNED table
                        if( !fileNumAlreadyExistsinAssignTable(fileNumId)){ 
                            OperationBinding operation = ADFUtils.findOperation("insertIntoFileNumAssign");
                            operation.getParamsMap().put("fileNumId",fileNumId );
                            operation.getParamsMap().put("staffId",staffId );
                            operation.execute(); 
                        }else{   //just update  instead of checking and then updating  
                            OperationBinding operation = ADFUtils.findOperation("updateFileAssignee");
                            operation.getParamsMap().put("fileNumId",fileNumId );
                            operation.getParamsMap().put("staffId",staffId );
                            operation.execute();
                        }
                    }
                }
                
            }
            rsi.closeRowSetIterator();
            if( !ADFUtils.doCommit()){
                String msg=rb.getString("VIEWCOMMENTINBOX_UNABLE_TOCOMMIT_FILEASSIGN");
                JSFUtils.addFacesErrorMessage(msg);  
            }
        ADFUtils.refreshIterator("FileNumberQueueROView1Iterator"); 
        logger.info("Ending assignFileNumbersToUser   **************************");
        return null;
    } */
    
    public boolean fileNumAlreadyExistsinAssignTable(Number fileNumId){
        boolean flag=false;
        OperationBinding operation = ADFUtils.findOperation("fileNumAlreadyExistsinAssignTable");
        operation.getParamsMap().put("fileNumId",fileNumId ); 
        operation.execute(); 
        Boolean result=(Boolean)operation.getResult();
        flag=result.booleanValue();
        return flag;
    }
 
    public Number getStaffId(){ 
      logger.info("Starting getStaffId in ViewCommentInbox ********************** ");  
        Number staffId=null;
        try {
               String userName=CllUtils.getCurrentUserName(); 
               logger.info("User name currently logged in is ******************** "+userName);
               logger.info("User name currently logged in is ******************** "+userName);
             // String userName="clluser_ops2";
              OperationBinding operation = ADFUtils.findOperation("getStaffDetailsByUserName");
              operation.getParamsMap().put("userName",userName );
              operation.execute();
              Map<String,Object> staffDetails=(Map<String,Object>)operation.getResult();
              logger.info("Staff id retrieved  inside getStaffId   is "+ staffId);
              staffId= (Number)staffDetails.get("staffId"); 
          }catch (JboException e){
               String msg=rb.getString("VIEWCOMMENTINBOX_UNABLETOGET_STAFFDETAILS");
               JSFUtils.addFacesErrorMessage(msg);  
           } catch (Exception e){ 
                e.printStackTrace();
                String msg=rb.getString("VIEWCOMMENTINBOX_UNABLETOGET_STAFFDETAILS");
                JSFUtils.addFacesErrorMessage(msg);   
           }  
        logger.info("Ending getStaffId in ViewCommentInbox ********************** ") ;
        return staffId;
    }

    /**
     * Returns the panel header title based on taskflow input parameters
     * 
     * @return
     */
    public String getPanelHeaderText(){
        String typeCode = (String)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pTypeCode");
        String dispCode = (String)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pDispCode");
        if (CllConstants.CLL_STATUS_TYPE_CODE_PRO.equals(typeCode) &&
            CllConstants.CLL_DISPOSITION_TYPE_APPR.equals(dispCode)) {
            return CllConstants.PUBLISHING_QUEUE_TITLE;
        } else {
            return CllConstants.COMMENT_INBOX_TITLE;
        }
    }

    public void setFileNumberTable(RichTable fileNumberTable) {
        this.fileNumberTable = fileNumberTable;
    }

    public RichTable getFileNumberTable() {
        return fileNumberTable;
    }
    
    /**Sets the currently selected row back to the same in the iterator to avoid issue with check box check getting cleared
     *
     * @param selectionEvent
     */
    public void rowSelectionListener(SelectionEvent selectionEvent) {
        logger.info("Starting rowSelectionListener in comment inbox  **********************");
        DCIteratorBinding dcItteratorBindings = ADFUtils.findIterator("FileNumberQueueROView1Iterator");         
        RowKeySet rksSelectedRowsKeys = fileNumberTable.getSelectedRowKeys();  
        if(null != rksSelectedRowsKeys && !rksSelectedRowsKeys.isEmpty()){ 
           Iterator itrSelectedRows = rksSelectedRowsKeys.iterator();   
           // RowSetIterator rowSetItator = dcItteratorBindings.getRowSetIterator();             
           if (itrSelectedRows.hasNext()) { 
               Key key = (Key)((List)itrSelectedRows.next()).get(0);  
                  //if( null !=rowSetItator.getRow(key)) {  
                  //rowSetItator.setCurrentRow(row);
                   dcItteratorBindings.setCurrentRowWithKey(key.toStringFormat(true));
                   FileNumberQueueROViewRowImpl  currentRow = (FileNumberQueueROViewRowImpl) dcItteratorBindings.getCurrentRow();                    
                   currentRow.setSelectRowTransAttr(true);
                   logger.info("File number inside Row Selection listener  is : "+currentRow.getFilenumber());
           }
           
        } 
          
        JSFUtils.invokeMethodExpression("#{bindings.bindings.FileNumberQueueROView1.collectionModel.makeCurrent}",
                                  Object.class, SelectionEvent.class,selectionEvent);

        logger.info("Ending rowSelectionListener in comment inbox  **********************");
    }


    public void setQueuesTable(RichTable queuesTable) {
        this.queuesTable = queuesTable;
    }

    public RichTable getQueuesTable() {
        return queuesTable;
    }
  /**CAS-1141 and CAS-1142 --CLL-Comment-Inbox-MissingFile#Queue and Internal to SEC queue integration
   * when refresh button is clicked on Comment inbox page,  the queues table and file number queue will  be refreshed
   */
    public void refreshActionListener(ActionEvent actionEvent) {
        // Add event code here...
        logger.info("Starting refreshActionListener in comment inbox  **********************");
        DCIteratorBinding dcItteratorBindings1 = ADFUtils.findIterator("FileNumberQueueROView1Iterator");   
        dcItteratorBindings1.executeQuery();
        DCIteratorBinding dcItteratorBindings2 = ADFUtils.findIterator("CommentInboxQueuesROView1Iterator");   
        dcItteratorBindings2.executeQuery();
        logger.info("Ending refreshActionListener in comment inbox  **********************");
    }
    
    /**CAS-1143_CLL-Comment-Inbox-NavigationTo-MissingFile#Queue
     * Task flow id  Missing File Number Comment List is passed as output parameter in order to assign itto the dynamic region.
     * @param actionEvent
     */
    public void  queuesLinkActionLsnr(ActionEvent actionEvent) {
               logger.info("Starting  queueLinkActionLsnr in ViewCommentInbox ******************");
               //String targetQueue =(String)ADFContext.getCurrent().getRequestScope().get("targetQueue"); --if we use af:setActionListener    
        
               Map<String, Object> attrs = actionEvent.getComponent().getAttributes();
               String targetQueue = (String)attrs.get("targetQueue"); 
               logger.info("target queue name selected is:" + targetQueue);
               UIComponent component = actionEvent.getComponent();
               Map<String, Object> attributes = component.getAttributes();
               if(targetQueue.contains("Missing")) {
                  attributes.put("targetQueueName", CllConstants.ORIGINATION_MISSING_FILENUM_Q);
               }
               else if(targetQueue.contains("Internal")) {
                    attributes.put("targetQueueName", CllConstants.ORIGINATION_INTERNAL_TOSEC_Q);
                }
               ADFUtils.processActionEvent(actionEvent, "viewQueuesEventBinding");
               logger.info("Ending  queueLinkActionLsnr in ViewCommentInbox ******************");
           }
}
