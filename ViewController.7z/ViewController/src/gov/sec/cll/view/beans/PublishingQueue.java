package gov.sec.cll.view.beans;

 
import gov.sec.cll.sharedcomponents.view.bundles.DatabaseResourceBundle;
import gov.sec.cll.sharedcomponents.view.utils.JSFUtils;
import gov.sec.cll.sharedcomponents.view.utils.SharedCompConstants;
import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;

import java.io.Serializable;

import java.util.Map;
import java.util.ResourceBundle;

import oracle.adf.share.logging.ADFLogger;

import oracle.jbo.JboException;

public class PublishingQueue implements Serializable {
   
    
    private static final ResourceBundle rb =
                ResourceBundle.getBundle(SharedCompConstants.RESOURCE_BUNDLE_LOCATION);
    private static final long serialVersionUID = -5341667845206938021L;
    private String DOC_URL;
    private static ADFLogger logger = ADFLogger.createADFLogger(PublishingQueue.class);
    
    public PublishingQueue() {
        super();
        loadUCMProperties();     
    }
    
    /** Loads  required UCM properties such as  DOC_URL
     * 
     */ 
    public void loadUCMProperties(){
        logger.info("Starting ... loadUCMProperties   in PublishingQueue init() method  ************************");
         try {            
         
                    DatabaseResourceBundle dsbundle = new DatabaseResourceBundle();
                    Map map = dsbundle.getResourceBundle();  
                    if(null==map || map.size() <=0) {
                        // if at least one property is not fetched that means, issue with fetching properties from database
                        logger.info("No properties fetched from database ....Error  fetching UCM properties from database");
                        JSFUtils.addFacesErrorMessage(rb.getString("PUBLISHINGQUEUE_ERR_FETCHING_UCMPROPERTIES")); 
                        return;
                    } 
                    DOC_URL=(String)map.get("DOC_URL");  
                    if(null == DOC_URL || DOC_URL.isEmpty()) {
                        logger.info("No properties fetched from database ....Error  fetching UCM properties from database");
                        JSFUtils.addFacesErrorMessage(rb.getString("PUBLISHINGQUEUE_ERR_FETCHING_UCMPROPERTIES"));  
                        return;
                    }
                    logger.info("DOC  URL  inside  FileUpload bean  is *********************" +DOC_URL);
            
         }catch (JboException e){ 
                    logger.info("********************************************************************");
                    e.printStackTrace();
                    logger.info("********************************************************************");
                    JSFUtils.addFacesErrorMessage(rb.getString("PUBLISHINGQUEUE_ERR_FETCHING_UCMPROPERTIES"));
        } catch(Exception e){ 
            logger.info("********************************************************************");
            e.printStackTrace();
            logger.info("********************************************************************");
            JSFUtils.addFacesErrorMessage(rb.getString("PUBLISHINGQUEUE_ERR_FETCHING_UCMPROPERTIES"));
       }
    
        logger.info("Ending ... loadUCMProperties   in PublishingQueue init() method  ************************");
    }

    public void setDOC_URL(String DOC_URL) {
        this.DOC_URL = DOC_URL;
    }

    public String getDOC_URL() {
        return DOC_URL;
    }
}
