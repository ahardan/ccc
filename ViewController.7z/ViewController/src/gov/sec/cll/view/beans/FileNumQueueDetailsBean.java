package gov.sec.cll.view.beans;

import oracle.adf.view.rich.component.rich.layout.RichShowDetailItem;
import oracle.adf.view.rich.context.AdfFacesContext;

import org.apache.myfaces.trinidad.event.DisclosureEvent;

public class FileNumQueueDetailsBean {
    private RichShowDetailItem commentsShowDetailBind;
    private RichShowDetailItem otherShowDetailItem;

    public FileNumQueueDetailsBean() {
    }

    public void commentsTabDiscLstnr(DisclosureEvent disclosureEvent) {
        String typeCode = (String)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pTypeCode");
        if (disclosureEvent.isExpanded()) {
            if(null == typeCode || "FL".equals(typeCode)){
                AdfFacesContext.getCurrentInstance().getPageFlowScope().put("pTypeCode", "CL");
            }else{
                AdfFacesContext.getCurrentInstance().getPageFlowScope().put("pTypeCode", "FL");
            }
        }
    }

    public void formTabDiscLstnr(DisclosureEvent disclosureEvent) {
        String typeCode = (String)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pTypeCode");
        if (disclosureEvent.isExpanded()) {
            if(null == typeCode || "CL".equals(typeCode)){
                AdfFacesContext.getCurrentInstance().getPageFlowScope().put("pTypeCode", "FL");
            }else{
                AdfFacesContext.getCurrentInstance().getPageFlowScope().put("pTypeCode", "CL");
            }
        }
    }

    public void setCommentsShowDetailBind(RichShowDetailItem commentsShowDetailBind) {
        this.commentsShowDetailBind = commentsShowDetailBind;
    }

    public RichShowDetailItem getCommentsShowDetailBind() {
        return commentsShowDetailBind;
    }

    public void setOtherShowDetailItem(RichShowDetailItem otherShowDetailItem) {
        this.otherShowDetailItem = otherShowDetailItem;
    }

    public RichShowDetailItem getOtherShowDetailItem() {
        this.getCommentsShowDetailBind().setDisclosed(true);
        return otherShowDetailItem;
    }
}
