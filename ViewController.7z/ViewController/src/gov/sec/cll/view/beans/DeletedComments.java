package gov.sec.cll.view.beans;

import java.io.Serializable;

public class DeletedComments implements Serializable{
    @SuppressWarnings("compatibility:-2394419376350898781")
    private static final long serialVersionUID = 1L;

    public DeletedComments() {
        super();
    }
    
    private String origination;

    public void setOrigination(String origination) {
        this.origination = origination;
    }

    public String getOrigination() {
        return origination;
    }
}
