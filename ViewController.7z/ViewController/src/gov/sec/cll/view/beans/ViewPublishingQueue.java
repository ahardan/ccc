package gov.sec.cll.view.beans;

import gov.sec.cas.common.view.dto.Document;
import gov.sec.cas.common.view.services.RIDCService;
import gov.sec.cas.common.view.utils.SecurityUtils;
import gov.sec.cll.model.adfbc.views.AttachmentPublishingROViewRowImpl;
import gov.sec.cll.sharedcomponents.model.adfbc.views.AttachmentViewRowImpl;
import gov.sec.cll.sharedcomponents.view.beans.ViewFileUpload;
import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;
import gov.sec.cll.sharedcomponents.view.utils.JSFUtils;

import gov.sec.cll.sharedcomponents.view.utils.SharedCompConstants;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;

import java.util.HashMap;
import java.util.Map;

import java.util.ResourceBundle;

import javax.faces.context.FacesContext;

import javax.faces.event.ActionEvent;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.component.rich.nav.RichButton;

import oracle.binding.OperationBinding;

import org.apache.myfaces.trinidad.render.ExtendedRenderKitService;
import org.apache.myfaces.trinidad.util.Service;

public class ViewPublishingQueue {
    
    private static ADFLogger logger = ADFLogger.createADFLogger(ViewPublishingQueue.class);
    private static final ResourceBundle rb =
                ResourceBundle.getBundle(SharedCompConstants.RESOURCE_BUNDLE_LOCATION);
    private RichButton fileDownloadButton;
    
    private final String CONTENT_TYPE_PARAM = "contentType";
    private final String FILE_NAME_PARAM = "filename";
    private final String FILE_ABSOLUTE_PATH = "fileAbsolutePath";

    public ViewPublishingQueue() {
        super();
    }
    
    /**
     * This method downloads first the document in server and then it invoke
     * programmatically a hidden button which uses the af:fileDownloadActionListener to download the
     * document in browser
     * 
     * @param actionEvent
     */
    public void docLinkActionListener(ActionEvent actionEvent) {
        //Get Current row from selected row
        DCIteratorBinding attachDCIter = ADFUtils.findIterator("AttachmentPublishingROView1Iterator");
        AttachmentPublishingROViewRowImpl row = (AttachmentPublishingROViewRowImpl)attachDCIter.getCurrentRow();
        logger.info("ViewPublishingQueue.docLinkActionListener :: Clicked Link for Doc Id : " + row.getUcmId());
        logger.info("ViewPublishingQueue.docLinkActionListener :: Clicked Link for Content Id : " + row.getContentId());
        
        //Download attachment in server so that it can be downloaded from there in browser
        try {
            Map<String, String> props = getApplicationProperties();
            String currentUsername = SecurityUtils.getUserNameFromSessionOrContext();
            RIDCService ridc = new RIDCService(currentUsername, props);
            Document latestDocInfo = ridc.downloadLatestDoc(row.getContentId(), row.getUcmId());
            if (null == latestDocInfo){
                JSFUtils.addFacesErrorMessage("Package could not be downloaded. Please contact the System Administrator.");
                return;
            }
            logger.info("ViewPublishingQueue.docLinkActionListener :: Downloaded Package File name : " + latestDocInfo.getFileName());
            logger.info("ViewPublishingQueue.docLinkActionListener :: Downloaded Package File Content-Type : " + latestDocInfo.getContentType());
            logger.fine("ViewPublishingQueue.docLinkActionListener :: Downloaded Package File Absolute Path : " + latestDocInfo.getFileAbsolutePath());
            
            //Add filename and content type in view scope to be used in af:fileDownloadActionListerner attributes
            ADFContext.getCurrent().getViewScope().put(FILE_NAME_PARAM, latestDocInfo.getFileName());
            ADFContext.getCurrent().getViewScope().put(CONTENT_TYPE_PARAM, latestDocInfo.getContentType());
            ADFContext.getCurrent().getViewScope().put(FILE_ABSOLUTE_PATH, latestDocInfo.getFileAbsolutePath());
            
            //Programmatically click the hidden buttton that executes af:fileDownloadActionListerner
            FacesContext fctx = FacesContext.getCurrentInstance();
            String buttonId = getFileDownloadButton().getClientId(fctx);
            StringBuilder script = new StringBuilder();
            script.append("var dlButton = AdfPage.PAGE.findComponentByAbsoluteId('" + buttonId + "');");
            script.append("dlEvent = new AdfActionEvent(dlButton);");
            script.append("dlButton.queueEvent(dlEvent, true);");
            ExtendedRenderKitService erks = Service.getService(fctx.getRenderKit(), ExtendedRenderKitService.class);
            erks.addScript(fctx, script.toString());

        } catch (Exception e){
            e.printStackTrace();
            logger.severe("ViewPublishingQueue.docLinkActionListener :: ERROR : " + e);
            JSFUtils.addFacesErrorMessage("Error in downloading document. Please contact System Administrator.");
        }
    }
    
    /**
     * This method is used along the docLinkActionListener method.
     * Open downloaded file in browser. The button that is using the download action listener is hidden.
     * Hidden button is invoked programmatically in docLinkActionListener method after file is downloaded 
     * in specified location.
     * 
     * @param facesContext
     * @param outputStream
     */
    public void fileDownloadActionListener(FacesContext facesContext, OutputStream outputStream) {
        logger.info("ViewPublishingQueue.fileDownloadActionListener :: START opening document...");
        try {
            String absoluteFilePath = (String)ADFContext.getCurrent().getViewScope().get(FILE_ABSOLUTE_PATH);
            logger.fine("ViewPublishingQueue.fileDownloadActionListener :: File Absolute Path : " + absoluteFilePath);
            File file = new File(absoluteFilePath);
            
            //Downloading generated file...
            FileInputStream fis = new FileInputStream(file);
            byte[] b;
            int n;
            while ((n = fis.available()) > 0) {
                b = new byte[n];
                int result = fis.read(b);
                outputStream.write(b, 0, b.length);
                if (result == -1) {
                    break;
                }
            }
            outputStream.flush();
            outputStream.close();
            fis.close();
            //After file is open, delete it from location
            if (file.delete()){
                logger.fine("ViewPublishingQueue.fileDownloadActionListener :: Package File was deleted from temp folder ");
            } else {
                logger.warning("ViewPublishingQueue.fileDownloadActionListener :: Package File was NOT deleted");
            }
            logger.info("ViewPublishingQueue.fileDownloadActionListener :: Opening document completed...");
        } catch (Exception e) {
            e.printStackTrace();
            JSFUtils.addFacesErrorMessage("Error while opening downloaded document. Please contact System Administrator.");
            logger.severe("ViewPublishingQueue.fileDownloadActionListener :: ERROR : " + e);
        }
    }
    
    /**
     * Returns the content-type for downloaded file from View Scope.
     * Value was added in docLinkActionListener method.
     * 
     * @return
     */
    public String getContentType() {
        String contentType= (String)ADFContext.getCurrent().getViewScope().get(CONTENT_TYPE_PARAM);
        logger.info("ViewPublishingQueue.getContentType :: Content-type : " + contentType);
        return contentType;
    }

    /**
     * Returns the filename for downloaded file from View Scope.
     * Value was added in docLinkActionListener method.
     * 
     * @return
     */
    public String getFilename() {
        String filename = (String)ADFContext.getCurrent().getViewScope().get(FILE_NAME_PARAM);
        logger.info("ViewPublishingQueue.getContentType :: Filename : " + filename);
        return filename;
    }
    
    public Map<String, String> getApplicationProperties(){
        Map<String,String> appProps = new HashMap<String,String>();
        OperationBinding binding = ADFUtils.findOperation("getResourceBundle");
        binding.execute();
        if (binding.getErrors().isEmpty()){
            appProps = (Map<String, String>) binding.getResult();
        } else {
            JSFUtils.addFacesErrorMessage(rb.getString("APPLICATION_PROPERTIES_RETRIEVE_ERROR"));
        }
        return appProps;
    }

    public void setFileDownloadButton(RichButton fileDownloadButton) {
        this.fileDownloadButton = fileDownloadButton;
    }

    public RichButton getFileDownloadButton() {
        return fileDownloadButton;
    }

}
