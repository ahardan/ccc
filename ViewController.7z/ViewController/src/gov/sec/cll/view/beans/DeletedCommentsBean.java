package gov.sec.cll.view.beans;

import gov.sec.cll.model.adfbc.views.CllCommentsListROViewRowImpl;
import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;

import gov.sec.cll.sharedcomponents.view.utils.JSFUtils;

import gov.sec.cll.view.utils.CllConstants;

import gov.sec.cll.view.utils.CllUtils;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.fragment.RichRegion;
import oracle.adf.view.rich.component.rich.input.RichSelectBooleanCheckbox;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.adf.view.rich.event.DialogEvent;

import oracle.binding.OperationBinding;

import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.domain.Number;

import org.apache.myfaces.trinidad.event.ReturnEvent;
import org.apache.myfaces.trinidad.event.SelectionEvent;
import org.apache.myfaces.trinidad.model.RowKeySet;
import org.apache.myfaces.trinidad.model.RowKeySetImpl;

public class DeletedCommentsBean {
    private RichTable commentsListTblBind;
    private RichPopup popupArchive;
    private RichPopup popupError;
    private static ADFLogger logger =
        ADFLogger.createADFLogger(DeletedCommentsBean.class);
    private RichRegion commentDetRegBind;
    private String packaingErrorMsg;
    private String archiveWarnMsg;
    private static final ResourceBundle rb =
                ResourceBundle.getBundle(CllConstants.RESOURCE_BUNDLE_LOCATION);


    public DeletedCommentsBean() {
        super();
    }

    public void setCommentsListTblBind(RichTable commentsListTblBind) {
        this.commentsListTblBind = commentsListTblBind;
    }

    public RichTable getCommentsListTblBind() {
        return commentsListTblBind;
    }


    


    /** Verifies whether user has selected comments to archive. If not, control goes back to UI page.
      *
      * @return
      */
     public String clickArchiveButtonAction() {
         logger.info("Archive button clicked");
         ArrayList<Number>  commIds = new ArrayList<Number> ();     
         commIds=selectedComments ();  // get selected list of comments
         if(commIds.size() > 0) {
             AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT", commIds.size());
             this.setArchiveWarnMsg( "Selected "+ commIds.size() + 
                                                " comment(s) will be archived. Do you wish to proceed? ");
             
               //RichPopup.PopupHints hints = new RichPopup.PopupHints();   
            this.getPopupArchive().show(new RichPopup.PopupHints());
         }else {
            JSFUtils.addFacesErrorMessage("Please select atleast one comment to archive.");
         }
         return null;
         
     }

    /**
     * Dialog listener to confirm archiving of selected comment letters.
     * Clicking "Ok" from the popup, it will archive the comments
     * and refresh comment list/
     * 
     * @param dialogEvent
     */
    public void archivingDialogListener(DialogEvent dialogEvent) {
        logger.info("Start ................. archivingDialogListener, dialog outcome = " + dialogEvent.getOutcome());
        // Archive comments
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.yes) {
            setArchiving();
            JSFUtils.addFacesInformationMessage("Selected " +
                                                AdfFacesContext.getCurrentInstance().getViewScope().get("COMMENTS_COUNT") +
                                                " comment(s) archived successfully.");
        }else{
            this.getPopupArchive().cancel();
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            commentsListTblBind.getSelectedRowKeys().removeAll();
            AdfFacesContext.getCurrentInstance().addPartialTarget(commentsListTblBind);
        } 
    }
        
                /**
        * Set selected comments to archive
        *
        */
     private void setArchiving() {
        logger.info("Start ...setArchiving method with bounded operation");    
        // Set selected comments to archive
            OperationBinding opb = ADFUtils.findOperation("setArchive");
            opb.execute();
            if(opb.getErrors().isEmpty()){
                String rslt = (String)opb.getResult();
                //Reset checkboxes
                if(null != rslt){

                    logger.info("Refreshing list of comments");  
                    CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                    commentsListTblBind.getSelectedRowKeys().removeAll();
                    ADFUtils.refreshIterator("CllCommentsListROView1Iterator"); 
                    AdfFacesContext.getCurrentInstance().addPartialTarget(commentsListTblBind);
                }else{
                    packaingErrorMsg=rb.getString("COMMENTLIST_ARCHIVE_ERROR_MSG");
                    getPopupError().show(new RichPopup.PopupHints());  
                }   
            }else{ 
                   JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_ARCHIVE_ERROR_MSG"));  
                }
        }
                
    /** Retrieves  selected comments in comment list tab
     *
     * @return
     */
    public ArrayList<Number>  selectedComments () {
        RowKeySet rksSelectedRows =
            commentsListTblBind.getSelectedRowKeys(); //reusable method
        ArrayList<Number> commIds =
            CllUtils.getSelectedCommentsFromBulkProcess(rksSelectedRows,
                                                        "CllCommentsListROView1Iterator");
        return commIds;
        
    }

    public void setCommentDetRegBind(RichRegion commentDetRegBind) {
        this.commentDetRegBind = commentDetRegBind;
    }

    public RichRegion getCommentDetRegBind() {
        return commentDetRegBind;
    }

  
    
    /**Sets  the row pointer to the one which is returned by comment details task flow
         *
         * @param returnEvent
         */
    public void commDetIdReturnListerner(ReturnEvent returnEvent) {
             logger.info("Starting commDetIdReturnListerner   *******************************"); 
             Map map=returnEvent.getReturnParameters();         
             Number  commDetId=(Number) map.get("pCommDetId") ;          
             logger.info("Comment id returned by comment details task flow : "+commDetId);
             DCIteratorBinding dcItteratorBindings = ADFUtils.findIterator("CllCommentsListROView1Iterator");
             dcItteratorBindings.setCurrentRowWithKeyValue(commDetId.toString());
             Row row  = dcItteratorBindings.getCurrentRow();
             RowKeySetImpl newRowKeySet = new RowKeySetImpl();
             ArrayList nextLst = new ArrayList(1);
             nextLst.add(row.getKey());
             newRowKeySet.add(nextLst); 
             // set the row from comment details back  in  the comment list   ADF  Table
             commentsListTblBind.setSelectedRowKeys(newRowKeySet);

            AdfFacesContext.getCurrentInstance().addPartialTarget(commentsListTblBind);
            logger.info("Ending commDetIdReturnListerner   *******************************");
      }
    
    
    
    /**Clear the check box for the currently selected row before opening up comment details page.
     *
     * @param ae
     */
    public void commentLinkActionLsnr(ActionEvent ae) {
        // Add event code here...
        DCIteratorBinding dcItteratorBindings = ADFUtils.findIterator("CllCommentsListROView1Iterator");         
        CllCommentsListROViewRowImpl  currentRow = (CllCommentsListROViewRowImpl) dcItteratorBindings.getCurrentRow();                    
        currentRow.setSelectAttr(false); 
        //return null;
    }


    public void setPopupArchive(RichPopup popupArchive) {
        this.popupArchive = popupArchive;
    }

    public RichPopup getPopupArchive() {
        return popupArchive;
    }

    public void setPopupError(RichPopup popupError) {
        this.popupError = popupError;
    }

    public RichPopup getPopupError() {
        return popupError;
    }
    
    /**Sets the currently selected row back to the same in the iterator to avoid issue with check box check getting cleared
     *
     * @param selectionEvent
     */
    public void rowSelectionListener(SelectionEvent selectionEvent) {
        logger.info("Starting rowSelectionListener in Deleted Queue list  **********************");
        DCIteratorBinding dcItteratorBindings = ADFUtils.findIterator("CllCommentsListROView1Iterator");         
        RowKeySet rksSelectedRowsKeys = commentsListTblBind.getSelectedRowKeys();   
        if(null != rksSelectedRowsKeys && !rksSelectedRowsKeys.isEmpty()){ 
           Iterator itrSelectedRows = rksSelectedRowsKeys.iterator();   
           // RowSetIterator rowSetItator = dcItteratorBindings.getRowSetIterator();             
           if (itrSelectedRows.hasNext()) { 
               Key key = (Key)((List)itrSelectedRows.next()).get(0);  
                  //if( null !=rowSetItator.getRow(key)) {  
                  //rowSetItator.setCurrentRow(row);
                   dcItteratorBindings.setCurrentRowWithKey(key.toStringFormat(true));
                   CllCommentsListROViewRowImpl  currentRow = (CllCommentsListROViewRowImpl) dcItteratorBindings.getCurrentRow();                    
                   currentRow.setSelectAttr(true);
                
           }
            
          JSFUtils.invokeMethodExpression("#{bindings.bindings.CllCommentsListROView1.collectionModel.makeCurrent}",
                                  Object.class, SelectionEvent.class,selectionEvent);
           
          logger.info("Ending rowSelectionListener in  Deleted Queue list  **********************");
           
       } 
        
    }

    public void setArchiveWarnMsg(String archiveWarnMsg) {
        this.archiveWarnMsg = archiveWarnMsg;
    }

    public String getArchiveWarnMsg() {
        return archiveWarnMsg;
    }
}
