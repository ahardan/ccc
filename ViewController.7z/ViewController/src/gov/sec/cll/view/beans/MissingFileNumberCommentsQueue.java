package gov.sec.cll.view.beans;

import gov.sec.cll.model.adfbc.views.CllActionTypeROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllCommentsListROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllDispositionTypeROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllMissingFileNumberCommentsListROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllSourceTypeROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllStatusTypeROViewImpl;
import gov.sec.cll.model.adfbc.views.CllStatusTypeROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllTypeROViewRowImpl;
import gov.sec.cll.model.adfbc.views.FileNumberQueueROViewRowImpl;
import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;
import gov.sec.cll.sharedcomponents.view.utils.JSFUtils;
import gov.sec.cll.view.utils.CllConstants;

import gov.sec.cll.view.utils.CllUtils;

import gov.sec.rellog.filenumber.view.dto.ReturnMasterFileNumberDTO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;


import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.fragment.RichRegion;
import oracle.adf.view.rich.component.rich.input.RichSelectBooleanCheckbox;
import oracle.adf.view.rich.component.rich.layout.RichPanelGroupLayout;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.adf.view.rich.event.DialogEvent;

import oracle.binding.OperationBinding;

import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.domain.Number;

import org.apache.commons.lang.StringUtils;
import org.apache.myfaces.trinidad.event.ReturnEvent;
import org.apache.myfaces.trinidad.event.SelectionEvent;
import org.apache.myfaces.trinidad.model.RowKeySet;
import org.apache.myfaces.trinidad.model.RowKeySetImpl;

public class MissingFileNumberCommentsQueue {
    private RichTable commentsListTblBind;
    private RichPanelGroupLayout commentDetailsBind;
    private RichRegion commentDetRegBind;
    private RichPopup popupError;
    private RichPopup popupArchive;
    private String packaingErrorMsg;
    private static final ResourceBundle rb =
        ResourceBundle.getBundle(CllConstants.RESOURCE_BUNDLE_LOCATION);
    private static ADFLogger logger =
        ADFLogger.createADFLogger(MissingFileNumberCommentsQueue.class);
    private RichPopup popupChgActionWarnMsg;
    private String actnChgWarnMsg;
    private String archiveWarnMsg;
    private RichPopup popupChgAction;
    private String chgActionPopUpTitle;
    private String chgActionMsg;
    private String cllTypeOtherDesc;
    private String cllFinalActionOtherDesc;
    private RichPopup popupFileNum;
    private String fileNumPopupTitle;
    private String fileNumPopupMsg;

    public MissingFileNumberCommentsQueue() {
        super();
    }

  /* as per  story  CAS-1122-CLL-Missing-File-Number-Queue-Changes,  below method is commented out */
   /* public void setAssignToMe(ActionEvent actionEvent) {
        RowKeySet rksSelectedRows =
            commentsListTblBind.getSelectedRowKeys(); // bulk selection
        if (rksSelectedRows.size() <= 0) {
            JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_ASSIGNING_NO_COMMENT_SELECTED_MSG"));
            return;
        }
        ArrayList<Number> commIds =
            CllUtils.getSelectedCommentsFromBulkProcess(rksSelectedRows,
                                                        "CllCommentsListROView1Iterator");
        OperationBinding opb = ADFUtils.findOperation("assignComment");
        opb.getParamsMap().put("action", "ASSIGN");
        opb.execute();
        String rslt = (String)opb.getResult();
        if (null != rslt && rslt.equalsIgnoreCase("User Found")) {
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            commentsListTblBind.getSelectedRowKeys().removeAll();
            ADFUtils.refreshIterator("CllCommentsListROView1Iterator");
            AdfFacesContext.getCurrentInstance().addPartialTarget(commentsListTblBind);
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            commentsListTblBind.getSelectedRowKeys().removeAll();
        } else {
            packaingErrorMsg = rb.getString("ASSIGN_COMMENTS_ERROR_MSG");
            getPopupError().show(new RichPopup.PopupHints());
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            commentsListTblBind.getSelectedRowKeys().removeAll();
        }
    } */


    /** Verifies whether user has selected comments to archive. If not, control goes back to UI page.
     *
     * @return
     */
    public String clickArchiveButtonAction() {
        logger.info("Archive button clicked");
        ArrayList<Number> commIds = new ArrayList<Number>();
        commIds = selectedComments(); // get selected list of comments
        if (commIds.size() > 0) {
            AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT",
                                                                    commIds.size());
            this.setArchiveWarnMsg("Selected " + commIds.size() +
                                   " comment(s) will be archived. Do you wish to proceed? ");

            //RichPopup.PopupHints hints = new RichPopup.PopupHints();
            this.getPopupArchive().show(new RichPopup.PopupHints());
        } else {
            JSFUtils.addFacesErrorMessage("Please select at least one comment to archive.");
        }
        return null;
    }

    /**
     * Dialog listener to confirm archiving of selected comment letters.
     * Clicking "Ok" from the popup, it will archive the comments
     * and refresh comment list/
     *
     * @param dialogEvent
     */
    public void archivingDialogListener(DialogEvent dialogEvent) {
        logger.info("Start ................. archivingDialogListener, dialog outcome = " +
                    dialogEvent.getOutcome());
        // Archive comments
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.yes) {
            setArchiving();
            JSFUtils.addFacesInformationMessage("Selected " +
                                                AdfFacesContext.getCurrentInstance().getViewScope().get("COMMENTS_COUNT") +
                                                " comment(s) archived successfully.");
        } else {
            this.getPopupArchive().cancel();
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            commentsListTblBind.getSelectedRowKeys().removeAll();
            AdfFacesContext.getCurrentInstance().addPartialTarget(commentsListTblBind);
        }
    }

    /**
     * Set selected comments to archive
     *
     */
    private void setArchiving() {
        logger.info("Start ...setArchiving method with bounded operation");
        // Set selected comments to archive
        OperationBinding opb = ADFUtils.findOperation("setArchive");
        opb.execute();
        if (opb.getErrors().isEmpty()) {
            String rslt = (String)opb.getResult();
            //Reset checkboxes
            if (null != rslt) {

                logger.info("Refreshing list of comments");
                CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                commentsListTblBind.getSelectedRowKeys().removeAll();
                ADFUtils.refreshIterator("CllCommentsListROView1Iterator");
                AdfFacesContext.getCurrentInstance().addPartialTarget(commentsListTblBind);
            } else {
                packaingErrorMsg =
                        rb.getString("COMMENTLIST_ARCHIVE_ERROR_MSG");
                getPopupError().show(new RichPopup.PopupHints());
            }
        } else {
            JSFUtils.addFacesErrorMessage(rb.getString("COMMENTLIST_ARCHIVE_ERROR_MSG"));
        }
    }

    /** Retrieves  selected comments in comment list tab
     *
     * @return
     */
    public ArrayList<Number> selectedComments() {
        RowKeySet rksSelectedRows = commentsListTblBind.getSelectedRowKeys();
        ArrayList<Number> commIds =
            CllUtils.getSelectedCommentsFromBulkProcess(rksSelectedRows,
                                                        "CllCommentsListROView1Iterator");
        return commIds;
    }

    public void selectAllCheckBoxes(ValueChangeEvent valueChangeEvent) {
        boolean isSelected =
            ((Boolean)valueChangeEvent.getNewValue()).booleanValue();
        DCIteratorBinding fileNumIterator =
            ADFUtils.findIterator("CllCommentsListROView1Iterator");
        RowSetIterator rsi =
            fileNumIterator.getViewObject().createRowSetIterator(null);
        rsi.reset();
        while (rsi.hasNext()) {
            Row row = rsi.next();
            row.setAttribute("SelectAttr", isSelected);
        }
        rsi.closeRowSetIterator();
        AdfFacesContext.getCurrentInstance().addPartialTarget(commentsListTblBind);
    }

    public void setCommentsListTblBind(RichTable commentsListTblBind) {
        this.commentsListTblBind = commentsListTblBind;
    }

    public RichTable getCommentsListTblBind() {
        return commentsListTblBind;
    }

    public void setCommentDetailsBind(RichPanelGroupLayout commentDetailsBind) {
        this.commentDetailsBind = commentDetailsBind;
    }

    public RichPanelGroupLayout getCommentDetailsBind() {
        return commentDetailsBind;
    }

    public void setCommentDetRegBind(RichRegion commentDetRegBind) {
        this.commentDetRegBind = commentDetRegBind;
    }

    public RichRegion getCommentDetRegBind() {
        return commentDetRegBind;
    }

    public void setPopupError(RichPopup popupError) {
        this.popupError = popupError;
    }

    public RichPopup getPopupError() {
        return popupError;
    }

    public void setPackaingErrorMsg(String packaingErrorMsg) {
        this.packaingErrorMsg = packaingErrorMsg;
    }

    public String getPackaingErrorMsg() {
        return packaingErrorMsg;
    }

    /**Sets  the row pointer to the one which is returned by comment details task flow
     *
     * @param returnEvent
     */
    public void commDetIdReturnListerner(ReturnEvent returnEvent) {
        logger.info("Starting commDetIdReturnListerner   *******************************");
        Map map = returnEvent.getReturnParameters();
        Number commDetId = (Number)map.get("pCommDetId");
        logger.info("Comment id returned by comment details task flow : " +
                    commDetId);
        DCIteratorBinding dcItteratorBindings =
            ADFUtils.findIterator("CllCommentsListROView1Iterator");
        dcItteratorBindings.setCurrentRowWithKeyValue(commDetId.toString());
        Row row = dcItteratorBindings.getCurrentRow();
        RowKeySetImpl newRowKeySet = new RowKeySetImpl();
        ArrayList nextLst = new ArrayList(1);
        nextLst.add(row.getKey());
        newRowKeySet.add(nextLst);
        // set the row from comment details back  in  the comment list   ADF  Table
        commentsListTblBind.setSelectedRowKeys(newRowKeySet);

        AdfFacesContext.getCurrentInstance().addPartialTarget(commentsListTblBind);
        logger.info("Ending commDetIdReturnListerner   *******************************");
    }

    /**Clear the check box for the currently selected row before opening up comment details page.
     *
     * @param ae
     */
    public void commentLinkActionLsnr(ActionEvent ae) {
        // Add event code here...
        DCIteratorBinding dcItteratorBindings =
            ADFUtils.findIterator("CllCommentsListROView1Iterator");
        CllCommentsListROViewRowImpl currentRow =
            (CllCommentsListROViewRowImpl)dcItteratorBindings.getCurrentRow();
        currentRow.setSelectAttr(false);
        //return null;
    }

    public void setPopupArchive(RichPopup popupArchive) {
        this.popupArchive = popupArchive;
    }

    public RichPopup getPopupArchive() {
        return popupArchive;
    }

    /**Sets the currently selected row back to the same in the iterator to avoid issue with check box check getting cleared
     *
     * @param selectionEvent
     */
    public void rowSelectionListener(SelectionEvent selectionEvent) {
        logger.info("Starting rowSelectionListener in Missing File Number Queue  **********************");
        DCIteratorBinding dcItteratorBindings =
            ADFUtils.findIterator("CllCommentsListROView1Iterator");
        RowKeySet rksSelectedRowsKeys =
            commentsListTblBind.getSelectedRowKeys();
        if (null != rksSelectedRowsKeys && !rksSelectedRowsKeys.isEmpty()) {
            Iterator itrSelectedRows = rksSelectedRowsKeys.iterator();
            // RowSetIterator rowSetItator = dcItteratorBindings.getRowSetIterator();
            if (itrSelectedRows.hasNext()) {
                Key key = (Key)((List)itrSelectedRows.next()).get(0);
                //if( null !=rowSetItator.getRow(key)) {
                //rowSetItator.setCurrentRow(row);
                dcItteratorBindings.setCurrentRowWithKey(key.toStringFormat(true));
                CllCommentsListROViewRowImpl currentRow =
                    (CllCommentsListROViewRowImpl)dcItteratorBindings.getCurrentRow();
                currentRow.setSelectAttr(true);
                //logger.info("Comment Id  inside Row Selection listener  is : "+currentRow.getCllCommDetId());
            }
        }
        JSFUtils.invokeMethodExpression("#{bindings.bindings.CllCommentsListROView1.collectionModel.makeCurrent}",
                                        Object.class, SelectionEvent.class,
                                        selectionEvent);
        logger.info("Ending rowSelectionListener in Missing File Number Queue **********************");
    }

    /** Verifies whether user has selected comments to add/change/delete a file number. If comments are selected, it will display confirmation message.
     * If not, throws error.
     *
     * @return
     */
    public String clickAddChgDelFileNumLinkAction() {
        logger.info("Change Action Link clicked");
        ArrayList<Number> commIds = new ArrayList<Number>();
        commIds = selectedComments(); // get selected list of comments
        if (commIds.size() > 0) {
            if (commIds.size() == 1) {
                setFileNumPopupMsg("File Number will be added to 1 comment. Do you wish to proceed?");
            } else {
                setFileNumPopupMsg("File Number will be added to " +
                                   commIds.size() +
                                   " comments. Do you wish to proceed?");
            }
            setFileNumPopupTitle("Add a File#");
            popupFileNum.show(new RichPopup.PopupHints());
        } else {
            JSFUtils.addFacesErrorMessage("Please select at least one comment to add a file number.");
        }
        return null;
    }

    /** Invokes  search file number task flow when Yes button is clicked in the confirmation window
     *
     * @return
     */
    public String yesFileNumAction() {
        popupFileNum.hide();
        return "searchfilenumber";
    }

    /**Clears  the bulk selection if user do not want to  proceed with bulk selection
     *
     * @return
     */
    public String noFileNumAction() {

        CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
        commentsListTblBind.getSelectedRowKeys().removeAll();
        return "";
    }

    public String clickChgActionLinkAction() {
        logger.info("Change Action Link clicked");
        ArrayList<Number> commIds = new ArrayList<Number>();
        commIds = selectedComments(); // get selected list of comments
        if (commIds.size() > 0) {
            AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT",
                                                                    commIds.size());
            this.setActnChgWarnMsg("Action will be changed in " +
                                   commIds.size() +
                                   " comments. Do you wish to proceed?");
            this.getPopupChgActionWarnMsg().show(new RichPopup.PopupHints());
        } else {
            JSFUtils.addFacesErrorMessage("Please select at least one comment to change Action.");
        }
        return null;
    }

    /**
     * Verify if user has selected comments. If comments are selected, it will display confirmation message. 
     * If not, throws error.
     * 
     * @return
     */    
    public String clickChgFinalActionLinkAction() {
        logger.info("Change Final Action Link clicked");
        ArrayList<Number> commIds = new ArrayList<Number>();
        commIds = selectedComments(); // get selected list of comments
        if (commIds.size() > 0) {
            AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT",
                                                                    commIds.size());
            this.setActnChgWarnMsg("Final Action will be changed in " +
                                   commIds.size() +
                                   " comments. Do you wish to proceed?");
            this.getPopupChgActionWarnMsg().show(new RichPopup.PopupHints());
        } else {
            JSFUtils.addFacesErrorMessage("Please select at least one comment to change Final Action.");
        }
        return null;
    }

    /**Retrieves  return parameter MasterFileNumberDTO from search file# task flow  or create file# task flow.
     *
     */
    public void returnFromSearchOrCreateFileNum(ReturnEvent returnEvent) {
        logger.info("Starting  returnFromSearchOrCreateFileNum in MissingFileNumberCommentsQueue***************************");
        Number fileNumId =
            CllUtils.getMasterFileNumberIdFromDTO(CllConstants.ORIGINATION_MISSING_FILENUM_Q); //DTO is  in the task flow bean
        if (null == fileNumId) {
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            commentsListTblBind.getSelectedRowKeys().removeAll();
            AdfFacesContext.getCurrentInstance().addPartialTarget(commentsListTblBind);
            return;
        }
        ArrayList<Number> commIds = new ArrayList<Number>();
        commIds = selectedComments(); // get selected list of comments
        Map<String, Object> pageFlowScope =
            AdfFacesContext.getCurrentInstance().getPageFlowScope();
        MissingFileNumberQList missingFileNumberQList =
            (MissingFileNumberQList)pageFlowScope.get("missingFileNumberQList");
        ReturnMasterFileNumberDTO masterFileNumDTO =
            missingFileNumberQList.getReturnMasterFileNumDTO();
        CllUtils.addFileNumToComments(commIds, fileNumId,
                                      masterFileNumDTO.getFileNumberTypeCode(),
                                      masterFileNumDTO.getAvailable(),
                                      masterFileNumDTO.getMasterFileNumberId(),
                                      CllConstants.ORIGINATION_MISSING_FILENUM_Q);
        CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
        commentsListTblBind.getSelectedRowKeys().removeAll();
        ADFUtils.refreshIterator("CllCommentsListROView1Iterator");
        AdfFacesContext.getCurrentInstance().addPartialTarget(commentsListTblBind);
        logger.info("Ending  returnFromSearchOrCreateFileNum in  MissingFileNumberCommentsQueue***************************");
    }


    public void setPopupChgActionWarnMsg(RichPopup popupChgActionWarnMsg) {
        this.popupChgActionWarnMsg = popupChgActionWarnMsg;
    }

    public RichPopup getPopupChgActionWarnMsg() {
        return popupChgActionWarnMsg;
    }

    public void chgActionPpDialogLstnr(DialogEvent dialogEvent) {
        logger.info("Start ................. ChgActionDialogListener, dialog outcome = " +
                    dialogEvent.getOutcome());
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.yes) {
            String action =
                (String)AdfFacesContext.getCurrentInstance().getViewScope().get("action");
            if (StringUtils.isNotBlank(action) && "ACTION".equals(action)) {
                ADFUtils.refreshIterator("CllActionTypeROView1Iterator");
                this.setChgActionPopUpTitle("Select Action Type");
                this.setChgActionMsg("Please select Action Type to be updated in the selected comments.");
                this.getPopupChgAction().show(new RichPopup.PopupHints());
            } else if (StringUtils.isNotBlank(action) && "FINAL_ACTION".equals(action)) {
                ADFUtils.refreshIterator("CllDispositionTypeROView1Iterator");
                this.setChgActionPopUpTitle("Select Final Action Type");
                this.setChgActionMsg("Please select Final Action Type to be updated in the selected comments.");
                this.getPopupChgAction().show(new RichPopup.PopupHints());
            } else if (StringUtils.isNotBlank(action) &&
                       "COMMENT".equals(action)) {
                ADFUtils.refreshIterator("CllTypeROView2Iterator");
                this.setChgActionPopUpTitle("Select Comment Type");
                this.setChgActionMsg("Please select Comment Type to be updated in the selected comments.");
                this.getPopupChgAction().show(new RichPopup.PopupHints());
            } else if (StringUtils.isNotBlank(action) &&
                       "SOURCE".equals(action)) {
                ADFUtils.refreshIterator("CllSourceTypeROView1Iterator");
                this.setChgActionPopUpTitle("Select Source Type");
                this.setChgActionMsg("Please select Source Type to be updated in the selected comments.");
                this.getPopupChgAction().show(new RichPopup.PopupHints());
            } else if (StringUtils.isNotBlank(action) &&
                       "DELETE".equals(action)) {
                Map inputMap = new HashMap();
                DCIteratorBinding statusIter =
                    ADFUtils.findIterator("CllStatusTypeROView2Iterator");
                CllStatusTypeROViewImpl statView =
                    (CllStatusTypeROViewImpl)statusIter.getViewObject();
                statView.setApplyViewCriteriaName("findByCode", false);
                statView.setNamedWhereClauseParam("bindCode", "DEL");
                statView.executeQuery();
                CllStatusTypeROViewRowImpl statViewRow =
                    (CllStatusTypeROViewRowImpl)statView.first();
                if (null != statViewRow) {
                    inputMap.put("CllStatusTypeId",
                                 statViewRow.getCllStatusTypeId());
                }
                OperationBinding opb =
                    ADFUtils.findOperation("updateSelectedActiontoComments");
                opb.getParamsMap().put("action", action);
                opb.getParamsMap().put("inputMap", inputMap);
                opb.execute();
                this.getPopupChgActionWarnMsg().cancel();
                CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
                commentsListTblBind.getSelectedRowKeys().removeAll();
                ADFUtils.refreshIterator("CllCommentsListROView1Iterator");
                AdfFacesContext.getCurrentInstance().addPartialTarget(commentsListTblBind);
                JSFUtils.addFacesInformationMessage(AdfFacesContext.getCurrentInstance().getViewScope().get("COMMENTS_COUNT") +
                                                    " comments deleted successfully.");
            }
        } else {
            this.getPopupChgActionWarnMsg().cancel();
            CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
            commentsListTblBind.getSelectedRowKeys().removeAll();
            AdfFacesContext.getCurrentInstance().addPartialTarget(commentsListTblBind);
        }
    }

    public void setActnChgWarnMsg(String actnChgWarnMsg) {
        this.actnChgWarnMsg = actnChgWarnMsg;
    }

    public String getActnChgWarnMsg() {
        return actnChgWarnMsg;
    }

    public void setPopupChgAction(RichPopup popupChgAction) {
        this.popupChgAction = popupChgAction;
    }

    public RichPopup getPopupChgAction() {
        return popupChgAction;
    }

    public void chgActionCommentActionLstnr(ActionEvent actionEvent) {
        logger.info("Entering Change Action Method.");
        Map inputMap = new HashMap();
        String actionType = null;
        String action =
            (String)AdfFacesContext.getCurrentInstance().getViewScope().get("action");
        String dispTypeCode = null;
        if (StringUtils.isNotBlank(action) && "ACTION".equals(action)) {
            actionType = "Action";
            DCIteratorBinding ActnTypeIter =
                ADFUtils.findIterator("CllActionTypeROView1Iterator");
            CllActionTypeROViewRowImpl ActnTypeRow =
                (CllActionTypeROViewRowImpl)ActnTypeIter.getCurrentRow();
            Number actnTypeId = ActnTypeRow.getCllActionTypeId();
            inputMap.put("CllActionTypeId", actnTypeId);
        } else if (StringUtils.isNotBlank(action) && "FINAL_ACTION".equals(action)) {
                actionType = "Final Action";
                DCIteratorBinding dispTypeIter = ADFUtils.findIterator("CllDispositionTypeROView1Iterator");
                CllDispositionTypeROViewRowImpl dispTypeRow = (CllDispositionTypeROViewRowImpl)dispTypeIter.getCurrentRow();
                dispTypeCode = dispTypeRow.getCode();

                //Validation for required Final Action Other Desc
                if (!StringUtils.trimToEmpty(dispTypeCode).isEmpty() &&
                    CllConstants.CLL_DISPOSITION_TYPE_OTH.equals(dispTypeCode) &&
                    StringUtils.trimToEmpty(getCllFinalActionOtherDesc()).isEmpty()) {
                    return;
                }
                
                Number dispTypeId = dispTypeRow.getCllDispositionTypeId();
                inputMap.put("CllDispositionTypeId", dispTypeId);
                inputMap.put("DispTypeCode", dispTypeRow.getCode());
                inputMap.put("OtherDisposition", this.getCllFinalActionOtherDesc());            
        } else if (StringUtils.isNotBlank(action) &&
                   "COMMENT".equals(action)) {
            actionType = "Comment Type";
            DCIteratorBinding commentTypeIter =
                ADFUtils.findIterator("CllTypeROView2Iterator");
            CllTypeROViewRowImpl commentTypeRow =
                (CllTypeROViewRowImpl)commentTypeIter.getCurrentRow();
            Number cllTypeId = commentTypeRow.getCllTypeId();
            String cllTypeCode = commentTypeRow.getCode();
            inputMap.put("CllTypeId", cllTypeId);
            inputMap.put("CllTypeCode", cllTypeCode);
            inputMap.put("CllTypeOtherDesc", this.getCllTypeOtherDesc());
        } else if (StringUtils.isNotBlank(action) && "SOURCE".equals(action)) {
            actionType = "Source Type";
            DCIteratorBinding sourceTypeIter =
                ADFUtils.findIterator("CllSourceTypeROView1Iterator");

            CllSourceTypeROViewRowImpl sourceTypeRow =
                (CllSourceTypeROViewRowImpl)sourceTypeIter.getCurrentRow();
            Number sourceTypeId = sourceTypeRow.getCllSourceTypeId();
            String sourceCode = sourceTypeRow.getCode();
            inputMap.put("sourceTypeId", sourceTypeId);
            inputMap.put("sourceTypeCode", sourceCode);

        }
        OperationBinding opb =
            ADFUtils.findOperation("updateSelectedActiontoComments");
        opb.getParamsMap().put("action", action);
        opb.getParamsMap().put("inputMap", inputMap);
        opb.execute();
        
        //There is no need to look for email receipients since comments in Missing File# queue don't have
        //File Number assigned and therefore, no CLL POCs
        if (opb.getErrors().isEmpty()){
            if (StringUtils.isNotBlank(action) && "FINAL_ACTION".equals(action) &&
                CllConstants.CLL_DISPOSITION_TYPE_APPR.equals(dispTypeCode)) {
                    JSFUtils.addFacesInformationMessage(rb.getString("VIEWCOMMENTDETAILS_COMM_PROCESSED_NO_FILES_TO_SEND_NOTIFICATION_NOT"));        
                }
        }
        
        this.getPopupChgAction().cancel();
        CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
        commentsListTblBind.getSelectedRowKeys().removeAll();
        ADFUtils.refreshIterator("CllCommentsListROView1Iterator");
        AdfFacesContext.getCurrentInstance().addPartialTarget(commentsListTblBind);
        JSFUtils.addFacesInformationMessage(actionType + " changed in " +
                                            AdfFacesContext.getCurrentInstance().getViewScope().get("COMMENTS_COUNT") +
                                            " comments successfully.");
    }

    public void cancelChgActionCommentActnLstnr(ActionEvent actionEvent) {
        this.getPopupChgAction().cancel();
        CllUtils.clearBulkSelection("CllCommentsListROView1Iterator");
        commentsListTblBind.getSelectedRowKeys().removeAll();
        AdfFacesContext.getCurrentInstance().addPartialTarget(commentsListTblBind);
    }

    public void setArchiveWarnMsg(String archiveWarnMsg) {
        this.archiveWarnMsg = archiveWarnMsg;
    }

    public String getArchiveWarnMsg() {
        return archiveWarnMsg;
    }

    public String clickChgCommentTypeAction() {
        logger.info("Change Action Link clicked");
        ArrayList<Number> commIds = new ArrayList<Number>();
        commIds = selectedComments(); // get selected list of comments
        if (commIds.size() > 0) {
            AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT",
                                                                    commIds.size());
            this.setActnChgWarnMsg("Comment Type will be changed in " +
                                   commIds.size() +
                                   " comments. Do you wish to proceed?");
            this.getPopupChgActionWarnMsg().show(new RichPopup.PopupHints());
        } else {
            JSFUtils.addFacesErrorMessage("Please select at least one comment to change Comment Type.");
        }
        return null;
    }

    public String clickChgSourceTypeAction() {
        logger.info("Change Source Link clicked");
        ArrayList<Number> commIds = new ArrayList<Number>();
        commIds = selectedComments(); // get selected list of comments
        if (commIds.size() > 0) {
            AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT",
                                                                    commIds.size());
            this.setActnChgWarnMsg("Source Type will be changed in " +
                                   commIds.size() +
                                   " comments. Do you wish to proceed?");
            this.getPopupChgActionWarnMsg().show(new RichPopup.PopupHints());
        } else {
            JSFUtils.addFacesErrorMessage("Please select at least one comment to change Source Type.");
        }
        return null;
    }

    public void setChgActionPopUpTitle(String chgActionPopUpTitle) {
        this.chgActionPopUpTitle = chgActionPopUpTitle;
    }

    public String getChgActionPopUpTitle() {
        return chgActionPopUpTitle;
    }

    public void setChgActionMsg(String chgActionMsg) {
        this.chgActionMsg = chgActionMsg;
    }

    public String getChgActionMsg() {
        return chgActionMsg;
    }

    public void setCllTypeOtherDesc(String cllTypeOtherDesc) {
        this.cllTypeOtherDesc = cllTypeOtherDesc;
    }

    public String getCllTypeOtherDesc() {
        return cllTypeOtherDesc;
    }
    
    public void setCllFinalActionOtherDesc(String cllFinalActionOtherDesc) {
        this.cllFinalActionOtherDesc = cllFinalActionOtherDesc;
    }

    public String getCllFinalActionOtherDesc() {
        return cllFinalActionOtherDesc;
    }

    public void setPopupFileNum(RichPopup popupFileNum) {
        this.popupFileNum = popupFileNum;
    }

    public RichPopup getPopupFileNum() {
        return popupFileNum;
    }

    public void setFileNumPopupTitle(String fileNumPopupTitle) {
        this.fileNumPopupTitle = fileNumPopupTitle;
    }

    public String getFileNumPopupTitle() {
        return fileNumPopupTitle;
    }

    public void setFileNumPopupMsg(String fileNumPopupMsg) {
        this.fileNumPopupMsg = fileNumPopupMsg;
    }

    public String getFileNumPopupMsg() {
        return fileNumPopupMsg;
    }

    public String clickDelCommentLinkAction() {
        logger.info("Delete Comments Link clicked");
        ArrayList<Number> commIds = new ArrayList<Number>();
        commIds = selectedComments(); // get selected list of comments
        if (commIds.size() > 0) {
            AdfFacesContext.getCurrentInstance().getViewScope().put("COMMENTS_COUNT",
                                                                    commIds.size());
            this.setActnChgWarnMsg(commIds.size() +
                                   " comments will be deleted. Do you wish to proceed?");
            this.getPopupChgActionWarnMsg().show(new RichPopup.PopupHints());
        } else {
            JSFUtils.addFacesErrorMessage("Please select at least one comment to Delete");
        }
        return null;
    }

}
