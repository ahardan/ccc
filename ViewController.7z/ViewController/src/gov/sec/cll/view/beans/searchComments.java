package gov.sec.cll.view.beans;

import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;
import gov.sec.cll.sharedcomponents.view.utils.JSFUtils;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.ADFContext;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.binding.OperationBinding;

import oracle.jbo.domain.Date;

import org.apache.commons.lang.StringUtils;

public class searchComments {
    public searchComments() {
    }

    public void searchActionListner(ActionEvent actionEvent) {
        String fileNum = (String) ADFUtils.evaluateEL("#{bindings.FileNumber.inputValue}");
        String relNum = (String) ADFUtils.evaluateEL("#{bindings.ReleaseNumber.inputValue}");
        String sub = (String) ADFUtils.evaluateEL("#{bindings.Subject.inputValue}");
        String affiliate = (String) ADFUtils.evaluateEL("#{bindings.Affiliate.inputValue}");
        Date dateofLtr = (Date) ADFUtils.evaluateEL("#{bindings.DateofLetter.inputValue}");
        Date endDtofLtr = (Date) ADFUtils.evaluateEL("#{bindings.endDateofLetter.inputValue}");
        String submitter = (String) ADFUtils.evaluateEL("#{bindings.SubmitterName.inputValue}");
        Integer fileType = (Integer) ADFUtils.evaluateEL("#{bindings.FileType.inputValue}");
        Date SecStDate = (Date) ADFUtils.evaluateEL("#{bindings.ReceivedStDate.inputValue}");
        Date SecEndDate = (Date) ADFUtils.evaluateEL("#{bindings.ReceivedEndDate.inputValue}");
        String fromCommentId = (String) ADFUtils.evaluateEL("#{bindings.FromCommentId.inputValue}");
        String toCommentId = (String) ADFUtils.evaluateEL("#{bindings.ToCommentId.inputValue}");
        String commentType = (String) ADFUtils.evaluateEL("#{bindings.commentType.inputValue}");
        

        if (fromCommentId == null) {
            ADFUtils.setBoundAttributeValue("ToCommentId", null);
            toCommentId = null;
        }
        if (StringUtils.isBlank(commentType) && fromCommentId == null && toCommentId == null && fileNum == null && null == relNum && null == sub && null == affiliate && null == dateofLtr && null == submitter && null == SecStDate &&
            null == SecEndDate && null == endDtofLtr) {
            JSFUtils.addFacesErrorMessage("Please enter at least one search field. For file number, please ensure that file type is selected.");
        } else if (null != fileNum && fileType == 0) {
            JSFUtils.addFacesErrorMessage("Please select valid File Number Type");
        } else if (null == fileNum && fileType != 0) {
            JSFUtils.addFacesErrorMessage("Please select valid File Number");
        } else if (null != fromCommentId && null != toCommentId && (Integer.parseInt(toCommentId)< Integer.parseInt(fromCommentId))) {

            JSFUtils.addFacesErrorMessage("To Comment ID should be greater than From Comment ID");


        } else {
            searchComm();
        }

    }

    public void searchComm() {
        OperationBinding opb = ADFUtils.findOperation("searchComments");
        opb.getParamsMap().put("index", AdfFacesContext.getCurrentInstance()
                                                       .getViewScope()
                                                       .get("fileType"));
        opb.execute();
        DCIteratorBinding srchCommIter = ADFUtils.findIterator("SearchCommentsROView1Iterator");
        if (null != srchCommIter && srchCommIter.getEstimatedRowCount() > 500) {
            ADFContext.getCurrent()
                      .getRequestScope()
                      .put("searchMesg", "Search results exceed limit. Please refine your search.");
        } else if (null != srchCommIter && srchCommIter.getEstimatedRowCount() < 1) {
            ADFContext.getCurrent()
                      .getRequestScope()
                      .put("searchMesg", "No records found matching the search criteria.");
        }
    }

    public void resetActionListner(ActionEvent actionEvent) {
        AdfFacesContext.getCurrentInstance()
                       .getViewScope()
                       .put("fileType", null);
        ADFUtils.findOperation("resetCommentsSearch").execute();
    }

    public void fileTypeValueChangeListner(ValueChangeEvent valueChangeEvent) {
        valueChangeEvent.getComponent().processUpdates(FacesContext.getCurrentInstance());
        if (valueChangeEvent.getNewValue().equals(0)) {
            ADFUtils.setBoundAttributeValue("FileNumber", null);
            AdfFacesContext.getCurrentInstance()
                           .getViewScope()
                           .put("fileType", null);
        } else {
            AdfFacesContext.getCurrentInstance()
                           .getViewScope()
                           .put("fileType", valueChangeEvent.getNewValue());
        }
    }

}
