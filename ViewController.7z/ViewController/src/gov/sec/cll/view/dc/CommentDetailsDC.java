package gov.sec.cll.view.dc;

import gov.sec.cll.cllservices.model.services.CllServicesAppModuleImpl;
import gov.sec.cll.model.adfbc.services.CommentLogAppModuleImpl;
import gov.sec.cll.model.adfbc.views.AttachmentROViewImpl;
import gov.sec.cll.model.adfbc.views.CllCommentDetailsDetagViewImpl;
import gov.sec.cll.model.adfbc.views.CllCommentDetailsDetagViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllCommentDetailsViewImpl;
import gov.sec.cll.model.adfbc.views.CllCommentDetailsViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFileNumberViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumAttyViewImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumCommDetViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFormLetterListPRViewImpl;
import gov.sec.cll.model.adfbc.views.CllFormLetterListPRViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFormLetterSubTypeROViewImpl;
import gov.sec.cll.model.adfbc.views.CllFormLetterViewImpl;
import gov.sec.cll.model.adfbc.views.CllFormLetterViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllParentCommDetailsROViewImpl;
import gov.sec.cll.model.adfbc.views.CllStatusPRViewImpl;
import gov.sec.cll.model.adfbc.views.CllStatusPRViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllSubmitterRepViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllSubmitterViewRowImpl;
import gov.sec.cll.model.adfbc.views.FileNumCommDetSeqNumROViewImpl;
import gov.sec.cll.model.adfbc.views.FileNumbersForCommentDetROViewImpl;
import gov.sec.cll.model.adfbc.views.FileNumbersForCommentDetROViewRowImpl;
import gov.sec.cll.sharedcomponents.model.adfbc.services.CLLSharedComponentsAppModuleImpl;
import gov.sec.cll.sharedcomponents.model.adfbc.views.AttachmentViewImpl;
import gov.sec.cll.sharedcomponents.model.adfbc.views.AttachmentViewRowImpl;
import gov.sec.cll.sharedcomponents.view.dto.PersonDTO;
import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;
import gov.sec.cll.sharedcomponents.view.wrapper.RellogServicesWrapper;
import gov.sec.cll.view.beans.CommentDetails;
import gov.sec.cll.view.beans.CommentListBean;
import gov.sec.cll.view.beans.FormLetterListBean;
import gov.sec.cll.view.beans.ViewCommentDetails;
import gov.sec.cll.view.dto.EmailRecipientDTO;
import gov.sec.cll.view.dto.ForwardCommentDTO;
import gov.sec.cll.view.utils.CllConstants;
import gov.sec.cll.view.utils.CllUtils;

import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.component.UIComponent;
import javax.faces.event.ActionEvent;

import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.jbo.Row;
import oracle.jbo.RowSet;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewCriteria;
import oracle.jbo.domain.ClobDomain;
import oracle.jbo.domain.DBSequence;
import oracle.jbo.domain.Number;
import oracle.jbo.server.ViewObjectImpl;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

public class CommentDetailsDC {
    public CommentDetailsDC() {
        super();
    }
    private static ADFLogger logger = ADFLogger.createADFLogger(CommentDetailsDC.class);
    private static final ResourceBundle rb =
                ResourceBundle.getBundle(CllConstants.RESOURCE_BUNDLE_LOCATION);
    

    /** Retrieves list of attorneys as email recipients for a  given fileNumberId
     *
     * @param fileNumId
     * @return
     */
    public List<EmailRecipientDTO> retrieveRecipientList(Number fileNumId) {

        logger.info("START... retrieveRecipientList");
        List<EmailRecipientDTO> recipienList = new ArrayList<EmailRecipientDTO>();
        
        // In case comment detail is not associated with any file number
        if (fileNumId == null) {
            return recipienList;    
        }
        // ---  With fileNumberId get a list of CommDetId from the CllFilenumCommDet table
        CllFilenumAttyViewImpl filenumAttyVO = getCommentLogAM().getCllFilenumAttyView1();
        String bindFileNumber = fileNumId.toString();
        logger.info("fileNumber for VC =" + bindFileNumber);
        filenumAttyVO.setbindFileNum(bindFileNumber);
        filenumAttyVO.setApplyViewCriteriaName("findByFileNum");
        filenumAttyVO.executeQuery();
        RowSetIterator filenumAttyIterator = filenumAttyVO.createRowSetIterator(null);
        filenumAttyIterator.reset();
        while (filenumAttyIterator.hasNext()) {
            Row filenumAttyRow = filenumAttyIterator.next();
            logger.info("Recipient - " + filenumAttyRow.getAttribute("FirstName") + " " + filenumAttyRow.getAttribute("LastName") + " " +filenumAttyRow.getAttribute("Email"));
            EmailRecipientDTO emailNode = new EmailRecipientDTO();
            emailNode.setFirstName((String)filenumAttyRow.getAttribute("FirstName"));
            emailNode.setLastName((String)filenumAttyRow.getAttribute("LastName"));
            emailNode.setEmail((String)filenumAttyRow.getAttribute("Email"));
            recipienList.add(emailNode);
        }
        filenumAttyIterator.closeRowSetIterator();
        logger.info("recipientList = " + recipienList);
        return recipienList;
    }

    /**
     * Retrieves the CLL POCs from Master File Number
     * 
     * @param masterFileNumberIdList    Master File Number Id List
     * @return  List of EmailRecipientDTO instances
     */
    private List<EmailRecipientDTO> retrieveRecipientList(List<Number> masterFileNumberIdList) throws Exception {
        logger.info("START... retrieveRecipientList for master file number id list :: " + masterFileNumberIdList);
        List<EmailRecipientDTO> recipienList = new ArrayList<EmailRecipientDTO>();
        if (CollectionUtils.isNotEmpty(masterFileNumberIdList)){
            List<PersonDTO> cllPocs = getRellogServicesWrapper().retriveFileNumberCllPocs(masterFileNumberIdList, "CLLPOC");
            for (PersonDTO personDTO : cllPocs){
                EmailRecipientDTO recipientDTO = new EmailRecipientDTO();
                recipientDTO.setFirstName(personDTO.getFirstName());
                recipientDTO.setLastName(personDTO.getLastName());
                recipientDTO.setEmail(personDTO.getEmail());
                recipienList.add(recipientDTO);
                
                 
            }
        }
        logger.info("Returning EmailRecipientDTO List :: size = " + recipienList.size());
        return recipienList;
    }
    
    

    /** Retrieves list of attorneys for a comment 
     * 
     *
     * @param commDetId
     * @return
     */
    public List<EmailRecipientDTO> retrieveMultipleFilenumRecipientList(Number commDetId) {
        logger.info("START... retrieveMultipleFilenumRecipientList");
        logger.info("commDetId = " + commDetId);
        List<Number> masterFNIdList = new ArrayList<Number>();
        List<EmailRecipientDTO> emailRecipienList = new ArrayList<EmailRecipientDTO>();

        // Get list of master file number ids related to commDetId
        if (commDetId != null) {
            refreshFileNumbersForComment(commDetId);
            FileNumbersForCommentDetROViewImpl fileNumCommDetRoVO = (FileNumbersForCommentDetROViewImpl)getCommentLogAM().getFileNumbersForCommentDetROView1();
            RowSetIterator rsi = fileNumCommDetRoVO.createRowSetIterator(null);
            rsi.reset();
            while (rsi.hasNext()) {
                FileNumbersForCommentDetROViewRowImpl row = (FileNumbersForCommentDetROViewRowImpl)rsi.next();
                logger.info("There is master file number = " + row.getMasterFileNumberId());
                masterFNIdList.add(row.getMasterFileNumberId());
            }
            rsi.closeRowSetIterator();
            // Fetch recipient list for multiple master file number Ids
            try {
                emailRecipienList = retrieveRecipientList(masterFNIdList);
            } catch (Exception e) {
                e.printStackTrace();
                logger.severe("Error retrieving POCs from Master File Number :: " + e.getMessage());
            }
        }
        logger.info("Multiple Filenumber recipientList = " + emailRecipienList);
        return emailRecipienList;
    }
    
    
    /** Prepares viewForwardComment
     *
    */
    public ForwardCommentDTO prepareViewForwardCommentData() {
        logger.info("START... prepareViewForwardComment");
        String subject = "";
        String comment= "";
        ForwardCommentDTO forwardComment = new ForwardCommentDTO();
        // Refreshes attachments
        AttachmentViewImpl attachmentVO = getCllSharedCompoentsAM().getAttachmentView1();
        attachmentVO.executeQuery();
        // Get current row from CllCommentDetailsView1     
        CllCommentDetailsViewImpl commDetVO = getCommentLogAM().getCllCommentDetailsView1();
        String currentTypeCode=(String)commDetVO.getCurrentRow().getAttribute("CommentTypeCode");
        Number formLetterId = (Number)commDetVO.getCurrentRow().getAttribute("CllFormLetterId");
        logger.info("Current type code =" + currentTypeCode);
        logger.info("formLetterId =" + formLetterId);
        if(currentTypeCode !=null && !currentTypeCode.isEmpty() ) {
            if (currentTypeCode.equalsIgnoreCase(CllConstants.CLL_TYPE_CODE_FORM_LETTER) && formLetterId !=null && !formLetterId.isZero()) {
                    logger.info("FormLetter type");
                    CllParentCommDetailsROViewImpl parentCommDetVO = getCommentLogAM().getCllParentCommDetailsROView1();
                    parentCommDetVO.setpFormLetterId(formLetterId);
                    parentCommDetVO.executeQuery();
                    logger.info("parentCommDetVO rowCount = " + parentCommDetVO.getEstimatedRowCount());
                    if(parentCommDetVO.hasNext()){
                        Row currentParentRow = parentCommDetVO.next();
                        logger.info("Current parent row = " + currentParentRow);
                        logger.info("Current parent row = " + currentParentRow.getAttribute("CllCommDetId"));
                        if (currentParentRow.getAttribute("Subject") != null) {
                            subject = rb.getString("VIEWFORWARDFORMLETTER_SUBJECT_PREFIX") + currentParentRow.getAttribute("Subject");
                        }
                        ClobDomain commentClob = (ClobDomain)currentParentRow.getAttribute("Comments");
                        if (commentClob != null && !commentClob.toString().isEmpty()) {
                            comment = commentClob.toString().trim();
                        }
                    }
                } else {
                    logger.info("CommentLetter type");
                    Row currentCommDetRow = commDetVO.getCurrentRow();
                    if (currentCommDetRow.getAttribute("Subject") != null) {
                        subject = rb.getString("VIEWFORWARDCOMMENT_SUBJECT_PREFIX") + currentCommDetRow.getAttribute("Subject");
                    }
                    ClobDomain commentClob = (ClobDomain)currentCommDetRow.getAttribute("Comments");
                    if (commentClob != null && !commentClob.toString().isEmpty()) {
                        comment = commentClob.toString().trim();
                    }
                }
        }
        forwardComment.setSubject(subject);
        forwardComment.setComment(comment);
        logger.info("Subject = " + forwardComment.getSubject());
        logger.info("Comment = " + forwardComment.getComment());
        logger.info("Returning from prepareViewForwardComment");
        return forwardComment;
        
    }


    /**
     * Retrieve set of Comment Details rows with the the iterator CllCommentDetailsViw2
     * 
     */
    public void retrieveCommDetFormLetter (Number formLetterId) {
        logger.info("Starting ... retrieveCommDetFormLetter  ...............");
        CllCommentDetailsViewImpl commDet2VO = getCommentLogAM().getCllCommentDetailsView2();  
        ViewCriteria vc = commDet2VO.getViewCriteria("CllCommentDetailsByFormLetterId");
        commDet2VO.setNamedWhereClauseParam("pFormLetterId", formLetterId);
        commDet2VO.applyViewCriteria(vc);
        commDet2VO.executeQuery(); 
        CllCommentDetailsViewRowImpl firstRow = (CllCommentDetailsViewRowImpl)commDet2VO.first(); 
        commDet2VO.setCurrentRow(firstRow);
        
        logger.finest("Ending  retrieveCommDetFormLetter ...");
    }     

    /**
     * Untag a comment of form letter to an unique comment
     * 
     * @param  commDetId  comment Letter Id
     * @return processing result
     */ 
    public String untagFormLetter (Number commDetId) {
        logger.info("Starting ......................... untagFormLetter");
        String procInstance = "Success";
        try {
            Number commentTypeId = getCommentLogAM().getCllTypeView1().getCommentTypeId(CllConstants.CLL_TYPE_CODE_COMMENT_LETTER);
            // -- Find the corresponding row in CommDet table and update
            CllCommentDetailsDetagViewImpl detagVO = getCommentLogAM().getCllCommentDetailsDetagView1();
            detagVO.setpCommDetId(new DBSequence(commDetId));
            detagVO.executeQuery();
            CllCommentDetailsDetagViewRowImpl detagRow = (CllCommentDetailsDetagViewRowImpl)detagVO.first();
            detagRow.setCllFormLetterId(null);
            detagRow.setCllTypeId(commentTypeId);
            ADFUtils.doCommit();
            logger.info("Deleted row in filenumCommDet table with commDetId =" + commDetId);
            } catch (Exception e){
            procInstance = ("Fault - " + e);
            }
    return procInstance;
    }


    /**
     * Retrieves an instance of the application module for CommentLogAppModule
     * 
     */
    private CommentLogAppModuleImpl getCommentLogAM() {
        CommentLogAppModuleImpl amImpl=(CommentLogAppModuleImpl)ADFUtils.getApplicationModuleForDataControl("CommentLogAppModuleDataControl");
        return amImpl;
    }
    
    /**
     * Retrieves an instance of the application module for CllSharedComponentsAppModule
     * 
     */
    private CLLSharedComponentsAppModuleImpl getCllSharedCompoentsAM() {
        CLLSharedComponentsAppModuleImpl amImpl=(CLLSharedComponentsAppModuleImpl)ADFUtils.getApplicationModuleForDataControl("CLLSharedComponentsAppModuleDataControl");
        return amImpl;
    }
    
    private CllServicesAppModuleImpl getCllServicesAM(){
        CllServicesAppModuleImpl cllSvcAM = (CllServicesAppModuleImpl) ADFUtils.getApplicationModuleForDataControl("CllServicesAppModuleDataControl");
        return cllSvcAM;
    }
    
    
    /**
     * Prepares new comment in  CommentDetailsView VO when user clicks link create new comment 
     * 
     */
    public void prepareNewComment(){
        logger.info("CommentDetailsDC.prepareNewComment :: Start preparing new comment");
        ViewObjectImpl commentVO = getCommentLogAM().getCllCommentDetailsView1();  
        //commentVO.clearViewCriterias(); 
        CllCommentDetailsViewRowImpl newCommRow = (CllCommentDetailsViewRowImpl)commentVO.createRow();  
        //Assigning default type 
        Number commentTypeId = getCommentLogAM().getCllTypeView1().getCommentTypeId(CllConstants.CLL_TYPE_CODE_COMMENT_LETTER);
        newCommRow.setCllTypeId(commentTypeId);
        
        //Assigning default status 
        Number statusTypeId = getCommentLogAM().getCllStatusTypeView1().getStatusTypeId(CllConstants.CLL_STATUS_TYPE_CODE_UPRO);
        newCommRow.setCllStatusTypeId(statusTypeId);     
        newCommRow.setCount1(new Number(1));   
        commentVO.insertRow(newCommRow);
        commentVO.setCurrentRow(newCommRow);
        
        //CASSECDEV-6285 / CASSECDEV-6296 : Create and update Submitter representative
        //Create new row in CLL_SUBMITTER_REP for binding attributes in Comment Detail.
        ViewObjectImpl submitterRepVO = getCommentLogAM().getCllSubmitterRepView1();
        CllSubmitterRepViewRowImpl submRepRow = (CllSubmitterRepViewRowImpl)submitterRepVO.createRow();
        submRepRow.setOboThirdParty("N"); //Defaulting to N (False)
        submRepRow.setIsAffiliated("N"); //Defaulting to N (False)
        submitterRepVO.insertRow(submRepRow);
            
        //initially when we create new comment,  default release numbers are shown ...below code is to avoid loading default release numbers
        setReleaseNumbersToEmpty();
        setExistingFileNumbersToEmpty();
            
        this.initFormLetterSubType(null);
        //if it is new comment nullify all variables in task flow bean
        
        logger.info("CommentDetailsDC.prepareNewComment :: End preparing new comment"); 
    }


    /**
     * Prepare an existing comment by
     * pointing to the row in CommentDetails table with commentDetId.
     *
     * @param commentDetId
     * @param fileNumId
     * @throws SQLException
     */
    public void prepareExistingComment(Number commentDetId, Number fileNumId) throws SQLException {
        logger.info("CommentDetailsDC.prepareExistingComment :: Start preparing existing comment : " + commentDetId); 
        ViewObjectImpl commentVO = getCommentLogAM().getCllCommentDetailsView1();
        ViewCriteria vc = commentVO.getViewCriteria("CllCommentDetailsByCommentDetId");
        commentVO.setNamedWhereClauseParam("pCommentDetId", commentDetId);
        commentVO.applyViewCriteria(vc);
        commentVO.executeQuery();
        CllCommentDetailsViewRowImpl commRow = (CllCommentDetailsViewRowImpl)commentVO.first();
        commentVO.setCurrentRow(commRow);
        
        //CASSECDEV-6285 / CASSECDEV-6296 : Create and update Submitter representative
        //This is to make sure a row is available for binding attributes in Comment Detail. 
        //Create new row in CLL_SUBMITTER_REP in case there isn't any.
        if (null != commRow){
            boolean insertedNewData = false;
            ViewObjectImpl submitterRepVO = getCommentLogAM().getCllSubmitterRepView1();
            if (submitterRepVO.getRowCount() == 0){
                CllSubmitterRepViewRowImpl submRepRow = (CllSubmitterRepViewRowImpl)submitterRepVO.createRow();
                submRepRow.setOboThirdParty("N"); //Defaulting to N (False)
                submRepRow.setIsAffiliated("N"); //Defaulting to N (False)
                submitterRepVO.insertRow(submRepRow);
                logger.info("CommentDetailsDC.prepareExistingComment :: Inserting Row for Submitter Representative for Comment Id " +
                            submRepRow.getCllCommDetId());
                insertedNewData = true;
            } else {
                //Defauting to N (False) for existing records
                CllSubmitterRepViewRowImpl submRepRow = (CllSubmitterRepViewRowImpl)submitterRepVO.first();
                if (StringUtils.isBlank(submRepRow.getOboThirdParty())){
                    submRepRow.setOboThirdParty("N");
                    insertedNewData = true;
                }
                if (StringUtils.isBlank(submRepRow.getIsAffiliated())){
                    submRepRow.setIsAffiliated("N");
                    insertedNewData = true;
                }
            }
            
            //CASSECDEV-6285 / CASSECDEV-6297 : Create and update Submitter address
            //CllSubmitterView is made of CllSubmitter and CllAddres EOs in same VO
            //Assign CllSubmitterView1.CllSubmitterId to FK CllSubmitterView1.CllSubmitterId1
            //This is to make sure the CllAddress entity usage in CllSubmitterView refers to the right CllSubmitter parent
            //in case address data is blank for the existig submitter.
            RowSet rowSetSubmitter = (RowSet)getCommentLogAM().getCllSubmitterView1().getRowSetIterator();
            if (rowSetSubmitter.getRowCount() > 0){
                while(rowSetSubmitter.hasNext()){
                    CllSubmitterViewRowImpl submitterRow = (CllSubmitterViewRowImpl)rowSetSubmitter.next();
                    if (null == submitterRow.getCllSubmitterId1()){
                        submitterRow.setCllSubmitterId1(submitterRow.getCllSubmitterId().getSequenceNumber());
                        insertedNewData = true;
                        logger.info("CommentDetailsDC.prepareExistingComment :: Inserting Row for Address for CommentId-SubmitterId " +
                                    submitterRow.getCllCommDetId() + "-" + submitterRow.getCllSubmitterId1());
                    }
                }
            }

            //Commit only if new data was inserted, and clear dirty transaction
            //This is to separate with other transactions and avoid frequent popup messages to confirm saving data
            if (insertedNewData){
                getCommentLogAM().getDBTransaction().commit();
            }
        }        
        
        //Retrieve the available Form Letter Types for the file num id
        //This is needed to have the data ready for Form Letter Type dropdown
        CllFormLetterSubTypeROViewImpl formLetterSubTypeVO = getCommentLogAM().getCllFormLetterSubTypeROView1();
        formLetterSubTypeVO.setbindFileNum(fileNumId);
        formLetterSubTypeVO.executeQuery();
        
        //show indicator if there is any attachment in the comment
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        CommentDetails commDetBean =
            (CommentDetails)pageFlowScope.get("commentDetails");
        boolean flag = attachmentsExists(commentDetId);
        if (null != commDetBean) {
            commDetBean.setAttachmentsExist(flag);
            ADFUtils.markScopeDirty(pageFlowScope);
        }
        //if  file number id is passed, set the detail view  FileNumCommentDetView to corresponding record
        if (fileNumId != null) {
            //user might have changed the file number for the current comment to some other file number but still user is in the current file number Q.
            //So,  check whether  this file number exists for this comment.  If not, set the first file number
            if (isFileNumExistForCommentDet(fileNumId, commentDetId)) {
                setFileNumCommentDet(commentDetId, fileNumId);
            } else { 
                setFirstFileNumber(commentDetId);  
            }
        } else {
            setFirstFileNumber(commentDetId);
        }
        //refresh existing filenumbers view for this comment
        refreshFileNumbersForComment(commentDetId);
        this.initFormLetterSubType(fileNumId);
        logger.info("CommentDetailsDC.prepareExistingComment :: End preparing existing comment : " + commentDetId); 
    }
    
    /** This method is created to fix the issue with ADF Rollback and 
     * then while creating new comment and save, different row was getting displayed
     *
     * @param commentDetId
     */
    public void setCurrentRowInCommDetVO(Number commentDetId){
        
        logger.info("Starting setCurrentRowInCommDetVO   *********************");
        ViewObjectImpl commentVO = getCommentLogAM().getCllCommentDetailsView1();
        ViewCriteria vc = commentVO.getViewCriteria("CllCommentDetailsByCommentDetId");
        commentVO.setNamedWhereClauseParam("pCommentDetId", commentDetId);
        commentVO.applyViewCriteria(vc);
        commentVO.executeQuery();
        CllCommentDetailsViewRowImpl firstRow = (CllCommentDetailsViewRowImpl)commentVO.first();
        commentVO.setCurrentRow(firstRow);
        logger.info("Ending setCurrentRowInCommDetVO   *********************");
        
    }    
    /**As per story 2522,  retrieve the first file number and its release numbers for the comment
     *
     * @param commentDetId
     */
    public void setFirstFileNumber(Number commentDetId){
        
        logger.info("Starting setFirstFileNumber ****************");
        Number fileNumId = getCommentLogAM().getCllFilenumCommDetROView1().getFirstFileNumberForComment(commentDetId);        
        logger.info("Ending  setFirstFileNumber ****************");
        if( fileNumId != null ) {
            setFileNumCommentDet(commentDetId,fileNumId); 
        }else{
            setReleaseNumbersToEmpty();
        }
        
    }
    
    /** Invokes data control method commentHasFileNumId from  CllFilenumCommDetROViewImpl
     *
     * @param commDetId
     * @param fileNumId
     */
    public boolean commentHasFileNumId(Number commDetId, Number fileNumId){
        
        logger.info("Starting  commentHasFileNumId ****************");
        boolean flag = getCommentLogAM().getCllFilenumCommDetROView1().commentHasFileNumId(commDetId, fileNumId);
        logger.info("Ending  commentHasFileNumId ****************");
        return flag;
        
    }
    
    /**Refreshes the File Numbers VO for a given comment ID
     *
     * @param commentDetId
     */
    public void refreshFileNumbersForComment(Number commentDetId){
        ViewObjectImpl fileNumberVO = getCommentLogAM().getFileNumbersForCommentDetROView1();
        fileNumberVO.clearCache();
        ViewCriteria vc = fileNumberVO.getViewCriteria("FileNumbersForCommentDetByComDetId");
        fileNumberVO.setNamedWhereClauseParam("pCommentDetId", commentDetId);
        fileNumberVO.applyViewCriteria(vc);
        fileNumberVO.executeQuery(); 
    }
    
    
    /**Retrieves  file number Id for a  given  file type and file number
     * 
     * @param fileNumTypeId  
     * @param inputFileNumber
     * @return
     */
    public Number   getFileNumId(Number fileNumTypeId, String inputFileNumber) {
        logger.info("Starting  getFileNumId   **********************");
        Number fileNumId = null;
        ViewObjectImpl fileNumberVO = getCommentLogAM().getCllFileNumber1View1();
        ViewCriteria vc = fileNumberVO.getViewCriteria("CllFileNumber1ByFileTypeIdFileNumber");
        fileNumberVO.setNamedWhereClauseParam("pFileNumTypeId", fileNumTypeId);
        fileNumberVO.setNamedWhereClauseParam("pFileNumber",inputFileNumber ); 
        fileNumberVO.applyViewCriteria(vc);
        fileNumberVO.executeQuery(); 
        if(fileNumberVO.getEstimatedRowCount()>0){
           Row  row = fileNumberVO.first(); 
           DBSequence id=(DBSequence)row.getAttribute("FilenumId");
           fileNumId=id.getSequenceNumber();
           logger.info("File number id "+ row.getAttribute("FilenumId")+ "File number is" + row.getAttribute("FileNumber") );
        }
        clearViewCriteriaOnFileNumberView();
        logger.info("Ending  getFileNumId   **********************");
        return   fileNumId ;
    }
        
    /** Clears the filter  from   File Number VO
     * 
     */
    public void clearViewCriteriaOnFileNumberView(){
        logger.info("Starting  clearViewCriteriaOnFileNumberView ****************");
                ViewObjectImpl vo = getCommentLogAM().getCllFileNumber1View1(); 
                vo.removeApplyViewCriteriaName("CllFileNumber1ByFileTypeIdFileNumber") ; 
                vo.executeQuery(); 
                long count= vo.getEstimatedRowCount();
                logger.info("Total rows found  ******"+count);
               /* while(vo.hasNext()){
                    Row row= vo.next();
                    logger.info(""+row.getAttribute("FileNumber"));
                    logger.info(""+row.getAttribute("FilenumTypeId"));
                    logger.info(""+row.getAttribute("FilenumId"));
                }*/
        logger.info("Ending  clearViewCriteriaOnFileNumberView ****************");   
    }
    
    /**  Retrieves file type, file number for a given file number ID
     *
     * @param fileNumId
     * @return fileTypeFileNumber
     */
    public String  getFileTypeFileNumber(Number fileNumId){
        logger.info("Starting getFileTypeFileNumber   *********************"); 
        String fileTypeFileNumber;
        ViewObjectImpl fileNumVO = getCommentLogAM().getCllFileNumberView1();
        ViewCriteria vc = fileNumVO.getViewCriteria("CllFileNumberByFileNumId");
        fileNumVO.setNamedWhereClauseParam("pFileNumId", fileNumId);
        fileNumVO.applyViewCriteria(vc);
        fileNumVO.executeQuery();
        CllFileNumberViewRowImpl row = (CllFileNumberViewRowImpl)fileNumVO.first();   
        fileTypeFileNumber= row.getType()+"-"+row.getFileNumber(); 
        logger.info(" FileTypeFileNumber inside getFileTypeFileNumber of CommentDetailsDC is  *********************" +fileTypeFileNumber);
        
        logger.info("Ending getFileTypeFileNumber   *********************");
        return fileTypeFileNumber;
    }
    
     
    
    /**Looks for File Num Comment Detail record in FileNumCommentDetView for a given Comment id and file num id 
     * This method is used when we open up existing comment through File#Q details in various tabs
     * Used in prepareExistingComment()
     * @param commentDetId
     * @param fileNumId
     */
    public void setFileNumCommentDet(Number commentDetId,Number fileNumId){ 
        logger.info("Starting setFileNumCommentDet   *********************"); 
        ViewObjectImpl fileNumCommDetVO = getCommentLogAM().getCllFilenumCommDetView1();
        ViewCriteria vc = fileNumCommDetVO.getViewCriteria("CllFilenumCommDetByFileIdCommId");   
        fileNumCommDetVO.setNamedWhereClauseParam("pFileNumId", fileNumId);
        fileNumCommDetVO.setNamedWhereClauseParam("pCommentDetId", commentDetId);
        fileNumCommDetVO.applyViewCriteria(vc);
        fileNumCommDetVO.executeQuery();
        if(fileNumCommDetVO.getEstimatedRowCount() >0) {
            logger.info("File Number Comment Detail record found  for comment id :" +commentDetId + "and File num :" +fileNumId);
            CllFilenumCommDetViewRowImpl   row = (CllFilenumCommDetViewRowImpl) fileNumCommDetVO.first(); 
            Number fileTypeId= row.getFilenumTypeId();
            fileNumCommDetVO.setCurrentRow(row);
            setReleaseNumbers(fileNumId);
        }
        
        logger.info("Ending setFileNumCommentDet   *********************");  
    }


    /**
     * Retrieves the release numbers from Master File Number for the comment detail file number 
     * 
     * @param fileNumId
     */
    public void setReleaseNumbers(Number fileNumId){
        logger.info("Setting release number for file number id : " + fileNumId);
        Number masterFileNumId = getCommentLogAM().getCllFileNumberView1().findMasterFileNumId(fileNumId);
        //Call CllUtils to retrieves list of release numbers
        List<String> releaseNumbersList = new ArrayList<String>();
        try {
            releaseNumbersList = CllUtils.getReleaseNumsForMasterFileNumber(masterFileNumId);
            if (CollectionUtils.isNotEmpty(releaseNumbersList)){
                logger.info("Setting release numbers : " + releaseNumbersList.size());
                Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
                CommentDetails commentDetailsBean = (CommentDetails)pageFlowScope.get("commentDetails");
                commentDetailsBean.getReleaseNumberList().clear();
                commentDetailsBean.getReleaseNumberList().addAll(releaseNumbersList);
                ADFUtils.markScopeDirty(pageFlowScope);
            }
        } catch (Exception e){
            e.printStackTrace();
            logger.severe("Error on setting releasre number for Comment :: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }
                                                                          
    
//    /** Filters  the File Number Type and File Number VOs so that respective release numbers are displayed
//     * initially when we open up existing Comment through  File# Q
//     * @param fileTypeId
//     * @param fileNumId
//     */
//    public void setReleaseNumbers(Number fileTypeId, Number fileNumId){
//        logger.info("Starting  setReleaseNumbers ****************");
//        if(null == fileTypeId || null == fileNumId ) {
//            setReleaseNumbersToEmpty();
//            return;
//        }
//        FileNumberType1ViewImpl vo = getCommentLogAM().getFileNumTypesFileNumbers(); 
//        logger.info("file num id and  file type id  :" +fileNumId+"  "+fileTypeId); 
//        vo.setpFilenumTypeId(fileTypeId); 
//        vo.setApplyViewCriteriaName("FileNumberType1ByeFilenumTypeId");
//        logger.info(vo.getQuery());
//        vo.executeQuery(); 
//        logger.info("Estimated row count "  +vo.getEstimatedRowCount());
//        logger.info("Total row count  "  +vo.getRowCount());
//        if(vo.getEstimatedRowCount() >0) {
//            Row fileTypeRow= vo.first();
//            logger.info(fileTypeRow.getAttribute("FilenumTypeId").toString());
//            logger.info(fileTypeRow.getAttribute("Type").toString());
//            
//            vo.setCurrentRow(fileTypeRow);
//            
//            ViewObjectImpl fileNumVO = getCommentLogAM().getCllFileNumber1View1();  
//             ViewCriteria vc = fileNumVO.getViewCriteria("CllFileNumber1ByFileNumId");
//            fileNumVO.setNamedWhereClauseParam("pFileNumId", fileNumId); 
//            fileNumVO.applyViewCriteria(vc);
//            fileNumVO.executeQuery();
//            if(fileNumVO.getEstimatedRowCount() >0) {
//                Row  row= fileNumVO.first();
//                fileNumVO.setCurrentRow(row); 
//            }
//            
//        }
//        logger.info("Starting  setReleaseNumbers ****************");
//    }
    
    /** This method ensures that default release number row is not loaded and it is used when we try to create new comment and 
     * in this case  file number is empty which means  release numbers list must be empty
     */
    public void  setReleaseNumbersToEmpty(){
        ViewObjectImpl vo = getCommentLogAM().getCllFilenumRelFr1View1();
        vo.executeEmptyRowSet();
        
       /* ViewObjectImpl fileNumCommDetVo=getCommentLogAM().getCllFilenumCommDetView1();
        CllFilenumCommDetViewRowImpl row= (CllFilenumCommDetViewRowImpl)fileNumCommDetVo.getCurrentRow();
        if ( row != null){
            logger.info("Current  file number for  comment  is  :" + row.getFileNumber());

            setReleaseNumbers( row.getFilenumTypeId(),  row.getFilenumId());
        }else{
            ViewObjectImpl vo = getCommentLogAM().getCllFilenumRelFr1View1();
             vo.executeEmptyRowSet();
        } */

        logger.info("Setting empty release numbers...");
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        CommentDetails commentDetailsBean = (CommentDetails)pageFlowScope.get("commentDetails");
        commentDetailsBean.getReleaseNumberList().clear();
        ADFUtils.markScopeDirty(pageFlowScope);

    }
    
    /** This method ensures that default file number row is not loaded and it is used when we try to create new comment and 
     * in this case  file number list is empty
     */
    public void setExistingFileNumbersToEmpty(){
        ViewObjectImpl vo = getCommentLogAM().getFileNumbersForCommentDetROView1();
        vo.executeEmptyRowSet();
        logger.info("Number of file numbers records: " + vo.getEstimatedRowCount());
    }
        
        
    /** Clears the filters from File Number Type VO and File Number VO
     * 
     */
    public void clearViewCriteriaOnFileTypeAndFileNumber(){
        logger.info("Starting  clearViewCriteriaOnFileTypeAndFileNumber ****************");
                ViewObjectImpl vo = getCommentLogAM().getFileNumTypesFileNumbers();  
                ViewCriteria vc = vo.getViewCriteria("FileNumberType1ByeFilenumTypeId");
                if(vc != null) {
                    vo.removeApplyViewCriteriaName("FileNumberType1ByeFilenumTypeId") ; 
                    vo.executeQuery(); 
                }
                 
                ViewObjectImpl vo1 = getCommentLogAM().getCllFileNumber1View1();  
                ViewCriteria vc1 = vo1.getViewCriteria("CllFileNumber1ByFileNumId");
                if(vc1 != null) {
                    vo1.removeApplyViewCriteriaName("CllFileNumber1ByFileNumId") ; 
                   vo1.executeQuery();
                }
        logger.info("Starting  clearViewCriteriaOnFileTypeAndFileNumber ****************");   
    }
    
    /** Verifies existance of file number comment detail record in  CllFilenumCommDet table for a given 
     * file num id and comment detail id
     *This method is invoked when user tries to add file numbers to a comment
     * @param fileNumId
     * @param commentDetId
     * @return true if the record exists
     */
    
    public boolean isFileNumExistForCommentDet( Number fileNumId, Number commentDetId) {
        logger.info("Starting  isFileNumExistForCommentDet ****************");
        ViewObjectImpl fileNumCommDetVO = getCommentLogAM().getCllFilenumCommDetROView1();
        ViewCriteria vc = fileNumCommDetVO.getViewCriteria("CllFilenumCommDetByFileIdCommId");
        fileNumCommDetVO.setNamedWhereClauseParam("pFileNumId", fileNumId);
        fileNumCommDetVO.setNamedWhereClauseParam("pCommentDetId", commentDetId);
        fileNumCommDetVO.applyViewCriteria(vc);
        fileNumCommDetVO.executeQuery();
        logger.info("Ending  isFileNumExistForCommentDet ****************");
        if(fileNumCommDetVO.getEstimatedRowCount() >0) {
            return true;
        }else{
            return false;
        } 
        
    }
    
    /** Verifies existance of file number comment detail record in  CllFilenumCommDet table for a given 
     * file num id and comment detail id
     *
     * @param fileNumId
     * @param commentDetId
     * @return true if the record exists
     */
    
    public boolean getFileNumCommentDet( Number fileNumId, Number commentDetId) {
      logger.info("Starting getFileNumCommentDet   *********************");  
        ViewObjectImpl fileNumCommDetVO = getCommentLogAM().getCllFilenumCommDetView1();
        ViewCriteria vc = fileNumCommDetVO.getViewCriteria("CllFilenumCommDetByFileIdCommId");
        fileNumCommDetVO.setNamedWhereClauseParam("pFileNumId", fileNumId);
        fileNumCommDetVO.setNamedWhereClauseParam("pCommentDetId", commentDetId);
        fileNumCommDetVO.applyViewCriteria(vc);
        fileNumCommDetVO.executeQuery();
        logger.info("Ending getFileNumCommentDet   *********************");  
        if(fileNumCommDetVO.getEstimatedRowCount() >0) {
            return true;
        }else{
        return false;
        }
        
    }
    
    /** Returns the status type Id for a given  status type code
     *
     * @param statusTypeCode
     * @return 
     */
    public Number getCommentStatusTypeId(String statusTypeCode){
        return getCommentLogAM().getCllStatusTypeView1().getStatusTypeId(statusTypeCode);
    }
    
    /** Handle the event triggered by Comment Details Task flow  when comment gets deleted
     * It is called by  CommentList page
     * @param payload
     */
    public void handlerCommentListEvent(Object payload){
        logger.info("Starting handlerCommentListEvent inside CommentDetailsDC...");
        String commentListBeanName="#{backingBeanScope.CommentListBean}";
        CommentListBean bean =  (CommentListBean )CllUtils.getBeanInstance(commentListBeanName);
        bean.refreshCommentList(); 
        logger.info("Ending handlerCommentListEvent inside CommentDetailsDC...");
        
    }
    
    public void initFormLetterSubType(Number fileNumId){
        String subType = (String)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pFormSubType");
        Number formLetterId = (Number)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("pFormLetterId");
        if(subType != null){
        CllFormLetterListPRViewImpl formLtrPRView = getCommentLogAM().getCllFormLetterListPRView1();
        CllFormLetterListPRViewRowImpl formLtrPRViewRow = new CllFormLetterListPRViewRowImpl();
        formLtrPRView.executeEmptyRowSet();
        if(formLtrPRView != null && null == formLtrPRView.first()){
            formLtrPRViewRow = (CllFormLetterListPRViewRowImpl)formLtrPRView.createRow();
            formLtrPRView.insertRow(formLtrPRViewRow);
        }else{
            formLtrPRViewRow = (CllFormLetterListPRViewRowImpl)formLtrPRView.first();
        }
        formLtrPRViewRow.setKeyAttr(1);
            formLtrPRViewRow.setSubType(subType);
        formLtrPRView.setCurrentRow(formLtrPRViewRow);
        RowSet rSet = formLtrPRViewRow.getCllFormLetterSubTypeROView1();
        if(fileNumId != null){
            rSet.setNamedWhereClauseParam("bindFileNum", fileNumId);
            rSet.executeQuery();
            if(null != formLetterId){
            CllFormLetterViewImpl formLetter =
                (CllFormLetterViewImpl) getCommentLogAM().getCllFormLetterView1();
            formLetter.setApplyViewCriteriaName("CllFormLetterViewCriteria", false);
            formLetter.setNamedWhereClauseParam("pFormLetterId", formLetterId);
            formLetter.executeQuery();
            }
        }
        }
    }

    /** Handle the event triggered by Comment Details Task flow  when comment gets deleted
     *  It is called by FormLetter page
     * @param payload
     */
    public void handlerFormListEvent(Object payload){
        logger.info("Starting handlerCommentListEvent inside CommentDetailsDC...");
        String commentListBeanName="#{backingBeanScope.FormLetterListBean}";
        FormLetterListBean bean =  (FormLetterListBean )CllUtils.getBeanInstance(commentListBeanName);
        bean.refreshFormLetterList();
        logger.info("Ending handlerCommentListEvent inside CommentDetailsDC...");
        
    }
    
   /** Invokes  comment details bean method to reffresh the  comment details page
     *
     * @param payload
     */
    public void handlerRefreshCommDetEvent(Object payload){   
        logger.info("Starting handlerRefreshCommDetEvent inside CommentDetailsDC...");  
           ActionEvent actionEvent = (ActionEvent)payload;
           UIComponent component = (UIComponent)actionEvent.getSource(); 
           //Boolean autoCommit = (Boolean)component.getAttributes().get("autoCommit");    //TODO  commented code will be used in phase 2
          // String currentKeyInCommLst=(String)component.getAttributes().get("rowKeyInCommList");  
            
           Boolean commentLogModified = (Boolean)component.getAttributes().get("commentLogModified");                
           ViewCommentDetails  commDet=(ViewCommentDetails)ADFUtils.evaluateEL("#{backingBeanScope.viewCommentDetails}");
           // commDet.refreshCommentDetails(autoCommit,currentKeyInCommLst); 
           commDet.refreshCommentDetails(commentLogModified);
          logger.info("Ending handlerRefreshCommDetEvent inside CommentDetailsDC...");
            
    }
   
   /** Invokes  Comment List  bean method to reffresh the Comment List Tab
     *
     * @param payload
     */
    public void handlerSetRowKeyInCommentListEvent(Object payload){  //TODO  Will be used in phase 2 based on user feedback
        logger.info("Starting handlerSetRowKeyInCommentListEvent inside CommentDetailsDC...");  
           ActionEvent actionEvent = (ActionEvent)payload;
           UIComponent component = (UIComponent)actionEvent.getSource();  
           String currentKeyInCommLst=(String)component.getAttributes().get("rowKeyInCommList");  
                           
           CommentListBean  commListBean=(CommentListBean)ADFUtils.evaluateEL("#{backingBeanScope.CommentListBean}");
           commListBean.setCurrentRowKey(currentKeyInCommLst);
          logger.info("Ending handlerSetRowKeyInCommentListEvent inside CommentDetailsDC...");
            
    }
   
   /** Retrieves  the status code for the selected comment status in the filter in comment tab
     *
     * @param index
     * @return commentStatusCode
     */
    public String getStatusCode(Integer  index ){   
        //this method is derived from already existing PILLAR metod   executeCommentsListByType() in App Module
        logger.info("Starting  getStatusCode *************************");  
        String commentStatusCode = null;
        CllStatusPRViewImpl statusView = getCommentLogAM().getCllStatusPRView1();
        CllStatusPRViewRowImpl statusViewRow = (CllStatusPRViewRowImpl)statusView.getCurrentRow();
        if(index != 0){         
             Row   row = statusViewRow.getCllStatusSLView1().getRowAtRangeIndex(index-1);
                commentStatusCode = (String)row.getAttribute("Code");
        }
        logger.info("Ending   getStatusCode  *********************");
        return commentStatusCode;

    }
   
    /** Retrieves  disposition type id for disposition approved
     * 
     * @return Number
     */
   public Number retrieveDispositionTypeIdApproved(){ 
       return getCommentLogAM().getCllDispositionTypeView1().getDispositionTypeId(CllConstants.CLL_DISPOSITION_TYPE_APPR);      
   }
    
      
   /**Retrieves  doc ids for  attachments for a comment
     *
     * @param caseId
     * @param modName
     * @return
     */
    public ArrayList<String> getSelectedDocIds(Number caseId, String modName){
        ArrayList<String> docIdList = new ArrayList<String>();
        AttachmentViewImpl vo = getCllSharedCompoentsAM().getAttachmentView1();
        vo.findByCaseIdModName(caseId, modName);
        logger.info("Attachments  for commment is "  + vo.getEstimatedRowCount());
        if(vo.getEstimatedRowCount()  >0){
               /*while(vo.hasNext()){
                    AttachmentViewRowImpl row= (AttachmentViewRowImpl)vo.next();
                    docIdList.add(row.getUcmId()); 
                }*/
             AttachmentViewRowImpl row =(AttachmentViewRowImpl)vo.first();
             while (row != null) {
                 docIdList.add(row.getUcmId());  
                  row = (AttachmentViewRowImpl)vo.next();
             }
        } 
        return docIdList;
    }

    /**
     * Converts the comment to form letter.
     * Invokes the FormLetterPrcessing Web Services
     *
     */
    public void convertCommentToFormLetter() {
        CllFormLetterViewImpl formLetter = (CllFormLetterViewImpl)this.getCommentLogAM().getCllFormLetterView1();
        CllFormLetterViewRowImpl formLetterRow = (CllFormLetterViewRowImpl)formLetter.getCurrentRow();
        CllFormLetterListPRViewImpl formLtrPRView = this.getCommentLogAM().getCllFormLetterListPRView1();
        CllFormLetterListPRViewRowImpl formLtrPRViewRow =
            (CllFormLetterListPRViewRowImpl)formLtrPRView.getCurrentRow();
        RowSet rset = formLtrPRViewRow.getCllFormLetterSubTypeROView1();
        rset.setNamedWhereClauseParam("bindFileNum", formLetterRow.getFilenumId());
        rset.executeQuery();
        formLtrPRViewRow.setSubType(formLetterRow.getSubType());
        CllCommentDetailsViewImpl commentDet = this.getCommentLogAM().getCllCommentDetailsView1();
        CllCommentDetailsViewRowImpl commentDetRow = (CllCommentDetailsViewRowImpl)commentDet.getCurrentRow();
        commentDetRow.setCllFormLetterId(formLetterRow.getCllFormLetterId().getSequenceNumber());
        this.getCommentLogAM().getDBTransaction().commit();

//        logger.info("Retrieving CLL Application Properties");
//        Map appProps = getCllSharedCompoentsAM().getResourceBundle();
//        String wsdlURL = (String)appProps.get("CLL_FORMLETTER_URL");
//        String namespaceURI = (String)appProps.get("CLL_FORMLETTER_QNAME_NAMESPACE_URI");
//        String localPart = (String)appProps.get("CLL_FORMLETTER_QNAME_LOCALPART");
//        logger.info("****** CLL_FORMLETTER_URL = " + wsdlURL);
//        logger.info("****** CLL_FORMLETTER_QNAME_NAMESPACE_URI = " + namespaceURI);
//        logger.info("****** CLL_FORMLETTER_QNAME_LOCALPART = " + localPart);

        try {
            Integer formLetterId = formLetterRow.getCllFormLetterId().getSequenceNumber().intValue();
            logger.info("Form Letter Id = " + formLetterId);
//            FormLetterProcessingWrapper wrapper = new FormLetterProcessingWrapper(wsdlURL, namespaceURI, localPart);
//            wrapper.processFormLetters(formLetterId); //TODO: It needs now a file number Id
            
            //Before it was inovking BPEL Service. Now, it calls the same method directly.
            getCllServicesAM().formLetterProcessing(new Number(formLetterId));
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }

    }

    /**Verifies any attachments exist or not for a comment log.
     *
     * @param commentDetId
     * @return boolean
     */
    public boolean attachmentsExists(Number commentDetId) {
        AttachmentROViewImpl vo = (AttachmentROViewImpl)getCommentLogAM().getAttachmentROView1(); //attachmentROVO
        boolean flag = vo.isAttachmentExist(commentDetId, CllConstants.CLL_MODULE);
        return flag;
    }

    /** invokes custom method from model which in turn gets next sequence number for a given file number  also sets it back to the database table
     *
     * @param fileNumId
     * @return
     */
    public Number getSetFileNumberSeqNumberNext(Number fileNumId) {
        Number nextSeqNumber = this.getCommentLogAM().getCllFileNumberView1().getSetFileNumberSeqNumberNext(fileNumId);
        return nextSeqNumber;
    }

    public boolean findRowWithSRSeqNumber(Number fileNumId, Number formLetId) {
        boolean flag = false;
        FileNumCommDetSeqNumROViewImpl view =
            (FileNumCommDetSeqNumROViewImpl)getCommentLogAM().getFileNumCommDetSeqNumROView1();
        view.findRowWithSRSeqNumber(fileNumId, formLetId);
        if (view.getEstimatedRowCount() > 0) {
            flag = true;
        }
        return flag;
    }
    
    
    /**
     * Provide an instance of RellogServicesWrapper to invoke Rellog Web Services through proxy
     * 
     * @return
     */
    private RellogServicesWrapper getRellogServicesWrapper(){
        logger.info("Retrieving CLL Application Properties");
        Map<String,String> appProps = getCllSharedCompoentsAM().getResourceBundle();
//        String wsdlURL = (String)appProps.get("RELLOGSERVICES_WSDL_URL");
//        String namespaceURI = (String)appProps.get("RELLOGSERVICES_QNAME_NAMESPACE_URI");
//        String localPart = (String)appProps.get("RELLOGSERVICES_QNAME_LOCALPART");
//        logger.finer("RELLOGSERVICES_WSDL_URL = " + wsdlURL);
//        logger.finer("RELLOGSERVICES_QNAME_NAMESPACE_URI : " + namespaceURI);
//        logger.finer("RELLOGSERVICES_QNAME_LOCALPART : " + localPart);
//        
//        RellogServicesWrapper wrapper = new RellogServicesWrapper(wsdlURL, namespaceURI, localPart);
        RellogServicesWrapper wrapper = new RellogServicesWrapper(appProps);
        return wrapper;
    }
    
    /** Invokes remote serice to retrieve release numbers for a master file number id
     *
     * @param masterFileNumId
     * @return
     */
    public List<String> getReleaseNumsForMasterFileNumber(Number masterFileNumId){  
        List<String> relNumbers=null;
        try {
             relNumbers= getRellogServicesWrapper().retrieveMasterReleaseNumbers(masterFileNumId);
            if(null ==relNumbers){
                relNumbers= new ArrayList<String>();
            }
        } catch (Exception e) {
            logger.info("Exception while invoking rellog service retrieveMasterReleaseNumbers() : " +e.getMessage()); 
            e.printStackTrace();
            
        }
       return  relNumbers;
     }
}
