package gov.sec.cll.view.dc;

 
import gov.sec.cll.model.adfbc.services.CommentLogAppModuleImpl;
import gov.sec.cll.model.adfbc.views.AttachmentROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllApplicationPropertiesViewImpl;
import gov.sec.cll.model.adfbc.views.CllCommentsListROViewImpl;
import gov.sec.cll.model.adfbc.views.CllDispositionTypeViewImpl;
import gov.sec.cll.model.adfbc.views.CllFileNumPubCommListROViewImpl;
import gov.sec.cll.model.adfbc.views.CllFileNumPubCommListROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFileNumberViewImpl;
import gov.sec.cll.model.adfbc.views.CllFileNumberViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumProcessingViewImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumRelFrViewImpl;
import gov.sec.cll.model.adfbc.views.CllFilenumRelFrViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllOrigInCommentROViewImpl;
import gov.sec.cll.model.adfbc.views.CllOrigInCommentROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllStatusTypeViewImpl;
import gov.sec.cll.model.adfbc.views.CllSubmitterForPublishingCommentROViewRowImpl;
import gov.sec.cll.model.adfbc.views.CllTypeViewImpl;
import gov.sec.cll.model.adfbc.views.CommentDetailsPublishingROViewImpl;
import gov.sec.cll.model.adfbc.views.CommentDetailsPublishingROViewRowImpl;
import gov.sec.cll.model.adfbc.views.FormLetterCountROViewImpl;
import gov.sec.cll.model.adfbc.views.FormLetterUnPubCountROViewImpl;
import gov.sec.cll.model.adfbc.views.StaffRolesROViewRowImpl;

import gov.sec.cll.sharedcomponents.view.utils.ADFUtils;
import gov.sec.cll.sharedcomponents.view.utils.SharedCompConstants;
import gov.sec.cll.view.beans.ManageCommentLog;

import gov.sec.cll.view.beans.ViewStateManageCommentLog;

import gov.sec.cll.view.utils.CllConstants;

import gov.sec.cll.view.utils.CllUtils;

import gov.sec.cll.view.utils.PackageUtils;

import java.math.BigDecimal;

import java.sql.CallableStatement;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.event.ActionEvent;

import oracle.adf.share.logging.ADFLogger;

import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.RowSet;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewCriteria;
import oracle.jbo.domain.ClobDomain;
import oracle.jbo.domain.Date;
import oracle.jbo.server.ViewObjectImpl;
import oracle.jbo.server.ViewRowImpl;
import oracle.jbo.domain.Number;
import oracle.jbo.server.DBTransaction;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;

public class ManageCommntLogDC {
    public ManageCommntLogDC() {
        super();
    }
    
    private static ADFLogger logger = ADFLogger.createADFLogger(ManageCommntLogDC.class);
    
    /**
     * Retrieves an instance of the application module for CommentLogAppModule
     * 
     */
    private CommentLogAppModuleImpl getCommentLogAM() {
        CommentLogAppModuleImpl amImpl=(CommentLogAppModuleImpl)ADFUtils.getApplicationModuleForDataControl("CommentLogAppModuleDataControl");
        return amImpl;
    }

    /**
     * Handkes the contextual event to shows the View Comment Inbox 
     * 
     * @param payload
     */
    public void handlerViewCommentInbox(Object payload){
        logger.info("Displaying Comment Inbox");
        ViewStateManageCommentLog viewStateManageCommentLog =
            (ViewStateManageCommentLog)AdfFacesContext.getCurrentInstance().getViewScope().get("viewStateManageCommentLog");
        viewStateManageCommentLog.commentInboxClickAction();        
    }
    
    /** Retrieves  user roles for a given user name
     *
     * @param userName
     * @return  list of roles
     */
    public ArrayList<Map<String,String>>  getStaffRolesByUserName(String userName){ 
           logger.info("Starting getStaffRolesByUserName  ***************"); 
           ViewObjectImpl staffRolesVO= getCommentLogAM().getStaffRolesROView1();
           ViewCriteria vc = staffRolesVO.getViewCriteria("StaffRolesByUserName");
           staffRolesVO.setNamedWhereClauseParam("pUserName", userName);
           staffRolesVO.applyViewCriteria(vc);
           staffRolesVO.executeQuery(); 
           logger.info(" ******************** Number of Roles fetched for the user ********"  + userName+ " is  :"  +staffRolesVO.getEstimatedRowCount()); 
           ArrayList<Map<String,String>> staffRoles= new  ArrayList<Map<String,String>>();
           while(staffRolesVO.hasNext()){
               Map<String,String> staffRoleInfo = new HashMap<String,String>(); 
               StaffRolesROViewRowImpl viewRowImpl = (StaffRolesROViewRowImpl)staffRolesVO.next();
               logger.info(" Role Code is  " +viewRowImpl.getStaffTypeCode());
               logger.info(" Role is  " +viewRowImpl.getType());
               staffRoleInfo.put("roleCode",viewRowImpl.getStaffTypeCode());
               staffRoleInfo.put("role",viewRowImpl.getType());
               staffRoleInfo.put("role",viewRowImpl.getType());
               staffRoleInfo.put("roleTypeId",viewRowImpl.getStaffTypeId().toString());
               staffRoles.add(staffRoleInfo);
           } 
           logger.info("Ending  getStaffRolesByUserName  ***************");
           return staffRoles; 
       }
    
    /**  Updates assignee for a file to with new staff
     *
     * @param fileNumId
     * @param staffId
     */
    public void updateFileAssignee(Number fileNumId,Number staffId){
        logger.info("Starting updateFileAssignee  ***************"); 
        ViewObjectImpl fileAssignVO= getCommentLogAM().getCllFileNumAssignView1(); 
        ViewCriteria vc = fileAssignVO.getViewCriteria("CllFileNumAssignByFileNumId");
        fileAssignVO.setNamedWhereClauseParam("pFileNumId", fileNumId);
        fileAssignVO.applyViewCriteria(vc);
        fileAssignVO.executeQuery();
        logger.info("Num of records matching file number is  "+fileAssignVO.getRowCount());
        Row row =  fileAssignVO.first();   
        row.setAttribute("StaffId", staffId);
        row.setAttribute("AssignedDate",  ADFUtils.getCurrentJboDate());
        logger.info("Ending updateFileAssignee  ***************"); 
    }
    
    /**  Insert assignee record for a given file with current staff
     *
     * @param fileNumId
     * @param staffId
     */
    public void insertIntoFileNumAssign(Number fileNumId,Number staffId){
        logger.info("Starting insertIntoFileNumAssign  ***************"); 
        ViewObjectImpl fileAssignVO= getCommentLogAM().getCllFileNumAssignView1();  
        fileAssignVO.executeQuery();
        ViewRowImpl row = (ViewRowImpl)fileAssignVO.createRow();  
        row.setAttribute("FilenumId", fileNumId);
        row.setAttribute("StaffId", staffId);
        row.setAttribute("AssignedDate",  ADFUtils.getCurrentJboDate()); 
        //row.setAttribute("CreatedBy",  "test");
        fileAssignVO.insertRow(row); 
        logger.info("Ending insertIntoFileNumAssign  ***************"); 
    }
    
    /** Handle the event triggered by Comment Inbox Task flow to access the payload passed
     *
     * @param payload
     */
    public void handlerViewFileNumEvent(Object payload) {
        logger.info("Starting handlerViewRellogEvent inside ManageCommntLogDC...");
        
        ActionEvent actionEvent = (ActionEvent)payload;
        UIComponent component = (UIComponent)actionEvent.getSource();
        
        Number fileNumId = (Number)component.getAttributes().get("fileNumId"); 
        String fileTypeFileNumber=(String)component.getAttributes().get("fileTypeFileNumber");
//        String typeCode = (String)component.getAttributes().get("typeCode");
        String dispCode = (String)component.getAttributes().get("dispCode");
        //String origination=(String)component.getAttributes().get("origination");
        logger.info("File Num Id passed from Comment Inbox task flow to Main TF  = " + fileNumId);
        logger.info("File Type+File Number passed from Comment Inbox task flow to Main TF  = "  + fileTypeFileNumber);
        //logger.info("Orgination passed from Comment Inbox task flow to Main TF  = "  + origination);
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        ManageCommentLog manageCommentLog = (ManageCommentLog)pageFlowScope.get("manageCommentLog");
        manageCommentLog.setFileNumId(fileNumId);
        manageCommentLog.setFileTypeFileNumber(fileTypeFileNumber);
//        manageCommentLog.setTypeCode(typeCode); 
        manageCommentLog.setDispCode(dispCode);
        ADFUtils.markScopeDirty(pageFlowScope);
        ViewStateManageCommentLog viewStateManageCommentLog = 
                  (ViewStateManageCommentLog)AdfFacesContext.getCurrentInstance().getViewScope().get("viewStateManageCommentLog");
        //viewStateManageCommentLog.setFileNumId(fileNumId); 
        viewStateManageCommentLog.fileNumberQDetailsBTF(); 
        
        logger.info("Ending handlerViewRellogEvent inside ManageCommntLogDC...");
    }

    public void handlerViewCommentDetails(Object payload) {
        ActionEvent actionEvent = (ActionEvent)payload;
        UIComponent component = (UIComponent)actionEvent.getSource();
        Number commentDetId = (Number)component.getAttributes().get("CommentId");
        Number fileNumId = (Number)component.getAttributes().get("FilenumId");
        String FileNumber = (String)component.getAttributes().get("FileNumber");
        String SubType = (String)component.getAttributes().get("SubType");
        BigDecimal FormLetterId = (BigDecimal)component.getAttributes().get("FormLetterId");
        String search = (String)component.getAttributes().get("SearchComments");
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        ManageCommentLog manageCommentLog =
            (ManageCommentLog)pageFlowScope.get("manageCommentLog");
        try {
            manageCommentLog.setCommentDetId(new Number(commentDetId));
            manageCommentLog.setFileNumId(new Number(fileNumId));
            manageCommentLog.setFileTypeFileNumber(FileNumber);
            manageCommentLog.setSubType(SubType);
            if (null != FormLetterId)
                manageCommentLog.setFormLetterId(new Number(FormLetterId));
            else
                manageCommentLog.setFormLetterId(null);
            manageCommentLog.setSearch(search);
            ADFUtils.markScopeDirty(pageFlowScope);
        } catch (SQLException e) {
        }
        ViewStateManageCommentLog viewStateManageCommentLog =
            (ViewStateManageCommentLog)AdfFacesContext.getCurrentInstance().getViewScope().get("viewStateManageCommentLog");
        viewStateManageCommentLog.commentDetailsBTF();
    }
    
    public void handlerFileNumberDetailsEvent(Object payload){
        ActionEvent actionEvent = (ActionEvent)payload;
        UIComponent component = (UIComponent)actionEvent.getSource();
        BigDecimal fileNumberId = (BigDecimal)component.getAttributes().get("fileNumberId"); 
        String search = (String)component.getAttributes().get("SearchFileNumbers");
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        ManageCommentLog manageCommentLog = (ManageCommentLog)pageFlowScope.get("manageCommentLog");
        try {
            manageCommentLog.setFileNumId(new Number(fileNumberId));
        } catch (SQLException e) {
        }
        manageCommentLog.setSearch(search);
        ADFUtils.markScopeDirty(pageFlowScope);
        ViewStateManageCommentLog viewStateManageCommentLog = 
                  (ViewStateManageCommentLog)AdfFacesContext.getCurrentInstance().getViewScope().get("viewStateManageCommentLog");
        viewStateManageCommentLog.fileNumberDetailsBTF();
    }

   /**  Verifies whether file number exists already in assign table  
     *
     * @param fileNumId
     * @return boolean
     */
    public boolean fileNumAlreadyExistsinAssignTable(Number fileNumId){
        boolean flag=false;
        ViewObjectImpl fileNumAssginVO= getCommentLogAM().getCllFileNumAssignROView1();
        ViewCriteria vc = fileNumAssginVO.getViewCriteria("CllFileNumAssignByFileNumId");
        fileNumAssginVO.setNamedWhereClauseParam("pFileNumId", fileNumId);
        fileNumAssginVO.applyViewCriteria(vc);
        fileNumAssginVO.executeQuery(); 
        if(fileNumAssginVO.getEstimatedRowCount() >0){
            flag=true;
        }else{
           flag=false;
        }
        return flag;
    }
    
    /** Retrieves  UCM  docIDs and doc names for a given  comment ID
     *
     * @param commentID
     * @return Map
     */
    public  Map<String,String> getDocIDsForComment(Number commentID)   {
        logger.info("Starting getDocIDsForComment   *******************");
        Map<String,String> docIDs= new HashMap<String,String>();
        ViewObjectImpl attachmentVO= getCommentLogAM().getAttachmentROView1();    
        ViewCriteria vc = attachmentVO.getViewCriteria("AttachmentViewByCaseIdModuleName");
        attachmentVO.setNamedWhereClauseParam("pCaseId", commentID);
        attachmentVO.setNamedWhereClauseParam("pModuleName", SharedCompConstants.CLL_MODULE);
        attachmentVO.applyViewCriteria(vc);
        attachmentVO.executeQuery(); 
        if(attachmentVO.getEstimatedRowCount() >0){
            while(attachmentVO.hasNext()) {
                AttachmentROViewRowImpl row=  (AttachmentROViewRowImpl)attachmentVO.next();
                docIDs.put(row.getUcmId(),row.getDocumentName());
            }
        }
        attachmentVO.removeApplyViewCriteriaName("AttachmentViewByCaseIdModuleName");
        attachmentVO.executeQuery();
        logger.info("Ending getDocIDsForComment   *******************");
        return docIDs;
    }
    
    //Retrieves  published  names for attachments  for  a list of comment IDs
      
    public  Map<Number,List<String>> getPublishedNamesForComments(List<Number> commentIds)   {
        logger.info("Starting getPublishedNamesForComments   *******************");
        Map<Number,List<String>> publishedNamesForComments= new HashMap<Number,List<String>>(); 
        ViewObjectImpl attachmentVO= getCommentLogAM().getAttachmentROView1();    
        for (Number commentId:commentIds){
            ArrayList<String> pubNames= new ArrayList<String>();
            ViewCriteria vc = attachmentVO.getViewCriteria("AttachmentViewByCaseIdModuleName");
            attachmentVO.setNamedWhereClauseParam("pCaseId", commentId);
            attachmentVO.setNamedWhereClauseParam("pModuleName", SharedCompConstants.CLL_MODULE);
            attachmentVO.applyViewCriteria(vc);
            attachmentVO.executeQuery(); 
            if(attachmentVO.getEstimatedRowCount() >0){
                while(attachmentVO.hasNext()) {
                    AttachmentROViewRowImpl row=  (AttachmentROViewRowImpl)attachmentVO.next();
                    pubNames.add(row.getPublishedName());
                }
                publishedNamesForComments.put(commentId,pubNames);
            }
            
        } 
        attachmentVO.removeApplyViewCriteriaName("AttachmentViewByCaseIdModuleName");
        attachmentVO.executeQuery();
        logger.info("Ending getPublishedNamesForComments   *******************");
        return publishedNamesForComments;
    }
    
    /** Update the status for  published comments
     *
     * @param commentIds
     * @return int
     */
    public int updateStatusForPublishedComments(String commentIds) {
        logger.info("Starting updateStatusForPublishedComments   ****************** ");
        //Retrieving Published Status Type Id
        CllStatusTypeViewImpl statusTypeVO = getCommentLogAM().getCllStatusTypeView1();
        Number pubtatusTypeId = statusTypeVO.getStatusTypeId(CllConstants.CLL_STATUS_TYPE_CODE_PUB); 
         
        
        DBTransaction trans = getCommentLogAM().getDBTransaction();

        CallableStatement statement = null;
        int rows = 0;

        StringBuffer plsql = new StringBuffer();
        plsql.append("BEGIN ")
             .append("UPDATE CLL.CLL_COMMENT_DETAILS ")
             .append("SET CLL_STATUS_TYPE_ID = ? ") 
             .append("WHERE CLL_COMM_DET_ID IN  ") 
             .append(commentIds) 
             .append(";") 
             .append("END; ");
              
        statement = trans.createCallableStatement(plsql.toString(), 0);
        try {
            statement.setInt(1, pubtatusTypeId.intValue()); 
            // statement.setString(2, commentIds);   
            rows = statement.executeUpdate(); 
            //trans.commit();
            //trans.rollback();
            logger.info(" Comments  have been  updated  with status   published  ******************");
        } catch (SQLException s) { 
            s.printStackTrace();
            throw new JboException(s);
        } finally {
            try {
                if (statement != null)
                    statement.close();
                return rows;
            } catch (SQLException s) { 
                logger.severe("Error closing SQL Update statement.", s);
            }
        }
        logger.info("Ending updateStatusForPublishedComments   ****************** ");
        return rows;
    }
    
    /** Update the status for  unpublished comments
     *
     * @param commentIds
     * @return int
     */
    public int updateStatusForUnPublishedComments(String commentIds) {
        logger.info("Starting updateStatusForUnPublishedComments   ****************** "); 
        
         
        CllStatusTypeViewImpl statusTypeVO = getCommentLogAM().getCllStatusTypeView1();
        Number processStatusTypeId = statusTypeVO.getStatusTypeId(CllConstants.CLL_STATUS_TYPE_CODE_PRO); 
         
        
        DBTransaction trans = getCommentLogAM().getDBTransaction();

        CallableStatement statement = null;
        int rows = 0;

        StringBuffer plsql = new StringBuffer();
        plsql.append("BEGIN ")
             .append("UPDATE CLL.CLL_COMMENT_DETAILS ")
             .append("SET CLL_STATUS_TYPE_ID = ? ") 
             .append("WHERE CLL_COMM_DET_ID IN  ") 
             .append(commentIds) 
             .append(";") 
             .append("END; ");
              
        statement = trans.createCallableStatement(plsql.toString(), 0);
        try {
            statement.setInt(1, processStatusTypeId.intValue()); 
            // statement.setString(2, commentIds);   
            rows = statement.executeUpdate(); 
            //trans.commit();
            //trans.rollback();
            logger.info(" Comments  have been  updated  with status   published  ******************");
        } catch (SQLException s) { 
            s.printStackTrace();
            throw new JboException(s);
        } finally {
            try {
                if (statement != null)
                    statement.close();
                return rows;
            } catch (SQLException s) { 
                logger.severe("Error closing SQL Update statement.", s);
            }
        }
        logger.info("Ending updateStatusForUnPublishedComments   ****************** ");
        return rows;
    }
     
    
    /**
     * Locks the File Number by adding one row with a specific file number Id in VO.
     * If lock already exist, it will return false
     *  
     * @param fileNumberId File Number Id
     */
    public boolean lockFileNumber(Number fileNumberId){
        CllFilenumProcessingViewImpl vo = getCommentLogAM().getCllFilenumProcessingView1();
        boolean exist = vo.findFileNumProcessing(fileNumberId);
        if (exist){
            return false;
        } else {
            vo.createInsertRow(fileNumberId);
            getCommentLogAM().getDBTransaction().commit();
            return true;
        }
    }
    
    /**
     * Locks the File Number by adding one row with a specific file number Id in VO.
     * If lock already exist, it will return 0
     *  
     * @param fileNumberId File Number Id
     */
    public Integer lockFileNumberRetInt(Number fileNumberId){
        CllFilenumProcessingViewImpl vo = getCommentLogAM().getCllFilenumProcessingView1();
        Integer retValue = 0;
        boolean exist = vo.findFileNumProcessing(fileNumberId);
        if (exist){
            return retValue;
        } else {
            vo.createInsertRow(fileNumberId);
            getCommentLogAM().getDBTransaction().commit();
            retValue = 1;
            return retValue;
        }
    }
    

    /**
     * Unlocks the file number by deleting the row for the specific file number Id
     * 
     * @param fileNumberId   File Number Id
     */
    public void unlockFileNumber(Number fileNumberId){
        CllFilenumProcessingViewImpl vo = getCommentLogAM().getCllFilenumProcessingView1();
        vo.deleteRow(fileNumberId);
        getCommentLogAM().getDBTransaction().commit(); 
    } 
     
    
    
    public void unlockFileNumberNoCommit(Number fileNumberId){
        CllFilenumProcessingViewImpl vo = getCommentLogAM().getCllFilenumProcessingView1();
        vo.deleteRow(fileNumberId);
    }
    
    
    /**
     * Retrieves release numbers in a String separated by commas
     * 
     * @param fileNumberId      File Number Id
     * @return  Release numbers
     */
    public String retrieveRelNumbersByFileNumId(Number fileNumberId){
        logger.info("Retriving Release Number by File Number Id = " + fileNumberId);
        String releaseNumbers = "";
        CllFilenumRelFrViewImpl vo = getCommentLogAM().getCllFilenumRelFrView2();
        vo.findByFileNum(fileNumberId.toString());
        List<String> relNumList = new ArrayList<String>();
        if (vo.getEstimatedRowCount() > 0){
            RowSetIterator rsi = vo.createRowSetIterator(null);
            rsi.reset();
            while (rsi.hasNext()){
                CllFilenumRelFrViewRowImpl row = (CllFilenumRelFrViewRowImpl)rsi.next();
                logger.info("Adding Release Number to List : " + row.getRelnum());
                relNumList.add(row.getRelnum());
            }
            rsi.closeRowSetIterator();
        }
        if (relNumList.size() > 0){
            releaseNumbers = relNumList.toString();
            releaseNumbers = releaseNumbers.substring(1, releaseNumbers.length()-1); 
        }
        logger.info("Returning Release Number List = " + releaseNumbers);
        return releaseNumbers;
    }

    /**
     * Calculates and retrieves the count of form letters instances to be published.
     * The Form letter instances (comments) that are consider for the count are 
     * Processed, and it has disposition approved.
     * 
     * @param formLetterId  Form Letter Id
     * @return  Form letter instances count
     */
    public int countApprovedFormLetterInstances(Number formLetterId){
        logger.info("Counting Approved Form Letter instances by FormLetterId = " + formLetterId);
        
        //Retrieving Status Type Id
        CllStatusTypeViewImpl statusTypeVO = getCommentLogAM().getCllStatusTypeView1();
        Number statusTypeId = statusTypeVO.getStatusTypeId(CllConstants.CLL_STATUS_TYPE_CODE_PRO);

        //Retrieving Cll Type Id
        CllTypeViewImpl cllTypeVO = getCommentLogAM().getCllTypeView1();
        Number cllTypeId = cllTypeVO.getCommentTypeId(CllConstants.CLL_TYPE_CODE_FORM_LETTER);

        //Retrieving Disposition Id
        CllDispositionTypeViewImpl dispTypeVO = getCommentLogAM().getCllDispositionTypeView1();
        Number dispTypeId = dispTypeVO.getDispositionTypeId(CllConstants.CLL_DISPOSITION_TYPE_APPR);
        
        //Counting the Form Letter Instances
        FormLetterCountROViewImpl countVO = getCommentLogAM().getFormLetterCountROView1();
        int count = countVO.countApprovedFormLetterInstances(formLetterId, statusTypeId, cllTypeId, dispTypeId);
        
        logger.info("ManageCommntLogDC.countApprovedFormLetterInstances() :: Returning count : " + count);        
        return count;
    }
    
    /**
     * Calculates and retrieves the count of form letters instances to be unpublished.
     * The Form letter instances (comments) that are consider for the count have status as Published
     * 
     * @param formLetterId  Form Letter Id
     * @return  Form letter instances count
     */
    public int countPublishedFormLetterInstances(Number formLetterId){
        logger.info("Counting Published Form Letter instances by FormLetterId = " + formLetterId);
        
        //Retrieving Status Type Id
        CllStatusTypeViewImpl statusTypeVO = getCommentLogAM().getCllStatusTypeView1();
        Number statusTypeId = statusTypeVO.getStatusTypeId(CllConstants.CLL_STATUS_TYPE_CODE_PUB);

        //Retrieving Cll Type Id
        CllTypeViewImpl cllTypeVO = getCommentLogAM().getCllTypeView1();
        Number cllTypeId = cllTypeVO.getCommentTypeId(CllConstants.CLL_TYPE_CODE_FORM_LETTER);
        
        //Counting the Form Letter Instances
        FormLetterUnPubCountROViewImpl countVO = getCommentLogAM().getFormLetterUnPubCountROView1();
        int count = countVO.countPublishedFormLetterInstances(formLetterId, statusTypeId, cllTypeId);
        
        logger.info("ManageCommntLogDC.countPublishedFormLetterInstances() :: Returning count : " + count);        
        return count;
    }

    /**
     * Updates the comment detail records with new status Published
     * 
     * @param formLetterId  Form Letter Id
     * @return
     */
    public int updateCommentDetPublishStatus(Number formLetterId) {
        logger.info("Updating Status for Comment Details to Published. Param :: formLetterId = " + formLetterId);
        //Retrieving Published Status Type Id
        CllStatusTypeViewImpl statusTypeVO = getCommentLogAM().getCllStatusTypeView1();
        Number pubtatusTypeId = statusTypeVO.getStatusTypeId(CllConstants.CLL_STATUS_TYPE_CODE_PUB);
        
        //Retrieving Processed Status Type Id
        Number proStatusTypeId = statusTypeVO.getStatusTypeId(CllConstants.CLL_STATUS_TYPE_CODE_PRO);

        //Retrieving Cll Type Id
        CllTypeViewImpl cllTypeVO = getCommentLogAM().getCllTypeView1();
        Number cllTypeId = cllTypeVO.getCommentTypeId(CllConstants.CLL_TYPE_CODE_FORM_LETTER);

        //Retrieving Disposition Id
        CllDispositionTypeViewImpl dispTypeVO = getCommentLogAM().getCllDispositionTypeView1();
        Number dispTypeId = dispTypeVO.getDispositionTypeId(CllConstants.CLL_DISPOSITION_TYPE_APPR);
        
        DBTransaction trans = getCommentLogAM().getDBTransaction();

        CallableStatement statement = null;
        int rows = 0;

        StringBuffer plsql = new StringBuffer();
        plsql.append("BEGIN ")
             .append("UPDATE CLL.CLL_COMMENT_DETAILS ")
             .append("SET CLL_STATUS_TYPE_ID = ? ")
             .append("WHERE CLL_FORM_LETTER_ID = ? ")
             .append("AND CLL_STATUS_TYPE_ID = ? ")
             .append("AND CLL_TYPE_ID = ? ")
             .append("AND CLL_DISPOSITION_TYPE_ID = ?; ")
             .append("END; ");

        statement = trans.createCallableStatement(plsql.toString(), 0);
        try {
            statement.setInt(1, pubtatusTypeId.intValue());
            statement.setInt(2, formLetterId.intValue());
            statement.setInt(3, proStatusTypeId.intValue());
            statement.setInt(4, cllTypeId.intValue());
            statement.setInt(5, dispTypeId.intValue());
            rows = statement.executeUpdate();
            
        } catch (SQLException s) {
            throw new JboException(s);
        } finally {
            try {
                if (statement != null)
                    statement.close();
                return rows;
            } catch (SQLException s) { 
                logger.severe("Error closing SQL Update statement.", s);
            }
        }
        return rows;
    }
    
    /**
     * Updates the comment detail records back to the status Processed
     * 
     * @param formLetterId  Form Letter Id
     * @return
     */
    public int updateCommentDetProcessedStatus(Number formLetterId) {
        logger.info("Updating Status for Comment Details to Processed. Param :: formLetterId = " + formLetterId);
        //Retrieving Processed Status Type Id
        CllStatusTypeViewImpl statusTypeVO = getCommentLogAM().getCllStatusTypeView1();
        Number pubtatusTypeId = statusTypeVO.getStatusTypeId(CllConstants.CLL_STATUS_TYPE_CODE_PUB);
        
        //Retrieving Processed Status Type Id
        Number proStatusTypeId = statusTypeVO.getStatusTypeId(CllConstants.CLL_STATUS_TYPE_CODE_PRO);

        //Retrieving Cll Type Id
        CllTypeViewImpl cllTypeVO = getCommentLogAM().getCllTypeView1();
        Number cllTypeId = cllTypeVO.getCommentTypeId(CllConstants.CLL_TYPE_CODE_FORM_LETTER);
        
        DBTransaction trans = getCommentLogAM().getDBTransaction();

        CallableStatement statement = null;
        int rows = 0;

        StringBuffer plsql = new StringBuffer();
        plsql.append("BEGIN ")
             .append("UPDATE CLL.CLL_COMMENT_DETAILS ")
             .append("SET CLL_STATUS_TYPE_ID = ? ")
             .append("WHERE CLL_FORM_LETTER_ID = ? ")
             .append("AND CLL_STATUS_TYPE_ID = ? ")
             .append("AND CLL_TYPE_ID = ?; ")
             .append("END; ");

        statement = trans.createCallableStatement(plsql.toString(), 0);
        try {
            statement.setInt(1, proStatusTypeId.intValue());
            statement.setInt(2, formLetterId.intValue());
            statement.setInt(3, pubtatusTypeId.intValue());
            statement.setInt(4, cllTypeId.intValue());
            rows = statement.executeUpdate();
            
        } catch (SQLException s) {
            throw new JboException(s);
        } finally {
            try {
                if (statement != null)
                    statement.close();
                return rows;
            } catch (SQLException s) { 
                logger.severe("Error closing SQL Update statement.", s);
            }
        }
        return rows;
    }
    
   
    /** Retrieves  comment details  needed for  publishing 
     *
     * @param commIds
     * @param commentAttachments
     * @return
     */
    public Map<Number, Map<String, String>> getCommentDetails(ArrayList<Number> commIds, Map <Number, ArrayList<String>>  commentAttachments,
                                                              String fileTypeFileNumber){ 
        logger.info("Starting getCommentDetails   in MangeCommentLogDC   ********************* "); 
        String updatedFileNum=fileTypeFileNumber.replaceAll("-", "").trim(); 
        updatedFileNum=StringUtils.lowerCase(updatedFileNum);
        updatedFileNum=CllUtils.removeSpecialCharsFromFileFolderName(updatedFileNum);
        logger.info("updatedFileNum  after removing  special characters inside ManageCommentLogDC *************** is : " +updatedFileNum); 
        fileTypeFileNumber=CllUtils.removeSpecialCharsFromFileFolderName(fileTypeFileNumber);
        logger.info("fileTypeFileNumber  after removing  special characters inside ManageCommentLogDC  *************** is : " +fileTypeFileNumber); 
        
        Map<Number, Map<String, String>> commDetails =new HashMap<Number, Map<String, String>>(); 
        CommentDetailsPublishingROViewImpl commDetVO=(CommentDetailsPublishingROViewImpl)getCommentLogAM().getCommentDetailsPublishingROView1();
        String link="";
        Map<String,String> namesJobAffiliation;
        Date recDate=null; 
        String commTextStr = "";
        String attachmentLinks="";
        String htmlFileNameForComment="";
        for(Number commId: commIds  ){ 
                commDetVO.findByCommentDetId(commId);
                if(commDetVO.getEstimatedRowCount() ==0) {
                    logger.info(" Error   retrieving   details of comment   id"  +commId  +"*********************************");
                    return null;
                }
                Map<String, String> currentCommDet= new HashMap<String, String>();
                recDate=null; 
                CommentDetailsPublishingROViewRowImpl commDetVOImpl = (CommentDetailsPublishingROViewRowImpl)commDetVO.first();
                recDate=commDetVOImpl.getLetterDate(); 
                currentCommDet.put("receivedDate",convertRecDate(recDate));  
                // Changes for CASSECDEV-6077: Added condition based on CLL Type Code 'ME' which is CllTypeId 3, to add memoStaffNotes key/value.
                if(commDetVOImpl.getCllTypeId() != null && CllConstants.CLL_TYPE_CODE_MEMO.equals(commDetVOImpl.getCode())){
                    if(commDetVOImpl.getStaffNotes() != null){
                        currentCommDet.put("memoStaffNotes", commDetVOImpl.getStaffNotes());
                    } else {
                        currentCommDet.put("memoStaffNotes", CllConstants.COMMENTlETTER_EMPTY_STAFF_NOTES);
                    }
                }
                // Changes for CASSECDEV-6309: get boolean flag value is Webform Comment
                boolean webformCommentFlag = isWebFormComment(commId);
            
               // get  submitter  info
                namesJobAffiliation= new HashMap<String,String>();
                RowSet rowset = (RowSet)commDetVOImpl.getAttribute("CllSubmitterForPublishingCommentROView");
                if(rowset.getEstimatedRowCount()==0){
                  // logger.info(" Error   retrieving   Submitter for comment Id "  +commId  +"*********************************");
                  // return null;
                      currentCommDet.put("submitter",CllConstants.COMMENTlETTER_EMPTY_SUBMTTER_NAME); 
                      currentCommDet.put("name",CllConstants.COMMENTlETTER_EMPTY_SUBMTTER_NAME); 
                      currentCommDet.put("affiliation","");
                      currentCommDet.put("allSubmitters", CllConstants.COMMENTlETTER_EMPTY_SUBMTTER_NAME);
                }else{
                     // Changes for CASSECDEV-6073, CASSECDEV-6072: Changed method concatnateNamesTitleAffiliation() to getConcatenatedNames()
                     namesJobAffiliation = getConcatenatedNames(rowset);
                    
                    if(namesJobAffiliation.isEmpty()  || namesJobAffiliation.size()==0){
                        //logger.info(" Error   retrieving   Submitter for  Id "  +  submitter.getCllSubmitterId() +"*********************************");
                        //return null;
                        currentCommDet.put("submitter",CllConstants.COMMENTlETTER_EMPTY_SUBMTTER_NAME); 
                        currentCommDet.put("name",CllConstants.COMMENTlETTER_EMPTY_SUBMTTER_NAME); 
                        currentCommDet.put("affiliation","");
                        currentCommDet.put("allSubmitters", CllConstants.COMMENTlETTER_EMPTY_SUBMTTER_NAME);
                    }else{ 
                        
                         currentCommDet.put("submitter",namesJobAffiliation.get("submitter")); 
                         currentCommDet.put("name",namesJobAffiliation.get("name")); 
                         currentCommDet.put("affiliation",namesJobAffiliation.get("affiliation")); 
                        currentCommDet.put("allSubmitters", namesJobAffiliation.get("allSubmitters"));
                    }
                }
               
                //get  link  in  index page for each comment letter 
                ArrayList<String>  attachments = new ArrayList<String>();
                attachments = commentAttachments.get(commId);
                link=""; 
                String partOfLink="/comments/"+ fileTypeFileNumber + "/";
                /**
                 *  -If one attachment exists for any comment type, point link to the attachment.
                 *  -If more than one attachment for webform comment type, point link to first non html attachment.
                 *  -For all else cases, point link to generated comment htm file.
                 */
                if(null == attachments || attachments.size()>1 || attachments.size() ==0){
                    // Changes for CASSECDEV-6309: For Webform comments change HTML index file link
                    //logger.info("In getCommentDetails... webformCommentFlag:"+webformCommentFlag+"  attachments:"+attachments);
                    if(webformCommentFlag && attachments != null && attachments.size()>1){
                        for(String attachName: attachments){
                            if(!attachName.contains(CllConstants.FILE_TYPE_EXTENSION_HTML)){
                                link = partOfLink + PackageUtils.convertExtDocToPdf(attachName); 
                                // No Comment htm file to be generated for Webform comment type with more than one attachment.
                                htmlFileNameForComment = "";
                                break;
                            }
                        }
                    } else {
                        link=partOfLink+updatedFileNum+"-"+commId+".htm"; 
                        htmlFileNameForComment=updatedFileNum+"-"+commId+".htm";
                    }                 
                    //logger.info("In getCommentDetails... webformCommentFlag:"+webformCommentFlag+"  link:"+link+"  htmlFileNameForComment:"+htmlFileNameForComment);
                } else if (attachments.size()==1){    //if  one attachment,  link should point to this attachment
                    // Changes for CASSECDEV-6078, convert file extention (.docx or .doc) to .pdf
                    link=partOfLink + PackageUtils.convertExtDocToPdf(attachments.get(0));
                    htmlFileNameForComment="";
                } 
                currentCommDet.put("link",link);   
                currentCommDet.put("htmlFileNameForComment",htmlFileNameForComment); 
                if(null != commDetVOImpl.getSubject()){ 
                    String parsedSubject= StringEscapeUtils.escapeHtml(commDetVOImpl.getSubject().trim()); 
                    currentCommDet.put("subject",parsedSubject);
                }else{
                    currentCommDet.put("subject","");
                }
            
                //form link for all attachments for the current comment    
                
                 if(attachments != null && attachments.size()>1) {  
                     currentCommDet.put("attachmentLinks", generateAttachmentsLink( attachments, partOfLink,  fileTypeFileNumber));
                 }else{
                     currentCommDet.put("attachmentLinks", " ");
                 }
                                
                //get contents of CLOB field comments   for  each comment letter     
                ClobDomain commTextClob = (ClobDomain)commDetVOImpl.getComments();
                if (commTextClob != null && !commTextClob.toString().isEmpty()) {  
                      String parsedText= StringEscapeUtils.escapeHtml(commTextClob.toString().trim()); 
                      commTextStr = "<pre style=\"white-space: pre-wrap; white-space: -moz-pre-wrap; white-space: -pre-wrap; white-space: -o-pre-wrap; word-wrap: break-word;\">"+parsedText+"</pre>";  
                }else{ 
                       commTextStr="";
                }
                currentCommDet.put("comment",commTextStr);  
                commDetails.put(commId, currentCommDet); 
               
        }  
        logger.info("Ending getCommentDetails   in MangeCommentLogDC   ********************* ");
        return commDetails; 
        
    }
    
    /**Generates  attachment links to display in html page for comment
     *
     * @param attachments
     * @return
     */
    private String generateAttachmentsLink(ArrayList<String> attachments, String partOfLink, String fileTypeFileNumber){
           //    (<a href="$attachmentlink$">$attahmenttxt$</a> )  
            String  ATTACHMENT_HYPERLINK_TXT="Attached File #";
            String attachmentLink=""; 
            String attachmentTxt="";
            String hrefTxt="";
            String hrefTxtForAllLinks="";
            int i=0;
             for(String attachmentName:attachments){ 
                 // Changes for CASSECDEV-6078, convert file extention (.docx or .doc) to .pdf
                 attachmentName = PackageUtils.convertExtDocToPdf(attachmentName);
                 attachmentTxt= ATTACHMENT_HYPERLINK_TXT+ ++i +":"+attachmentName ;
                 attachmentLink=partOfLink+attachmentName;
                 hrefTxt="(<a href=" + "\""+attachmentLink+"\">"+attachmentTxt+ "</a>)";
                 hrefTxtForAllLinks=hrefTxtForAllLinks+hrefTxt;
            } 
        
            return hrefTxtForAllLinks;
    }
    
    /** Converts  Comment received date to required format
     *
     * @param recDate
     * @return
     */
    private String convertRecDate( Date recDate){
             if(recDate ==null ){ 
                return "";
             }
             java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MMM. dd, yyyy");
             String recDateStr="";
               
             Calendar cal = Calendar.getInstance();  
             cal.setTime(recDate.getValue());   
             recDateStr= sdf.format(cal.getTime());  
                     
             return recDateStr; 

    }
    
    public String retrieveFileSubject(Number fileNumId){
            String subject="";
            CllFileNumberViewImpl fileNumVO = getCommentLogAM().getCllFileNumberView1();
            fileNumVO.findByFiileNumbId(fileNumId);
            if(fileNumVO.getEstimatedRowCount() ==0) {
                logger.info(" Error   retrieving   subject for the file number   id"  +fileNumId  +"*********************************");
                return null;
            }else {
                CllFileNumberViewRowImpl fileNumVORowImpl = (CllFileNumberViewRowImpl)fileNumVO.first();
                subject=fileNumVORowImpl.getSubject();
                if(null == subject){
                    subject="";
                }
            }
          return subject;
       }
    
    // Changes for CASSECDEV-6073, CASSECDEV-6072
    /** Concatenates prefix, first name, middle name, last name, suffix, job title, affiliate of submitter
     *
     * @param rowSet
     * @return Map<String, String>
     */
    private Map<String, String> getConcatenatedNames(RowSet rowSet) {
        //logger.info("In getConcatenatedNames.... At start getRowCount:"+rowSet.getRowCount());
        CllSubmitterForPublishingCommentROViewRowImpl commentSubmitteRow=(CllSubmitterForPublishingCommentROViewRowImpl)rowSet.first();
        Map<String, String> names = new HashMap<String, String>();
        StringBuilder name = new StringBuilder();        
        name.append(getConcatenatedSubmitterStr(commentSubmitteRow, Boolean.FALSE));
        names.put("name", name.toString());
        
        if (commentSubmitteRow.getAffiliate() != null && !(commentSubmitteRow.getAffiliate()).isEmpty()) {
            name.append(", "+commentSubmitteRow.getAffiliate());
            names.put("affiliation", commentSubmitteRow.getAffiliate());
        } else {
            names.put("affiliation", "");
        }
        names.put("submitter", name.toString());
        //logger.info("In getConcatenatedNames.... before multi row check.. getRowCount:"+rowSet.getRowCount());
        if(rowSet.getRowCount() > 0){
            StringBuilder allSubmitters = new StringBuilder();
            allSubmitters.append(name.toString());
            while(rowSet.hasNext()){
                if(allSubmitters.length() > 1){
                    // CASSECDEV-6307 : Implementation CASSUP-1476 - Changes to separate submitter's with semicolon delimiter
                    allSubmitters.append(CllConstants.INDEXPAGE_SUBMITTER_DELIMITER);
                }
                allSubmitters.append(getConcatenatedSubmitterStr((CllSubmitterForPublishingCommentROViewRowImpl) rowSet.next(), Boolean.TRUE));
            }
            names.put("allSubmitters", allSubmitters.toString());
        } else {
            names.put("allSubmitters", name.toString());
        }
        //logger.info("In getConcatenatedNames...  name:"+names.get("name")+"  submitter:"+names.get("submitter")+"  allSubmitters:"+names.get("allSubmitters"));
        return names;
    }
    
    private String getConcatenatedSubmitterStr(CllSubmitterForPublishingCommentROViewRowImpl commentSubmitterRow, boolean needAffiliation) {
        StringBuilder submitter = new StringBuilder();
        if(commentSubmitterRow.getPrefix() != null && !(commentSubmitterRow.getPrefix()).isEmpty()){
            submitter.append(commentSubmitterRow.getPrefix()+" ");
        }
        
        if (commentSubmitterRow.getFirstName() != null && !(commentSubmitterRow.getFirstName()).isEmpty()) {
            submitter.append(commentSubmitterRow.getFirstName());
        }

        if (commentSubmitterRow.getMiddleName() != null && !(commentSubmitterRow.getMiddleName()).isEmpty()) {
            submitter.append(" "+commentSubmitterRow.getMiddleName());
        }

        if (commentSubmitterRow.getLastName() != null && !(commentSubmitterRow.getLastName()).isEmpty()) {
            submitter.append(" "+commentSubmitterRow.getLastName());
        }
        
        if(commentSubmitterRow.getSuffix() != null && !(commentSubmitterRow.getSuffix()).isEmpty()){
            submitter.append(" "+commentSubmitterRow.getSuffix());
        }

        if (submitter != null && submitter.length() == 0) {
            submitter.append(CllConstants.COMMENTlETTER_EMPTY_SUBMTTER_NAME);
        }
        
        if (commentSubmitterRow.getJobTitle() != null && !(commentSubmitterRow.getJobTitle()).isEmpty()) {
            submitter.append(", "+commentSubmitterRow.getJobTitle());
        }
        
        if (needAffiliation && commentSubmitterRow.getAffiliate() != null && !(commentSubmitterRow.getAffiliate()).isEmpty()) {
            submitter.append(", "+commentSubmitterRow.getAffiliate());
        }
        logger.info("In getConcatenatedSubmitters... submitter:"+submitter.toString());
        return StringUtils.trim(submitter.toString());
    }
    
    
    // Changes for CASSECDEV-6309
    /** Check and returns flag value for comment is a Webform comment or not
     *
     * @param commDetailId
     * @return boolean
     */    
    public boolean isWebFormComment(Number commDetailId){
        boolean retValue = Boolean.FALSE;
        try {
            CllOrigInCommentROViewImpl origInCommVo = getCommentLogAM().getCllOrigInCommentROView1();
            origInCommVo.findByCommentDetailId(commDetailId);
            if(origInCommVo.getEstimatedRowCount() > 0){
                CllOrigInCommentROViewRowImpl origInCommRow = (CllOrigInCommentROViewRowImpl) origInCommVo.first();
                CllApplicationPropertiesViewImpl appPropVo = getCommentLogAM().getCllApplicationPropertiesView1();
                String webFormEmailConstant = appPropVo.getWebFormEmailConstant();
                if(webFormEmailConstant != null){
                    retValue = origInCommRow.getEmailfrom().contains(webFormEmailConstant);
                }
            }            
        } catch (Exception e) {
            logger.severe("Exception occurred in isWebFormComment()..",e);
        }
        logger.info("In isWebFormComment... commDetailId:"+commDetailId+"   retValue:"+retValue);
        return retValue;
    }
    
    
    /** Handle the event triggered by File Number Publisher Inbox Task flow to access the payload passed
     *
     * @param payload
     */
    public void handlerViewFileNumPubEvent(Object payload) {
        logger.info("Starting handlerViewFileNumPubEvent inside ManageCommntLogDC...");
        
        ActionEvent actionEvent = (ActionEvent)payload;
        UIComponent component = (UIComponent)actionEvent.getSource();
        
        Number fileNumId = (Number)component.getAttributes().get("fileNumId"); 
        String fileTypeFileNumber=(String)component.getAttributes().get("fileTypeFileNumber");
    //        String typeCode = (String)component.getAttributes().get("typeCode");
        String dispCode = (String)component.getAttributes().get("dispCode");
        //String origination=(String)component.getAttributes().get("origination");
        logger.info("In handlerViewFileNumPubEvent... File Num Id passed from Comment Inbox task flow to Main TF  = " + fileNumId);
        logger.info("In handlerViewFileNumPubEvent.. File Type+File Number passed from Comment Inbox task flow to Main TF  = "  + fileTypeFileNumber);
        //logger.info("Orgination passed from Comment Inbox task flow to Main TF  = "  + origination);
        Map<String, Object> pageFlowScope = AdfFacesContext.getCurrentInstance().getPageFlowScope();
        ManageCommentLog manageCommentLog = (ManageCommentLog)pageFlowScope.get("manageCommentLog");
        manageCommentLog.setFileNumId(fileNumId);
        manageCommentLog.setFileTypeFileNumber(fileTypeFileNumber);
    //        manageCommentLog.setTypeCode(typeCode);
        manageCommentLog.setDispCode(dispCode);
        ADFUtils.markScopeDirty(pageFlowScope);
        ViewStateManageCommentLog viewStateManageCommentLog = 
                  (ViewStateManageCommentLog)AdfFacesContext.getCurrentInstance().getViewScope().get("viewStateManageCommentLog");
        //viewStateManageCommentLog.setFileNumId(fileNumId); 
        viewStateManageCommentLog.fileNumberPubQDetailsBTF(); 
        
        logger.info("Ending handlerViewFileNumPubEvent inside ManageCommntLogDC...");
    }
    
    /** Return the CLL Type Id by Type code
     *
     * @param typeCode
     * @return Integer
     */    
    public Number getCllTypeId(String typeCode){
        Number cllTypeId = new Number(0);
        try {
            CllTypeViewImpl cllTypeVO = getCommentLogAM().getCllTypeView1();
            cllTypeId = cllTypeVO.getCommentTypeId(typeCode);
        } catch (Exception e) {
            logger.severe("Exception occurred in getCllTypeId()..",e);
        }
        return cllTypeId;
    }
    
    public CllFileNumPubCommListROViewRowImpl getCommentDetailsForFormLetter(Number fileNumber, Number typeId, Number formLtrId){
        CllFileNumPubCommListROViewRowImpl commentsListRow = null;
        try {
            //System.out.println("In getCommentDetailsForFormLetter... fileNumber:"+fileNumber+"  typeId:"+typeId+"   formLtrId:"+formLtrId);
            CllFileNumPubCommListROViewImpl commentsListView = getCommentLogAM().getCllFileNumPubCommListROView1();
            commentsListView.setApplyViewCriteriaName("findByFormLetterCriteria");
            commentsListView.setNamedWhereClauseParam("bindFileNum", fileNumber);
            commentsListView.setNamedWhereClauseParam("bindType", typeId);
            commentsListView.setNamedWhereClauseParam("bindFormLtrId", formLtrId);
            commentsListView.executeQuery();
            //System.out.println("In getCommentDetailsForFormLetter.... commentsListView.getRowCount:"+commentsListView.getRowCount());
            if(commentsListView.hasNext()){
                commentsListRow = (CllFileNumPubCommListROViewRowImpl)commentsListView.first();
                //System.out.println("In getCommentDetailsForFormLetter.... "+commentsListRow.getCllCommDetId());
            }
        } catch (Exception e) {
            logger.severe("Exception occurred in getCommentDetailsForFormLetter()..",e);
        }
        return commentsListRow;
    }
    
    
    /** Handle the event triggered by Comment Inbox queue links  to access the payload passed
        *CAS-1143_CLL-Comment-Inbox-NavigationTo-MissingFile#Queue
        * CAS-1305_CLL-Comment-Inbox-NavigationTo-InternalToSEC_Queue
        * @param payload
        */
       public void handlerCommentInboxQueuesEvent(Object payload) {
           logger.info("Starting handlerCommentInboxQueuesEvent inside ManageCommntLogDC...");
           
           ActionEvent actionEvent = (ActionEvent)payload;
           UIComponent component = (UIComponent)actionEvent.getSource(); 
           String targetQueue = (String)component.getAttributes().get("targetQueueName");  
          //ADFUtils.markScopeDirty(pageFlowScope);
           ViewStateManageCommentLog viewStateManageCommentLog = 
            (ViewStateManageCommentLog)AdfFacesContext.getCurrentInstance().
                                                 getViewScope().get("viewStateManageCommentLog");
            if(targetQueue.equals(CllConstants.ORIGINATION_MISSING_FILENUM_Q)) { 
                   viewStateManageCommentLog.MissingFileNumberQueueClickAction(); 
             } else if ( targetQueue.equals(CllConstants.ORIGINATION_INTERNAL_TOSEC_Q)) {
                         viewStateManageCommentLog.InternalToSecCommentsClickAction(); 
             }
           
           logger.info("Ending handlerCommentInboxQueuesEvent inside ManageCommntLogDC...");
       }
           
           
}
